/* П1 — вариант 2 «Рабочее место сметы во всю ширину» (Дизайнер §75, направление 2).
   Панель стройки — только список; смета уводит на свою страницу (1192 px, «‹ Корпус 2»): слева редакции и
   оглавление разделов, справа таблица. Сопоставление — режим таблицы с выбором строк и липкой полосой,
   материалы — боковая панель, импорт — черновая редакция со страницей отчёта. */
(function () {
  var X = window.P0, P = window.P1, I = P.I;

  function site(detail, h) {
    return X.shell({ sections: P.rail('site'), w: 1280, h: h || 560, ws: 'Пространство: ЭОМ',
      content: X.card({ title: 'ЖК «Северный», корпус 2', blocks: P.siteNav(), detail: detail }) });
  }
  // Страница сметы во всю ширину: рейл без подпанели.
  function workplace(o) {
    var revs = '<div class="nsec">Редакции</div>' + [
      { t: 'Импорт ЛСР_02-01-03', s: 'ждёт решения · вчера', b: 'ждёт', tone: 'warn', on: o.sel === 'imp' },
      { t: 'Ред. 3', s: '20.10 · 300 строк', b: o.cost === null ? null : '17', tone: 'warn', on: o.sel === 3 },
      { t: 'Ред. 2', s: '03.09 · КП-2026-014, график', b: 'действующая', tone: 'brand' },
      { t: 'Ред. 1', s: '12.08 · КП-2026-009' }]
      .map(function (r) { return '<div class="ni' + (r.on ? ' on' : '') + '" style="height:auto;padding:8px 12px;align-items:flex-start;border-radius:12px"><span class="t" style="white-space:normal"><span style="display:block">' + r.t + '</span><span class="sub">' + r.s + '</span></span>' + (r.b ? '<span class="bdg ' + (r.tone || '') + '">' + r.b + '</span>' : '') + '</div>'; }).join('');
    var toc = o.toc === false ? '' : '<div class="nsec">Разделы ЛСР · ред. 3</div>' + P.SECTIONS.slice(0, 13).map(function (s) {
      var u = P.UNM[+s[0]] || 0, n = +s[0];
      return '<div class="spi' + (n === 9 ? ' on' : '') + '" style="height:28px;font-size:12.5px;border-radius:14px"><span class="t">' + s[0] + '. ' + s[1] + '</span><span class="nt" style="' + (u ? 'color:var(--f-warning-text);font-weight:600' : '') + '">' + (s[2] - u) + '/' + s[2] + '</span></div>';
    }).join('') + '<div class="sub" style="padding:4px 12px">…ещё 17 разделов</div>';
    var left = '<div style="width:272px;flex:none;border-right:1px solid var(--f-stroke2);background:var(--f-bg1);padding:8px;box-sizing:border-box;overflow:hidden;display:flex;flex-direction:column;gap:2px">' + revs + toc + '</div>';
    var head = '<div class="ldh" style="padding-bottom:0"><div class="crumb"><a>Стройки</a> › <a>ЖК «Северный», корпус 2</a> › <a>Сметы</a></div><div class="pgh" style="margin:2px 0 12px;align-items:center"><div><h1 style="font-size:20px">' + I('sheet', 20) + 'ЭОМ корпус 2 ' + P.mark('q', 'основная') + '</h1></div><div class="acts">' + (o.headActs || '') + '</div></div></div>';
    var body = '<div class="ld">' + head + '<div class="ldb">' + left + '<div class="ldd" style="position:relative">' + o.main + '</div>' + (o.sheet || '') + '</div></div>';
    return X.shell({ sections: P.rail('site'), w: o.w || 1280, h: o.h || 860, ws: 'Пространство: ЭОМ', content: body });
  }

  /* (а) панель стройки — список; щелчок уводит */
  var list = '<div class="pg"><div class="pgh"><div><h1>Сметы</h1><p>Смета открывается рабочим местом во всю ширину</p></div><div class="acts">' + P.btn('Загрузить смету', 'filled', 'upload') + '</div></div>' +
    X.grid({ cols: ['Смета', 'Действующая', 'Ждут решения', 'Себестоимость', ''], flex: [2.2, 1.2, 2, 1.2, .3], rows: [
      ['<b style="font-weight:500">ЭОМ корпус 2</b> <span class="muted">· основная</span>', 'ред. 2 из 3', P.mark('unm', 'импорт ЛСР_02-01-03') + ' ' + P.mark('unm', 'ред. 3: 17 строк'), '<span class="num">18 420 300 ₽</span>', I('arrow', 16)],
      ['<b style="font-weight:500">Слаботочные системы</b> <span class="muted">· основная</span>', 'ред. 1', '<span class="muted">—</span>', '<span class="num">4 115 800 ₽</span>', I('arrow', 16)],
      ['<b style="font-weight:500">Доп. работы по фасаду</b> <span class="muted">· дополнительная</span>', '<span class="muted">редакций нет</span>', '—', '—', I('arrow', 16)]] }) + '</div>';

  /* (б) просмотр */
  function viewMain(cost) {
    return '<div class="pg" style="gap:10px">' +
      X.band('<span><b>Ред. 3</b> · 20.10.2026 · Смирнова А. В. · ЛСР_02-01-01_ЭОМ_ред3.gsfx · <b>не действующая</b> — план по ред. 2 · ' + P.pnote('материалов без номенклатуры: 9') + '</span>' + (cost ? P.btn('Сделать действующей', 'tonal sm') : '')) +
      (cost ? '' : X.band(I('lock', 16) + '<span>' + P.HIDDEN + '</span>')) +
      '<div class="tb">' + (cost ? '<span class="tbs" style="background:var(--f-bg3);border-radius:18px;padding:3px;gap:0"><span class="on" style="border:0;padding:5px 14px;border-radius:15px;background:var(--f-bg1);color:var(--f-fg1)">Просмотр</span><span style="border:0;padding:5px 14px">Сопоставление</span></span>' : '') +
      '<span class="sbox">' + I('search', 16) + 'Шифр или наименование</span>' + P.chip('Не сопоставлены', { tone: 'warn', count: 17 }) + P.chip('Ед. изменилась', { tone: 'warn', count: 1 }) + P.chip('Запомнено', { count: 204 }) + '</div>' +
      P.lsrTable({ open: 9, cost: cost, sections: P.SECTIONS.slice(7, 11), flex: cost ? [.4, 1.2, 3.6, .55, .55, 2.1, 1.1, .95] : [.4, 1.2, 4, .55, .55, 2.3, 1.1],
        more: '…ещё 26 разделов' + (cost ? ' · итог ред. 3: <b>18 906 450,12 ₽</b>' : '') }) + '</div>';
  }

  /* (в) импорт — черновая редакция со страницей отчёта */
  var impMain = '<div class="pg" style="gap:10px"><div class="pgh"><div><h1 style="font-size:20px">Импорт ЛСР_02-01-03_ЭОМ.gsfx</h1><p>разобран 25.10.2026 · Смирнова А. В. · ГРАНД-Смета 2026.1 · цель: новая редакция этой сметы (станет ред. 4)</p></div></div>' +
    P.OTHERCALC +
    '<div class="cols2"><div class="card"><h4>Разобрано 280 из 300 позиций</h4><div class="meter"><i style="width:93.3%;background:var(--f-brand)"></i></div><div class="sub" style="margin-top:6px">ЛСР 02-01-03 · 30 разделов · неактивных позиций 4 · итог по разобранному 17 960 210,00 ₽</div></div>' +
    '<div class="card"><h4 style="color:var(--f-warning-text)">20 не разобраны — в редакцию не войдут</h4><div class="sub">чаще всего: нет единицы измерения (14), позиция без расценки и ресурсов (6)</div></div></div>' +
    '<div class="cols2" style="align-items:start"><div>' + P.mini(['Раздел', 'Строк', 'Итог, ₽'], [3, .6, 1.1], [['1. Кабельные конструкции. Подвал', '12', '<span class="num">412 806,00</span>'], ['2. Кабельные конструкции. Этажи 1–9', '14', '<span class="num">1 102 340,00</span>'], ['3. Вводно-распределительное устройство', '9', '<span class="num">2 806 115,00</span>'], ['<span class="muted">…ещё 27</span>', '', '']], 'compact') + '</div>' +
    '<div>' + P.UNPARSED + '</div></div></div>';
  var impHead = P.btn('Отказаться', 'text') + P.btn('Создать редакцию без 20 строк…', 'filled');

  /* (г) режим сопоставления */
  var cb = function (on) { return '<span style="display:inline-grid;place-items:center;width:16px;height:16px;border-radius:3px;' + (on ? 'background:var(--f-brand);color:#fff' : 'border:2px solid var(--f-fg3);box-sizing:border-box') + '">' + (on ? I('check', 12) : '') + '</span>'; };
  var rowsM = P.ROWS9.slice(0, 7).map(function (r) {
    var sel = r.mk === 'unm';
    return '<div class="etr' + (r.mk === 'unm' || r.mk === 'chg' ? ' attn' : '') + '">' +
      [cb(sel), '<span class="mono">' + r.n + '</span>', '<span class="nm">' + r.name + '</span>', '<span class="num">' + r.sv + '</span>', r.su,
       r.wt ? '<span class="inp" style="height:32px;font-size:13px;justify-content:space-between"><span>' + r.wt + '</span>' + I('chevd', 14) + '</span><span class="sub">' + r.v + ' ' + r.u + ' · ' + r.f + ' · ' + (r.mk === 'rem' ? 'запомнено' : '') + '</span>'
         : '<span class="inp" style="height:32px;font-size:13px;justify-content:space-between;border-color:var(--f-warning-stroke)"><span class="ph">выбрать вид работы</span>' + I('chevd', 14) + '</span>' + (r.why ? '<span class="sub warn">' + r.why + '</span>' : '')]
        .map(function (c, i) { return '<span style="flex:' + [.25, .4, 3, .55, .55, 2.6][i] + ';' + (i === 5 ? 'display:flex;flex-direction:column;gap:2px' : '') + '">' + c + '</span>'; }).join('') + '</div>';
  }).join('');
  var matchMain = '<div class="pg" style="gap:10px;padding-bottom:84px">' +
    '<div class="tb"><span class="tbs" style="background:var(--f-bg3);border-radius:18px;padding:3px;gap:0"><span style="border:0;padding:5px 14px">Просмотр</span><span class="on" style="border:0;padding:5px 14px;border-radius:15px;background:var(--f-bg1);color:var(--f-fg1)">Сопоставление</span></span>' +
    P.chip('Не сопоставлены', { on: true, tone: 'warn', count: 17 }) + '<span class="sub">выбор в клетке сохраняется сразу; несколько строк — флажками</span></div>' +
    '<div class="et"><div class="etr eth"><span style="flex:.25"></span><span style="flex:.4">№</span><span style="flex:3">Наименование</span><span style="flex:.55">Объём</span><span style="flex:.55">Ед.</span><span style="flex:2.6">Вид работы в плане</span></div>' +
    '<div class="etg open"><span class="cv">' + cb(false) + '</span><span class="gn">Раздел 9. Групповые сети. 2–9 этажи</span><span class="gc">16 строк</span><span class="mk warn">ждут 5</span></div>' + rowsM +
    '<div class="etg"><span class="cv">' + cb(false) + '</span><span class="gn">Раздел 11. Электроосвещение. МОП</span><span class="gc">13 строк</span><span class="mk warn">ждут 1</span></div></div>' +
    '<div style="position:absolute;left:24px;right:24px;bottom:16px;background:var(--f-bg1);border:1px solid var(--f-stroke2);border-radius:14px;box-shadow:var(--f-shadow16,0 6px 18px rgba(0,0,0,.16));padding:10px 14px;display:flex;align-items:center;gap:12px">' +
    '<b style="font-weight:500;white-space:nowrap">Выбрано 3 строки в разделе 9</b><span class="inp" style="flex:1;height:36px;justify-content:space-between"><span>Монтаж электроустановочных изделий</span>' + I('chevd', 14) + '</span>' +
    '<span class="inp" style="height:36px">100 шт ' + I('arrow', 14) + ' шт <b style="font-weight:500">× 100</b></span><label class="sub" style="white-space:nowrap">☑ запомнить</label>' + P.btn('Назначить', 'filled') + '<span class="ib">' + I('close', 16) + '</span></div></div>';

  /* (д) материалы — боковая панель строки */
  var sheet = '<aside class="sheet"><div class="mdh"><div><h3 style="font-size:16px;font-weight:500">Материалы строки 9.1</h3><p>Кабель до 35 кВ в проложенных трубах… · 2 материала</p></div><span class="ib">' + I('close', 18) + '</span></div>' +
    '<div class="mdb" style="gap:10px"><div class="card" style="padding:10px 12px"><div style="display:flex;gap:8px;align-items:center"><b style="font-weight:500;flex:1">Кабель ВВГнг(А)-LS 3х2,5</b>' + P.mark('rem') + '</div><div class="sub">ФССЦ-21.1.06.09-0156 · 1 265 м → Кабель ВВГнг(А)-LS 3х2,5 ок</div></div>' +
    '<div class="card" style="padding:10px 12px;border-color:var(--f-warning-stroke)"><div style="display:flex;gap:8px;align-items:center"><b style="font-weight:500;flex:1">Провод ПуГВ 1х2,5</b>' + P.mark('unm', 'без номенклатуры') + '</div><div class="sub">ФССЦ-21.2.01.02-0071 · 4 820 м</div>' +
    '<span class="sbox" style="width:100%;margin:8px 0">' + I('search', 16) + 'ПуГВ 1х2,5</span>' + P.candidates() + '<div class="tb" style="margin-top:8px">' + P.btn('Новая позиция…', 'text sm', 'plus') + '<span class="sp1"></span><label class="sub">☑ запомнить</label>' + P.btn('Выбрать', 'tonal sm') + '</div></div></div></aside>';

  /* (е) сделать действующей */
  var cur = P.scrim(1100, 640, P.modal({ title: 'Сделать ред. 3 действующей?', sub: 'План стройки будет считаться по ред. 3 вместо ред. 2. ' + P.pnote('Расхождения по видам работ') + ':',
    body: P.DIFF + '<div class="sub">Ред. 2 останется в списке слева — зафиксирована КП-2026-014 и графиком «Основной».</div>', foot: P.btn('Отмена', 'text') + P.btn('Сделать действующей', 'filled') }));

  /* (ж) глобальный раздел — плоский список, стройка колонкой */
  var global = X.shell({ sections: P.rail('plan'), panel: P.PANEL, w: 1280, h: 520, ws: 'Пространство: ЭОМ', content: X.page({ title: 'Сметы', sub: 'Все стройки пространства', action: 'Загрузить смету',
    body: '<div class="tb"><span class="sbox">' + I('search', 16) + 'Смета</span>' + P.chip('Стройки: все', {}) + P.chip('Ждут решения', { tone: 'warn', count: 2 }) + '</div>' +
      X.grid({ cols: ['Смета', 'Стройка', 'Действующая', 'Ждут', 'Изменена'], flex: [1.8, 2, 1, 1.4, .9], rows: [
        ['ЭОМ корпус 2', 'ЖК «Северный», корпус 2', 'ред. 2 из 3', P.mark('unm', 'импорт') + ' ' + P.mark('unm', '17 строк'), '25.10.2026'],
        ['Слаботочные системы', 'ЖК «Северный», корпус 2', 'ред. 1', '<span class="muted">—</span>', '21.10.2026'],
        ['ЭОМ, этап 1', 'Склад «Восток»', 'ред. 5', '<span class="muted">—</span>', '07.10.2026'],
        ['Реконструкция ТП-14', 'ПС «Заречная»', 'ред. 2', P.mark('unm', '3 строки'), '29.09.2026']] }) }) });

  var phone = P.phoneList('<div class="phc"><b>ЭОМ корпус 2</b><span>действующая ред. 2 · 296 строк</span><span class="sub">ждут: импорт, 17 строк ред. 3</span></div>' +
    '<div class="phc"><b>Слаботочные системы</b><span>ред. 1 · 96 строк</span></div><p class="sub" style="padding:0 4px">Рабочее место сметы на телефоне — только просмотр строк по разделам; режима сопоставления и импорта нет.</p>');

  window.V2 = function () {
    return P.turn('2', 'Вариант 2 · «Рабочее место сметы во всю ширину»',
      'Панель «Сметы» стройки — только список; смета <b>уводит на свою страницу во всю ширину</b> (1192 px, «Стройки › Корпус 2 › Сметы», без навигации стройки). Слева — <b>редакции списком</b> и оглавление разделов ЛСР с ходом «11/16»; ' +
      'справа — таблица. <b>Сопоставление — режим таблицы</b>: выбор вида работы в клетке (сохраняется сразу), флажки строк и раздела, липкая полоса «Выбрано 3 строки…». <b>Материалы — боковая панель</b> строки. ' +
      '<b>Импорт — черновая редакция</b> в списке слева со страницей отчёта: «Создать редакцию» / «Отказаться» в шапке.',
      P.proscons(['ширина: наименование в одну-две строки, таблица, оглавление и редакции видны сразу', 'отчёт импорта — место со своим адресом, а не окно: не теряется, отдаётся ссылкой; прямо ложится на запись импорта (<code>state</code>, <code>version</code>)', 'массовое сопоставление сразу по нескольким разделам'],
        ['новый механизм — пункт модуля «уводит» (вариант 3 П0, П0 его не завёл): вопрос Архитектору', 'режим «Просмотр / Сопоставление» — человек забывает, в каком он', 'боковая панель материалов на 1280 снова сжимает таблицу'],
        ['МП ходит между сметой, «Ходом работ» и графиком одной стройки через «‹ Корпус 2»', '«выбрано 12» в разделах, которых не видно при прокрутке 300 строк']),
      [P.opt('2а', '(а) Панель «Сметы» карточки стройки — список, щелчок уводит', site(list), 'Здесь же видно, что ждёт: импорт и несопоставленные строки — у сметы, а не над списком.'),
       P.opt('2б', '(б) Рабочее место глазами «Сметчика» — ред. 3, просмотр', workplace({ sel: 3, cost: true, main: viewMain(true), headActs: P.btn('Загрузить редакцию', 'outlined', 'upload') + '<span class="ib">' + I('dots', 18) + '</span>' }), 'Оглавление «11/16» — ход сопоставления по разделу; щелчок прокручивает таблицу. Счётчики разделов — ' + P.pnote('считает клиент из строк') + ' (страница строк — 200, читать всё).'),
       P.opt('2б′', '(б) Та же смета у читающего — только <code>plan.estimate.read</code>', workplace({ sel: 3, cost: false, main: viewMain(false), h: 760 }), 'Колонки стоимости нет, над таблицей — причина и имя права. Без <code>plan.estimate.edit</code> нет переключателя «Сопоставление», «Загрузить редакцию» и «Сделать действующей»; черновика импорта в списке нет.'),
       P.opt('2в', '(в) Импорт — черновая редакция, страница отчёта', workplace({ sel: 'imp', cost: true, main: impMain, toc: false, headActs: impHead, h: 720 }), 'Кнопка называет, чего не будет в редакции: «без 20 строк…» и затем подтверждение — это <code>acceptPartial</code>. Отчёт открыт только с <code>plan.estimate.edit</code> — у читающего черновика в списке нет.'),
       P.opt('2г', '(г) Режим сопоставления: флажки и липкая полоса', workplace({ sel: 3, cost: true, main: matchMain }), 'Строка другой единицы (9.3) флажком не выбирается в общую полосу — у неё свой выбор в клетке. «Новый вид работы» — последним пунктом выпадающего выбора, только с <code>core.worktypes.edit</code>.'),
       P.opt('2д', '(д) Материалы строки — боковая панель', workplace({ sel: 3, cost: true, main: viewMain(true), sheet: sheet }), 'Панель не закрывает таблицу целиком; «Новая позиция…» — шаг панели. Очереди «все материалы без номенклатуры» здесь нет — ход по строкам.'),
       P.opt('2е', '(е) «Сделать действующей» — расхождения', cur, 'То же окно, что в варианте 1; <b>нет носителя</b> «было → станет».', 1100),
       P.opt('2ж', '(ж) Глобальный раздел «Сметы» — стройка колонкой, отбор по стройке', global, P.pnote('Глобального списка') + ' сервер сегодня не отдаёт.'),
       P.opt('2з', '(з) Телефон', phone, null, 390)]);
  };
})();
