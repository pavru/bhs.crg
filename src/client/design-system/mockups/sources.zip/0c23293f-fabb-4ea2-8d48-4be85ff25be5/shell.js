/* Каркас макетов П0: оболочка (рейл 88 + подпанель 240 + шапка 48), карточка стройки (ListDetailShell,
   навигация 320), телефон 390. Размеры и классы — по коду клиента: SectionRail.tsx, ListDetailShell.tsx,
   AppShell.tsx. Без React: варианты описаны данными в variants.js, здесь только отрисовка. */
(function () {
  var P = {
    building: '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4M10 10h4M10 14h4M10 18h4"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
    calc: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01M8 10h.01M12 10h.01M16 10h.01"/>',
    wallet: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
    wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9l-3.8 3.8z"/>',
    plan: '<path d="M3 3v18h18"/><path d="M7 7h8M7 11h11M7 15h5"/>',
    ruler: '<path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.4 2.4 0 0 1 0-3.4l2.6-2.6a2.4 2.4 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2M11.5 9.5l2-2M8.5 6.5l2-2M17.5 15.5l2-2"/>',
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1Z"/>',
    layers: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
    table: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M12 3v18"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    sheet: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5M8 13h2M14 13h2M8 17h2M14 17h2"/>',
    gantt: '<path d="M8 6h10M6 12h9M11 18h7"/>',
    progress: '<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
    help: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
    chev: '<path d="m9 18 6-6-6-6"/>',
    chevd: '<path d="m6 9 6 6 6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    panel: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18m7-6-3-3 3-3"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    dots: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
    offer: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M9 15h6M9 11h2"/>',
    tag: '<path d="M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4Z"/><circle cx="7.5" cy="7.5" r=".5"/>',
    cal: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'
  };
  function I(name, size) {
    return '<svg width="' + (size || 18) + '" height="' + (size || 18) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (P[name] || '') + '</svg>';
  }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  /* ── рейл ── */
  function rail(o) {
    var html = '<div class="rail"><div class="logo"><span class="lg">' + I('layers', 24) + '</span><span>BHS.CRG</span></div>';
    (o.sections || []).forEach(function (s) {
      if (s === '|') { html += '<div class="rsep"></div>'; return; }
      html += '<div class="ri' + (s.on ? ' on' : '') + (s.dim ? ' dim' : '') + '"><span class="pill">' + I(s.icon, 20) + '</span><span class="rl">' + esc(s.label) + '</span>' +
        (s.mark ? '<span class="rmark">' + esc(s.mark) + '</span>' : '') + '</div>';
    });
    return html + '</div>';
  }
  /* ── подпанель ── */
  function panel(o) {
    var html = '<nav class="sp"><div class="sph"><div><h2>' + esc(o.title) + '</h2><p>' + esc(o.hint || '') + '</p></div><span class="ib">' + I('panel', 18) + '</span></div>';
    (o.groups || []).forEach(function (g) {
      if (g.label) html += '<div class="spg">' + esc(g.label) + '</div>';
      g.items.forEach(function (it) {
        html += '<div class="spi' + (it.on ? ' on' : '') + (it.dim ? ' dim' : '') + '"><span class="t">' + esc(it.label) + '</span>' +
          (it.note ? '<span class="nt">' + esc(it.note) + '</span>' : '') + '</div>';
      });
    });
    if (o.footer) html += '<p class="spf">' + o.footer + '</p>';
    return html + '</nav>';
  }
  /* ── шапка ── */
  function header(o) {
    return '<header class="hd">' + (o.ws ? '<span class="ws">' + I('grid', 14) + esc(o.ws) + I('chevd', 14) + '</span>' : '') +
      '<span class="srch">' + I('search', 18) + '<span>Найти счёт, стройку или действие</span><kbd>Ctrl K</kbd></span>' +
      '<span class="sp1"></span><span class="ib">' + I('bell', 20) + '</span><span class="ib">' + I('help', 20) + '</span><span class="av">' + esc(o.av || 'АС') + '</span></header>';
  }
  /* ── экран: рейл + (подпанель) + шапка + содержимое ── */
  function shell(o) {
    return '<div class="app" style="width:' + (o.w || 1280) + 'px;height:' + (o.h || 720) + 'px">' + rail(o) +
      (o.panel ? panel(o.panel) : '') +
      '<main class="mn">' + header(o) + (o.bar || '') + '<div class="ct">' + (o.content || '') + '</div></main></div>';
  }

  /* ── карточка стройки (ListDetailShell) ── */
  function navItem(it) {
    if (it.add) return '<div class="ni add">' + I('plus', 16) + '<span class="t">' + esc(it.label) + '</span></div>';
    return '<div class="ni' + (it.on ? ' on' : '') + (it.dim ? ' dim' : '') + '"><span class="ic">' + I(it.icon || 'layers', 17) + '</span><span class="t">' + esc(it.label) + '</span>' +
      (it.badge ? '<span class="bdg ' + (it.badgeTone || '') + '">' + esc(it.badge) + '</span>' : '') +
      (it.count != null ? '<span class="cnt">' + esc(it.count) + '</span>' : '') +
      (it.chev ? '<span class="cv">' + I('chev', 14) + '</span>' : '') + '</div>';
  }
  function card(o) {
    var nav = '<div class="ldn">';
    (o.blocks || []).forEach(function (b) {
      if (b.label) nav += '<div class="nsec">' + esc(b.label) + (b.sub ? '<span class="nsub">' + esc(b.sub) + '</span>' : '') + '</div>';
      if (b.note) nav += '<p class="nnote">' + b.note + '</p>';
      (b.items || []).forEach(function (it) { nav += navItem(it); });
    });
    nav += '</div>';
    var head = '<div class="ldh"><div class="crumb">Стройки</div><div class="ttl">' + I('building', 20) + '<span>' + esc(o.title || 'ЖК «Северный», корпус 2') + '</span>' +
      (o.badge || '') + '</div>' + (o.tabs || '') + '</div>';
    return '<div class="ld">' + head + (o.plaque || '') + '<div class="ldb">' + (o.noNav ? '' : nav) + '<div class="ldd">' + (o.detail || '') + '</div></div></div>';
  }
  function plaque(text, back) {
    return '<div class="plq">' + I('grid', 14) + '<span>' + text + '</span><a>' + esc(back || 'Вернуться в пространство') + '</a></div>';
  }

  /* ── содержимое-заглушки (сдержанные: макет о навигации, не о самих экранах) ── */
  function grid(o) {
    var cols = o.cols, rows = o.rows || [];
    var h = '<div class="dg"><div class="dgr dgh">' + cols.map(function (c, i) { return '<span style="flex:' + (o.flex ? o.flex[i] : 1) + '">' + esc(c) + '</span>'; }).join('') + '</div>';
    rows.forEach(function (r) {
      h += '<div class="dgr">' + r.map(function (c, i) { return '<span style="flex:' + (o.flex ? o.flex[i] : 1) + '">' + c + '</span>'; }).join('') + '</div>';
    });
    return h + '</div>';
  }
  function page(o) {
    return '<div class="pg"><div class="pgh"><div><h1>' + esc(o.title) + '</h1>' + (o.sub ? '<p>' + esc(o.sub) + '</p>' : '') + '</div>' +
      (o.action ? '<span class="btnf">' + esc(o.action) + '</span>' : '') + '</div>' + (o.tabs || '') + (o.body || '') + '</div>';
  }
  function tabs(list, on) {
    return '<div class="tbs">' + list.map(function (t, i) { return '<span class="' + (i === on ? 'on' : '') + '">' + esc(t) + '</span>'; }).join('') + '</div>';
  }
  function status(t, tone) { return '<span class="sb ' + (tone || '') + '">' + esc(t) + '</span>'; }
  function band(t, tone) { return '<div class="bnd ' + (tone || '') + '">' + t + '</div>'; }

  /* ── телефон ── */
  function phone(o) {
    var bn = '<div class="bn">' + (o.bottom || []).map(function (s) {
      return '<div class="bni' + (s.on ? ' on' : '') + '"><span class="pill w">' + I(s.icon, 22) + '</span><span>' + esc(s.label) + '</span></div>';
    }).join('') + '</div>';
    return '<div class="phone"><div class="phh"><span class="ib">' + I('layers', 22) + '</span><span class="srch sm">' + I('search', 18) + '</span><span class="sp1"></span><span class="av">' + esc(o.av || 'АС') + '</span></div>' +
      '<div class="phb">' + (o.content || '') + '</div>' + bn + '</div>';
  }

  window.P0 = { I: I, esc: esc, shell: shell, card: card, plaque: plaque, grid: grid, page: page, tabs: tabs, status: status, band: band, phone: phone, navItem: navItem };
})();
