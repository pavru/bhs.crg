/* П1 — вариант 1 «Смета в карточке стройки, работа — окнами» (Дизайнер §75, направление 1).
   Всё на месте (панель «Сметы» блока «Работы»), редакции — вкладками, строки — DataGrid с группами
   разделов ЛСР, сопоставление, материалы, импорт и смена действующей — окнами Modal wide. */
(function () {
  var X = window.P0, P = window.P1, I = P.I;

  function site(detail, h) {
    return X.shell({ sections: P.rail('site'), w: 1280, h: h || 760, ws: 'Пространство: ЭОМ',
      content: X.card({ title: 'ЖК «Северный», корпус 2', blocks: P.siteNav(), detail: detail }) });
  }

  /* (а) панель «Сметы» стройки */
  var list = '<div class="pg"><div class="pgh"><div><h1>Сметы</h1><p>План стройки считается по действующим редакциям</p></div>' +
    '<div class="acts">' + P.btn('Загрузить смету', 'filled', 'upload') + '</div></div>' +
    X.band(I('upload', 16) + '<span>Импорт <b>ЛСР_02-01-03_ДУ.gsfx</b> разобран и ждёт решения · Смирнова А. В., вчера</span>' + P.btn('Открыть', 'text sm'), 'info') +
    X.grid({ cols: ['Смета', 'Действующая', 'Последняя', 'Строк', 'Ждут', 'Себестоимость'], flex: [2.1, 1.4, 1.6, .5, .55, 1.2], rows: [
      ['<b style="font-weight:500">ЭОМ корпус 2</b> <span class="muted">· основная</span>', 'ред. 2 ' + P.mark('q', 'КП · график'), 'ред. 3 ' + P.mark('unm', 'не действующая'), '<span class="num">300</span>', P.mark('unm', '17'), '<span class="num">18 420 300 ₽</span>'],
      ['<b style="font-weight:500">Слаботочные системы</b> <span class="muted">· основная</span>', 'ред. 1', 'ред. 1', '<span class="num">96</span>', '<span class="muted">—</span>', '<span class="num">4 115 800 ₽</span>'],
      ['<b style="font-weight:500">Доп. работы по фасаду</b> <span class="muted">· дополнительная</span>', '<span class="muted">редакций нет</span>', '—', '—', '—', '—']] }) + '</div>';

  /* (б) карточка сметы: вкладки редакций, таблица */
  function cardDetail(cost) {
    return '<div class="pg" style="gap:10px"><div class="crumb"><a>‹ Сметы</a></div>' +
      '<div class="pgh"><div><h1>ЭОМ корпус 2 ' + P.mark('q', 'основная') + '</h1><p>ЛСР 02-01-01 · ресурсно-индексный метод</p></div><div class="acts">' + (cost ? P.btn('Новая редакция', 'outlined', 'upload') : '') + '<span class="ib">' + I('dots', 18) + '</span></div></div>' +
      '<div class="tbs" style="border-bottom:1px solid var(--f-stroke2)"><span class="on">Ред. 3</span><span>Ред. 2 · действующая</span><span>Ред. 1 · КП-2026-014</span></div>' +
      X.band('<span>20.10.2026 · Смирнова А. В. · ЛСР_02-01-01_ЭОМ_ред3.gsfx · 300 строк · <b>не действующая</b> — план считается по ред. 2 · ' + P.pnote('материалов без номенклатуры: 9 ▸') + '</span>' + (cost ? P.btn('Сделать действующей', 'tonal sm') : '')) +
      (cost ? '' : X.band(I('lock', 16) + '<span>' + P.HIDDEN + '</span>')) +
      '<div class="tb"><span class="sbox">' + I('search', 16) + 'Шифр или наименование</span>' + P.chip('Все', { on: true, count: 300 }) + P.chip('Не сопоставлены', { tone: 'warn', count: 17 }) + P.chip('Ед. изменилась', { tone: 'warn', count: 1 }) + P.chip('Запомнено', { count: 204 }) +
      '</div>' +
      P.lsrTable({ open: 9, cost: cost, sections: P.SECTIONS.slice(6, 12), groupAction: cost ? P.btn('Сопоставить раздел', 'text sm') : '',
        flex: cost ? [.45, 1.25, 3, .55, .55, 1.9, 1.05, .95] : [.45, 1.3, 3.4, .6, .6, 2.1, 1.1], more: '…ещё 24 раздела' + (cost ? ' · итог ред. 3: <b>18 906 450,12 ₽</b>' : '') }) + '</div>';
  }

  /* (в) импорт — окно с шагами; здесь шаг «отчёт» */
  var impBody =
    '<div class="tb" style="gap:6px;font-size:12.5px;color:var(--f-fg3)">' + P.mark('ok', '1 Файл и цель') + I('chev', 12) + P.mark('ok', '2 Разбор') + I('chev', 12) + P.mark('brand', '3 Отчёт') + '</div>' +
    '<div class="kv"><dt>Файл</dt><dd>ЛСР_02-01-03_ЭОМ.gsfx · ГРАНД-Смета 2026.1 · ЛСР 02-01-03</dd><dt>Куда</dt><dd>Новая редакция сметы «ЭОМ корпус 2» — станет ред. 4</dd></div>' +
    '<div class="bnd"><span><b>Разобрано 280 из 300 позиций</b> · 30 разделов · итог по разобранному 17 960 210,00 ₽</span></div>' +
    '<div class="bnd warn"><span><b>20 позиций не разобраны</b> — в редакцию не войдут</span>' + I('chevd', 16) + '</div>' + P.UNPARSED + P.OTHERCALC;
  var imp = P.scrim(1280, 760, '<div class="ghost">' + site(list) + '</div>' + P.modal({ title: 'Загрузка сметы', sub: 'ЖК «Северный», корпус 2', body: impBody,
    foot: '<span class="lft">☐ Создать без 20 не разобранных</span>' + P.btn('Отказаться', 'text') + '<span class="btn filled dis">Создать редакцию</span>' }));

  /* (г) окно сопоставления раздела */
  var matchBody = '<div class="bnd"><span>Раздел 9 · 16 строк · сопоставлено 11 · <b>ждут 5</b></span></div>' + P.UNITSPLIT + P.unitsBlock() + P.secTable() +
    '<label style="display:flex;gap:8px;font-size:13px;align-items:center">☑ Запомнить для шифров раздела — следующий импорт подставит сам</label>';
  function match(canNew) {
    return P.scrim(1280, 760, '<div class="ghost">' + site(cardDetail(true)) + '</div>' + P.modal({ title: 'Сопоставить раздел 9', sub: 'Групповые сети. 2–9 этажи · ЭОМ корпус 2, ред. 3', body: matchBody,
      foot: '<span class="lft">' + (canNew ? P.btn('Новый вид работы', 'text sm', 'plus') : '<span class="muted">нового вида работы нет: нет права «справочник видов работ»</span>') + '</span>' + P.btn('Отмена', 'text') + P.btn('Сопоставить 3 строки', 'filled') }));
  }

  /* (д) окно материала, шаг «новая позиция» */
  var resBody = '<div class="kv"><dt>Материал</dt><dd><b style="font-weight:500">Провод ПуГВ 1х2,5</b> · ФССЦ-21.2.01.02-0071 · 4 820 м · строка 9.8</dd></div>' +
    '<span class="sbox" style="width:100%">' + I('search', 16) + 'ПуГВ 1х2,5</span>' + P.candidates() +
    '<label style="display:flex;gap:8px;font-size:13px">☑ Запомнить по коду ресурса</label>';
  var res = P.scrim(1280, 760, '<div class="ghost">' + site(cardDetail(true)) + '</div>' + P.modal({ title: 'Позиция номенклатуры', sub: 'для материала сметы · ещё без номенклатуры: 8', body: resBody,
    foot: '<span class="lft">' + P.btn('Новая позиция…', 'text sm', 'plus') + '</span>' + P.btn('Пропустить', 'text') + P.btn('Выбрать и к следующему', 'filled') }));

  /* (е) сделать действующей */
  var cur = P.scrim(1100, 640, P.modal({ title: 'Сделать ред. 3 действующей?', sub: 'План стройки будет считаться по ред. 3 вместо ред. 2. ' + P.pnote('Расхождения по видам работ') + ':',
    body: P.DIFF + '<div class="sub">Ред. 2 останется — зафиксирована КП-2026-014 и графиком «Основной».</div>', foot: P.btn('Отмена', 'text') + P.btn('Сделать действующей', 'filled') }));

  /* (ж) глобальный раздел «Сметы» */
  var global = X.shell({ sections: P.rail('plan'), panel: P.PANEL, w: 1280, h: 560, ws: 'Пространство: ЭОМ', content: X.page({ title: 'Сметы', sub: 'Все стройки пространства',
    action: 'Загрузить смету', body: '<div class="tb"><span class="sbox">' + I('search', 16) + 'Смета или стройка</span>' + P.chip('Ждут решения', { tone: 'warn', count: 2 }) + '</div>' +
      '<div class="dg"><div class="dgr dgh"><span style="flex:2">Смета</span><span style="flex:1.2">Действующая</span><span style="flex:.6">Строк</span><span style="flex:.6">Ждут</span><span style="flex:1">Изменена</span></div>' +
      '<div class="dgr grp">ЖК «Северный», корпус 2</div>' +
      '<div class="dgr"><span style="flex:2">ЭОМ корпус 2</span><span style="flex:1.2">ред. 2 из 3</span><span style="flex:.6" class="num">300</span><span style="flex:.6">' + P.mark('unm', '17') + '</span><span style="flex:1">20.10.2026</span></div>' +
      '<div class="dgr"><span style="flex:2">Слаботочные системы</span><span style="flex:1.2">ред. 1</span><span style="flex:.6" class="num">96</span><span style="flex:.6" class="muted">—</span><span style="flex:1">21.10.2026</span></div>' +
      '<div class="dgr grp">Склад «Восток»</div>' +
      '<div class="dgr"><span style="flex:2">ЭОМ, этап 1</span><span style="flex:1.2">ред. 5</span><span style="flex:.6" class="num">412</span><span style="flex:.6" class="muted">—</span><span style="flex:1">07.10.2026</span></div></div>' }) });

  /* (з) телефон */
  var phone = P.phoneList('<div class="phc"><b>ЭОМ корпус 2</b><span>действующая ред. 2 · 296 строк</span><span class="sub">ред. 3 не действующая · 17 не сопоставлены</span></div>' +
    '<div class="phc"><b>Слаботочные системы</b><span>ред. 1 · 96 строк</span></div><p class="sub" style="padding:0 4px">На телефоне — только чтение: строки по разделам, без сопоставления и импорта.</p>');

  window.V1 = function () {
    return P.turn('1', 'Вариант 1 · «Смета в карточке стройки, работа — окнами»',
      'Продолжение выбора П0 без новых механизмов. Смета открывается <b>на месте</b>, в панели «Сметы» блока «Работы»; «‹ Сметы» — назад. <b>Редакции — вкладками</b>, под ними строка редакции. ' +
      'Строки — <code>DataGrid</code> с группами разделов ЛСР, в заголовке раздела — «не сопоставлено N» и «Сопоставить раздел». <b>Сопоставление, материалы, импорт, смена действующей — окнами</b> <code>Modal wide</code>; «новый вид работы» и «новая позиция» — шагом окна.',
      P.proscons(['ничего нового: окна, вкладки и сетка — как в счетах (<code>LineMatchChip</code>, <code>NomenclaturePicker</code>)', 'адреса и механизм панелей — из П0; код дешевле всего', 'импорт ждёт решения — полосой над списком, окно открывается снова'],
        ['824 px на 8 колонок: наименование расценки — в две-три строки, 300 строк — около 15 экранов', 'окно закрывает таблицу: соседний раздел не виден', 'больше шести вкладок редакций прокручиваются вбок'],
        ['первый импорт целиком несопоставлен — 30 открытий окна подряд, к десятому не видно, сколько осталось', 'отчёт импорта живёт, пока открыто окно: ссылкой его не отдать']),
      [P.opt('1а', '(а) Панель «Сметы» карточки стройки', site(list, 560), 'Действующая и последняя — отдельными колонками: расхождение видно в списке. Ждущий импорт — полосой (<code>GET /api/plan/imports</code>).'),
       P.opt('1б', '(б) Карточка сметы глазами «Сметчика» — ред. 3, раздел 9 раскрыт', site(cardDetail(true), 940), 'Отбор «Не сопоставлены» оставляет разделы, где они есть. Строка ресурса (9.8) — серой под расценкой. «Материалы без номенклатуры · 9» — ' + P.pnote('нет счётчика') + ' на сервере.'),
       P.opt('1б′', '(б) Та же смета у читающего — только <code>plan.estimate.read</code>', site(cardDetail(false), 900), 'Колонки стоимости нет, итогов нет; над таблицей — причина и имя права. Без <code>plan.estimate.edit</code> нет «Новой редакции», «Сделать действующей» и «Сопоставить раздел».'),
       P.opt('1в', '(в) Импорт: шаг «отчёт» окна загрузки', imp, '«Создать редакцию» недоступна, пока не отмечено «создать без 20 не разобранных» (<code>acceptPartial</code>). Предупреждение «номер ЛСР не совпадает» — над кнопкой, а не в конце.'),
       P.opt('1г', '(г) Окно сопоставления раздела — с правом на новый вид работы', match(true), 'Единицы раздела — чипами сверху: «раздел целиком» берёт одну, строки других единиц остаются ждать и названы заранее (сервер вернёт их в <code>skipped</code> как <code>differentUnit</code>). Запомненные строки — тихие, в выбор не попадают.'),
       P.opt('1г′', '(г) То же без <code>core.worktypes.edit</code>', '<div class="mdl wide" style="position:static;box-shadow:none;border:1px solid var(--f-stroke2)"><div class="mdf"><span class="lft muted">«Новый вид работы» нет в разметке вовсе</span>' + P.btn('Отмена', 'text') + P.btn('Сопоставить 3 строки', 'filled') + '</div></div>', 'Подсказка слева здесь только для макета: в коде пункта просто нет.', 896),
       P.opt('1д', '(д) Окно материала', res, '«Выбрать и к следующему» ведёт по материалам без номенклатуры редакции, не закрывая окна. «Новая позиция…» — шаг окна (<code>NewNomenclatureStep</code>).'),
       P.opt('1е', '(е) «Сделать действующей» — расхождения', cur, 'Таблица «было → станет» целиком — <b>нет носителя</b>: сервер сегодня меняет действующую сразу.', 1100),
       P.opt('1ж', '(ж) Глобальный раздел «Сметы»', global, 'Сгруппирован по стройкам. Сервер сегодня отдаёт сметы только по стройке — ' + P.pnote('глобального списка нет') + '.'),
       P.opt('1з', '(з) Телефон', phone, null, 390)]);
  };
})();
