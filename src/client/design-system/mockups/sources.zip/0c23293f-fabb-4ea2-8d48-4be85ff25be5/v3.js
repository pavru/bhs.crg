/* П1 — вариант 3 «Очередь: смета показывает, что ждёт решения» (Дизайнер §75, направление 3).
   На месте (панель «Сметы»), редакции — шкалой, над таблицей — полоса очередей со счётчиками сервера;
   сопоставление — разбор очереди раздел за разделом, материалы — очередь по материалу; импорт — полоса
   над черновой редакцией, после создания остаётся пометкой «частично 280 из 300». */
(function () {
  var X = window.P0, P = window.P1, I = P.I;

  function site(detail, h) {
    return X.shell({ sections: P.rail('site'), w: 1280, h: h || 560, ws: 'Пространство: ЭОМ',
      content: X.card({ title: 'ЖК «Северный», корпус 2', blocks: P.siteNav(), detail: detail }) });
  }
  // Шкала редакций.
  function scale(sel, imp) {
    var pts = [{ n: 'Ред. 1', s: '12.08 · КП-2026-009' }, { n: 'Ред. 2', s: '03.09 · КП-2026-014, график', cur: true }, { n: 'Ред. 3', s: '20.10 · 300 строк' }];
    if (imp) pts.push({ n: 'Импорт', s: 'ждёт решения', imp: true });
    return '<div style="display:flex;align-items:flex-start;gap:0;padding:4px 0 2px">' + pts.map(function (p, i) {
      var on = (sel === i + 1) || (sel === 'imp' && p.imp);
      return '<div style="flex:1;display:flex;flex-direction:column;gap:4px;min-width:0"><div style="display:flex;align-items:center"><span style="width:14px;height:14px;border-radius:50%;flex:none;box-sizing:border-box;' +
        (p.cur ? 'background:var(--f-brand);' : p.imp ? 'border:2px dashed var(--f-warning-text);' : 'border:2px solid var(--f-fg3);background:var(--f-bg1);') + (on ? 'box-shadow:0 0 0 4px var(--f-brand-bg2);' : '') + '"></span>' +
        (i < pts.length - 1 ? '<span style="flex:1;height:2px;background:var(--f-stroke2);' + (pts[i + 1].imp ? 'background:repeating-linear-gradient(90deg,var(--f-stroke2) 0 5px,transparent 5px 9px)' : '') + '"></span>' : '') + '</div>' +
        '<span style="font-size:13px;' + (on ? 'font-weight:600' : '') + '">' + p.n + (p.cur ? ' ' + P.mark('brand', 'действующая') : '') + '</span><span class="sub">' + p.s + '</span></div>';
    }).join('') + '</div>';
  }
  // Полоса очередей (счётчики сервера).
  function queues(o) {
    o = o || {};
    var q = [['Не разобрано при импорте', '20', 'partial', 'позиций файла'], ['Не сопоставлено', '17', 'unm', 'строк в 7 разделах'], ['Материалов без номенклатуры', '9', 'mat', 'материалов'], ['Единица изменилась', '1', 'chg', 'строка']];
    return '<div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px">' + q.map(function (x) {
      var nc = x[2] === 'mat' || x[2] === 'partial';
      return '<div class="card" style="padding:10px 12px;border-color:var(--f-warning-stroke);background:color-mix(in srgb,var(--f-warning-bg) 40%,var(--f-bg1))"><div class="sub">' + x[0] + '</div><div style="display:flex;align-items:baseline;gap:6px"><span style="font-size:20px;color:var(--f-warning-text)">' +
        (nc ? P.pnote(x[1]) : x[1]) + '</span><span class="sub">' + x[3] + '</span><span class="sp1"></span>' + (o.edit === false ? '' : '<span class="pick" style="font-size:12.5px">разобрать ' + I('arrow', 13) + '</span>') + '</div></div>';
    }).join('') + '</div>';
  }

  /* (а) панель «Сметы» — с очередями у смет */
  var list = '<div class="pg"><div class="pgh"><div><h1>Сметы</h1><p>Первыми — сметы, где что-то ждёт решения</p></div><div class="acts">' + P.btn('Загрузить смету', 'filled', 'upload') + '</div></div>' +
    '<div class="stack">' +
    '<div class="card" style="display:flex;gap:16px;align-items:center"><div style="flex:1"><b style="font-weight:500">ЭОМ корпус 2</b> <span class="muted">· основная · действующая ред. 2 из 3 · 18 420 300 ₽</span><div class="chips" style="margin-top:6px">' + P.chip('Импорт ждёт решения', { tone: 'warn' }) + P.chip('Не сопоставлено', { tone: 'warn', count: 17 }) + P.chip('Без номенклатуры', { tone: 'warn', count: 9 }) + '</div></div>' + I('chev', 18) + '</div>' +
    '<div class="card" style="display:flex;gap:16px;align-items:center"><div style="flex:1"><b style="font-weight:500">Слаботочные системы</b> <span class="muted">· основная · ред. 1 · 4 115 800 ₽</span><div class="sub" style="margin-top:4px">' + I('check', 12) + ' разобрана: все строки входят в план</div></div>' + I('chev', 18) + '</div>' +
    '<div class="card" style="display:flex;gap:16px;align-items:center"><div style="flex:1"><b style="font-weight:500">Доп. работы по фасаду</b> <span class="muted">· дополнительная</span><div class="sub" style="margin-top:4px">редакций нет — загрузите файл ЛСР</div></div>' + I('chev', 18) + '</div></div></div>';

  /* (б) карточка: шкала, очереди, таблица с отбором «Ждут решения» */
  function cardDetail(cost) {
    return '<div class="pg" style="gap:10px"><div class="crumb"><a>‹ Сметы</a></div>' +
      '<div class="pgh"><div><h1>ЭОМ корпус 2 ' + P.mark('q', 'основная') + '</h1><p>ЛСР 02-01-01 · ресурсно-индексный метод</p></div><div class="acts">' + (cost !== false ? P.btn('Сделать ред. 3 действующей', 'tonal') : '') + '<span class="ib">' + I('dots', 18) + '</span></div></div>' +
      scale(3, true) + (cost ? queues() : X.band(I('lock', 16) + '<span>' + P.HIDDEN + '</span>')) +
      (cost ? '' : X.band('<span>Ред. 3: <b>17 строк не сопоставлены</b> — в план не входят · разбирает сметчик</span>', 'warn')) +
      '<div class="tb">' + P.chip('Ждут решения', { on: true, count: 18 }) + P.chip('Вся смета', { count: 300 }) + P.chip('Запомнено', { count: 204 }) + '<span class="sbox">' + I('search', 16) + 'Шифр или наименование</span></div>' +
      P.lsrTable({ open: 9, cost: cost, sections: [P.SECTIONS[2], P.SECTIONS[8], P.SECTIONS[10]], rows: P.ROWS9.filter(function (r) { return r.mk === 'unm' || r.mk === 'chg'; }),
        flex: cost ? [.45, 1.25, 3, .55, .55, 1.9, 1.05, .95] : [.45, 1.3, 3.4, .6, .6, 2.1, 1.1], more: 'показаны 3 раздела из 7, где ждут · остальные 23 разобраны' }) + '</div>';
  }

  /* (в) импорт — полоса над черновой редакцией */
  var impDetail = '<div class="pg" style="gap:10px"><div class="crumb"><a>‹ Сметы</a></div><div class="pgh"><div><h1>ЭОМ корпус 2</h1></div></div>' + scale('imp', true) +
    '<div class="bnd warn" style="flex-direction:column;align-items:stretch;gap:8px"><div style="display:flex;gap:10px;align-items:center"><span style="flex:1"><b>Импорт ЛСР_02-01-03_ЭОМ.gsfx · разобрано 280 из 300</b> · 20 не разобраны ▾ · станет ред. 4</span>' + P.btn('Отказаться', 'text sm') + P.btn('Создать редакцию без 20…', 'filled') + '</div>' +
    '<div style="display:flex;gap:6px;align-items:center">' + I('alert', 14) + '<span>Номер ЛСР не совпадает с прежней редакцией: в файле 02-01-03, у ред. 2 — 02-01-01.</span></div></div>' +
    P.UNPARSED + '<div class="sub">Ниже — строки будущей редакции по разделам (сводка <code>summary.chapters</code>), сопоставления до создания нет.</div>' +
    P.mini(['Раздел', 'Строк', 'Итог, ₽'], [3, .6, 1.1], [['1. Кабельные конструкции. Подвал', '12', '<span class="num">412 806,00</span>'], ['2. Кабельные конструкции. Этажи 1–9', '14', '<span class="num">1 102 340,00</span>'], ['<span class="muted">…ещё 28</span>', '', '']], 'compact') + '</div>';
  var afterImp = '<div class="card" style="display:flex;gap:10px;align-items:center;width:600px;box-sizing:border-box">' + P.mark('unm', 'импортирована частично') + '<span>Ред. 4 · <b style="font-weight:500">280 из 300</b> позиций файла · 20 не вошли ▸</span></div>';

  /* (г) разбор очереди: раздел за разделом */
  var stepper = '<div style="width:280px;flex:none;border-right:1px solid var(--f-stroke2);padding:12px 8px;display:flex;flex-direction:column;gap:2px;background:var(--f-bg2)"><div class="nsec">Ждут: 7 разделов · 17 строк</div>' +
    [['3. Вводно-распределительное устройство', 'готово', 'ok'], ['9. Групповые сети. 2–9 этажи', '5 строк', 'on'], ['11. Электроосвещение. МОП', '1'], ['15. Силовое оборудование ИТП', '3'], ['18. Электроснабжение ДУ и ПД', '2'], ['24. Огнезащита проходок', '3'], ['28. Пусконаладочные работы', '2']]
      .map(function (s) { return '<div class="spi' + (s[2] === 'on' ? ' on' : '') + '" style="height:auto;min-height:36px;padding:6px 12px"><span class="t" style="white-space:normal">' + s[0] + '</span><span class="nt">' + (s[2] === 'ok' ? '<span style="color:var(--f-success-text)">' + I('check', 14) + '</span>' : s[1]) + '</span></div>'; }).join('') + '</div>';
  var reviewBody = '<div class="split" style="margin:0 -24px">' + stepper + '<div style="flex:1;min-width:0;padding:4px 24px;display:flex;flex-direction:column;gap:12px">' +
    '<div><div class="sub">Раздел 2 из 7</div><div style="font-size:18px">9. Групповые сети. 2–9 этажи</div></div>' + P.UNITSPLIT + P.unitsBlock() + P.secTable() + '</div></div>';
  var review = X.shell({ sections: P.rail('site'), w: 1280, h: 800, ws: 'Пространство: ЭОМ', content: '<div class="scrim" style="position:absolute;inset:0;border:0;border-radius:0">' +
    P.modal({ size: 'full', title: 'Разбор: несопоставленные строки ред. 3', sub: 'ЭОМ корпус 2 · ЖК «Северный», корпус 2 · сделано 1 из 7', body: reviewBody,
      foot: '<span class="lft"><label>☑ Запомнить для шифров раздела</label> · ' + P.btn('Новый вид работы', 'text sm', 'plus') + '</span>' + P.btn('Пропустить раздел', 'text') + P.btn('Применить к 3 строкам и дальше', 'filled') }) + '</div>' });

  /* (д) очередь материалов — по материалу */
  var matBody = '<div class="split" style="margin:0 -24px"><div style="width:340px;flex:none;border-right:1px solid var(--f-stroke2);padding:8px;display:flex;flex-direction:column;gap:2px;background:var(--f-bg2)"><div class="nsec">Без номенклатуры: 9 материалов</div>' +
    [['Провод ПуГВ 1х2,5', 'в 6 строках · 4 820 м', 'on'], ['Кабель-канал 40х25', 'в 3 строках · 312 м'], ['Труба гофр. ПВХ d20', 'в 4 строках · 1 040 м'], ['Розетка 2P+E утопл.', 'в 2 строках · 216 шт'], ['Коробка распаечная 100х100', 'в 2 строках · 64 шт'], ['…ещё 4', '']]
      .map(function (s) { return '<div class="spi' + (s[2] ? ' on' : '') + '" style="height:auto;min-height:40px;padding:6px 12px;flex-direction:column;align-items:flex-start;gap:0;border-radius:12px"><span>' + s[0] + '</span><span class="sub">' + s[1] + '</span></div>'; }).join('') + '</div>' +
    '<div style="flex:1;min-width:0;padding:4px 24px;display:flex;flex-direction:column;gap:12px"><div><div class="sub">Материал 1 из 9 · ФССЦ-21.2.01.02-0071 · м</div><div style="font-size:18px">Провод ПуГВ 1х2,5 — в 6 строках</div></div>' +
    '<span class="sbox" style="width:100%">' + I('search', 16) + 'ПуГВ 1х2,5</span>' + P.candidates() + '</div></div>';
  var mat = P.scrim(1280, 680, P.modal({ size: 'wide', title: 'Разбор: материалы без номенклатуры', sub: 'ред. 3 · выбор применится ко всем 6 строкам с этим материалом', body: matBody,
    foot: '<span class="lft"><label>☑ Запомнить по коду ресурса</label> · ' + P.btn('Новая позиция…', 'text sm', 'plus') + '</span>' + P.btn('Пропустить', 'text') + P.btn('Выбрать и к следующему', 'filled') }));

  /* (е) сделать действующей — из шкалы */
  var cur = P.scrim(1100, 680, P.modal({ title: 'Сделать ред. 3 действующей?', sub: 'План стройки будет считаться по ред. 3 вместо ред. 2. ' + P.pnote('Расхождения по видам работ') + ':',
    body: P.DIFF + '<div class="bnd warn"><span><b>В ред. 3 ждут решения 17 строк</b> — сначала разобрать? Действующей её можно сделать и сейчас: несопоставленное в план не войдёт.</span>' + P.btn('Разобрать', 'text sm') + '</div>',
    foot: P.btn('Отмена', 'text') + P.btn('Сделать действующей', 'filled') }));

  /* (ж) глобальный — с очередями, ждущие первыми */
  var global = X.shell({ sections: P.rail('plan'), panel: P.PANEL, w: 1280, h: 520, ws: 'Пространство: ЭОМ', content: X.page({ title: 'Сметы', sub: 'Все стройки · первыми те, где что-то ждёт', action: 'Загрузить смету',
    body: X.grid({ cols: ['Смета', 'Стройка', 'Действующая', 'Ждут решения'], flex: [1.6, 1.8, 1, 2.6], rows: [
      ['ЭОМ корпус 2', 'ЖК «Северный», корпус 2', 'ред. 2 из 3', P.mark('unm', 'импорт') + ' ' + P.mark('unm', '17 строк') + ' ' + P.mark('unm', '9 материалов')],
      ['Реконструкция ТП-14', 'ПС «Заречная»', 'ред. 2', P.mark('unm', '3 строки')],
      ['Слаботочные системы', 'ЖК «Северный», корпус 2', 'ред. 1', '<span class="sub">' + I('check', 12) + ' разобрана</span>'],
      ['ЭОМ, этап 1', 'Склад «Восток»', 'ред. 5', '<span class="sub">' + I('check', 12) + ' разобрана</span>']] }) }) });

  var phone = P.phoneList('<div class="phc"><b>ЭОМ корпус 2</b><span>действующая ред. 2</span><span class="sub">ждут решения: импорт · 17 строк · 9 материалов</span><span class="sub">разбор — с компьютера</span></div>' +
    '<div class="phc"><b>Слаботочные системы</b><span class="sub">' + I('check', 12) + ' разобрана: все строки в плане</span></div>');

  window.V3 = function () {
    return P.turn('3', 'Вариант 3 · «Очередь: смета показывает, что ждёт решения»',
      'Работа по задачам, а не по таблице. Смета — <b>на месте</b>, редакции — <b>шкалой</b> (история: какая из какой и что из неё сделано). Над таблицей — <b>полоса очередей</b>: «не разобрано при импорте», «не сопоставлено», «материалов без номенклатуры», «единица изменилась»; каждая открывает разбор. ' +
      '<b>Сопоставление — разбор очереди раздел за разделом</b> (окно во весь экран); <b>материалы — по материалу</b>, а не по строке. <b>Импорт — полоса над черновой редакцией</b>, после создания остаётся пометкой «частично 280 из 300». Таблица — справка, по умолчанию отбор «Ждут решения».',
      P.proscons(['закрывает ошибки «забытый частичный импорт», «несопоставленное молча выпало из плана», «сменили действующую посмотреть»', 'работа видна числом и убывает; 30 разделов проходятся подряд, без поиска', 'материалы по материалу — единственное, что масштабируется на 1500 ресурсов'],
        ['для правки двух строк очередь тяжела (построчная правка есть и из таблицы, меню строки)', 'читающему (МП) по умолчанию показано «что ждёт», а ему нужен обзор', 'разбор во весь экран — новый вид окна: <code>fullScreen</code> по правилам «Окон» — для редакторов, мастер туда не вписан'],
        ['неверное «запомнено» очередь прячет — нужен отбор «Запомнено» в таблице', 'без новых счётчиков сервера вариант не собрать (пунктир)']),
      [P.opt('3а', '(а) Панель «Сметы» — у каждой сметы её очереди', site(list), 'Сметы, где что-то ждёт, — первыми. Разобранная говорит об этом словами, а не пустотой.'),
       P.opt('3б', '(б) Карточка глазами «Сметчика»: шкала, очереди, «Ждут решения»', site(cardDetail(true), 940), 'Пустая очередь пропадает; все пусты — «Редакция разобрана: все строки входят в план». Пунктир — счётчиков нет на сервере.'),
       P.opt('3б′', '(б) Та же смета у читающего — только <code>plan.estimate.read</code>', site(cardDetail(false), 760), 'Без <code>plan.estimate.edit</code> очередей «разобрать» нет — только факт, что ждёт.'),
       P.opt('3в', '(в) Импорт — полоса над черновой редакцией', site(impDetail, 840), 'Черновик — точкой с пунктиром на шкале. ВОР и КА полосы с «создать редакцию» не получают — «приложите к смете» (лист 0).'),
       P.opt('3в′', '(в) После создания — пометка остаётся у редакции', afterImp, P.pnote('Связи редакции с импортом') + ' и признака «частично» в ответе редакции нет.', 600),
       P.opt('3г', '(г) Разбор очереди: раздел за разделом', review, '«Применить и дальше» — следующий раздел; «Пропустить» оставляет раздел в очереди. Окно во весь экран — вопрос правилу «Окна» (или страница со своим адресом).'),
       P.opt('3д', '(д) Очередь материалов — по материалу', mat, 'Один выбор — на все строки с этим материалом (<code>PUT …/resources/{id}/match</code> по каждой — сервер массового нет).'),
       P.opt('3е', '(е) «Сделать действующей» — с напоминанием об очереди', cur, '<b>Нет носителя</b> «было → станет».', 1100),
       P.opt('3ж', '(ж) Глобальный раздел — ждущие первыми', global, P.pnote('Глобального списка') + ' и счётчиков очередей у смет сервер сегодня не отдаёт.'),
       P.opt('3з', '(з) Телефон', phone, null, 390)]);
  };
})();
