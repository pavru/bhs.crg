/* П1 — общие данные примера и детали экранов смет (plan-09-estimate-ui). Данные выдуманные.
   Носители — по ответам сервера plan-06…plan-08 (EstimateDto, EstimateRowDto, EstimateImportDto,
   SectionMatchDto, ResourceCandidatesDto). Чего сервер не отдаёт — помечено в макете знаком «нет носителя». */
(function () {
  var X = window.P0, esc = X.esc;
  var EXTRA = {
    check: '<path d="M20 6 9 17l-5-5"/>',
    upload: '<path d="M12 3v12M7 8l5-5 5 5"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>',
    file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4 2v-8Z"/>',
    alert: '<path d="M12 3 2 21h20Z"/><path d="M12 10v4M12 18h.01"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9Z"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    box: '<path d="M21 8 12 3 3 8v8l9 5 9-5Z"/><path d="m3 8 9 5 9-5M12 13v8"/>'
  };
  function I(name, size) {
    if (!EXTRA[name]) return X.I(name, size);
    var s = size || 18;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + EXTRA[name] + '</svg>';
  }

  /* ── 30 разделов ЛСР «ЭОМ корпус 2», 300 строк ── */
  var SECTIONS = [
    ['1', 'Кабельные конструкции. Подвал', 12], ['2', 'Кабельные конструкции. Этажи 1–9', 14], ['3', 'Вводно-распределительное устройство', 9],
    ['4', 'Магистральные линии 0,4 кВ', 11], ['5', 'Этажные щиты', 10], ['6', 'Квартирные щиты', 8],
    ['7', 'Групповые сети. Подвал', 10], ['8', 'Групповые сети. 1 этаж', 12], ['9', 'Групповые сети. 2–9 этажи', 16],
    ['10', 'Электроосвещение. Подвал', 9], ['11', 'Электроосвещение. МОП', 13], ['12', 'Аварийное освещение', 8],
    ['13', 'Освещение лестничных клеток', 7], ['14', 'Наружное освещение фасада', 6], ['15', 'Силовое оборудование ИТП', 11],
    ['16', 'Силовое оборудование насосной', 9], ['17', 'Электроснабжение лифтов', 7], ['18', 'Электроснабжение ДУ и ПД', 10],
    ['19', 'Кабельные линии к ВРУ', 8], ['20', 'Учёт электроэнергии', 6], ['21', 'Заземление', 9],
    ['22', 'Молниезащита', 8], ['23', 'Уравнивание потенциалов', 7], ['24', 'Огнезащита проходок', 8],
    ['25', 'Демонтажные работы', 5], ['26', 'Земляные работы для КЛ', 9], ['27', 'Прокладка КЛ в траншее', 10],
    ['28', 'Пусконаладочные работы', 12], ['29', 'Измерения и испытания', 9], ['30', 'Прочие работы', 7]
  ];
  // Несопоставленные по разделам: 17 всего (как в П0).
  var UNM = { 3: 2, 9: 4, 11: 1, 15: 3, 18: 2, 24: 3, 28: 2 };
  var CHG = { 9: 1 };   // unit-changed

  var ROWS9 = [ // раздел 9 «Групповые сети. 2–9 этажи» — раскрытый
    { n: '9.1', code: 'ГЭСНм08-02-399-01', name: 'Кабель до 35 кВ в проложенных трубах, блоках и коробах, масса 1 м до 1 кг', sv: '12,4', su: '100 м', wt: 'Прокладка кабеля до 1 кВ', v: '1 240', u: 'м', f: '× 100', mk: 'rem', cost: '412 806,00' },
    { n: '9.2', code: 'ГЭСНм08-02-399-01', name: 'Кабель до 35 кВ в проложенных трубах, блоках и коробах, масса 1 м до 1 кг', sv: '8,6', su: '100 м', wt: 'Прокладка кабеля до 1 кВ', v: '860', u: 'м', f: '× 100', mk: 'rem', cost: '286 294,00' },
    { n: '9.3', code: 'ГЭСНм08-02-409-01', name: 'Труба гофрированная ПВХ по стенам и колоннам с креплением скобами, диаметр до 25 мм', sv: '6,3', su: '100 м', wt: null, mk: 'chg', why: 'шифр запомнен для ед. «м»', cost: '58 212,00' },
    { n: '9.4', code: 'ГЭСНм08-03-591-02', name: 'Розетка штепсельная утопленного типа при скрытой проводке', sv: '2,16', su: '100 шт', wt: null, mk: 'unm', cost: '94 521,60' },
    { n: '9.5', code: 'ГЭСНм08-03-591-08', name: 'Выключатель одноклавишный утопленного типа при скрытой проводке', sv: '1,44', su: '100 шт', wt: null, mk: 'unm', cost: '51 408,00' },
    { n: '9.6', code: 'ГЭСНм08-03-573-04', name: 'Коробка распаечная, установочная для скрытой проводки', sv: '3,6', su: '100 шт', wt: null, mk: 'unm', cost: '43 920,00' },
    { n: '9.7', code: 'ГЭСНм08-03-600-01', name: 'Устройство защитного отключения в щитке', sv: '72', su: 'шт', wt: 'Монтаж модульных аппаратов', v: '72', u: 'шт', f: '× 1', mk: 'rem', cost: '137 160,00' },
    { n: '9.8', code: 'ФССЦ-21.2.01.02-0071', name: 'Провод ПуГВ 1х2,5', sv: '4 820', su: 'м', res: true, wt: '— материал', mk: 'mat', cost: '149 420,00' }
  ];

  var PERM = 'видеть себестоимость сметы';
  var HIDDEN = 'Стоимость скрыта: нужно право «' + PERM + '» (<code>plan.estimate.cost</code>)';

  var REVS = [
    { n: 3, date: '20.10.2026', who: 'Смирнова А. В.', file: 'ЛСР_02-01-01_ЭОМ_ред3.gsfx', rows: 300, unm: 17, frozen: null, current: false, total: '18 906 450,12' },
    { n: 2, date: '03.09.2026', who: 'Смирнова А. В.', file: 'ЛСР_02-01-01_ЭОМ_ред2.gsfx', rows: 296, unm: 0, frozen: 'график «Основной»', current: true, total: '18 420 300,00' },
    { n: 1, date: '12.08.2026', who: 'Петров К. О.', file: 'ЛСР_02-01-01_ЭОМ.gsfx', rows: 281, unm: 0, frozen: 'КП-2026-014', current: false, total: '17 950 120,40' }
  ];

  /* ── мелкие детали ── */
  function btn(t, v, icon) { return '<span class="btn ' + (v || 'outlined') + '">' + (icon ? I(icon, 16) : '') + esc(t) + '</span>'; }
  function mark(code, text) {
    var cls = { brand: 'brand', ok: 'ok', unm: 'warn', chg: 'warn', rem: 'quiet', mat: 'quiet', remd: 'quiet', hid: 'quiet' }[code] || 'quiet';
    var t = text || { unm: 'не сопоставлена', chg: 'другая единица', rem: 'запомнено', mat: 'материал' }[code] || code;
    return '<span class="mk ' + cls + '">' + esc(t) + '</span>';
  }
  function chip(t, o) { o = o || {}; return '<span class="chip' + (o.on ? ' on' : '') + (o.tone ? ' ' + o.tone : '') + (o.dashed ? ' dashed' : '') + '">' + (o.on ? I('check', 14) : '') + esc(t) + (o.count != null ? '<b>' + esc(o.count) + '</b>' : '') + '</span>'; }
  function pnote(t) { return '<span class="nocar" title="нет носителя">' + t + '</span>'; }
  function modal(o) {
    return '<div class="mdl ' + (o.size || 'wide') + '" style="' + (o.style || '') + '"><div class="mdh"><div><h3>' + esc(o.title) + '</h3>' + (o.sub ? '<p>' + o.sub + '</p>' : '') + '</div><span class="ib">' + I('close', 18) + '</span></div>' +
      '<div class="mdb">' + (o.body || '') + '</div>' + (o.foot ? '<div class="mdf">' + o.foot + '</div>' : '') + '</div>';
  }
  function scrim(w, h, inner) { return '<div class="scrim" style="width:' + w + 'px;height:' + h + 'px">' + inner + '</div>'; }

  /* ── строки таблицы строк редакции ── */
  function rowCells(r, o) {
    o = o || {};
    var wt = r.wt && r.wt.charAt(0) !== '—'
      ? '<span class="wt">' + esc(r.wt) + '</span><span class="sub">' + esc(r.v) + ' ' + esc(r.u) + ' · ' + esc(r.f) + '</span>'
      : r.res ? '<span class="muted">' + esc(r.wt) + '</span>'
      : '<span class="pick">' + I('plus', 14) + 'выбрать вид работы</span>' + (r.why ? '<span class="sub warn">' + esc(r.why) + '</span>' : '');
    return [
      '<span class="mono">' + esc(r.n) + '</span>',
      '<span class="mono sm">' + esc(r.code) + '</span>',
      '<span class="nm">' + esc(r.name) + '</span>',
      '<span class="num">' + esc(r.sv) + '</span>',
      '<span>' + esc(r.su) + '</span>',
      '<span class="wtc">' + wt + '</span>',
      '<span>' + (r.mk === 'rem' ? mark('rem') : r.mk === 'chg' ? mark('chg') : r.mk === 'unm' ? mark('unm') : r.mk === 'mat' ? mark('mat') : '') + '</span>'
    ].concat(o.cost ? ['<span class="num">' + esc(r.cost) + '</span>'] : []);
  }
  function lsrTable(o) {
    o = o || {};
    var cols = ['№', 'Шифр', 'Наименование', 'Объём', 'Ед.', 'Вид работы в плане', 'Пометки'].concat(o.cost ? ['Стоимость, ₽'] : []);
    var flex = o.flex || [.45, 1.25, 3.2, .6, .6, 2.1, 1.1, 1];
    var h = '<div class="et"><div class="etr eth">' + cols.map(function (c, i) { return '<span style="flex:' + flex[i] + '">' + c + '</span>'; }).join('') + '</div>';
    var list = o.sections || SECTIONS.slice(0, 14);
    list.forEach(function (s, idx) {
      var n = +s[0], u = UNM[n] || 0, open = o.open === n;
      h += '<div class="etg' + (open ? ' open' : '') + '"><span class="cv">' + I(open ? 'chevd' : 'chev', 14) + '</span><span class="gn">Раздел ' + s[0] + '. ' + esc(s[1]) + '</span><span class="gc">' + s[2] + ' строк</span>' +
        (u ? '<span class="mk warn">не сопоставлено: ' + u + '</span>' : '<span class="mk ok">' + I('check', 12) + 'всё сопоставлено</span>') +
        (o.groupAction && u ? '<span class="ga">' + o.groupAction + '</span>' : '') + (o.cost ? '<span class="gt num">' + ['412 806', '1 102 340', '2 806 115', '904 220', '651 008'][idx % 5] + ' ₽</span>' : '') + '</div>';
      if (open) (o.rows || ROWS9).forEach(function (r) {
        h += '<div class="etr' + (r.mk === 'unm' || r.mk === 'chg' ? ' attn' : '') + (r.res ? ' res' : '') + '">' + rowCells(r, o).map(function (c, i) { return '<span style="flex:' + flex[i] + '">' + c + '</span>'; }).join('') + '</div>';
      });
    });
    if (o.more) h += '<div class="etmore">' + o.more + '</div>';
    return h + '</div>';
  }

  /* ── общие куски: одинаковое содержимое, разный контейнер в вариантах ── */
  function mini(cols, flex, rows, cls) {
    return '<div class="dg ' + (cls || '') + '"><div class="dgr dgh">' + cols.map(function (c, i) { return '<span style="flex:' + flex[i] + '">' + c + '</span>'; }).join('') + '</div>' +
      rows.map(function (r) { return '<div class="dgr' + (r.cls ? ' ' + r.cls : '') + '">' + (r.c || r).map(function (c, i) { return '<span style="flex:' + flex[i] + '">' + c + '</span>'; }).join('') + '</div>'; }).join('') + '</div>';
  }
  // Отчёт разбора: «N из M», причины, otherCalculation (EstimateImportDto).
  var UNPARSED = mini(['Где', 'Почему не разобрана'], [1, 2.6], [
    ['<span class="mono">Раздел 24, стр. 812</span>', 'Нет единицы измерения у позиции'], ['<span class="mono">Раздел 24, стр. 818</span>', 'Нет единицы измерения у позиции'],
    ['<span class="mono">Раздел 30, стр. 1104</span>', 'Позиция без расценки и ресурсов'], ['<span class="muted">…</span>', '<span class="muted">ещё 17 — показать все</span>']], 'compact');
  var OTHERCALC = '<div class="bnd warn"><span>' + I('alert', 14) + ' <b>Номер ЛСР не совпадает с прежней редакцией:</b> в файле 02-01-03, у ред. 2 — 02-01-01. Это точно новая редакция этой сметы?</span></div>';
  // Сопоставление раздела: две единицы внутри, запомненная и unit-changed строки.
  function unitsBlock(o) {
    o = o || {};
    return '<div class="cols2"><div class="fld"><label>Вид работы для раздела</label><div class="inp sel"><span>Монтаж электроустановочных изделий</span>' + I('chevd', 16) + '</div></div>' +
      '<div class="fld"><label>Пересчёт единицы</label><div class="inp"><span>100 шт</span>' + I('arrow', 14) + '<span>шт</span><span style="margin-left:auto;font-weight:500">× 100</span></div>' +
      '<span class="sub">например, 9.4: 2,16 × 100 шт = <b>216 шт</b> · коэффициент предложен единицами</span></div></div>';
  }
  var SECROWS = [
    { c: ['☑', '9.4', 'Розетка штепсельная утопленного типа при скрытой проводке', '2,16', '100 шт', '216 шт'] },
    { c: ['☑', '9.5', 'Выключатель одноклавишный утопленного типа', '1,44', '100 шт', '144 шт'] },
    { c: ['☑', '9.6', 'Коробка распаечная, установочная', '3,6', '100 шт', '360 шт'] },
    { c: ['—', '9.3', 'Труба гофрированная ПВХ по стенам, диаметр до 25 мм ' + mark('chg', 'другая единица'), '6,3', '100 м', '<span class="sub warn">шифр запомнен для «м» — выберите для этой строки</span>'], cls: 'attn' },
    { c: ['—', '9.1', 'Кабель до 35 кВ в проложенных трубах… ' + mark('rem'), '12,4', '100 м', '<span class="muted">Прокладка кабеля до 1 кВ · 1 240 м</span>'] },
    { c: ['—', '9.7', 'Устройство защитного отключения в щитке ' + mark('rem'), '72', 'шт', '<span class="muted">Монтаж модульных аппаратов · 72 шт</span>'] }
  ];
  function secTable(rows) { return mini(['', '№', 'Строка', 'Объём', 'Ед.', 'В плане станет'], [.25, .4, 3, .55, .6, 2], rows || SECROWS, 'compact'); }
  var UNITSPLIT = '<div class="chips"><span class="sub">В разделе:</span>' + chip('100 шт', { on: true, count: 3 }) + chip('100 м', { count: 3 }) + chip('шт', { count: 10 }) + '<span class="sub">— раздел целиком берёт одну единицу; строки других единиц останутся ждать</span></div>';
  // Похожие позиции номенклатуры (ResourceCandidatesDto).
  function candidates(sel) {
    return '<div class="stack" style="gap:2px">' + [
      ['Провод ПуГВ 1х2,5 белый', 'лучшее совпадение · совпал код ресурса · ед. м', true],
      ['Провод ПуГВнг(А)-LS 1х2,5', 'похоже по наименованию', false],
      ['Провод ПВ3 1х2,5', 'похоже по наименованию', false]]
      .map(function (c, i) { return '<div class="cand' + (i === (sel || 0) ? ' on' : '') + '">' + (c[2] ? '<span style="color:var(--f-brand)">' + I('star', 16) + '</span>' : '<span style="width:16px;flex:none"></span>') + '<div><div>' + c[0] + '</div><div class="why">' + c[1] + '</div></div></div>'; }).join('') +
      '<div class="sub" style="padding:4px 10px">ещё в архиве: 1 — заводить такую заново не нужно</div></div>';
  }
  // «Было → станет» по видам работ — НЕТ НОСИТЕЛЯ.
  var DIFF = mini(['Вид работы', 'Ед.', 'Было (ред. 2)', 'Станет (ред. 3)', ''], [2.4, .4, .9, .9, 1.1], [
    ['Прокладка кабеля до 1 кВ', 'м', '<span class="num">9 840</span>', '<span class="num">10 200</span>', '<span class="sub">+360</span>'],
    ['Монтаж светильников', 'шт', '<span class="num">380</span>', '<span class="num">412</span>', '<span class="sub">+32</span>'],
    ['Монтаж кабельных лотков', 'м', '<span class="num">1 150</span>', '<span class="num">1 150</span>', '<span class="sub">без изменений</span>'],
    ['Огнезащита кабельных проходок', 'шт', '<span class="num">—</span>', '<span class="num">48</span>', mark('brand', 'новый вид')],
    ['Демонтаж электропроводки', 'м', '<span class="num">220</span>', '<span class="num">—</span>', '<span class="mk quiet">ушёл</span>'],
    { c: ['<i>Не сопоставлены</i>', '', '', '<span class="num">17 строк</span>', mark('unm', 'в план не войдут')], cls: 'attn' }], 'compact');
  // Телефон: список смет и карточка — только чтение.
  function phoneList(extra) {
    return X.phone({ bottom: [{ icon: 'home', label: 'Главная' }, { icon: 'building', label: 'Стройки', on: true }, { icon: 'database', label: 'Данные' }, { icon: 'wallet', label: 'Затраты' }, { icon: 'plan', label: 'Планы' }],
      content: '<p class="phsec">ЖК «Северный», корпус 2</p><div class="phtitle">Сметы</div><div class="phlist">' + (extra || '') + '</div>' });
  }

  /* ── листы (как в П0) ── */
  function turn(id, name, sub, pc, opts, extra) {
    return '<section class="dv-turn" id="v' + id + '" data-screen-label="Вариант ' + id + '"><div class="dv-thd"><span class="dv-tid">' + id + '</span><span class="dv-tname">' + name + '</span></div>' +
      '<p class="dv-tsub">' + sub + '</p>' + (pc || '') + '<div class="dv-opts">' + opts.join('') + '</div>' + (extra || '') + '</section>';
  }
  function opt(id, label, body, note, w) {
    return '<div class="dv-opt" style="--w:' + (w || 1280) + 'px"><div class="dv-olabel"><span class="dv-oid">' + id + '</span>' + label + '</div>' + body +
      (note ? '<p class="dv-note">' + note + '</p>' : '') + '</div>';
  }
  function proscons(p, c, b) {
    return '<div class="pc"><div><b>Где сильнее</b><ul>' + p.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul></div>' +
      '<div><b>Где слабее</b><ul>' + c.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>' +
      (b ? '<b>Чем ломается</b><ul>' + b.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>' : '') + '</div></div>';
  }
  /* ── выбранная П0 оболочка: рейл варианта 1, «Планы» последним рабочим ── */
  function rail(on) {
    return [{ icon: 'home', label: 'Главная' }, { icon: 'building', label: 'Стройки', on: on === 'site' }, { icon: 'database', label: 'Данные' },
      { icon: 'wallet', label: 'Затраты' }, { icon: 'plan', label: 'Планы', on: on === 'plan' }, '|', { icon: 'wrench', label: 'Система' }];
  }
  var PANEL = { title: 'Планирование', hint: 'Сметы, КП, справочники', groups: [
    { items: [{ label: 'Сметы', on: true }, { label: 'Коммерческие предложения' }] },
    { label: 'Справочники', items: [{ label: 'Прайс-лист' }, { label: 'Календарь компании' }, { label: 'Запомненные сопоставления' }] }] };
  // Навигация карточки стройки — П0, вариант 2: блок «Работы» сверху.
  function siteNav(on) {
    return [{ label: 'Работы', items: [{ icon: 'progress', label: 'Ход работ' }, { icon: 'sheet', label: 'Сметы', on: on !== false, count: 3 }, { icon: 'gantt', label: 'График' }] },
      { label: 'Разделы', items: [{ icon: 'layers', label: 'Корпус 2. ЭОМ', count: 4, chev: true }, { icon: 'layers', label: 'Слаботочные системы', count: 3, chev: true }, { add: true, label: 'Добавить раздел' }] },
      { label: 'Эта стройка', items: [{ icon: 'grid', label: 'Каталог' }, { icon: 'database', label: 'Наборы данных' }, { icon: 'users', label: 'Подписчики' }] }];
  }

  window.P1 = { mini: mini, UNPARSED: UNPARSED, OTHERCALC: OTHERCALC, unitsBlock: unitsBlock, SECROWS: SECROWS, secTable: secTable, UNITSPLIT: UNITSPLIT,
    candidates: candidates, DIFF: DIFF, phoneList: phoneList,
    I: I, turn: turn, opt: opt, proscons: proscons, rail: rail, PANEL: PANEL, siteNav: siteNav, SECTIONS: SECTIONS, UNM: UNM, ROWS9: ROWS9, REVS: REVS, PERM: PERM, HIDDEN: HIDDEN,
    btn: btn, mark: mark, chip: chip, pnote: pnote, modal: modal, scrim: scrim, lsrTable: lsrTable, rowCells: rowCells };
})();
