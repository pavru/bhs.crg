const D=window.PALETTE;
const L=h=>{const v=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255).map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4);return .2126*v[0]+.7152*v[1]+.0722*v[2]};
const CR=(a,b)=>{const[x,y]=[L(a),L(b)].sort((p,q)=>q-p);return (x+.05)/(y+.05)};
const F=c=>c.toFixed(2).replace('.',',');
const VARS=[['current','0 · Было (сегодня)',''],['tonalSpot','А · TonalSpot','star'],['fidelity','Б · Fidelity',''],['content','В · Content','']];
const DESC={current:'Значения вписаны руками: у fg3 свой серый, fg4 — это outline, у обводки предупреждения свой цвет, текст статуса — цветом самой роли.',tonalSpot:'Схема Material You по умолчанию: контейнеры приглушённые, вторичный и третичный цвета — от seed с малой насыщенностью.',fidelity:'Контейнеры сохраняют насыщенность seed: primary-container = #1d5fb0 — посмотрите на плашку «Распознано». Третичный — оранжевый (пометка «Правка»).',content:'Как Б, но третичный цвет сиреневый: он подобран по температуре цвета.'};
const st=()=>{const g=n=>document.querySelector('input[name='+n+']:checked').value;return{g:g('g'),h:g('h'),b:g('b'),p:g('p')}};
function roles(key,th,s){
 const cur=key==='current';
 const base={...D[key][th]};
 if(!cur){
  if(s.p==='gen'&&th==='light')base.primary=D[key].lightUnpinned.primary;
  const e=D.ext[s.h];for(const n of ['success','warning']){const x=e[n][th];base[n]=x.c;base['on-'+n]=x.on;base[n+'-container']=x.cont;base['on-'+n+'-container']=x.onCont}
 }
 const old=cur||s.g==='old', fg3=D.current[th].fg3;
 const g={head:old?fg3:base['on-surface-variant'],meta:old?base.outline:base['on-surface-variant'],
  'meta-sel':old?base.outline:base['on-secondary-container'],label:old?fg3:base['on-surface-variant'],
  'ok-text':cur?base.success:base['on-success-container'],'warn-text':cur?base.warning:base['on-warning-container'],
  'err-text':cur?base.error:base['on-error-container'],
  'warn-border':(cur||s.b==='on')?D.current[th]['warning-border']:'transparent'};
 return {base,g};
}
const SURF=['surface','surface-dim','surface-bright','surface-container-lowest','surface-container-low','surface-container','surface-container-high','surface-container-highest'];
function frame(key,th,s){
 const {base,g}=roles(key,th,s);
 const css=Object.entries(base).map(([k,v])=>'--r-'+k+':'+v).join(';')+';'+Object.entries(g).map(([k,v])=>'--g-'+k+':'+v).join(';');
 const pairs=[['подпись на surface',g.meta,base.surface,4.5],['подпись на выс. контейнере',g.meta,base['surface-container-highest'],4.5],['шапка таблицы',g.head,base['surface-container'],4.5],['подпись в выбранной',g['meta-sel'],base['secondary-container'],4.5],['«Оплачен»',g['ok-text'],base['success-container'],4.5],['«Ждёт оплаты»',g['warn-text'],base['warning-container'],4.5],['«Отклонён»',g['err-text'],base['error-container'],4.5],['кнопка',base['on-primary'],base.primary,4.5],['«Распознано»',base['on-primary-container'],base['primary-container'],4.5]];
 if(g['warn-border']!=='transparent')pairs.push(['рамка предупреждения',g['warn-border'],base.surface,3]);
 pairs.push(['outline на surface',base.outline,base.surface,3]);
 const cr=pairs.map(([n,a,b,t])=>{const c=CR(a,b);return '<span class="'+(c<t?'bad':'ok')+'">'+n+' '+F(c)+'</span>'}).join('');
 return '<div><div class="cap">'+(th==='light'?'Светлая':'Тёмная')+' · primary '+base.primary+' · primary-container '+base['primary-container']+' · tertiary '+base.tertiary+'</div><div class="app" style="'+css+'">'+
 '<nav class="rail"><div class="logo"></div><div class="ri"><i></i>Главная</div><div class="ri on"><i></i>Счета</div><div class="ri"><i></i>Реестр</div><div class="ri"><i></i>Планы</div><div class="ri"><i></i>Каталог</div></nav>'+
 '<div class="main"><div class="bar"><h4>Счета</h4><div class="search">Номер, поставщик</div><div class="btn t">Отбор</div><div class="btn f">Добавить счёт</div></div>'+
 '<div class="info"><b>Распознано 12 строк из 14</b> две отмечены для проверки<span class="lnk">Показать</span></div>'+
 '<div class="card"><table><thead><tr><th>Счёт</th><th>Поставщик</th><th class="num">Сумма, ₽</th><th>Состояние</th></tr></thead><tbody>'+
 '<tr><td>№ 1020<span class="meta">от 14.10.2026</span></td><td>ООО «Электрокомплект»<span class="meta">ЖК «Северный», корп. 2</span></td><td class="num">184 320,00<span class="meta">НДС 30 720,00</span></td><td><span class="chip c-ok">Оплачен</span></td></tr>'+
 '<tr class="sel"><td>№ 1021<span class="meta">от 15.10.2026</span></td><td>ИП Соколов А. В.<span class="meta">Школа № 12</span></td><td class="num">42 900,00<span class="meta">без НДС</span></td><td><span class="chip c-wait">Ждёт оплаты</span></td></tr>'+
 '<tr><td>№ 1022<span class="meta">от 16.10.2026</span></td><td>АО «Кабель-Сервис»<span class="meta">ЖК «Северный», корп. 1</span></td><td class="num">1 006 450,00<span class="meta">НДС 167 741,67</span></td><td><span class="chip c-err">Отклонён</span></td></tr>'+
 '<tr><td>№ 1023<span class="meta">от 17.10.2026</span></td><td>ООО «ТД Светотехника»<span class="meta">не разобран</span></td><td class="num">—</td><td><span class="chip c-draft">Черновик</span> <span class="chip c-man">Правка</span></td></tr>'+
 '</tbody></table></div></div>'+
 '<aside class="side"><h5>Счёт № 1021</h5><div class="kv"><span>Поставщик</span><span>ИП Соколов А. В.</span><span>Стройка</span><span>Школа № 12</span><span>Оплатить</span><span>до 25.10.2026</span></div>'+
 '<div class="callout">Сумма строк не сходится с итогом на 1 200,00 ₽</div><div class="err">Поставщик с ИНН 7701… не найден</div><div><span class="done">✓ Разобран</span></div>'+
 '<div class="dlgwrap"><div class="dlg"><b>Удалить черновик?</b><p>Счёт № 1023 и его файл будут удалены.</p><div class="acts"><span class="btn x">Отмена</span><span class="btn x">Удалить</span></div></div></div></aside>'+
 '</div><div class="cr">'+cr+'</div></div>';
}
function minMeta(key,th,s){const {base,g}=roles(key,th,s);return Math.min(...SURF.map(x=>CR(g.meta,base[x])))}
function sw(t,c,on,cont,onc,oldText){const txt=oldText||onc;return '<div class="swc"><div style="background:'+c+';color:'+on+'">'+t+'<small>'+c+' · '+F(CR(on,c))+'</small></div><div style="background:'+cont+';color:'+txt+'">Контейнер<small>'+cont+' · текст '+F(CR(txt,cont))+(oldText?' (цветом роли)':'')+'</small></div></div>'}
function render(){
 const s=st();let h='';
 for(const [k,t,star] of VARS){h+='<h2>'+t+(star?'<span class="tag star">★ Дизайнер</span>':'')+'</h2><p class="note">'+DESC[k]+' Худший контраст подписи на всех поверхностях: в светлой '+F(minMeta(k,'light',s))+', в тёмной '+F(minMeta(k,'dark',s))+'.</p><div class="row">'+frame(k,'light',s)+frame(k,'dark',s)+'</div>'}
 document.getElementById('rows').innerHTML=h;
 let e='';
 for(const th of ['light','dark']){e+='<h3>'+(th==='light'?'Светлая':'Тёмная')+'</h3><div class="sw">';
  const cur=D.current[th];
  for(const n of ['success','warning']){
   e+=sw('Было · '+n,cur[n],cur['on-'+n],cur[n+'-container'],cur['on-'+n+'-container'],cur[n]);
   for(const sh of ['0','5','15']){const x=D.ext[sh][n][th];e+=sw((sh==='0'?'Без гармонизации':sh+'°')+' · '+n,x.c,x.on,x.cont,x.onCont,null)}}
  e+='</div>'}
 document.getElementById('ext').innerHTML=e;
}
document.getElementById('ctl').addEventListener('change',render);render();
