/* Экраны трёх макетов change sharedui-md3-13-containers (окна, меню, листы, карточки; решение В8).
   Один набор экранов на три варианта. Оси (разбор Дизайнера 01.11.2026):
   - крестик окна: нет, выход в подвале (А) / IconButton у замыкающего края — отступление (Б, В);
   - черта и подвал: черта только при прокрутке (А, Б) / подвал полосой всегда (В);
   - окно во весь экран и на телефоне: действие в шапке (А, В) / крестик и заголовок, действия в подвале (Б);
   - слой над окном: surface-container (А) / surface-container-highest (Б) / рамка outline-variant (В);
   - меню раздела и профиля: Menu с галочкой (А) / текущее залито (Б) / карточка профиля с сегментами (В).
   Одинаково: окно 28, уровень 3, surface-container-high, заголовок headline-small; меню 4, уровень 2,
   пункт 48 / 40; листы и карточки. */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'MD3 буквально', cross: 0, line: 'scroll', fs: 'top', ack: 'text', prof: 'menu', sect: 'check',
      rule: 'Крестика у окна нет: выход — «Отмена» или «Закрыть» в подвале, Esc и «Назад»; окнам без подвала (35 пикеров и справок) заводится «Закрыть» в подвале. Черта под шапкой и над подвалом — только при прокрутке тела. Окно во весь экран и любое окно формы на телефоне — full-screen dialog: крестик у ведущего края, главное действие — в шапке (у окна появляется свойство «главное действие»; подвалы — произвольная разметка в ~80 окнах). Слой над окном (меню, список, поповер) — surface-container, уровень 2, без рамки. «Понятно» — text. Меню раздела и профиля — обычный Menu: текущее отмечено галочкой, тема — три пункта с отметкой.' },
    b: { key: 'b', name: 'Б', title: 'MD3 и названные отступления', cross: 1, line: 'scroll', fs: 'foot', ack: 'filled', prof: 'menu', sect: 'fill',
      rule: 'Крестик — IconButton 40 со знаком 24 у замыкающего края шапки (отступление D8); у «да / нет» и у ответа «Понятно» его нет, как сегодня. Черта — только при прокрутке. Во весь экран и на телефоне: крестик у ведущего края и заголовок, действия остаются в подвале — второе отступление (шапке не нужно знать главное действие окна). Слой над окном — surface-container-highest: в тёмной теме он светлее окна, уровень 2, без рамки. «Понятно» — filled, одинаково в Modal и ConfirmDialog. Текущий пункт меню раздела залит secondary-container.' },
    v: { key: 'v', name: 'В', title: 'Подвал полосой и рамка у слоёв', cross: 1, line: 'band', fs: 'top', ack: 'filled', prof: 'card', sect: 'fill',
      rule: 'Крестик — как в Б. Подвал отделён всегда: полоса surface-container с чертой — видно, где кончается форма, и без прокрутки. Во весь экран — по MD3: действие в шапке, как в А. У слоёв над окном тонкая рамка outline-variant — нынешнее правило «Слои над окном» сохраняется отступлением. Меню профиля — карточка-поповер (форма 16) с SegmentedButton темы.' },
  };
  const V = VARS[window.VARIANT || 'a'];
  document.body.classList.add('v-' + V.key);
  const ST = { theme: new URLSearchParams(location.search).get('theme') === 'dark' ? 'dark' : 'light' };

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c) => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}'>${s(n)}</span>`;
  const btn = (t, v, n) => `<span class='btn ${v}'>${n ? s(n) : ''}${t}</span>`;
  const tf = (label, value, o = {}) => `<div class='tf${o.on ? ' on' : ''}'><label>${label}</label><span class='v${o.ph ? ' ph' : ''}'>${value}</span>${o.trail ? s(o.trail, 's24') : ''}${o.hint ? `<span class='hint'>${o.hint}</span>` : ''}</div>`;
  const cbx = (t, on) => `<div class='cbx${on ? ' on' : ''}'><i></i>${t}</div>`;

  /* окно: o.w, title, body, foot, note, scroll ('top' | 'mid'), noCross, closeFoot (выход в подвале у окна без подвала) */
  const win = (o) => {
    const cross = V.cross && !o.noCross;
    const lineTop = V.line === 'scroll' && o.scroll === 'mid';
    const lineBot = V.line === 'scroll' && !!o.scroll;
    let foot = o.foot || '';
    if (!foot && o.pickerFoot && !V.cross) foot = btn('Закрыть', 'text');
    return `<div class='win w${o.w}' role='dialog' style='${o.style || ''}'>` +
      `<div class='hd${lineTop ? ' ln' : ''}'><h2>${o.title}</h2>${cross ? ib('close', 'Закрыть') : ''}</div>` +
      `<div class='bd${o.scroll ? ' sc' : ''}' style='${o.bodyStyle || ''}'>${o.body}</div>` +
      (foot ? `<div class='ft${lineBot ? ' ln' : ''}'>${o.note ? `<span class='fnote'>${o.note}</span>` : ''}${foot}</div>` : (o.pickerFoot ? `<div style='height:24px;flex:none'></div>` : '')) +
      `</div>`;
  };
  const over = (inner, z2) => `<div class='scr${z2 ? ' z2' : ''}'></div><div class='ctr${z2 ? ' z2' : ''}'>${inner}</div>`;

  const RAIL = [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['apartment', 'Стройки'],
    ['folder_open', 'Комплекты'], ['table_chart', 'Таблицы'], ['settings', 'Настройки']];
  const rail = (on) => `<nav class='rail'>` + RAIL.map(([n, t]) =>
    `<div class='it${t === on ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const laptop = (label, on, inner, top = '', theme) => `<div class='md3' data-theme='${theme || ST.theme}' data-screen-label='${label}'><div class='app laptop'>${rail(on)}<div class='work'>${inner}</div>${top}</div></div>`;
  const phone = (label, inner, theme) => `<div class='md3' data-theme='${theme || ST.theme}' data-screen-label='${label}'><div class='app phone'>${inner}</div></div>`;
  const cap = (t) => `<div class='cap'>${t}</div>`;
  const sec = (h, t, body) => `<h2>${h}</h2>${t ? cap(t) : ''}${body}`;

  /* ---- реестр счетов (фон) ---- */
  const ICO = { ok: 'check_circle', warn: 'warning', err: 'error', q: '' };
  const stx = (k, t) => `<span class='st ${k}'>${ICO[k] ? s(ICO[k]) : ''}${t}</span>`;
  const ROWS = [['1021', 'ЭТМ «Север»', '30.10.2026', '412 560,00', ['q', 'Черновик']],
    ['1020', 'Кабельный завод «Проводник»', '28.10.2026', '1 284 900,00', ['err', 'Не распознан']],
    ['1019', 'ООО «Электромонтаж»', '27.10.2026', '96 300,00', ['q', 'Ждёт оплаты']],
    ['1018', 'АО «Светотехника»', '25.10.2026', '238 017,40', ['warn', 'Расхождение сумм']],
    ['1017', 'ЭТМ «Север»', '24.10.2026', '57 840,00', ['ok', 'Оплачен']],
    ['1016', 'ИП Семёнов', '22.10.2026', '18 600,00', ['ok', 'Оплачен']],
    ['1015', 'Кабельный завод «Проводник»', '21.10.2026', '742 115,00', ['q', 'Закрытый период']],
    ['1014', 'АО «Светотехника»', '20.10.2026', '11 270,00', ['ok', 'Оплачен']],
    ['1013', 'ООО «Электромонтаж»', '19.10.2026', '64 080,00', ['ok', 'Оплачен']],
    ['1012', 'ЭТМ «Север»', '17.10.2026', '7 950,00', ['ok', 'Оплачен']]];
  const registry = (o = {}) => `<div class='ph'><h1>Счета</h1><span class='sub'>ЖК «Северный», корпус 2</span><span class='sp'></span>` +
    `<span class='search'>${s('search')}Поиск по номеру и поставщику</span>${btn('Распознать пакет', 'tonal', 'upload_file')}${ib('account_circle', 'Профиль', o.prof ? 'sel' : '')}</div>` +
    `<div class='tblw'><table class='g'><colgroup><col style='width:72px'><col><col style='width:120px'><col style='width:150px'><col style='width:220px'><col style='width:48px'></colgroup>` +
    `<tr><th>№</th><th>Поставщик</th><th>Дата</th><th class='num'>Сумма, ₽</th><th>Состояние</th><th></th></tr>` +
    ROWS.map((r, i) => `<tr${o.sel === i ? " class='sel'" : ''}><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class='num'>${r[3]}</td><td>${stx(...r[4])}</td>` +
      `<td class='acts'><div>${ib('more_vert', 'Действия', 'dense' + (o.menu === i ? ' sel' : ''))}</div></td></tr>`).join('') + `</table></div>`;

  /* ---- 1. окно формы, список над окном, вопрос над окном ---- */
  const payWin = () => win({ w: 512, title: 'Оплата: Счёт № 1018 от 25.10.2026',
    body: `<p>АО «Светотехника» · к оплате <span class='on-s'>238 017,40 ₽</span></p>` +
      tf('Дата платежа', '30.10.2026', { trail: 'calendar_today' }) +
      `<div class='row2'>${tf('Сумма, ₽', '238 017,40')}${tf('Платёжный документ', 'п/п № 4417', { hint: 'необязательно; можно дописать позже' })}</div><div style='height:12px'></div>`,
    foot: btn('Отмена', 'text') + btn('Внести оплату', 'filled') });
  const UNITS = ['шт', 'м', 'км', 'кг', 'компл', 'упак'];
  const stepWin = () => win({ w: 512, title: 'Новая позиция номенклатуры', scroll: 'top',
    body: tf('Вид', 'Кабель силовой', { trail: 'arrow_drop_down' }) + tf('Наименование', 'Кабель ВВГнг(А)-LS 5×16') +
      `<div class='row2'>${tf('Артикул', 'ВВГ-516', {})}${tf('Единица измерения', 'м', { on: 1, trail: 'arrow_drop_up' })}</div>` + tf('Группа', '— не выбрано —', { ph: 1, trail: 'arrow_drop_down' }),
    foot: btn('Назад', 'text') + btn('Создать позицию', 'filled') });
  const unitList = (style) => `<div class='lay mn' role='listbox' style='position:absolute;z-index:3;width:224px;${style}'>` +
    UNITS.map(u => `<div class='mi${u === 'м' ? ' cur' : ''}${u === 'км' ? ' hov' : ''}'><span class='t'>${u}</span>${u === 'м' ? s('check', 's24 chk') : ''}</div>`).join('') + `</div>`;
  const formScreen = (theme) => laptop(`Окно формы (${theme === 'dark' ? 'тёмная' : 'светлая'})`, 'Счета', registry(), over(payWin()), theme);
  const listScreen = (theme) => laptop(`Список над окном (${theme === 'dark' ? 'тёмная' : 'светлая'})`, 'Счета', registry(),
    over(`<div style='position:relative'>${stepWin()}${unitList('left:264px;top:286px')}</div>`), theme);
  const askScreen = (theme) => laptop(`Вопрос над окном (${theme === 'dark' ? 'тёмная' : 'светлая'})`, 'Счета', registry(),
    over(payWin()) + over(win({ w: 384, noCross: 1, title: 'Закрыть без сохранения?', body: '<p>Несохранённые изменения будут потеряны.</p>',
      foot: btn('Продолжить редактирование', 'text') + btn('Закрыть', 'filled danger') }), 1), theme);

  /* ---- 2. «да / нет», ответ, окно без подвала ---- */
  const confirmShort = () => win({ w: 384, noCross: 1, title: 'Скопировать «Кабельный журнал» в «ЖК Северный, корпус 2»?',
    body: '<p>Шаблон и его версии появятся в комплекте. Документы, уже собранные по шаблону, не изменятся.</p>',
    foot: btn('Отмена', 'text') + btn('Скопировать', 'filled') });
  const CASC = ['4 раздела: «Электроосвещение», «Силовое электрооборудование», «Слаботочные сети», «Наружное освещение»',
    '18 комплектов исполнительной документации и 312 документов в них', '47 счетов и 21 накладная этой стройки', 'Наборы данных стройки: 6',
    'Привязки документов качества: 129', 'Файлы во хранилище: 1,8 ГБ', 'Журнал изменений стройки сохранится'];
  const confirmLong = () => win({ w: 384, noCross: 1, scroll: 'mid', title: 'Удалить стройку «ЖК Северный, корпус 2»?', style: 'height:470px',
    body: `<p>Удаление необратимо. Вместе со стройкой будут удалены:</p><ul class='casc'>${CASC.map(c => `<li>${c}</li>`).join('')}</ul>` + cbx('Понимаю, что удаление необратимо', 1),
    foot: btn('Отмена', 'text') + btn('Удалить', 'filled danger') });
  const ack = () => win({ w: 384, noCross: 1, title: 'Пакет распознан',
    body: '<p>Распознано 7 из 8 файлов. Файл «scan_0412.pdf» не похож на счёт — он остался в пакете без счёта.</p>',
    foot: btn('Понятно', V.ack) });
  const PICK = [['apartment', 'ЖК «Северный», корпус 2', 'ул. Строителей, 14'], ['apartment', 'ЖК «Северный», корпус 3', 'ул. Строителей, 16'],
    ['apartment', 'Школа на 825 мест', 'мкр. Солнечный'], ['apartment', 'ТП-1042 и наружные сети', 'мкр. Солнечный']];
  const picker = () => win({ w: 512, title: 'Выбрать объект', pickerFoot: 1,
    body: `<span class='search' style='width:auto;background:var(--schh)'>${s('search')}Название или адрес</span>` +
      PICK.map(([n, t, a], i) => `<div class='li' style='min-height:56px;padding-left:0;border:0${i === 1 ? ';background:color-mix(in srgb,var(--on-surface) 8%,transparent);border-radius:8px' : ''}'>${s(n, 's24')}<div class='b'><div class='on-s'>${t}</div><div class='t-bs'>${a}</div></div></div>`).join('') });
  const stageDialogs = () => `<div class='md3' data-theme='${ST.theme}' data-screen-label='Да / нет, ответ, пикер'><div class='stage'><div class='scr'></div>` +
    confirmShort() + confirmLong() + `<div style='display:flex;flex-direction:column;gap:24px;position:relative;z-index:1'>${ack()}</div>` + picker() + `</div></div>`;

  /* ---- 3. во весь экран и телефон ---- */
  const OBJ = ['Корпус 2', 'Корпус 3', 'Паркинг', 'Наружные сети'];
  const MATRIX = [['Кабель ВВГнг(А)-LS 5×16', '1 240 м', ['820', '420', '—', '—']], ['Кабель ВВГнг(А)-LS 3×2,5', '6 800 м', ['3 400', '3 400', '—', '—']],
    ['Светильник LED 36 Вт', '412 шт', ['180', '200', '32', '—']], ['Автоматический выключатель С16', '96 шт', ['40', '40', '16', '—']],
    ['Лоток перфорированный 200×50', '310 м', ['120', '110', '80', '—']], ['Труба гофрированная ПНД 25', '2 400 м', ['—', '—', '—', '2 400']],
    ['Щит ЩРн-24', '12 шт', ['6', '6', '—', '—']]];
  const fsTop = (title, act, lead = 'close') => `<div class='tb'>${ib(lead, lead === 'close' ? 'Закрыть' : 'Назад')}<h2>${title}</h2>${V.fs === 'top' ? act : ''}</div>`;
  const fsFoot = (note, acts) => V.fs === 'foot' ? `<div class='ff ln'>${note ? `<span class='fnote'>${note}</span>` : ''}${acts}</div>` : '';
  const allocation = () => laptop('Во весь экран: разноска', 'Счета', registry(), `<div class='fsd'>` +
    fsTop('Разноска по объектам · Счёт № 1018', btn('Сохранить разноску', 'text')) +
    (V.fs === 'top' ? `<div class='subl'>Разнесено 238 017,40 из 238 017,40 ₽ · 7 строк</div>` : '') +
    `<div class='fb'><table class='g'><colgroup><col><col style='width:120px'>${OBJ.map(() => "<col style='width:150px'>").join('')}</colgroup>` +
    `<tr><th>Строка счёта</th><th class='num'>Всего</th>${OBJ.map(o => `<th class='num'>${o}</th>`).join('')}</tr>` +
    MATRIX.map(r => `<tr><td>${r[0]}</td><td class='num'>${r[1]}</td>${r[2].map(c => `<td class='num'>${c}</td>`).join('')}</tr>`).join('') + `</table></div>` +
    fsFoot('Разнесено 238 017,40 из 238 017,40 ₽ · 7 строк', btn('Закрыть', 'text') + btn('Сохранить разноску', 'filled')) + `</div>`);
  const phonePos = () => phone('Телефон: окно формы', `<div class='fsd'>` + fsTop('Позиция номенклатуры', btn('Сохранить', 'text')) +
    `<div class='fb'>${tf('Наименование', 'Кабель ВВГнг(А)-LS 5×16')}${tf('Артикул', 'ВВГ-516')}${tf('Единица измерения', 'м', { trail: 'arrow_drop_down' })}` +
    `${tf('Группа', 'Кабельная продукция', { trail: 'arrow_drop_down' })}<div>${btn('Новая позиция номенклатуры', 'text', 'add')}</div></div>` +
    fsFoot('', btn('Отмена', 'text') + btn('Сохранить', 'filled')) + `</div>`);
  const phoneStep = () => phone('Телефон: шаг окна', `<div class='fsd'>` + fsTop('Новая позиция номенклатуры', btn('Создать', 'text'), 'arrow_back') +
    `<div class='fb'>${tf('Вид', 'Кабель силовой', { trail: 'arrow_drop_down' })}${tf('Наименование', 'Кабель ВВГнг(А)-LS 5×16')}${tf('Артикул', '', { ph: 1 })}${tf('Единица измерения', 'м', { trail: 'arrow_drop_down' })}</div>` +
    fsFoot('', btn('Назад', 'text') + btn('Создать позицию', 'filled')) + `</div>`);
  const phoneConfirm = () => phone('Телефон: да / нет', `<div class='ptop'>${ib('menu', 'Меню')}<h1>Счёт № 1018</h1>${ib('more_vert', 'Действия')}</div>` +
    `<div class='pbody'>${ROWS.slice(0, 7).map(r => `<div class='li'><div class='b'><div>№ ${r[0]} · ${r[1]}</div><div class='t-bs muted'>${r[2]} · ${r[3]} ₽</div></div></div>`).join('')}</div>` +
    `<div class='scr'></div><div class='ctr' style='width:327px'>${win({ w: 384, noCross: 1, title: 'Удалить счёт № 1018?', style: 'width:327px',
      body: '<p>Счёт, его строки и разноска будут удалены. Файл счёта останется в пакете.</p>', foot: btn('Отмена', 'text') + btn('Удалить', 'filled danger') })}</div>`);

  /* ---- 4. меню ---- */
  const rowMenu = (style) => `<div class='lay mn dense' role='menu' style='position:absolute;z-index:12;${style}'>` +
    `<div class='mi hov'>${s('open_in_new')}<span class='t'>Открыть</span></div>` +
    `<div class='mi'>${s('content_copy')}<span class='t'>Скопировать номер</span><span class='tr'>Ctrl+C</span></div>` +
    `<div class='mi'>${s('call_split')}<span class='t'>Разнести по объектам</span>${s('chevron_right', 's24')}</div>` +
    `<div class='mi dis'>${s('payments')}<span class='t'>Внести оплату</span></div><div class='msep'></div>` +
    `<div class='mi'>${s('block')}<span class='t'>Отклонить…</span></div>` +
    `<div class='mi danger'>${s('delete')}<span class='t'>Удалить счёт…</span></div></div>`;
  const SECT = [['receipt_long', 'Реестр счетов'], ['local_shipping', 'Накладные'], ['fact_check', 'Сверка'], ['category', 'Статьи затрат'], ['inventory_2', 'Номенклатура']];
  const sectMenu = () => `<div class='lay mn' role='menu'><div class='mlab'>Счета и накладные</div>` + SECT.map(([n, t], i) => {
    const cur = i === 0;
    return `<div class='mi${cur && V.sect === 'fill' ? ' cur' : ''}'>${s(n)}<span class='t'>${t}</span>${cur && V.sect === 'check' ? s('check', 's24 chk') : ''}</div>`;
  }).join('') + `</div>`;
  const THEMES = [['light_mode', 'Светлая'], ['dark_mode', 'Тёмная'], ['brightness_auto', 'Авто']];
  const profMenu = () => V.prof === 'card'
    ? `<div class='lay pcard' role='dialog'><div class='who'><span class='ava'>ИП</span><div><div class='n'>Иван Петров</div><div class='t-bs muted'>Инженер ПТО</div></div></div>` +
      `<div class='mlab'>Оформление</div><div class='seg'>${THEMES.map(([n, t], i) => `<span class='${i === 1 ? 'on' : ''}'>${t}</span>`).join('')}</div><div class='msep'></div>` +
      `<div class='mi'>${s('person')}<span class='t'>Профиль и пароль</span></div><div class='mi'>${s('bug_report')}<span class='t'>Сообщить о проблеме</span></div>` +
      `<div class='mi'>${s('admin_panel_settings')}<span class='t'>Администрирование</span></div><div class='msep'></div><div class='mi'>${s('logout')}<span class='t'>Выйти</span></div><div class='mfoot'>Версия 2.54.0</div></div>`
    : `<div class='lay mn' role='menu' style='width:280px'><div class='who'><span class='ava'>ИП</span><div><div class='n'>Иван Петров</div><div class='t-bs muted'>Инженер ПТО</div></div></div>` +
      `<div class='mi'>${s('person')}<span class='t'>Профиль и пароль</span></div><div class='msep'></div><div class='mlab'>Оформление</div>` +
      THEMES.map(([n, t], i) => `<div class='mi'>${s(n)}<span class='t'>${t}</span>${i === 1 ? s('check', 's24 chk') : ''}</div>`).join('') +
      `<div class='msep'></div><div class='mi'>${s('bug_report')}<span class='t'>Сообщить о проблеме</span></div><div class='mi'>${s('admin_panel_settings')}<span class='t'>Администрирование</span></div>` +
      `<div class='msep'></div><div class='mi'>${s('logout')}<span class='t'>Выйти</span></div><div class='mfoot'>Версия 2.54.0</div></div>`;
  const ZOOM = ['По ширине', 'Страница целиком', '—', '50 %', '75 %', '100 %', '150 %', '200 %'];
  const zoomMenu = () => `<div class='lay mn dense' role='menu'>` + ZOOM.map(z => z === '—' ? `<div class='msep'></div>` :
    `<div class='mi'><span class='sym s24'>${z === 'По ширине' ? 'check' : ''}</span><span class='t'>${z}</span></div>`).join('') + `</div>`;
  const menusBoard = (theme) => `<div class='md3' data-theme='${theme}' data-screen-label='Меню (${theme === 'dark' ? 'тёмная' : 'светлая'})'><div class='board2'>` +
    `<div class='col'><span class='h'>Меню раздела · пункт 48</span>${sectMenu()}</div>` +
    `<div class='col'><span class='h'>Меню профиля</span>${profMenu()}</div>` +
    `<div class='col'><span class='h'>Масштаб просмотрщика · плотное 40</span>${zoomMenu()}</div>` +
    `<div class='col'><span class='h'>Действия строки · плотное 40</span>${rowMenu('position:static')}</div></div></div>`;
  const rowMenuScreen = () => laptop('Меню действий строки', 'Счета', registry({ menu: 3, sel: 3 }), rowMenu('right:20px;top:286px'));
  const menuOverWin = (theme) => laptop(`Меню над окном (${theme === 'dark' ? 'тёмная' : 'светлая'})`, 'Счета', registry(),
    over(`<div style='position:relative'>${win({ w: 512, title: 'Строки счёта № 1018', scroll: 'top',
      body: `<table class='g'><colgroup><col><col style='width:90px'><col style='width:48px'></colgroup><tr><th>Наименование</th><th class='num'>Кол-во</th><th></th></tr>` +
        MATRIX.slice(0, 5).map((r, i) => `<tr${i === 4 ? " class='sel'" : ''}><td>${r[0]}</td><td class='num'>${r[1]}</td><td class='acts'><div>${ib('more_vert', 'Действия', 'dense' + (i === 4 ? ' sel' : ''))}</div></td></tr>`).join('') + `</table>`,
      foot: btn('Закрыть', 'text') + btn('Сохранить', 'filled') })}${rowMenu('left:300px;top:352px')}</div>`), theme);

  /* ---- 5. листы ---- */
  const KV = [['Номер', '1018'], ['Поставщик', 'АО «Светотехника»'], ['Дата', '25.10.2026'], ['Сумма, ₽', '238 017,40'], ['НДС', 'в т. ч. 20 %'], ['Раздел', 'Электроосвещение'], ['Состояние', stx('warn', 'Расхождение сумм')]];
  const rowSheetBody = () => KV.map(([k, v], i) => (i ? `<div class='dv'></div>` : '') + `<div class='kv'><span class='k'>${k}</span><span class='val'>${v}</span></div>`).join('');
  const tablePage = () => `<div class='ph'><h1>Таблица: Счета</h1><span class='sub'>все стройки</span><span class='sp'></span>${btn('Представление', 'text', 'view_column')}</div>` +
    `<div class='split'><div class='pane'><div class='tblw'><table class='g'><colgroup><col style='width:72px'><col><col style='width:120px'><col style='width:150px'></colgroup>` +
    `<tr><th>№</th><th>Поставщик</th><th>Дата</th><th class='num'>Сумма, ₽</th></tr>` +
    ROWS.map((r, i) => `<tr${i === 3 ? " class='sel'" : ''}><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class='num'>${r[3]}</td></tr>`).join('') + `</table></div></div>` +
    `<aside class='ss' aria-label='Строка: счёт'><div class='sh'><h3>Строка: счёт № 1018</h3>${ib('open_in_new', 'Открыть запись')}${ib('close', 'Закрыть строку')}</div><div class='sb'>${rowSheetBody()}</div></aside></div>`;
  const FACTS = [['ok', 'check_circle', 'Распознан', 'по профилю «Счёт на оплату», 22 строки'], ['warn', 'warning', 'Расхождение сумм', 'строки дают 236 777,40 ₽, итог счёта — 238 017,40 ₽'],
    ['warn', 'warning', '3 строки без раздела', 'разнесите их по разделам или весь счёт на раздел'], ['q', 'schedule', 'Оплата не внесена', 'ждёт оплаты с 25.10.2026'], ['ok', 'link', 'Накладная № 772 связана', 'принято 22 из 22 строк']];
  const factsBody = () => FACTS.map(([k, n, t, d], i) => (i ? `<div class='dv inset'></div>` : '') + `<div class='fact ${k}'>${s(n)}<div class='b'><div class='t1'>${t}</div><div class='t2'>${d}</div></div></div>`).join('');
  const invoiceBg = () => `<div class='ph'>${ib('arrow_back', 'Назад')}<h1>Счёт № 1018</h1><span class='sub'>АО «Светотехника» · 25.10.2026</span><span class='sp'></span>${btn('Состояние счёта', 'tonal', 'checklist')}${btn('Сохранить', 'filled')}</div>` +
    `<div class='tblw'><table class='g'><colgroup><col><col style='width:120px'><col style='width:120px'><col style='width:150px'></colgroup><tr><th>Наименование</th><th class='num'>Кол-во</th><th class='num'>Цена</th><th class='num'>Сумма, ₽</th></tr>` +
    MATRIX.map(r => `<tr><td>${r[0]}</td><td class='num'>${r[1]}</td><td class='num'>—</td><td class='num'>—</td></tr>`).join('') + `</table></div>`;
  const modalSheet = () => laptop('Modal side sheet', 'Счета', invoiceBg(), `<div class='scr'></div><aside class='ss modal' role='dialog' aria-label='Состояние счёта'><div class='sh'><h3>Состояние счёта</h3>${ib('close', 'Закрыть')}</div><div class='sb'>${factsBody()}</div></aside>`);
  const phoneBottom = () => phone('Телефон: bottom sheet', `<div class='ptop'>${ib('arrow_back', 'Назад')}<h1>Счёт № 1018</h1>${ib('checklist', 'Состояние счёта', 'sel')}</div>` +
    `<div class='pbody'>${MATRIX.map(r => `<div class='li'><div class='b'><div>${r[0]}</div><div class='t-bs muted'>${r[1]}</div></div></div>`).join('')}</div>` +
    `<div class='scr'></div><div class='bs' role='dialog' aria-label='Состояние счёта'><div class='hdl'><i></i></div><div class='sh'><h3>Состояние счёта</h3>${ib('close', 'Закрыть')}</div><div class='sb'>${factsBody()}</div></div>`);
  const phoneRow = () => phone('Телефон: standard во весь экран', `<aside class='ss full' aria-label='Строка: счёт'><div class='sh' style='padding-left:4px'>${ib('close', 'Закрыть строку')}<h3 style='margin-left:8px'>Строка: счёт № 1018</h3>${ib('open_in_new', 'Открыть запись')}</div><div class='sb'>${rowSheetBody()}</div></aside>`);

  /* ---- 6. карточки ---- */
  const cardsBoard = (theme) => `<div class='md3' data-theme='${theme}' data-screen-label='Карточки (${theme === 'dark' ? 'тёмная' : 'светлая'})'><div class='cards'>` +
    `<div class='card out'><div class='ch'><h4>Шаг 1. Реквизиты счёта</h4>${ib('more_vert', 'Действия')}</div><div class='cbd'>${tf('Номер', '1018')}${tf('Дата', '25.10.2026', { trail: 'calendar_today' })}</div></div>` +
    `<div class='card fil'><div class='ch'><h4>Итоги счёта</h4></div><div class='cbd'><div><div class='t-bs'>Сумма с НДС</div><div class='big'>238 017,40 ₽</div></div><div><div class='t-bs'>НДС 20 %</div><div class='on-s' style='color:var(--on-surface)'>39 669,57 ₽</div></div></div></div>` +
    `<div class='card elv'><div class='ch'><h4>Смета: ЖК «Северный»</h4>${ib('more_vert', 'Действия')}</div><div class='cbd'><div>Текущая версия 4 от 12.10.2026 · 1 214 позиций</div></div><div class='ca'>${btn('Сравнить', 'text')}${btn('Открыть', 'tonal')}</div></div>` +
    `<div class='card out hov'><div class='ch'>${s('apartment', 's24')}<h4>ЖК «Северный», корпус 2</h4></div><div class='cbd'><div>ул. Строителей, 14</div><div>4 раздела · 18 комплектов</div></div></div>` +
    `</div></div>`;

  /* ---- лист ---- */
  const nav = `<span class='nav'><a href='00 Разбор и вопрос.html'>0 Разбор и вопрос</a>` + Object.values(VARS).map(x =>
    `<a href='${x.name} - ${x.title}.html'${x.key === V.key ? " class='cur'" : ''}>${x.name} ${x.title}</a>`).join('') + `</span>`;
  const ctl = `<div class='ctl'><button data-th='light' class='${ST.theme === 'light' ? 'on' : ''}'>Светлая</button><button data-th='dark' class='${ST.theme === 'dark' ? 'on' : ''}'>Тёмная</button>${nav}</div>`;
  const both = (fn) => `<div class='two'>${fn('light')}${fn('dark')}</div>`;

  document.getElementById('root').innerHTML = ctl +
    `<h1>${V.name} — ${V.title}</h1><div class='lead'><p>${V.rule}</p><p class='muted'>Одинаково на всех трёх листах: окно — форма 28, уровень 3, surface-container-high, заголовок headline-small, действия справа, filled — одна; меню — форма 4, уровень 2, пункт 48 (плотное 40), знак 24; листы и карточки по дельте [UI-77]. Переключатель вверху меняет тему у экранов без пометки темы.</p></div>` +
    sec('1. Окно формы', 'Обычное окно 512 над реестром. Тело помещается — черт нет ни в одном варианте; в В подвал отделён полосой всегда.', both(formScreen)) +
    sec('2. Список, свисающий с окна', 'Шаг «Новая позиция номенклатуры»: открыт список «Единица измерения» у нижнего края окна, он свисает на затемнение. Тело прокручено вверх — в А и Б черта только над подвалом. Главный риск — тёмная тема: слой без рамки над окном.', both(listScreen)) +
    sec('3. Вопрос над окном', '«Закрыть без сохранения?» — тот же basic dialog поверх окна, со своим затемнением; окно под ним неактивно. Крестика у вопроса нет ни в одном варианте.', both(askScreen)) +
    sec('4. «Да / нет», ответ и пикер', 'Слева направо: короткое подтверждение с длинным заголовком на 384; удаление стройки с каскадом — тело прокручено до середины; ответ «Понятно»; пикер без подвала «Выбрать объект».', stageDialogs()) +
    sec('5. Меню над окном', 'Меню «⋮» строки в окне: слой свисает за край окна.', both(menuOverWin)) +
    sec('6. Меню', 'Все меню — один компонент. Знак 24; отключённый пункт — 38 %; «Удалить счёт…» — error (как сегодня). Масштаб: отмеченный пункт — галочка.', both(menusBoard) + cap('Меню «⋮» строки реестра — плотное 40:') + rowMenuScreen()) +
    sec('7. Окно во весь экран и телефон', `Разноска по объектам (fullScreen) и окно 512 на 375 px. ${V.fs === 'top' ? 'Главное действие — текстом в шапке; пояснение подвала уходит строкой под шапку.' : 'Шапка — крестик и заголовок; подвал с пояснением и действиями остаётся внизу.'} У шага — стрелка «Назад» вместо крестика. «Да / нет» на телефоне остаётся basic dialog.`,
      allocation() + `<div class='row' style='margin-top:16px'>${phonePos()}${phoneStep()}${phoneConfirm()}</div>`) +
    sec('8. Листы', 'Standard side sheet — панель строки таблицы: таблица сдвинута, затемнения нет. Modal side sheet — «Состояние счёта» (вариант Г экрана счёта): затемнение, уровень 1, ведущие углы 16. На телефоне modal — bottom sheet с ручкой, standard — во весь экран. Листы одинаковы во всех вариантах.',
      laptop('Standard side sheet', 'Таблицы', tablePage()) + `<div style='height:16px'></div>` + modalSheet() + `<div class='row' style='margin-top:16px'>${phoneBottom()}${phoneRow()}</div>`) +
    sec('9. Карточки', 'Outlined (12, outline-variant), filled (surface-container-highest), elevated (surface-container-low, уровень 1) и кликабельная outlined под наведением — слой состояния и уровень 1. Одинаковы во всех вариантах.', both(cardsBoard));

  document.querySelectorAll('.ctl button[data-th]').forEach(b => b.onclick = () => {
    const u = new URL(location.href); u.searchParams.set('theme', b.dataset.th); location.href = u.toString();
  });
})();
