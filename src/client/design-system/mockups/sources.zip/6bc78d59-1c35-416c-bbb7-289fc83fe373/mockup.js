/* Поле даты: обвязка size md/sm, границы min/max, диапазон (#1464). Рамки повторяют Select (h-9 / h-7,
   rounded-md, border-stroke-strong), календарь — Calendar после #1552 (строка действий «Очистить» /
   «Сегодня»). Состояния и цифры — по §71 разбора Дизайнера. «Сегодня» во всех кадрах — 21.10.2026. */
(function () {
  var h = React.createElement, F = React.Fragment;
  var TODAY = '2026-10-21';

  /* ── значки: прямоугольник и линии, как lucide ── */
  function svg(size, kids) {
    return h('svg', { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' }, kids);
  }
  function CalIcon(p) {
    return svg(p.size || 16, [h('rect', { key: 1, x: 3, y: 5, width: 18, height: 16, rx: 2 }), h('line', { key: 2, x1: 3, y1: 10, x2: 21, y2: 10 }),
      h('line', { key: 3, x1: 8, y1: 3, x2: 8, y2: 7 }), h('line', { key: 4, x1: 16, y1: 3, x2: 16, y2: 7 })]);
  }
  function XIcon(p) { return svg(p.size || 16, [h('line', { key: 1, x1: 6, y1: 6, x2: 18, y2: 18 }), h('line', { key: 2, x1: 18, y1: 6, x2: 6, y2: 18 })]); }
  function Chev(p) {
    var d = { l: '15 6 9 12 15 18', r: '9 6 15 12 9 18', d: '6 9 12 15 18 9' }[p.dir];
    return svg(p.size || 16, h('polyline', { points: d }));
  }

  /* ── даты ── */
  function iso(y, m, d) { return y + '-' + String(m).padStart(2, '0') + '-' + String(d).padStart(2, '0'); }
  var MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
  var SHORT = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'];
  var WEEK = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

  /* ── сегменты ДД.ММ.ГГГГ ── */
  var PH = { d: 'ДД', m: 'ММ', y: 'ГГГГ' };
  function Segs(p) {
    var g = /^(\d{4})-(\d{2})-(\d{2})/.exec(p.value || '');
    var all = { d: g ? g[3] : '', m: g ? g[2] : '', y: g ? g[1] : '' };
    if (p.parts) all = p.parts;
    var order = p.precision === 'month' ? ['m', 'y'] : ['d', 'm', 'y'];
    return h('span', { className: 'seg' + (p.err ? ' err' : '') }, order.map(function (k, i) {
      return h(F, { key: k }, i > 0 ? h('span', { className: 'sep' }, '.') : null,
        h('span', { className: (all[k] ? '' : 'ph') + (p.selFirst && i === 0 ? ' sel' : '') }, all[k] || PH[k]));
    }));
  }

  /* ── обвязка: рамка, сегменты, хвост (× только у md и только по наведению/фокусу) ── */
  function Box(p) {
    var size = p.size || 'md';
    var st = p.state || 'rest';
    var active = st === 'hover' || st === 'focus';
    var showX = size === 'md' && !p.required && !p.ro && !!(p.value || p.parts) && active;
    var cls = 'bx ' + size + (st === 'focus' || st === 'open' ? ' foc' : '') + (p.err ? ' err' : '') + (p.ro ? ' ro' : '') + (p.flash ? ' flash' : '');
    var icon = size === 'sm' ? 14 : 16;
    return h('span', { className: cls, style: { width: p.w } },
      p.prefix ? h('span', { className: 'pre' }, p.prefix) : null,
      h('span', { className: 'fill' }, p.range
        ? h('span', { className: 'seg' }, h(Segs, { value: p.value }), h('span', { className: 'sep', style: { padding: '0 6px' } }, '–'), h(Segs, { value: p.value2 }))
        : h(Segs, { value: p.value, parts: p.parts, precision: p.precision, err: p.err, selFirst: st === 'focus' && !!p.value })),
      h('span', { className: 'tail' },
        showX ? h('span', { className: 'ib' + (st === 'hover' ? ' hov' : '') }, h(XIcon, { size: icon }),
          st === 'hover' && !p.notip ? h('span', { className: 'tip' }, 'Очистить дату') : null,
          st === 'hover' ? h('span', { className: 'cursor' }) : null) : null,
        p.ro ? null : h('span', { className: 'ib' + (st === 'open' ? ' hov' : '') }, h(CalIcon, { size: icon }))));
  }
  function Sel(p) {
    return h('span', { className: 'sl ' + (p.size || 'md'), style: { width: p.w } }, h('span', null, p.text), h(Chev, { dir: 'd', size: p.size === 'sm' ? 14 : 15 }));
  }

  /* ── календарь: дни вне min/max неактивны, фокус и стрелки в них не заходят ── */
  function Cal(p) {
    var y = p.y, m = p.m, min = p.min || '', max = p.max || '';
    var first = (new Date(y, m - 1, 1).getDay() + 6) % 7;
    var days = new Date(y, m, 0).getDate();
    // Предыдущий месяц целиком вне диапазона — если первое число этого не позже нижней границы.
    var low = p.offBefore && (!min || p.offBefore > min) ? p.offBefore : min;
    var prevOff = !!(low && iso(y, m, 1) <= low);
    var nextOff = !!(max && iso(y, m, days) >= max);
    var cells = [];
    for (var i = 0; i < first; i++) cells.push(h('span', { key: 'e' + i, className: 'dc' }));
    for (var d = 1; d <= days; d++) {
      var v = iso(y, m, d);
      var off = (min && v < min) || (max && v > max) || (p.offBefore && v < p.offBefore);
      var lo = p.band && p.band[0], hi = p.band && (p.band[1] || p.hover);
      var inBand = lo && hi && v >= lo && v <= hi && lo !== hi;
      var bandCls = inBand ? 'b' + (v === lo ? ' l' : v === hi ? ' r' : '') + (p.band && !p.band[1] ? ' pv' : '') : null;
      var n = 'n' + (v === TODAY ? ' today' : '') + (p.sel && p.sel.indexOf(v) >= 0 ? ' sel' : '') + (p.ring === v ? ' ring' : '') + (p.hover === v && !(p.sel && p.sel.indexOf(v) >= 0) ? ' hov' : '');
      cells.push(h('span', { key: d, className: 'dc' + (off ? ' off' : '') }, bandCls ? h('span', { className: bandCls }) : null, h('span', { className: n }, d)));
    }
    var foot = p.foot === false ? null : (p.clear || p.today !== false) ? h('div', { className: 'pf' },
      p.clear ? h('span', { className: 'tb' }, 'Очистить') : null,
      h('span', { className: 'sp' }),
      p.today === false ? null : h('span', { className: 'tb' + (p.todayOff ? ' off' : '') }, p.todayLabel || 'Сегодня')) : null;
    return h('div', { className: 'pop' + (p.sheet ? ' sheet' : '') },
      h('div', { className: 'ch' },
        h('span', { className: 't' }, MONTHS[m - 1] + ' ' + y, h(Chev, { dir: 'd', size: 14 })),
        h('span', { className: 'ar' }, h('span', { className: 'ab' + (prevOff ? ' off' : '') }, h(Chev, { dir: 'l' })), h('span', { className: 'ab' + (nextOff ? ' off' : '') }, h(Chev, { dir: 'r' })))),
      p.hint ? h('div', { style: { fontSize: 12, color: 'var(--f-brand)', padding: '0 8px 6px' } }, p.hint) : null,
      h('div', { className: 'wk' }, WEEK.map(function (w) { return h('span', { key: w }, w); })),
      h('div', { className: 'gd' }, cells),
      foot);
  }
  function MonthCal(p) {
    var y = p.y, min = p.min || '', max = p.max || '';
    return h('div', { className: 'pop' },
      h('div', { className: 'ch' }, h('span', { className: 't' }, String(y), h(Chev, { dir: 'd', size: 14 })),
        h('span', { className: 'ar' }, h('span', { className: 'ab' + (min && String(y) <= min.slice(0, 4) ? ' off' : '') }, h(Chev, { dir: 'l' })),
          h('span', { className: 'ab' + (max && String(y) >= max.slice(0, 4) ? ' off' : '') }, h(Chev, { dir: 'r' })))),
      h('div', { className: 'mg' }, SHORT.map(function (s, i) {
        var v = iso(y, i + 1, 1);
        var off = (min && v < min.slice(0, 8) + '01') || (max && v > max.slice(0, 8) + '01');
        return h('span', { key: s, className: (off ? 'off' : '') + (p.sel === v ? ' sel' : '') + (TODAY.slice(0, 7) === v.slice(0, 7) && p.sel !== v ? ' today' : '') }, s);
      })),
      h('div', { className: 'pf' }, p.clear ? h('span', { className: 'tb' }, 'Очистить') : null, h('span', { className: 'sp' }), h('span', { className: 'tb' }, 'Этот месяц')));
  }

  /* ── разметка листа ── */
  function Cap(p) { return h('p', { className: 'cap' }, h('i', null, p.k), p.children); }
  function Opt(p) {
    return h('div', { className: 'dv-opt', id: p.id, style: { '--w': p.w + 'px' } },
      h('div', { className: 'dv-olabel' }, h('a', { className: 'dv-oid', href: '#' + p.id }, p.id), p.label),
      p.children,
      p.note ? h('p', { className: 'dv-note' }, p.note) : null);
  }
  function Frame(p) { return h('div', { className: 'frame' + (p.dark ? ' dk' : ''), 'data-theme': p.dark ? 'dark' : undefined, style: { width: p.w } }, p.children); }
  function Tag(k, t) { return h('span', { className: 'tag ' + k }, t); }

  /* ── 0. Общее: обвязка и границы ── */
  function StateRow(label, md, sm) {
    return h(F, { key: label }, h('span', { className: 'lbl' }, label), md, sm);
  }
  function Common() {
    var V = '2026-11-03';
    return h('section', { className: 'dv-turn', id: 't0' },
      h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t0' }, '0'), h('span', { className: 'dv-tname' }, 'Общее для всех вариантов — следует из правил')),
      h('p', { className: 'dv-tsub' }, h('b', null, 'Варианты различаются только диапазоном.'), ' Рамку обвязки, границы календаря и «Сегодня» вне диапазона правила docs/UI.md и прежние решения уже решают — здесь это показано для подтверждения.'),
      h('div', { className: 'dv-opts' },
        h(Opt, { id: '0a', w: 470, label: 'Обвязка size="md" и "sm" — как у Select',
          note: h(F, null, h('b', null, 'Рамку, высоту и кольцо рисует поле'), ', экраны своих рамок больше не рисуют. md — h-9, крестик по наведению и фокусу, как у поля формы. sm — h-7, ', h('b', null, 'без крестика'), ' (в отборе у чипа свой ×); видимый круг календаря 24 px, зона нажатия 32. Только чтение — фон muted, без календаря.') },
          h(Frame, { w: 470 },
            h('div', { className: 'states' },
              h('span', null), h('span', { className: 'h' }, 'md · h-9'), h('span', { className: 'h' }, 'sm · h-7'),
              StateRow('покой', h(Box, { size: 'md', value: V, w: 190 }), h(Box, { size: 'sm', value: V, w: 132 })),
              StateRow('наведение', h(Box, { size: 'md', value: V, state: 'hover', notip: true, w: 190 }), h(Box, { size: 'sm', value: V, state: 'hover', w: 132 })),
              StateRow('фокус', h(Box, { size: 'md', value: V, state: 'focus', w: 190 }), h(Box, { size: 'sm', value: V, state: 'focus', w: 132 })),
              StateRow('календарь открыт', h(Box, { size: 'md', value: V, state: 'open', w: 190 }), h(Box, { size: 'sm', value: V, state: 'open', w: 132 })),
              StateRow('пусто', h(Box, { size: 'md', w: 190 }), h(Box, { size: 'sm', w: 132 })),
              StateRow('ошибка', h(Box, { size: 'md', err: true, parts: { d: '31', m: '02', y: '2026' }, w: 190 }), h(Box, { size: 'sm', err: true, parts: { d: '31', m: '02', y: '2026' }, w: 132 })),
              StateRow('только чтение', h(Box, { size: 'md', value: V, ro: true, w: 190 }), h(Box, { size: 'sm', value: V, ro: true, w: 132 })),
              StateRow('рядом Select', h(Sel, { size: 'md', text: 'Все стройки', w: 190 }), h(Sel, { size: 'sm', text: 'Все стройки', w: 132 }))))),
        h(Opt, { id: '0b', w: 288, label: 'Дни вне min/max',
          note: h(F, null, 'min 10.10.2026, max 25.11.2026. Дни вне границ — ', h('b', null, '38 % непрозрачности'), ', без зачёркивания; стрелки ← и фокус по сетке в них не заходят. Стрелка «назад» неактивна: сентябрь целиком вне диапазона.') },
          h(Cal, { y: 2026, m: 10, min: '2026-10-10', max: '2026-11-25', sel: ['2026-10-14'], clear: true })),
        h(Opt, { id: '0c', w: 288, label: 'Точность «месяц»: месяцы вне границ',
          note: h(F, null, 'min 07.2026, max 03.2027. ', h('b', null, 'Сравнение — по точности'), ': min и значение усекаются до месяца, поэтому 07.2026 при min 15.07.2026 допустим. Годы вне границ гаснут так же.') },
          h(MonthCal, { y: 2026, min: '2026-07-01', max: '2027-03-01', sel: '2026-09-01', clear: true })),
        h(Opt, { id: '0d', w: 288, label: '«Сегодня» вне диапазона — скрыта',
          note: h(F, null, 'min 01.01.2027, сегодня 21.10.2026. ', h('b', null, 'Невыполнимое скрываем'), ': кнопка «Сегодня» не ставит другой день. Пустое поле открывается на ближайшей границе — январь 2027. У обязательного поля подвал пуст — строки нет совсем.') },
          h(Cal, { y: 2027, m: 1, min: '2027-01-01', clear: true, today: false })),
        h(Opt, { id: '0e', w: 300, label: 'Набрано вне границ — ошибку называет форма',
          note: h(F, null, 'Поле не отказывает и не откатывает (#1460): отдаёт дату, форма сразу проверяет ограничение типа и пишет ошибку под полем. ↑/↓ ходят по кругу, в границу не упираются.') },
          h(Frame, { w: 300 },
            h('div', null,
              h('p', { className: 'legend' }, 'Дата приёмки'),
              h(Box, { size: 'md', value: '2026-10-05', err: true, state: 'focus', w: 220 }),
              h('p', { className: 'msg err' }, 'Дата не ранее 10.10.2026')))))
    );
  }

  /* ── варианты диапазона ── */
  var FROM = '2026-10-12', TO = '2026-10-24';
  var VARIANTS = [
    { id: 'А', name: 'Два поля через тире', tag: Tag('ok', 'рекомендует Дизайнер'),
      sub: h(F, null, h('b', null, 'Два поля своего слоя и «—» между ними'), ', подпись группы — над парой (как «Учётный период» у затрат). В календаре «по» дни раньше «с» неактивны, сама «с» обведена кольцом. Набранная с клавиатуры граница поправляет другую ', h('b', null, 'молча, при уходе из поля'), ' — как сейчас в «Затратах по стройке».'),
      pc: [h(F, null, h('b', null, '+'), ' ближе всех к правилам, два обычных DateInput, строить дёшево'), h(F, null, h('b', null, '−'), ' молчаливая поправка заметна только по значению; на телефоне столбиком тире пропадает, и «с»/«по» читаются лишь порядком')],
      bar: function (sz) { return h(F, null, h(Box, { size: sz, value: FROM, w: sz === 'sm' ? 120 : 168 }), h('span', { className: 'dash' }, '—'), h(Box, { size: sz, value: TO, w: sz === 'sm' ? 120 : 168 })); },
      legendTop: true,
      cal: h(Cal, { y: 2026, m: 10, sel: [TO], ring: FROM, offBefore: FROM, clear: true }),
      calNote: h(F, null, 'Календарь «по». Дни до 12.10 (это «с») ', h('b', null, 'неактивны'), ', «с» — в кольце. Календарь «с» свободен: иначе сдвинуть период вперёд можно было бы, только начав с «по».'),
      fix: function () {
        return h(F, null,
          h(Cap, { k: 'набрано' }, '«с» = 28.10, «по» = 24.10'),
          h('div', { className: 'row' }, h(Box, { size: 'md', value: '2026-10-28', state: 'focus', w: 168 }), h('span', { className: 'dash' }, '—'), h(Box, { size: 'md', value: TO, w: 168 })),
          h(Cap, { k: 'после ухода' }, '«по» поправлено молча'),
          h('div', { className: 'row' }, h(Box, { size: 'md', value: '2026-10-28', w: 168 }), h('span', { className: 'dash' }, '—'), h(Box, { size: 'md', value: '2026-10-28', w: 168 })));
      },
      fixNote: h(F, null, h('b', null, 'Побеждает граница, которую правили'), ': поздняя «с» тянет «по», ранняя «по» тянет «с». Поправка — при фиксации (уход, выбор в календаре), а не на каждой отданной дате: иначе ↓ по дню утянула бы другую границу безвозвратно. Стёртая граница другую не трогает.'),
      phone: function () {
        return h('div', null, h('p', { className: 'legend' }, 'Дата счёта'),
          h('div', { className: 'stack' }, h(Box, { size: 'md', value: FROM }), h(Box, { size: 'md', value: TO })));
      },
      phoneNote: h(F, null, 'Две рамки с тире ≈ 376 px, на экране 390 есть 358 — ', h('b', null, 'столбиком'), ' (container query по своей ширине). Тире пропадает; для чтения с экрана — «Дата счёта, с» / «по».') },

    { id: 'Б', name: '«с … по …» с пометкой', tag: Tag('alt', 'вариант'),
      sub: h(F, null, h('b', null, 'Слова «с» и «по» у рамок'), ', подпись группы — только для чтения с экрана. В обоих календарях лента периода между границами, перекрёстного запрета нет. Сдвинутая граница ', h('b', null, 'на миг подсвечивается'), ', под парой — «„по“ сдвинуто на 28.10», та же фраза — в живой области.'),
      pc: [h(F, null, h('b', null, '+'), ' поправка не молчит; «с»/«по» читаются и на телефоне; лента показывает период целиком'), h(F, null, h('b', null, '−'), ' строка-пометка и подсветка — новое поведение, которого нет нигде; можно выбрать «по» раньше «с» и получить поправку')],
      bar: function (sz) { return h(F, null, h(Box, { size: sz, value: FROM, prefix: 'с', w: sz === 'sm' ? 134 : 186 }), h(Box, { size: sz, value: TO, prefix: 'по', w: sz === 'sm' ? 140 : 192 })); },
      legendTop: false,
      cal: h(Cal, { y: 2026, m: 10, sel: [FROM, TO], band: [FROM, TO], clear: true }),
      calNote: h(F, null, 'Календарь «по». ', h('b', null, 'Лента от «с» до «по»'), ', все дни доступны: щелчок по 08.10 поставит «по» = 08.10 и сдвинет «с» с пометкой.'),
      fix: function () {
        return h(F, null,
          h(Cap, { k: 'набрано' }, '«с» = 28.10, «по» = 24.10'),
          h('div', { className: 'row' }, h(Box, { size: 'md', value: '2026-10-28', prefix: 'с', state: 'focus', w: 186 }), h(Box, { size: 'md', value: TO, prefix: 'по', w: 192 })),
          h(Cap, { k: 'после ухода' }, '«по» подсвечено, под парой — пометка'),
          h('div', null,
            h('div', { className: 'row' }, h(Box, { size: 'md', value: '2026-10-28', prefix: 'с', w: 186 }), h(Box, { size: 'md', value: '2026-10-28', prefix: 'по', flash: true, w: 192 })),
            h('p', { className: 'msg' }, '«по» сдвинуто на 28.10')));
      },
      fixNote: h(F, null, 'Та же поправка, но ', h('b', null, 'видимая'), ': подсветка гаснет за ~1 с, пометка стоит до следующей правки. «Сегодня» вне диапазона здесь можно показать неактивной с подсказкой — ', h('b', null, 'против прежнего решения «невыполнимое скрываем»'), '.'),
      phone: function () {
        return h('div', { className: 'pair' },
          h('span', { className: 'pre' }, 'с'), h(Box, { size: 'md', value: FROM, w: '100%' }),
          h('span', { className: 'pre' }, 'по'), h(Box, { size: 'md', value: TO, w: '100%' }));
      },
      phoneNote: h(F, null, 'Столбиком «с»/«по» ', h('b', null, 'остаются словами'), ' — границы читаются и без тире.') },

    { id: 'В', name: 'Одно поле-диапазон', tag: Tag('warn', 'дороже всех'),
      sub: h(F, null, h('b', null, 'Одна рамка «дата – дата» и один календарь'), ': два щелчка выбирают «с» и «по», под наведением видна будущая лента. Второй щелчок раньше первого начинает выбор заново. На телефоне — нижний лист во всю ширину.'),
      pc: [h(F, null, h('b', null, '+'), ' удобнее всех для отбора: период — одним жестом, поправки нет вовсе'), h(F, null, h('b', null, '−'), ' новый режим выбора в Calendar, две группы сегментов в одной рамке, свой вид для точности «месяц»; дороже всех')],
      bar: function (sz) { return h(Box, { size: sz, value: FROM, value2: TO, range: true, w: sz === 'sm' ? 214 : 268 }); },
      legendTop: true,
      cal: h(Cal, { y: 2026, m: 10, sel: [FROM], band: [FROM, null], hover: TO, clear: true, hint: 'Выберите последний день' }),
      calNote: h(F, null, 'После первого щелчка (12.10): ', h('b', null, 'пунктирная лента до дня под указателем'), ', в подвале — что делать дальше. Второй щелчок фиксирует период и закрывает календарь.'),
      fix: function () {
        return h(F, null,
          h(Cap, { k: 'щелчок 08.10' }, 'раньше «с» = 12.10'),
          h(Cal, { y: 2026, m: 10, sel: ['2026-10-08'], band: ['2026-10-08', null], hover: '2026-10-15', foot: true, hint: 'Начато заново: с 08.10', today: false }));
      },
      fixNote: h(F, null, 'Поправлять нечего: «по» раньше «с» не выбрать. ', h('b', null, 'Второй щелчок раньше первого — новое начало'), '. С клавиатуры набранная пара проверяется так же, как в А: при уходе.'),
      phone: function () {
        return h('div', null, h('p', { className: 'legend' }, 'Дата счёта'), h(Box, { size: 'md', value: FROM, value2: TO, range: true, state: 'open', w: '100%' }));
      },
      phoneSheet: true,
      phoneNote: h(F, null, 'Одна рамка помещается в 358 px. Календарь — ', h('b', null, 'нижний лист'), ' во всю ширину, с той же строкой действий.') },
  ];

  function Toolbar(v) {
    return h('div', { className: 'row', style: { gap: 12, alignItems: 'flex-end' } },
      h(Sel, { size: 'sm', text: 'Все стройки', w: 128 }),
      h('div', null, v.legendTop ? h('p', { className: 'legend', style: { fontSize: 11 } }, 'Дата счёта') : null, h('div', { className: 'row', style: { gap: 4 } }, v.bar('sm'))),
      h(Sel, { size: 'sm', text: 'Любое состояние', w: 140 }));
  }
  function Phone(v) {
    return h('div', { className: 'phone', style: { height: v.phoneSheet ? 720 : 400 } },
      h('div', { className: 'ph-bar' }, h('span', { className: 'ib' }, h(Chev, { dir: 'l', size: 20 })), h('span', { className: 'ph-t' }, 'Отбор: счета')),
      h('div', { className: 'ph-b' }, h(Sel, { size: 'md', text: 'Все стройки', w: '100%' }), v.phone()),
      v.phoneSheet ? h(F, null, h('div', { className: 'ph-scrim' }), h('div', { className: 'ph-sheet' }, h(Cal, { y: 2026, m: 10, sel: [FROM, TO], band: [FROM, TO], clear: true, sheet: true }))) : null);
  }

  function Sheet(v) {
    return h(F, null,
      h(Opt, { id: v.id + '1', w: 600, label: 'Отбор реестра (sm) и редактор типа (md)',
        note: h(F, null, 'Сверху — строка отбора счетов рядом с Select sm. Снизу — «Допустимые даты» у примитивного типа: сейчас min и max там — два несвязанных поля, и что min не позже max, не проверяет никто.') },
        h(Frame, { w: 600 },
          h(Toolbar, v),
          h('div', { style: { marginTop: 8 } },
            v.legendTop ? h('p', { className: 'legend' }, 'Допустимые даты') : null,
            h('div', { className: 'row', style: { gap: 6 } }, v.bar('md'))))),
      h(Opt, { id: v.id + '2', w: 288, label: 'Календарь', note: v.calNote }, v.cal),
      h(Opt, { id: v.id + '3', w: v.id === 'В' ? 288 : 430, label: 'Граница позже другой', note: v.fixNote },
        v.id === 'В' ? v.fix() : h(Frame, { w: 430 }, v.fix())),
      h(Opt, { id: v.id + '4', w: 390, label: 'Телефон 390 px', note: v.phoneNote }, h(Phone, v)),
      h(Opt, { id: v.id + '5', w: 470, label: 'Тёмная тема', note: 'Те же токены, что у приложения в тёмной теме.' },
        h(Frame, { w: 470, dark: true },
          h('div', null, v.legendTop ? h('p', { className: 'legend' }, 'Допустимые даты') : null, h('div', { className: 'row', style: { gap: 6 } }, v.bar('md'))),
          v.cal)));
  }

  function App() {
    return h(F, null,
      h(Common),
      VARIANTS.map(function (v, i) {
        return h('section', { key: v.id, className: 'dv-turn', id: 't' + (i + 1) },
          h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t' + (i + 1) }, v.id), h('span', { className: 'dv-tname' }, 'DateRange: ' + v.name), v.tag),
          h('p', { className: 'dv-tsub' }, v.sub),
          h('div', { className: 'pc' }, v.pc.map(function (x, j) { return h('span', { key: j }, x); })),
          h('div', { className: 'dv-opts' }, h(Sheet, v)));
      }));
  }

  ReactDOM.createRoot(document.getElementById('root')).render(h(App));
})();
