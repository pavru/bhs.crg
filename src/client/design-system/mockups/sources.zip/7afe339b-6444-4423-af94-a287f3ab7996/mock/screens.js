/* Экраны трёх макетов change sharedui-md3-12-feedback. Один набор экранов на три варианта; оси,
   по которым они расходятся (разбор Дизайнера §76 — оси не склеивать):
   - уведомление: по одному без знака (А) / по одному со знаком ошибки (Б) / стопка до трёх с цветом ошибки (В);
   - пометка: StatusText (А, Б) / пилюля с тонкой заливкой контейнера (В);
   - число у подписи: текст (А) / текст с тоном (Б) / пилюля с тоном по [UI-45] (В).
   Общее для всех: badge MD3 (error) на знаке, вкладке и пункте навигации; Banner; простая и богатая
   подсказки; LinearProgress. Подписи — с настоящих экранов или близко к ним. */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'MD3 целиком', snack: 'one', errIcon: 0, mark: 'text', count: 'text',
      rule: 'Уведомление — snackbar по одному, без знаков и без цвета: ошибка отличается текстом, временем (8 с), «Закрыть» и «Сообщить». Пометка — StatusText. Число у подписи вкладки, кнопки, строки — просто текст on-surface-variant; badge (error) — только на знаке, вкладке и пункте навигации. Решение [UI-45] от 22.10.2026 отменяется.' },
    b: { key: 'b', name: 'Б', title: 'По одному, ошибка со знаком, число с тоном', snack: 'one', errIcon: 1, mark: 'text', count: 'tone',
      rule: 'Snackbar по одному, как в А, но у ошибки — ведущий знак error (на inverse-surface он берёт тон ошибки тёмной схемы — как inverse-primary у действия); подложка прежняя. Знак — отступление от MD3: ошибку пакета замечают боковым зрением. Пометка — StatusText. Число у подписи — текст label-medium цвета роли по смыслу (слово [UI-45] «тон по смыслу» сохранено, пилюля — нет); badge (error) — на знаке, вкладке, пункте навигации.' },
    v: { key: 'v', name: 'В', title: 'Стопка до трёх и пилюли по [UI-45]', snack: 'stack', errIcon: 1, mark: 'pill', count: 'pill',
      rule: 'Альтернатива В9: стопка до трёх уведомлений в форме MD3, ошибка — на error-container со знаком. Пометка — пилюля с тонкой заливкой контейнера роли, форма 8, без рамки. Счётчик у подписи — пилюля с тоном по смыслу, как решено в [UI-45]. Оба — названные отступления от MD3; badge (error) на знаке — как в А и Б.' },
  };
  const V = VARS[window.VARIANT || 'a'];
  const ST = { theme: 'light', gap: 0 };
  const q = new URLSearchParams(location.search);
  if (q.get('theme') === 'dark') ST.theme = 'dark';
  if (q.get('gap') === '1') ST.gap = 1;

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c, extra = '') => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}' style='position:relative'>${s(n)}${extra}</span>`;
  const btn = (t, v, n, extra = '') => `<span class='btn ${v}' style='position:relative'>${n ? s(n) : ''}${t}${extra}</span>`;
  const DEF = { success: 'check_circle', warning: 'warning', error: 'error' };
  /* пометка состояния по варианту */
  const mark = (t, tone = 'neutral', icon) => {
    const n = icon || DEF[tone];
    return V.mark === 'pill'
      ? `<span class='pil ${tone}'>${n ? s(n) : ''}${t}</span>`
      : `<span class='stx ${tone}'>${n ? s(n) : ''}${t}</span>`;
  };
  /* число у подписи по варианту */
  const cnt = (n, tone = 'neutral') => V.count === 'pill' ? `<span class='cnt-pil ${tone}'>${n}</span>`
    : V.count === 'tone' ? `<span class='cnt-tone ${tone}'>${n}</span>` : `<span class='cnt-t'>${n}</span>`;
  const bdg = (n) => n === 'dot' ? `<span class='bdg dot' aria-hidden='true'></span>` : `<span class='bdg' aria-hidden='true'>${n}</span>`;
  const lp = (v, cap) => v == null ? `<div class='lp ind' role='progressbar' aria-label='${cap || ''}'><i></i></div>`
    : `<div class='lp' role='progressbar' aria-valuenow='${v}' style='--v:${v}%'><i style='width:${v}%'></i></div>`;
  const tip = (t, pos) => `<span class='tip' role='tooltip' style='${pos}'>${t}</span>`;
  const rtip = (h, t, acts, pos) => `<div class='rtip${acts ? '' : ' noact'}' role='dialog' aria-label='${h}' style='${pos}'><div class='h'>${h}</div>${t}` +
    (acts ? `<div class='acts'>${acts.map(a => `<span class='btn text'>${a}</span>`).join('')}</div>` : '') + '</div>';
  const banner = (tone, icon, text, acts) => `<div class='bnr ${tone}' role='status'><span class='ic'>${s(icon, 'fill')}</span><div class='b'>${text}</div>` +
    (acts && acts.length ? `<div class='acts'>${acts.map(a => `<span class='btn text'>${a}</span>`).join('')}</div>` : '') + '</div>';

  /* snackbar: kind ok|info|err; o.trace — «Сообщить», o.act — своё действие */
  const snk = (kind, text, o = {}) => {
    const err = kind === 'err';
    const stackErr = err && V.snack === 'stack';
    const lead = err && V.errIcon ? `<span class='lead'>${s('error', 'fill')}</span>` : (V.snack === 'stack' && kind === 'ok' ? `<span class='lead' style='color:var(--inverse-primary)'>${s('check_circle')}</span>` : '');
    const acts = (o.act ? `<span class='btn text'>${o.act}</span>` : '') + (err && o.trace ? `<span class='btn text'>Сообщить</span>` : '') +
      (err ? ib('close', 'Закрыть') : '');
    return `<div class='snk${o.two ? ' two' : ''}${stackErr ? ' errc' : ''}' role='${err ? 'alert' : 'status'}' style='${o.w ? 'width:' + o.w + 'px;' : ''}'>${lead}<span class='tx'>${text}</span>${acts}</div>`;
  };
  const E500 = 'Счёт не сохранён: сервер ответил ошибкой. Набранное осталось на экране.';
  /* что видно внизу экрана в момент «ошибка при других сообщениях» */
  const snackNow = (phone) => V.snack === 'stack'
    ? [snk('ok', 'Счёт № 1018 сохранён'), snk('info', 'Распознано 3 из 8 файлов пакета'), snk('err', E500, { trace: 1, two: 1 })].join('')
    : snk('err', E500, { trace: 1, two: 1 });

  const RAIL = [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['apartment', 'Стройки'],
    ['folder_open', 'Комплекты'], ['table_chart', 'Таблицы'], ['settings', 'Настройки']];
  const rail = (on) => `<nav class='rail'>` + RAIL.map(([n, t]) =>
    `<div class='it${t === on ? ' on' : ''}'><span class='pill' style='position:relative'>${s(n, 's24' + (t === on ? ' fill' : ''))}${t === 'Накладные' ? bdg('dot') : ''}</span>${t}</div>`).join('') + '</nav>';
  const laptop = (label, on, inner, o = {}) => `<div class='md3' data-theme='${o.theme || ST.theme}' data-screen-label='${label}'><div class='app laptop'>${rail(on)}<div class='work'>${inner}</div>` +
    (o.snack ? `<div class='snkbox' style='${V.snack === 'stack' ? 'right:24px;align-items:flex-end' : 'left:104px'}'>${o.snack}</div>` : '') + `</div></div>`;
  const activity = (n) => ib('notifications', `Активность: ${n} непрочитанных`, '', bdg(n));

  /* ---- Реестр счетов ---- */
  const ROWS = [
    ['1021', 'ЭТМ «Север»', '30.10.2026', '412 560,00', [['Черновик']], ['14', ['3', 'warning', 'без раздела']]],
    ['1020', 'Кабельный завод «Проводник»', '28.10.2026', '1 284 900,00', [['Не распознан', 'error']], ['—']],
    ['1019', 'ООО «Электромонтаж»', '27.10.2026', '96 300,00', [['Ждёт оплаты', 'primary', 'schedule']], ['6']],
    ['1018', 'АО «Светотехника»', '25.10.2026', '238 017,40', [['Расхождение сумм', 'warning'], ['Ждёт оплаты', 'primary', 'schedule']], ['22', ['1', 'error', 'с ошибкой']]],
    ['1017', 'ЭТМ «Север»', '24.10.2026', '57 840,00', [['Оплачен', 'success']], ['9']],
    ['1016', 'ИП Семёнов', '22.10.2026', '18 600,00', [['Оплачен', 'success']], ['3']],
    ['1015', 'Кабельный завод «Проводник»', '21.10.2026', '742 115,00', [['Закрытый период', 'neutral', 'lock']], ['31']],
    ['1014', 'АО «Светотехника»', '20.10.2026', '11 270,00', [['Оплачен', 'success']], ['2']],
  ];
  const lines = (l) => l[0] + (l[1] ? ` <span class='muted'>·</span> ${V.count === 'text' ? `<span class='muted'>${l[1][2]} ${l[1][0]}</span>` : `${l[1][2]}${cnt(l[1][0], l[1][1])}`}` : '');
  const tabsInv = () => `<div class='tabs'><span>Все${cnt(214)}</span><span class='on'>Черновики${cnt(12)}</span><span>Ждут оплаты${cnt(3, 'primary')}</span>` +
    `<span>Не распознаны${cnt(2, 'error')}</span><span>Сверка${bdg('dot')}</span></div>`;
  const registry = (o = {}) => laptop('Реестр счетов', 'Счета', `
    <div class='ph'><h1>Счета</h1><span class='sub'>ЖК «Северный», корпус 2</span><span class='sp'></span>
      <span class='search'>${s('search')}Поиск по номеру и поставщику</span>${btn('Распознать пакет', 'tonal', 'upload_file')}${activity(12)}</div>
    ${tabsInv()}
    <div class='tblw'><table class='g'><colgroup><col style='width:72px'><col><col style='width:110px'><col style='width:140px'><col style='width:300px'><col style='width:200px'></colgroup>
      <tr><th>№</th><th>Поставщик</th><th>Дата</th><th class='num'>Сумма, ₽</th><th>Состояние</th><th>Строки</th></tr>
      ${ROWS.map((r, i) => `<tr${i === 3 && o.sel ? " class='sel'" : ''}><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class='num'>${r[3]}</td><td>${r[4].map(m => mark(...m)).join('')}</td><td>${lines(r[5])}</td></tr>`).join('')}
    </table></div>`, { snack: o.snack === false ? '' : snackNow() });

  /* ---- Счёт: banner вверху, полоса пакета, богатая подсказка, простая ---- */
  const invoice = () => laptop('Счёт', 'Счета', `
    <div class='ph'>${ib('arrow_back', 'К реестру')}<h1>Счёт № 1021 от 30.10.2026</h1>${mark('Черновик')}<span class='sp'></span>
      ${btn('Сохранить', 'outlined', 'save')}
      ${btn('Провести', 'filled dis', 'check_circle', rtip('Провести пока нельзя', 'В 3 строках не выбран раздел. Разнесите их или назначьте весь счёт на раздел.', ['Показать строки', 'Весь счёт на раздел'], 'top:48px;right:0'))}
      ${activity(12)}</div>
    ${banner('error', 'sync_problem', '<b>Счёт не перечитался:</b> сервер не ответил. На экране — прежнее состояние: его могли тем временем изменить. Набранное не пропало.', ['Повторить'])}
    <div class='split'>
      <div class='pane' style='flex:0 0 520px;padding:16px 16px 16px 24px;gap:12px'>
        <div style='display:flex;align-items:center;gap:8px'><span class='t-tm'>Файл счёта</span><span class='muted t-bs'>счет_1021.pdf · 2 листа</span><span class='sp'></span>
          ${ib('rotate_right', 'Повернуть')}${ib('download', 'Скачать файл', 'hover', tip('Скачать файл', 'top:44px;right:-20px'))}</div>
        <div class='scan' style='flex:1'>${s('picture_as_pdf', 's24')}&nbsp;скан счёта</div>
        <div class='card' style='padding:12px 16px;display:flex;flex-direction:column;gap:8px'>
          <div style='display:flex;align-items:center;gap:8px'><span>Распознаётся пакет: 3 из 8 файлов</span><span class='sp'></span><span class='btn text'>Остановить</span></div>
          ${lp(38)}<div class='t-bs muted'>Сейчас: счет_1024.pdf</div></div>
      </div>
      <div class='pane' style='padding:16px 24px;gap:16px'>
        <div class='kv'><span class='k'>Поставщик</span><span>ЭТМ «Север», ИНН 7810123456</span>
          <span class='k'>Объект</span><span>ЖК «Северный», корпус 2</span>
          <span class='k'>Сумма</span><span>412 560,00 ₽, в т. ч. НДС 68 760,00 ₽</span>
          <span class='k'>Сверка</span><span>${mark('Сумма сходится', 'success')}${mark('3 строки без раздела', 'warning')}</span></div>
        <table class='g'><colgroup><col style='width:36px'><col><col style='width:70px'><col style='width:120px'><col style='width:180px'></colgroup>
          <tr><th>#</th><th>Наименование</th><th class='num'>Кол.</th><th class='num'>Сумма</th><th>Раздел</th></tr>
          <tr><td>1</td><td>Кабель ВВГнг(А)-LS 3×2,5</td><td class='num'>500</td><td class='num'>48 250,00</td><td>ЭОМ, секция 1</td></tr>
          <tr><td>2</td><td>Автомат ВА 47-29 1Р 16А</td><td class='num'>40</td><td class='num'>9 160,00</td><td>${mark('не выбран', 'warning')}</td></tr>
          <tr><td>3</td><td>Гофра ПВХ 20 мм</td><td class='num'>300</td><td class='num'>4 470,00</td><td>${mark('не выбран', 'warning')}</td></tr>
        </table></div></div>`, { snack: snk('ok', 'Поставщик запомнен для следующих счетов') });

  /* ---- Окно над окном: banner в теле, подсказка над верхним окном ---- */
  const dialogs = (theme) => `<div class='md3' data-theme='${theme}' data-screen-label='Окно над окном ${theme}'><div class='app laptop'>${rail('Комплекты')}<div class='work'>
      <div class='ph'><h1>Комплект ИД «ЭОМ, секция 1»</h1></div><div class='tblw'></div></div>
      <div class='scrim'><div class='dlg' style='width:880px;height:600px;position:relative'>
        <h2>Разбиение PDF на документы</h2>
        ${banner('info', 'info', 'Сначала сохраните разбиение — документы создаются по сохранённому.', ['Сохранить разбиение'])}
        <div style='display:flex;gap:12px;flex:1'><div class='scan' style='flex:1'>листы 1–4</div><div class='scan' style='flex:1'>листы 5–9</div><div class='scan' style='flex:1'>лист 10</div></div>
        <div class='acts'><span class='btn text'>Отмена</span><span class='btn filled'>Сохранить</span></div>
        <div class='scrim' style='border-radius:28px'><div class='dlg' style='width:440px'>
          <div style='display:flex;align-items:center;gap:8px'><h2 style='flex:1'>Документ на листах 5–9</h2>${ib('rotate_right', 'Повернуть листы', 'hover', tip('Повернуть листы на 90°', 'bottom:46px;right:-30px'))}</div>
          <div class='kv' style='grid-template-columns:110px 1fr'><span class='k'>Тип</span><span>АОСР</span><span class='k'>Листов</span><span>5</span></div>
          <div class='acts'><span class='btn text'>Отмена</span><span class='btn filled'>Готово</span></div></div></div>
      </div></div></div></div>`;

  /* ---- Отчёт проверки связок (BindingCheckReport) — все статусы ---- */
  const CHECK = [
    ['Подрядчик', 'ООО «Электромонтаж»', 'связано', 'success'],
    ['Технадзор', 'Иванов П. С. — в каталоге нет записи с таким именем', 'не найдено', 'warning', 'search_off'],
    ['Проектировщик', 'запись удалена из каталога 29.10.2026', 'запись удалена', 'error', 'link_off'],
    ['Заказчик', 'ИНН в записи изменили после связки', 'устарело', 'warning', 'history'],
    ['Ответственный за работы', 'форма записи старого вида', 'пересохранить', 'warning', 'save'],
    ['Субподрядчик', '', 'в архиве', 'neutral'],
    ['Поставщик кабеля', 'запись в архиве, в документ не подставлена', 'в архиве — не подставлено', 'warning', 'inventory_2'],
    ['Объект', 'ссылка на тип, которого нет', 'не разрешилось', 'error'],
  ];
  const report = () => `<div class='md3' data-theme='${ST.theme}' data-screen-label='Отчёт сверки'><div class='frame' style='width:640px'>
      <div class='ph' style='min-height:56px'><span class='t-tm'>Проверка связок комплекта</span><span class='sp'></span>${mark('2 ошибки', 'error')}${mark('4 предупреждения', 'warning')}</div>
      <div class='rep' style='border-top:1px solid var(--outline-variant)'>${CHECK.map(c => `<div class='ri'><div class='b'><div>${c[0]}</div>${c[1] ? `<div class='t-bs muted'>${c[1]}</div>` : ''}</div>${mark(c[2], c[3], c[4])}</div>`).join('')}</div></div></div>`;

  /* ---- Очередь уведомлений во времени ---- */
  const fr = (cap, inner) => `<div><div class='st'>${cap}</div><div class='md3' data-theme='${ST.theme}'><div class='frame' style='width:600px;height:${V.snack === 'stack' ? 240 : 120}px;background:var(--surface)'>
      <div class='snkbox' style='left:16px;right:16px;align-items:${V.snack === 'stack' ? 'flex-end' : 'flex-start'}'>${inner}</div></div></div></div>`;
  const queue = () => V.snack === 'stack' ? [
      fr('0 с — сохранение и отказ одновременно: видны оба', snk('ok', 'Счёт № 1018 сохранён') + snk('err', E500, { trace: 1, two: 1, w: 560 })),
      fr('через 1 с — пришло третье, верхнее остаётся', snk('ok', 'Счёт № 1018 сохранён') + snk('info', 'Распознано 3 из 8 файлов пакета') + snk('err', E500, { trace: 1, two: 1, w: 560 })),
      fr('четвёртое вытесняет самое старое не-ошибку; пара от одного сохранения — одним сообщением', snk('ok', 'Сохранено. Поставщик запомнен, прежний забыт', { two: 1, w: 420 }) + snk('err', E500, { trace: 1, two: 1, w: 560 })),
    ].join('') : [
      fr('0 с — «Сохранено»; отказ, пришедший вслед, ждёт', snk('ok', 'Счёт № 1018 сохранён')),
      fr('4 с — ошибка: 8 с или до «Закрыть»; успех и сведения ждут за ней', snk('err', E500, { trace: 1, two: 1 })),
      fr('после «Закрыть» — следующее; пара от одного сохранения склеена в одно', snk('ok', 'Сохранено. Поставщик запомнен, прежний забыт')),
      fr('своё действие — 8 с (InvoicesPage, «Вернуться»)', snk('ok', 'Счёт № 1021 создан из № 1015; вы — в новом', { act: 'Вернуться' })),
    ].join('');

  /* ---- Телефон ---- */
  const pnav = (on) => `<nav class='pnav'>` + [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['notifications', 'Активность'], ['menu', 'Ещё']]
    .map(([n, t]) => `<div class='it${t === on ? ' on' : ''}'><span class='pill' style='position:relative'>${s(n, 's24' + (t === on ? ' fill' : ''))}${t === 'Активность' ? bdg('999+') : ''}</span>${t}</div>`).join('') + '</nav>';
  const phone = (label, title, body, nav, snack) => `<div class='md3' data-theme='${ST.theme}' data-screen-label='${label}'><div class='app phone'>
      <div class='ptop'>${title}</div><div class='pbody'>${body}
      ${snack ? `<div class='snkbox' style='left:16px;right:16px;${V.snack === 'stack' ? 'align-items:stretch' : ''}'>${snack}</div>` : ''}</div>${pnav(nav)}</div></div>`;
  const pList = () => phone('Телефон: счета', `${ib('menu', 'Меню')}<h1>Счета</h1>${ib('search', 'Поиск')}`,
    `<div class='tabs' style='padding:0'><span class='on'>Черновики${cnt(12)}</span><span>Ждут${cnt(3, 'primary')}</span><span>Не расп.${cnt(2, 'error')}</span></div>` +
    ROWS.slice(0, 6).map(r => `<div class='li'><div class='b'><div>№ ${r[0]} · ${r[1]}</div><div class='t-bs muted'>${r[2]} · ${r[3]} ₽</div><div style='margin-top:4px'>${r[4].map(m => mark(...m)).join('')}</div></div></div>`).join(''),
    'Счета', V.snack === 'stack' ? [snk('ok', 'Счёт № 1018 сохранён'), snk('err', E500, { trace: 1, two: 1 })].join('') : snk('err', E500, { trace: 1, two: 1 }));
  const pInvoice = () => phone('Телефон: счёт', `${ib('arrow_back', 'Назад')}<h1>Счёт № 1021</h1>${ib('more_vert', 'Ещё')}`,
    banner('warning', 'edit_note', '<b>Счёт изменили, пока вы правили.</b> Набранное на экране, но сохранение откажет.', ['Что изменилось', 'Перечитать']) +
    `<div style='padding:16px;display:flex;flex-direction:column;gap:12px'>
      <div style='display:flex;align-items:center;gap:8px'>${mark('Черновик')}${mark('3 строки без раздела', 'warning')}</div>
      <div class='kv' style='grid-template-columns:100px 1fr'><span class='k'>Поставщик</span><span>ЭТМ «Север»</span><span class='k'>Сумма</span><span>412 560,00 ₽</span></div>
      <div class='card' style='padding:12px;display:flex;flex-direction:column;gap:8px'><span>Распознаётся пакет: 3 из 8</span>${lp(38)}</div>
      <div style='display:flex;flex-direction:column;gap:4px'>${btn('Провести', 'filled dis', 'check_circle')}
        <span class='t-bs muted'>Провести пока нельзя: в 3 строках не выбран раздел.</span><span class='btn text' style='align-self:flex-start;margin-left:-12px'>Показать строки</span></div></div>`,
    'Счета', snk('ok', 'Поставщик запомнен для следующих счетов'));

  /* ---- «Сейчас → станет» ---- */
  const board = () => {
    const r = (h, old, now) => `<div class='h'>${h}</div><div class='r'>${old}</div><div class='r'>${now}</div>`;
    return `<div class='md3' data-theme='${ST.theme}'><div class='board' style='grid-template-columns:150px 420px 1fr'>
      <div></div><div class='h'><b>Сейчас</b></div><div class='h'><b>Станет (${V.name})</b></div>
      ${r('Уведомление — успех', `<div class='toast-old ok'>${s('check_circle', 'fill')}<span>Счёт № 1018 сохранён</span></div>`, snk('ok', 'Счёт № 1018 сохранён'))}
      ${r('Уведомление — ошибка', `<div class='toast-old err'>${s('error', 'fill')}<span>${E500} <a>Сообщить</a></span></div>`, snk('err', E500, { trace: 1, two: 1, w: 520 }))}
      ${r('Подсказка', `<span style='position:relative;display:inline-block;height:34px;width:200px'><span class='tip-old' style='top:0;left:0'>Скачать файл</span></span>`, `<span style='position:relative;display:inline-block;height:28px;width:200px'><span class='tip' style='top:0;left:0'>Скачать файл</span></span>`)}
      ${r('Богатая подсказка', `<span class='muted'>нет: причина — в простой подсказке, действия нет</span>`, `<span style='position:relative;display:inline-block;height:150px;width:320px'>${rtip('Сначала сохраните разбиение', 'Документы создаются по сохранённому разбиению, а в нём есть несохранённые правки.', ['Сохранить'], 'top:0;left:0')}</span>`)}
      ${r('Пометка состояния', ['Черновик:neutral', 'Оплачен:success', 'Расхождение:warning', 'Не распознан:error', 'Ждёт оплаты:primary'].map(x => { const [t, c] = x.split(':'); return `<span class='sb-old ${c}'>${t}</span>`; }).join(''),
        mark('Черновик') + mark('Оплачен', 'success') + mark('Расхождение', 'warning') + mark('Не распознан', 'error') + mark('Ждёт оплаты', 'primary', 'schedule'))}
      ${r('Число у подписи', `<span>Черновики <span class='sb-old neutral'>12</span></span><span>Не распознаны <span class='sb-old error'>2</span></span>`, `<span>Черновики${cnt(12)}</span><span>Не распознаны${cnt(2, 'error')}</span><span>Ждут оплаты${cnt(3, 'primary')}</span>`)}
      ${r('Badge на знаке', `<span class='bh'>${ib('notifications', 'Активность', '', `<span class='bdg old'>99+</span>`)}</span><span class='t-bs muted'>самодельный Count: «99+», primary</span>`,
        ib('notifications', 'Активность', '', bdg('dot')) + ib('notifications', 'Активность', '', bdg(3)) + ib('notifications', 'Активность', '', bdg('999+')) + `<span class='t-bs muted'>точка 6 · счётчик 16 · «999+» при 1200; имя — с точным числом</span>`)}
      ${r('Ход операции', `<div style='width:300px'><div class='lp-old'><i style='width:38%'></i></div></div>`, `<div style='width:300px;display:flex;flex-direction:column;gap:12px'>${lp(38)}${lp(null, 'Идёт разбор')}</div><span class='t-bs muted'>с долей и без</span>`)}
      ${r('Плашка → banner', `<div class='plq error' style='width:400px'>${s('error')}<span>Счёт не перечитался: сервер не ответил. <a>Повторить</a></span></div>`,
        `<div style='width:100%;border:1px dashed var(--outline-variant)'>${banner('error', 'sync_problem', 'Счёт не перечитался: сервер не ответил.', ['Повторить'])}${banner('success', 'check', 'Разбиение сохранено, документы можно создавать.', [])}</div>`)}
    </div></div>`;
  };

  /* ---- лист варианта ---- */
  const RISK = {
    a: 'Ошибка пакета (scanBatch, выгрузка) без цвета и знака заметна только тому, кто смотрит на низ экрана. Число «не распознаны 2» у вкладки не отличается от «черновики 12» — тревогу несёт только слово.',
    b: 'Знак у ошибки — названное отступление; его цвет на inverse-surface — тон ошибки другой схемы (в MD3 такой роли нет, её придётся завести: --inverse-error). Число с тоном — текст, а не пилюля: в строке вкладок слабее отделено от подписи.',
    v: 'Два отступления от MD3 вместо одного; стопка накрывает низ таблицы (см. реестр) и на телефоне закрывает треть списка. Пилюля-пометка и пилюля-счётчик рядом с чипами (форма 8) — третий оттенок «прямоугольника с заливкой» на одном экране.',
  };
  const order = ['a', 'b', 'v'], files = { a: 'А - MD3 целиком.html', b: 'Б - знак ошибки и число с тоном.html', v: 'В - стопка и пилюли.html' };
  const nav = `<span class='nav'><a href='${encodeURI('00 Разбор и вопрос.html')}'>0 Разбор</a>` + order.map(k => `<a href='${encodeURI(files[k])}'${k === V.key ? ` class='cur'` : ''}>${VARS[k].name} — ${VARS[k].title}</a>`).join('') + '</span>';
  const sec = (h, cap, body) => `<h2>${h}</h2>${cap ? `<div class='cap'>${cap}</div>` : ''}<div class='row'>${body}</div>`;
  const ctl = () => `<div class='ctl'><button data-t='light'${ST.theme === 'light' ? ` class='on'` : ''}>Светлая</button><button data-t='dark'${ST.theme === 'dark' ? ` class='on'` : ''}>Тёмная</button>
    <button data-gap='1'${ST.gap ? ` class='on'` : ''} style='margin-left:12px'>Полоса M3 2024: зазор и точка</button>${nav}</div>`;
  const html = () => `${ctl()}
    <h1>${V.name} — ${V.title}</h1>
    <div class='lead'><p>${V.rule}</p><p><b>Риск:</b> ${RISK[V.key]}</p>
      <p>Одинаково во всех трёх: простая подсказка на inverse-surface без рамки и тени; богатая — на surface-container, форма 12; banner — знак в круге контейнера роли (знак — парный on-*-container, как требует правило container-text), разделитель снизу; badge (error) на знаке, вкладке «Сверка» и пункте навигации; полоса хода 4 px. Кнопка «Полоса M3 2024» вверху — независимый вопрос.</p></div>
    ${sec('Сейчас → станет', 'Каждый вид обратной связи. Слева — как сегодня в коде (тост Fluent 380, StatusBadge-пилюля, плашка с рамкой, самодельные Count и полоса).', board())}
    ${sec('Реестр счетов — 1366×768', `Пометки в строках (две соседних у № 1018), числа у вкладок и в колонке «Строки», badge на знаке активности, точка на пункте «Накладные» и вкладке «Сверка». Внизу — отказ 500 с «Сообщить» и «Закрыть»${V.snack === 'stack' ? ' сверху стопки из трёх, справа' : ', у ведущего края содержимого, правее рейла'}.`, registry())}
    ${sec('Очередь уведомлений во времени', V.snack === 'stack' ? 'Стопка до трёх: всё видно сразу, ошибка отличается цветом. Пара «запомнено/забыто» от одного сохранения (InvoiceLinesTable) склеена и здесь: правило склейки не зависит от В9.' : 'Виден один. Ошибка не вытесняется; среди ожидающих ошибки идут первыми (Архитектор). Пара «запомнено/забыто» от одного сохранения (InvoiceLinesTable) склеена в одно сообщение в вызывающем коде, а не стоит в очереди за ошибкой (Дизайнер).', `<div class='tl'>${queue()}</div>`)}
    ${sec('Счёт — 1366×768', 'Banner «Счёт не перечитался» (RereadFailedNotice — единственная плашка shared/, переводится в 12) вверху области. Богатая подсказка у неактивной «Провести» — с действиями, не исчезает, пока указатель внутри. Простая — у «Скачать файл». Полоса пакета с долей (InvoiceScanDrop). Успех внизу.', invoice())}
    ${sec('Окно над окном — обе темы', 'Banner в теле окна (на surface-container-high окна фон banner — surface, смотрите, не выбивается ли). Простая подсказка во вложенном окне — в body, над обоими (#1521). В тёмной теме inverse-surface — светлая плашка на тёмном: это MD3.', dialogs('light') + dialogs('dark'))}
    ${sec('Отчёт проверки связок — все статусы', 'BindingCheckReport — единственное место bordered; фон отчёта не цветной (Дизайнер), рамка уходит без замены. Три разных warning «не найдено», «устарело», «пересохранить» — своими знаками (icon), не только словом. «В архиве» (neutral) — без знака.', report())}
    ${sec('Телефон — 375 px', 'Snackbar по центру над нижней навигацией, 16 px по бокам, навигация не закрыта. Badge «999+» на «Активности». Banner с действиями под текстом. Наведения нет — причина неактивной «Провести» и её действие стоят на экране (Архитектор: действие богатой подсказки дублируется).', pList() + pInvoice())}`;

  const root = document.getElementById('root');
  function paint() {
    document.body.classList.toggle('lp-gap', !!ST.gap);
    root.innerHTML = html();
    root.querySelectorAll('.ctl [data-t]').forEach(b => b.addEventListener('click', () => { ST.theme = b.dataset.t; paint(); }));
    root.querySelector('.ctl [data-gap]').addEventListener('click', () => { ST.gap = ST.gap ? 0 : 1; paint(); });
  }
  paint();
})();
