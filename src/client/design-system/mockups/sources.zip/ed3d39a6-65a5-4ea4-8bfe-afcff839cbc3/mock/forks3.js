/* Развилки Р7–Р9. */
window.FORKS = window.FORKS || [];
(() => {
  const { I, B, IB, IBx, TF, SEL, CARD, SUP, ST, CB, DIV, SEG, CHIP, PAIR, PAGE, MEAS } = window.K;

  // ── Р7: карточка стройки ──
  const sites = [
    { n: 'ЖК «Северный», корпус 2', s: 6, k: 11, p: '64%', np: 2, att: 3, fav: true, sec: ['ЭОМ', 'СС', 'ОВ', 'ВК'], more: 2 },
    { n: 'Школа на 1100 мест, ул. Лесная', s: 3, k: 7, p: '38%', np: 0, att: 0, sec: ['ЭОМ', 'ЭН', 'СКС'] },
    { n: 'Склад «Логистик-Парк»', s: 2, k: 2, p: null, np: 0, att: 0, sec: ['ЭОМ', 'ЭН'] },
  ];
  const word = (n, a, b, c) => { const m = n % 10, h = n % 100; return n + ' ' + (m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 12 || h > 14) ? b : c); };
  const facts = x => `<div class="fx g16 bs v" style="flex-wrap:wrap;gap:4px 16px"><span>${word(x.s, 'раздел', 'раздела', 'разделов')}</span><span>${word(x.k, 'комплект', 'комплекта', 'комплектов')}</span>${x.p ? `<span class="num">готовность: ${x.p}${x.np ? ` (без плана: ${word(x.np, 'комплект', 'комплекта', 'комплектов')})` : ''}</span>` : ''}${x.att ? `<span class="wr">требует разбора: ${x.att}</span>` : ''}</div>`;
  const secs = x => `<div class="fx" style="gap:4px 0;flex-wrap:wrap">${x.sec.map((s, i) => (i ? '<span class="v lm" style="padding:0 6px">·</span>' : '') + ST('q', s)).join('')}${x.more ? `<span class="bs v" style="margin-left:8px">+${x.more} ещё</span>` : ''}</div>`;
  const siteCard = (v, x, i) => {
    if (v === 'a') return `<div class="card outlined" style="flex:1;${i === 0 ? 'box-shadow:var(--el1)' : ''}"><div class="cbd top col g12" style="position:relative">${i === 0 ? '<span style="position:absolute;inset:0;background:var(--on-surface);opacity:.08"></span>' : ''}<div class="fx"><h3 class="tm f1">${x.n}</h3>${x.fav ? `<span class="pri" style="display:flex">${I('star', 18, 'fill')}</span>` : ''}</div>${facts(x)}${secs(x)}</div></div>`;
    if (v === 'b') return CARD('outlined', { style: 'flex:1', lead: `<span class="ib ${x.fav ? 'on' : ''}" style="margin-left:-8px">${I('star', 24, x.fav ? 'fill' : '')}</span>`, title: x.n, menu: true, body: `<div class="col g12">${facts(x)}${secs(x)}</div>`, actions: B('Открыть', 'text') });
    return '';
  };
  const sitesPage = v => {
    const head = `<div class="fx" style="padding:12px 16px 12px 24px;min-height:64px"><h1 class="tl f1" style="margin:0">Стройки</h1>${B('Стройка', 'filled', 'add')}</div><div style="padding:0 24px 16px"><span class="fx" style="height:56px;border-radius:999px;background:var(--sch);padding:0 16px;width:420px;color:var(--on-surface-variant)">${I('search', 24)}<span class="bl">Поиск стройки</span></span></div>`;
    if (v === 'c') {
      const rows = sites.map(x => `<tr><td style="width:56px;padding:0 0 0 8px">${IBx('star', x.fav ? 'on' : '')}</td><td class="fm">${x.n}</td><td class="num">${x.s}</td><td class="num">${x.k}</td><td class="num">${x.p ?? '<span class="v">—</span>'}${x.np ? ` <span class="bs v">без плана: ${x.np}</span>` : ''}</td><td>${x.att ? ST('wr', 'требует разбора: ' + x.att) : ''}</td><td style="width:56px;padding:0 8px">${IBx('more_vert')}</td></tr>`).join('');
      return `<div class="col">${head}<div style="padding:0 24px 24px"><table class="grid"><thead><tr><th></th><th>Стройка</th><th>Разделы</th><th>Комплекты</th><th>Готовность</th><th>Требует разбора</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
    }
    return `<div class="col">${head}<div class="fx g16" style="align-items:stretch;padding:0 24px 24px">${sites.map((x, i) => siteCard(v, x, i)).join('')}</div></div>`;
  };
  window.FORKS.push({
    id: 'r7', title: 'Кликабельная карточка с действиями внутри',
    places: '1 место: <code>document-sets/ConstructionsList.tsx:182</code>. Сейчас щелчок по карточке открывает стройку, а внутри — «избранное», «переименовать» (с правкой имени на месте) и «удалить» по наведению. У кликабельного Card своих кнопок и меню внутри быть не может (UI.md, «Карточки»). Числа — образец.',
    say: {
      a: '<b>Кликабельный Card целиком</b> — одна цель со слоем состояния и уровнем 1 под курсором (первая карточка показана под курсором). «Избранное», «Переименовать» и «Удалить» уходят в шапку страницы стройки; на карточке остаётся знак «в избранном».',
      b: '<b>Статичный Card outlined</b>, действия остаются на карточке и видны всегда: звезда — IconButton-переключатель в шапке, «⮿» — переименовать и удалить, «Открыть» — действие под телом. Щелчок по пустому месту карточки ничего не делает.'.replace('⮿', '⋮'),
      c: '<b>Список строк вместо сетки карточек</b>: DataGrid с открытием строки, звездой в первой клетке (interactive) и меню действий строки. Разделы стройки списком имён уходят — остаётся число.',
    },
    flags: {
      a: [['ok', 'готовый Card onClick'], ['dev', 'действия переезжают на страницу стройки — новое место для них там нужно сделать']],
      b: [['ok', 'готовый Card (menu, actions)'], ['dev', 'переименование на месте заменяется окном из меню']],
      c: [['ok', 'готовый DataGrid'], ['dev', 'смена раскладки страницы — самая большая перемена из трёх']],
    },
    render: v => PAIR('Страница «Стройки» <span>— document-sets/ConstructionsList.tsx</span>', 1020, 0, () => sitesPage(v)),
  });

  // ── Р8: панель выделения ──
  const mats = [
    ['Кабель ВВГнг(А)-LS 3×2,5', 'Сертификат № РОСС RU.HB61.H01234', 'Стройка', 1],
    ['Кабель ВВГнг(А)-LS 5×4', null, '', 1],
    ['Труба гофрированная ПВХ 20 мм', 'Паспорт качества № 518', 'Комплект', 0],
    ['Провод ПуГВ 1×6', 'Сертификат № 77-1142', 'Система', 1],
    ['Лоток перфорированный 200×50', null, '', 0],
    ['Автоматический выключатель ВА47-29 1P 16А', 'Декларация ЕАЭС N RU Д-RU.РА01.В.12345', 'Стройка', 0],
    ['Коробка распаячная 100×100', null, '', 0],
    ['Светильник светодиодный 36 Вт', 'Сертификат № RU C-RU.АЯ46.В.03117', 'Стройка', 0],
  ];
  const wider = 'Шире выбранного уровня — 1 (система: 1): документ сменится на уровне самой связки, то есть и в других комплектах.';
  const selTable = (n = 8) => `<table class="grid"><thead><tr><th class="cbx">${'<span class="cb on" style="background:var(--primary)">' + I('remove') + '</span>'}</th><th>Материал</th><th>Документ качества</th><th>Уровень</th></tr></thead><tbody>${mats.slice(0, n).map(m => `<tr class="${m[3] ? 'sel' : ''}"><td class="cbx">${CB(m[3])}</td><td>${m[0]}</td><td>${m[1] ? m[1] : `<span class="btn text" style="height:32px;padding:0 8px">Связать</span>`}</td><td>${m[2] ? `<span class="bs v">${m[2]}</span>` : ''}</td></tr>`).join('')}</tbody></table>`;
  const tabHead = `<div class="fx" style="height:64px;padding:0 16px 0 24px"><h2 class="tm f1">Материалы комплекта</h2><span class="fx" style="height:40px;border-radius:999px;background:var(--sch);padding:0 16px;width:260px;color:var(--on-surface-variant)">${I('search', 24)}<span class="bm">Поиск материала</span></span></div>`;
  const bulk = v => {
    if (v === 'a') return `<div class="col" style="height:100%"><div style="background:var(--sch)"><div class="fx" style="height:64px;padding:0 16px 0 8px">${IB('close')}<h2 class="tl f1" style="margin-left:4px">Выбрано: 3</h2>${B('Связать выбранные (3)', 'filled', 'link')}</div><div style="padding:0 24px 12px">${SUP('wr', wider, 'warning')}</div></div><div style="flex:1;overflow:hidden;padding:0 8px">${selTable()}</div></div>`;
    if (v === 'b') return `<div class="col" style="height:100%;position:relative">${tabHead}<div style="flex:1;overflow:hidden;padding:0 8px">${selTable()}</div><div style="position:absolute;left:0;right:0;bottom:0;background:var(--sc);box-shadow:var(--el2)"><div class="fx" style="height:64px;padding:0 16px 0 24px"><span class="bm f1">Выбрано: 3</span>${B('Снять выбор')}${B('Связать выбранные (3)', 'filled', 'link')}</div><div style="padding:0 24px 12px;margin-top:-8px">${SUP('wr', wider, 'warning')}</div></div></div>`;
    return `<div class="col" style="height:100%">${tabHead}<div class="fx" style="min-height:48px;padding:0 16px 0 24px;border-top:1px solid var(--outline-variant)"><span class="bm v">Выбрано: 3</span>${B('Связать выбранные (3)', 'text', 'link')}${B('Снять выбор')}</div><div style="padding:0 24px 8px">${SUP('wr', wider, 'warning')}</div><div style="flex:1;overflow:hidden;padding:0 8px">${selTable()}</div></div>`;
  };
  const bulkPhone = v => {
    const rows = mats.slice(0, 7).map(m => `<div class="fx g16" style="min-height:72px;padding:8px 16px;${m[3] ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : ''}">${CB(m[3])}<div class="col f1"><span class="bm">${m[0]}</span><span class="bs" style="${m[3] ? '' : 'color:var(--on-surface-variant)'}">${m[1] ?? 'не связан'}</span></div></div>`).join('');
    const appbar = v === 'a' ? `<div class="appbar" style="background:var(--sch)">${IB('close')}<h2>Выбрано: 3</h2>${IB('link')}</div>` : `<div class="appbar">${IB('arrow_back')}<h2>АОСР № 12</h2>${IB('search')}</div>`;
    const strip = v === 'c' ? `<div class="fx" style="min-height:48px;padding:0 8px 0 16px;flex-wrap:wrap"><span class="bm v f1">Выбрано: 3</span>${B('Связать (3)', 'text', 'link')}${IB('close')}</div>` : '';
    const bottom = v === 'b' ? `<div style="position:absolute;left:0;right:0;bottom:0;background:var(--sc);box-shadow:var(--el2);padding:8px 16px 12px" class="col g4"><div class="fx"><span class="bm f1">Выбрано: 3</span>${IB('close')}${B('Связать (3)', 'filled', 'link')}</div>${SUP('wr', wider, 'warning')}</div>` : '';
    const warnTop = v === 'a' ? `<div style="padding:0 16px 8px;background:var(--sch)">${SUP('wr', wider, 'warning')}</div>` : v === 'c' ? `<div style="padding:0 16px 8px">${SUP('wr', wider, 'warning')}</div>` : '';
    return `<div class="col" style="height:100%;position:relative">${appbar}${warnTop.startsWith('<div style="padding:0 16px 8px;background') ? warnTop : ''}${strip}${v === 'c' ? warnTop : ''}<div style="flex:1;overflow:hidden">${rows}</div>${bottom}</div>`;
  };
  window.FORKS.push({
    id: 'r8', title: 'Липкая панель выделения',
    places: '2 места: <code>document-sets/editor/BulkSelectionBar.tsx:20</code> (вкладка «Документы качества» документа) · <code>quality-docs/QualityDocLinks.tsx:186</code> (та же панель с «Перепривязать» и «Разорвать»). Сейчас — плашка sticky bottom с рамкой, радиусом 8 и тенью 1, видна только при непустом выборе. Строки — образец; текст предупреждения — из кода.',
    say: {
      a: '<b>Контекстная шапка</b>: при выборе шапка вкладки сменяется полосой «✕ Выбрано: 3» с действиями (как режим выбора в top app bar MD3). ✕ — «Снять выбор». На телефоне так же сменяется верхняя полоса экрана.',
      b: '<b>Нижняя закреплённая панель во всю ширину</b> области — там же, где сейчас, но без рамки и скругления: surface-container, уровень 2, «Снять выбор» — кнопка text вместо своей.',
      c: '<b>Строка над таблицей, не липкая</b>: «Выбрано: 3» и text-кнопки под шапкой вкладки, без заливки и возвышения. Уходит с прокруткой вместе со списком.',
    },
    flags: {
      a: [['new', 'общий компонент «шапка выбора» (два потребителя) — Архитектор']],
      b: [['new', 'общий компонент «панель выбора» — Архитектор'], ['dev', 'нижняя панель действий — из M3 Expressive (docked toolbar), а не из базового MD3']],
      c: [['ok', 'без нового компонента (Button text)'], ['dev', 'на длинном списке действие уходит из вида вместе со строкой']],
    },
    render: v => PAIR('Вкладка «Документы качества», выбрано 3 строки <span>— document-sets/editor/QualityLinksTab.tsx + BulkSelectionBar.tsx, 900 px</span>', 900, 600, () => bulk(v))
      + PAIR('То же на 375 px', 375, 680, () => bulkPhone(v)),
  });

  // ── Р9: боковые колонки ──
  const rail = `<div class="col" style="width:80px;flex:none;align-items:center;gap:12px;padding-top:12px">${['home', 'description', 'payments', 'event_note', 'settings'].map((ic, i) => `<div class="col" style="align-items:center;gap:4px"><span style="width:56px;height:32px;border-radius:999px;display:grid;place-items:center;${i === 1 ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : 'color:var(--on-surface-variant)'}">${I(ic, 24, i === 1 ? 'fill' : '')}</span><span class="lm v">${['Главная', 'ИД', 'Учёт', 'План', 'Настр.'][i]}</span></div>`).join('')}</div>`;
  const navSecs = `<div class="col" style="width:288px;flex:none;border-right:1px solid var(--outline-variant);padding:12px;gap:2px"><div class="bs fm v" style="padding:0 12px 6px">Разделы</div>${[['Общие сведения', 'radio_button_checked', 1], ['Участники', 'check_circle', 0], ['Работы', 'radio_button_checked', 0], ['Материалы', 'circle', 0], ['Приложения', 'circle', 0]].map(s => `<div class="fx g12" style="height:44px;padding:0 12px;border-radius:999px;${s[2] ? 'background:var(--primary-container);color:var(--on-primary-container)' : 'color:var(--on-surface-variant)'}"><span style="display:flex;${s[1] === 'check_circle' || s[2] ? 'color:var(--primary)' : ''}">${I(s[1])}</span><span class="bm ${s[2] ? 'fm' : ''}">${s[0]}</span></div>`).join('')}</div>`;
  const docForm = w => `<div class="col g16" style="flex:1;min-width:0;padding:20px 24px;overflow:hidden"><div><h3 class="tm">Общие сведения</h3><p class="bs v">Заполнено 5 из 8 · раздел 1 из 5</p></div>
    <div class="fx g16">${TF('Номер акта', '12', { style: 'flex:1' })}${TF('Дата акта', '28.10.2026', { style: 'flex:1', trail: IBx('calendar_month') })}</div>
    ${TF('Работы, предъявленные к освидетельствованию', 'Прокладка кабеля ВВГнг(А)-LS 3×2,5 в гофрированной трубе ПВХ 20 мм по стенам и перекрытиям, этаж 3, оси 1–6', { multi: true })}
    ${TF('Проектная документация', 'ЭОМ-1, листы 3–7')}
    ${TF('При выполнении работ применены', 'см. раздел «Материалы»', { ph: true })}
    <div class="fx" style="justify-content:flex-end">${B('Участники →', 'tonal')}</div></div>`;
  const pdfBody = (w, h) => `<div style="flex:1;min-height:0;background:var(--sc);display:flex;justify-content:center;padding:16px;overflow:hidden">${PAGE(Math.min(w - 48, 520), 22, 'box-shadow:var(--el1)')}</div>`;
  const editor = v => {
    const head = `<div class="fx" style="min-height:64px;padding:12px 16px 12px 8px">${IB('arrow_back')}<div class="f1 col" style="margin-left:4px"><h1 class="tl trunc" style="margin:0">АОСР № 12 — Акт освидетельствования скрытых работ</h1><span class="bs v">Комплект «ЭОМ, корпус 2»</span></div>${v === 'c' ? B('Предпросмотр', 'outlined', 'visibility') : v === 'a' ? `<span class="ib" style="background:var(--secondary-container);color:var(--on-secondary-container)">${I('right_panel_close', 24)}</span>` : ''}${B('Сформировать PDF', 'filled', 'picture_as_pdf')}${IB('more_vert')}</div>
      <div class="fx" style="height:48px;padding:0 24px;gap:0;border-bottom:1px solid var(--outline-variant)">${['Реквизиты', 'Наборы данных', 'Документы качества'].map((t, i) => `<span class="ts" style="height:48px;display:flex;align-items:center;padding:0 16px;${i === 0 ? 'color:var(--primary);box-shadow:inset 0 -3px 0 var(--primary)' : 'color:var(--on-surface-variant)'}">${t}</span>`).join('')}</div>`;
    let side = '', formW = 0;
    if (v === 'a') { formW = 598; side = `<div class="col" style="width:400px;flex:none;border-left:1px solid var(--outline-variant);background:var(--surface)"><div class="fx" style="min-height:72px;padding:12px 12px 12px 24px"><h2 class="tl f1">Предпросмотр документа</h2>${IB('refresh')}${IB('close')}</div>${pdfBody(400)}</div>`; }
    if (v === 'b') { formW = 432; side = `<div class="col" style="width:566px;flex:none;border-left:1px solid var(--outline-variant)"><div class="fx" style="height:48px;padding:0 4px 0 16px;border-bottom:1px solid var(--outline-variant)"><span class="v" style="display:flex">${I('description')}</span><h2 class="ts f1">Предпросмотр документа</h2><span class="bs v">обновлено 2 мин назад</span>${IB('refresh')}${IB('right_panel_close')}</div>${pdfBody(566)}</div>`; }
    if (v === 'c') { formW = 998; }
    const body = `<div class="fx" style="flex:1;min-height:0;align-items:stretch;gap:0">${navSecs}${docForm(formW)}${side}</div>`;
    const overlay = v === 'c' ? `<div class="scrim" style="z-index:5"></div><div class="col" style="position:absolute;z-index:6;top:0;right:0;bottom:0;width:400px;background:var(--scl);border-radius:16px 0 0 16px;box-shadow:var(--el1)"><div class="fx" style="min-height:72px;padding:12px 12px 12px 24px"><h2 class="tl f1">Предпросмотр документа</h2>${IB('refresh')}${IB('close')}</div>${pdfBody(400)}</div>` : '';
    const m = v === 'c'
      ? MEAS(368, 740, 998, 'форма: 998 px при закрытом листе (сейчас 432)') + MEAS(966, 700, 400, 'лист поверх: 400')
      : MEAS(368, 740, formW, `форма: ${formW} px${v === 'b' ? ' (как сейчас)' : ' (сейчас 432)'}`) + MEAS(368 + formW, 700, 1366 - 368 - formW, `предпросмотр: ${1366 - 368 - formW}`);
    return `<div class="fx bgl" style="height:100%;align-items:stretch;gap:0;background:var(--scl)">${rail}<div class="col" style="flex:1;min-width:0;margin-top:8px;border-top-left-radius:16px;background:var(--surface);position:relative;overflow:hidden">${head}${body}${overlay}</div></div>${m}`;
  };
  const editorPhone = v => {
    const top = `<div class="appbar">${IB(v === 'a' ? 'close' : 'arrow_back')}<h2>${v === 'b' ? 'АОСР № 12' : 'Предпросмотр документа'}</h2>${v === 'b' ? IB('more_vert') : IB('refresh')}</div>`;
    if (v === 'a') return `<div class="col" style="height:100%">${top}${pdfBody(375)}</div>`;
    if (v === 'b') return `<div class="col" style="height:100%">${top}<div class="col g16" style="padding:8px 16px"><h3 class="tm">Общие сведения</h3>${TF('Номер акта', '12')}${TF('Дата акта', '28.10.2026')}${TF('Работы, предъявленные к освидетельствованию', 'Прокладка кабеля ВВГнг(А)-LS 3×2,5 в гофрированной трубе…', { multi: true })}<p class="bs v">На узком экране колонки предпросмотра нет (как сейчас: она есть с 1280 px).</p></div></div>`;
    return `<div class="col" style="height:100%;position:relative;background:var(--surface)"><div class="appbar">${IB('arrow_back')}<h2>АОСР № 12</h2>${IB('visibility')}</div><div class="col g16" style="padding:8px 16px">${TF('Номер акта', '12')}${TF('Дата акта', '28.10.2026')}</div><div class="scrim"></div><div class="col" style="position:absolute;left:0;right:0;bottom:0;height:86%;background:var(--scl);border-radius:28px 28px 0 0;box-shadow:var(--el1);overflow:hidden"><div style="display:flex;justify-content:center;padding:16px 0 8px"><span style="width:32px;height:4px;border-radius:999px;background:var(--on-surface-variant);opacity:.4"></span></div><div class="fx" style="padding:0 8px 8px 24px"><h2 class="tl f1">Предпросмотр документа</h2>${IB('refresh')}</div>${pdfBody(375)}</div></div>`;
  };
  // Окно выбора позиции номенклатуры (Modal wide = 896)
  const noms = [['Кабель ВВГнг(А)-LS 3×2,5', 'м · Кабель', 1], ['Кабель ВВГнг(А)-LS 3×1,5', 'м · Кабель'], ['Кабель ВВГнг(А)-FRLS 3×2,5', 'м · Кабель'], ['Кабель NYM 3×2,5', 'м · Кабель'], ['Кабель ВВГ-Пнг(А)-LS 3×2,5', 'м · Кабель']];
  const nomCard = (titleCls = 'tm') => `<div class="col g12"><dl style="margin:0;display:grid;grid-template-columns:8rem minmax(0,1fr);gap:4px 12px" class="bm">${[['Артикул <span class="ls v">ключ</span>', '<span class="mono">ВВГ-3х2,5-LS</span>'], ['Ед. изм.', 'м'], ['Производитель', 'Кабельный завод «Электрокабель»'], ['Другие имена', 'ВВГнгLS 3х2.5'], ['Вид', 'Кабель <span class="ls v">уровень: система</span>']].map(r => `<dt class="bs v" style="padding-top:2px">${r[0]}</dt><dd style="margin:0">${r[1]}</dd>`).join('')}</dl><p class="bs v">Выбирали в 18 строках счетов.</p><div>${B('Выбрать эту позицию', 'tonal')}</div></div>`;
  const picker = v => {
    const listW = v === 'a' ? 496 : v === 'b' ? 493 : 896;
    const rows = noms.map(n => `<div class="fx g16" style="min-height:56px;padding:0 16px;${n[2] && v !== 'c' ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : ''}"><div class="col f1"><span class="bm trunc">${n[0]}</span><span class="bs" style="${n[2] && v !== 'c' ? '' : 'color:var(--on-surface-variant)'}">${n[1]}</span></div>${v === 'c' ? `<span class="v" style="display:flex">${I('chevron_right', 24)}</span>` : ''}</div>`).join('');
    const list = `<div class="col" style="width:${listW}px;flex:none;padding:12px 0"><div style="padding:0 16px 12px"><span class="fx" style="height:40px;border-radius:999px;background:var(--schh);padding:0 16px;color:var(--on-surface-variant)">${I('search', 24)}<span class="bm" style="color:var(--on-surface)">ввг 3х2,5</span></span></div><h3 class="ts v" style="padding:4px 16px 4px">Найдено в справочнике</h3>${rows}</div>`;
    const pane = v === 'a'
      ? `<div class="col" style="width:400px;flex:none;border-left:1px solid var(--outline-variant);background:var(--surface);--bg:var(--surface)"><div class="fx" style="min-height:72px;padding:12px 12px 12px 24px"><h2 class="tl f1" style="font-size:20px">Кабель ВВГнг(А)-LS 3×2,5</h2>${IB('close')}</div><div style="padding:0 24px 24px">${nomCard()}</div></div>`
      : v === 'b' ? `<div class="col g12" style="width:403px;flex:none;border-left:1px solid var(--outline-variant);padding:16px 20px"><h3 class="tm">Кабель ВВГнг(А)-LS 3×2,5</h3>${DIV()}${nomCard()}</div>` : '';
    const win = `<div class="win" style="width:896px;height:600px"><div class="hd"><h2>Позиция номенклатуры</h2></div><div class="fx" style="flex:1;min-height:0;align-items:stretch;gap:0;border-top:1px solid var(--outline-variant);border-bottom:1px solid var(--outline-variant);overflow:hidden">${list}${pane}</div><div class="ft">${B('Новая позиция', 'text', 'add')}<span class="f1"></span>${B('Закрыть')}</div></div>`;
    const x0 = (1366 - 896) / 2;
    const m = MEAS(x0, 700, listW, `список: ${listW} px${v === 'b' ? ' (как сейчас, 55/45)' : ' (сейчас 493)'}`) + (v === 'c' ? '' : MEAS(x0 + listW, 730, 896 - listW, `карточка: ${896 - listW}`));
    return `<div style="position:absolute;inset:0;background:var(--scl)"></div><div class="scrim"></div><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">${win}</div>${m}`;
  };
  const pickerStep = () => `<div style="position:absolute;inset:0;background:var(--scl)"></div><div class="scrim"></div><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center"><div class="win" style="width:640px"><div class="hd fx" style="padding-left:12px">${IB('arrow_back')}<h2>Карточка позиции</h2></div><div class="bd"><h3 class="tm">Кабель ВВГнг(А)-LS 3×2,5</h3>${nomCard().replace(B('Выбрать эту позицию', 'tonal'), '')}</div><div class="ft">${B('К списку')}${B('Выбрать эту позицию', 'filled')}</div></div></div>`;
  window.FORKS.push({
    id: 'r9', title: 'Боковые колонки экранов',
    places: 'Сверх правил: <code>document-sets/editor/DocumentPreviewPanel.tsx:86</code> — колонка <code>w-[44%] min-w-[380px]</code> с своей шапкой, свёртывается в полосу 44 px, видна с 1280 px · <code>costs/NomenclatureCardPanel.tsx</code> — aside в окне <code>NomenclaturePicker</code> (сетка 55/45, окно wide = 896) и в шаге <code>NewNomenclatureStep</code>, всегда видна, идёт за выделением. Кадры 1366×768 с замером (розовая черта). Расчёт: рейл 80, разделы формы 288 (с 1024 px), сейчас предпросмотр 44 % от 1286 = 566 → форме остаётся 432.',
    say: {
      a: '<b>SideSheet standard 400</b>: заголовок title-large, крестик, Esc. Предпросмотр открывается кнопкой-переключателем в шапке документа (полоса 44 px уходит), карточка позиции — по выбору строки. Форме остаётся 598 вместо 432, но PDF в 400 — мелкий. На телефоне лист — во весь экран.',
      b: '<b>Supporting pane канонической раскладки MD3</b>: колонка остаётся на месте и шириной раскладки (44 %, свёртка в полосу сохраняется), без своего крестика, отделена Divider; шапка — ролью title-small. В окне позиции — как сейчас (55/45). Форме — 432, как сейчас.',
      c: '<b>Колонки нет.</b> Предпросмотр — SideSheet modal по кнопке «Предпросмотр» (на телефоне — лист снизу), форма занимает всю ширину (998). Карточка позиции — шаг окна (WindowStep) на любой ширине, как сейчас на узком экране: список — во всё окно.',
    },
    flags: {
      a: [['ok', 'готовый SideSheet'], ['new', 'ширина листа зашита в 400; лист внутри Modal спорит с ним за Esc и фокус — Архитектор'], ['dev', 'карточка позиции получает крестик, которого у неё не было']],
      b: [['ok', 'без новых компонентов (Divider, роли текста)'], ['dev', 'не SideSheet: сценарий спеки «Карточка номенклатуры» переписывается /opsx:update']],
      c: [['ok', 'готовые SideSheet modal, BottomSheet, WindowStep'], ['dev', 'предпросмотр не рядом с формой: править и смотреть одновременно нельзя; сценарий спеки переписывается']],
    },
    render: v => PAIR('Редактор документа, вкладка «Реквизиты» с предпросмотром, 1366×768 <span>— document-sets/editor/RequisitesTab.tsx + DocumentPreviewPanel.tsx</span>', 1366, 768, () => editor(v))
      + PAIR('Окно «Позиция номенклатуры», 1366×768 <span>— costs/NomenclaturePicker.tsx + NomenclatureCardPanel.tsx (справочные данные — образец)</span>', 1366, 768, () => picker(v))
      + (v === 'c' ? PAIR('В: щелчок по строке → шаг окна «Карточка позиции»', 1366, 768, () => pickerStep()) : '')
      + PAIR('Предпросмотр на 375 px', 375, 720, () => editorPhone(v)),
  });
})();
