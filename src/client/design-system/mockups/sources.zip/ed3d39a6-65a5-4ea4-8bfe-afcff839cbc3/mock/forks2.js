/* Развилки Р4–Р6. */
window.FORKS = window.FORKS || [];
(() => {
  const { I, B, IB, IBx, TF, SEL, CARD, ST, CB, DIV, SEG, CHIP, PAIR, PAGE } = window.K;

  // ── Р4: плитка выбранного значения ──
  const vals = [
    { label: 'Подрядчик', kind: 'ref', icon: 'link', name: 'ООО «Электромонтаж»', sub: 'Стройка', acts: [['sync', 'Заменить'], ['link_off', 'Снять ссылку', 'err']], src: 'RefTile' },
    { label: 'Исполнительная схема', kind: 'doc', icon: 'description', name: 'Схема ЭОМ-1, лист 3', sub: 'Исполнительная схема', acts: [['open_in_new', 'Открыть'], ['link_off', 'Снять ссылку', 'err']], src: 'DocRefField' },
    { label: 'Сертификат соответствия', kind: 'cat', icon: 'database', name: 'Сертификат № РОСС RU.HB61.H01234', sub: 'Из каталога документов', acts: [['sync', 'Заменить ссылку'], ['link_off', 'Снять ссылку', 'err']], src: 'DocRefCatalogPickerField' },
    { label: 'Протокол испытаний', kind: 'file', icon: 'picture_as_pdf', name: 'protocol_izol_2026-10.pdf', sub: '1,2 МБ', acts: [['visibility', 'Предпросмотр'], ['delete', 'Удалить', 'err']], src: 'FileField' },
    { label: 'Ответственный представитель', kind: 'sum', icon: 'edit_note', name: 'Иванов И. И., прораб, приказ № 14 от 03.09.2026', sub: 'Составное — правка в окне', acts: [['edit', 'Изменить'], ['link', 'Из каталога']], src: 'ComplexFields' },
  ];
  const tile = (v, x) => {
    if (v === 'a') {
      const chip = x.kind === 'sum'
        ? `<div class="fx" style="flex-wrap:wrap">${CHIP(x.name, { icon: 'edit_note', style: 'max-width:320px' })}${CHIP('Из каталога', { icon: 'link' })}</div>`
        : `<div class="fx">${CHIP(x.name + (x.kind === 'file' ? ' · 1,2 МБ' : ''), { icon: x.icon, x: x.kind !== 'file' || true, style: 'max-width:360px' })}${x.kind === 'ref' ? ST('q', 'Стройка') : ''}</div>`;
      return `<div class="col g4"><span class="bs v">${x.label}</span>${chip}</div>`;
    }
    if (v === 'b') return TF(x.label, x.name, { ro: true, lead: x.icon, trail: (x.kind === 'ref' ? `<span class="bs v" style="align-self:center;padding-right:4px">Стройка</span>` : x.kind === 'file' ? `<span class="bs v" style="align-self:center;padding-right:4px">1,2 МБ</span>` : '') + x.acts.map(a => IBx(a[0], a[2] || '')).join('') });
    return `<div class="col"><span class="bs v" style="padding:0 0 2px">${x.label}</span><div class="fx g16" style="min-height:56px"><span class="v" style="display:flex">${I(x.icon, 24)}</span><div class="f1 col"><span class="bm trunc">${x.name}</span><span class="bs v">${x.sub}</span></div>${x.acts.map(a => IB(a[0], a[2] || '')).join('')}</div></div>`;
  };
  const form = v => `<div class="col" style="padding:20px 24px;gap:${v === 'c' ? 8 : 20}px">${vals.map((x, i) => tile(v, x) + (v === 'c' && i < vals.length - 1 ? DIV() : '')).join('')}</div>`;
  window.FORKS.push({
    id: 'r4', title: 'Плитка выбранного значения: ссылка, файл, сводка составного',
    places: '8 мест: <code>document-sets/fields/RefTile.tsx:23</code> · <code>DocRefField.tsx:73, :105</code> · <code>DocRefCatalogPickerField.tsx:21</code> · <code>FileField.tsx:191</code> · <code>ComplexFields.tsx:744, :967</code> · <code>BaseCandidatePicker.tsx:125</code>. Сейчас вид ссылки говорит заливка: документ — primary-container, каталог — warning-container (тревоги в ней нет). Во всех трёх решениях вид говорит знак, а не цвет. Форма — вкладка «Реквизиты» документа, значения — образец.',
    say: {
      a: '<b>Input chip</b> (Chip с крестиком) со знаком вида под подписью поля. «Заменить» — щелчок по чипу (открывает тот же выбор), «Снять» — крестик. Сводка составного — assist chip, открывающий окно; «Из каталога» — соседний assist chip. Уровень ссылки — StatusText рядом.',
      b: '<b>TextField readOnly на месте плитки</b>: знак вида у ведущего края, подпись в вырезе рамки, действия — IconButton XS 32 в хвосте поля (как крестик DateInput). Все значения формы — одной высоты 56.',
      c: '<b>Строка списка MD3 без рамки</b>: знак 24, две строки (имя; уровень, вид или размер), действия IconButton 40 справа, между значениями — Divider. Заливки и обводки нет.',
    },
    flags: {
      a: [['ok', 'готовый Chip'], ['dev', 'длинное имя в чипе обрезается; «Заменить» спрятано в щелчке по чипу']],
      b: [['new', 'общий компонент «поле-ссылка» вместо RefTile и соседей (8 мест в 6 файлах) — Архитектор']],
      c: [['new', 'тот же общий компонент, вид — строка списка'], ['dev', 'значение перестаёт выглядеть полем формы']],
    },
    render: v => PAIR('Вкладка «Реквизиты», пять видов значения <span>— RefTile, DocRefField, DocRefCatalogPickerField, FileField, ComplexFields (сверху вниз)</span>', 560, 0, () => form(v)),
  });

  // ── Р5: миниатюры ──
  const tiles = v => {
    const one = (n, sel) => {
      const pg = PAGE(112, 12);
      if (v === 'a') return `<div class="col g4" style="align-items:center"><div style="position:relative;border-radius:12px;overflow:hidden;background:var(--schh);padding:8px;${sel ? 'outline:2px solid var(--primary);outline-offset:-2px' : ''}">${pg}${sel ? `<span style="position:absolute;top:6px;left:6px;width:24px;height:24px;border-radius:999px;background:var(--primary);color:var(--on-primary);display:grid;place-items:center">${I('check')}</span>` : ''}<span class="ib xs" style="position:absolute;right:4px;bottom:4px;background:var(--schh)">${I('zoom_in', 20)}</span></div><span class="bs v">Стр. ${n}</span></div>`;
      if (v === 'b') return `<div class="card ${sel ? 'filled' : 'outlined'}" style="padding:8px;align-items:center;gap:4px;width:130px">${pg}<div class="fx" style="width:100%"><span class="bs v f1">Стр. ${n}</span>${IBx('zoom_in')}</div></div>`;
      return `<div class="col g4" style="align-items:center;padding:6px;border-radius:8px;${sel ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : ''}"><div style="position:relative;border:1px solid var(--outline-variant)">${pg}</div><div class="fx" style="width:100%"><span class="bs f1" style="${sel ? '' : 'color:var(--on-surface-variant)'}">Стр. ${n}</span>${IBx('zoom_in')}</div></div>`;
    };
    return `<div style="padding:16px">${CARD('outlined', { title: 'АОСР-12 · Акт освидетельствования скрытых работ', sub: '4 листа · выбран 1', menu: true, body: `<div class="fx g12" style="align-items:flex-start">${one(5)}${one(6, true)}${one(7)}${one(8)}</div>` })}</div>`;
  };
  const logo = v => {
    const mark = `<svg width="40" height="40" viewBox="0 0 40 40"><rect x="4" y="4" width="32" height="32" rx="8" fill="#1d5fb0"/><path d="M22 9l-9 13h7l-2 9 9-13h-7z" fill="#fff"/></svg>`;
    const frame = v === 'a' ? `<div style="width:64px;height:64px;border-radius:12px;background:var(--schh);display:grid;place-items:center">${mark}</div>`
      : v === 'b' ? `<div class="card outlined" style="width:64px;height:64px;display:grid;place-items:center">${mark}</div>`
        : `<div style="width:64px;height:64px;border:1px solid var(--outline-variant);display:grid;place-items:center">${mark}</div>`;
    return `<div style="padding:20px 24px" class="col g12"><h3 class="ts">Логотип</h3><div class="fx g16">${frame}${B('Заменить', 'outlined', 'upload')}${B('Убрать', 'text')}</div><p class="bs v">PNG, JPG или SVG — из него строятся значки приложения.</p></div>`;
  };
  window.FORKS.push({
    id: 'r5', title: 'Изображения и миниатюры, выбор плитки',
    places: '5 мест: <code>datasets/PdfGroupingEditor.tsx:96</code> (миниатюра A4), <code>:125</code> (выбранная плитка листа), <code>:180</code> (лист под лупой — то же решение, что у миниатюры) · <code>document-sets/fields/ImageField.tsx:156</code> (превью картинки — как логотип) · <code>settings/BrandingSection.tsx:200</code> (рамка логотипа 64). Страница PDF белая в обеих темах — это содержимое файла. Карточка группы — Card outlined во всех трёх (это место «компонент», :283).',
    say: {
      a: '<b>Медиа без обводки</b> на surface-container-highest, радиус 12 — как медиа в карточке MD3. Выбранная плитка — галка в круге primary и обводка 2 px primary, как выбор в списке изображений. Лупа — на миниатюре.',
      b: '<b>Каждая миниатюра — Card outlined</b> с подписью и лупой внизу; выбранная — Card filled. Ближе всего к нынешнему: рамка со скруглением, только из компонента.',
      c: '<b>«Лист бумаги»</b>: обводка outline-variant без заливки и без скругления — страница A4 и плитка логотипа так и выглядят. Выбранная — заливка secondary-container вокруг листа («выбранное — цвет»).',
    },
    flags: {
      a: [['ok', 'без новых компонентов'], ['dev', 'галка выбора поверх миниатюры — своя разметка места (в shared/ui такой нет)']],
      b: [['ok', 'готовый Card'], ['dev', 'выбор заливкой карточки: у Card нет состояния «выбрана» — переключение variant, вопрос Архитектору (состояния Card)']],
      c: [['dev', 'снятое скругление — решение о форме листа (rounded-none — ступень шкалы), а не обход правила; решает владелец']],
    },
    render: v => PAIR('Разбиение PDF на документы, группа из четырёх листов, выбран лист 6 <span>— datasets/PdfGroupingEditor.tsx</span>', 640, 0, () => tiles(v))
      + PAIR('Логотип экземпляра <span>— settings/BrandingSection.tsx (так же — превью поля-картинки ImageField)</span>', 480, 0, () => logo(v)),
  });

  // ── Р6: конструкторы ──
  const cond = (c, o, val) => `<div class="fx" style="gap:8px">${SEL('', c, { dense: true, style: 'width:150px' })}${SEL('', o, { dense: true, style: 'width:120px' })}${TF('', val, { dense: true, style: 'flex:1' })}${IBx('close', 'err')}</div>`;
  const filt = v => {
    const nested = `<div class="col g12">${'<div class="fx">' + SEG(['AND', 'OR'], 1, true) + '<span class="bs v f1">вложенная группа</span>' + IBx('close', 'err') + '</div>'}${cond('Тип', 'равно', 'Кабель')}${cond('Тип', 'равно', 'Провод')}<div class="fx">${B('Условие', 'text', 'add')}</div></div>`;
    const box = v === 'a' ? `<div class="card outlined" style="padding:12px">${nested}</div>`
      : v === 'b' ? `<div class="card filled2" style="padding:12px">${nested}</div>`
        : `<div style="display:flex;gap:12px"><div class="vdiv" style="width:2px;margin-left:12px"></div><div class="f1" style="padding:4px 0">${nested}</div></div>`;
    return `<div style="padding:24px;display:flex;justify-content:center"><div class="win" style="width:600px"><div class="hd"><h2>Фильтрация строк</h2></div><div class="bd" style="gap:12px">
      <p class="bs v">Строки, не прошедшие фильтр, исключаются до маппинга. Вычисляемые колонки (если заданы) доступны для фильтрации. Можно вкладывать группы с разной логикой (AND/OR).</p>
      <div class="card outlined" style="padding:12px"><div class="col g12"><div class="fx">${SEG(['AND', 'OR'], 0, true)}</div>${cond('Статус', 'равно', 'Принят')}${cond('Кол-во', 'больше', '0')}${box}<div class="fx">${B('Условие', 'text', 'add')}${B('Группа', 'text', 'add')}</div></div></div>
      </div><div class="ft">${B('Сбросить фильтр', 'text', null, 'danger')}<span class="f1"></span>${B('Отмена')}${B('Сохранить', 'filled')}</div></div></div>`;
  };
  const xpath = v => {
    const step = (name, pred, last) => {
      const inner = `<div class="col g4"><div class="fx" style="gap:4px">${last ? `<span class="chip sel" style="height:24px;padding:0 8px;font-size:12px">@</span>` : ''}${TF('', name, { dense: true, style: 'width:130px', mono: true })}</div>${pred ? `<div class="fx" style="gap:4px"><span class="bs v mono">[</span>${TF('', pred, { dense: true, style: 'width:150px', mono: true })}<span class="bs v mono">]</span></div>` : `<span class="bs pri">+ условие</span>`}</div>`;
      if (v === 'a') return `<div class="card outlined" style="padding:8px">${inner}</div>`;
      if (v === 'b') return `<div class="card filled2" style="padding:8px">${inner}</div>`;
      return `<div style="padding:0 4px">${inner}</div>`;
    };
    const slash = '<span class="tm v mono" style="align-self:flex-start;margin-top:8px">/</span>';
    return `<div style="padding:20px 24px" class="col g12"><h3 class="ts">Путь к строкам</h3><div class="fx" style="align-items:flex-start;gap:6px">${slash}${step('Document')}${slash}${step('Positions')}${slash}${step('Position', "@type='work'")}${slash}${step('code', '', true)}</div>
      <p class="bs v mono">//Document/Positions/Position[@type='work']/@code</p></div>`;
  };
  window.FORKS.push({
    id: 'r6', title: 'Элементы конструкторов выражений',
    places: '2 места: <code>datasets/RowFilterDialog.tsx:210</code> (вложенная группа: сейчас левый акцент цветом по глубине и скругление справа) · <code>datasets/xpath/XPathBuilder.tsx:142</code> (блок шага пути). Переключатель AND/OR во всех трёх — SegmentedButton (это место «компонент», :28); внешняя рамка дерева — Card outlined (:296).',
    say: {
      a: '<b>Card outlined на каждый уровень</b> и на каждый шаг пути. Глубину показывает вложенность карточек, цветной акцент уходит.',
      b: '<b>Card filled с тоном поверхности</b>: вложенная группа и шаг — подложка surface-container, глубже — следующая ступень. Ближе всего к нынешней подложке группы.',
      c: '<b>Без контейнера</b>: вложенность — отступом и вертикальным Divider (как дерево), шаг XPath — просто поля между «/».',
    },
    flags: {
      a: [['ok', 'готовый Card'], ['dev', 'карточка в карточке — в MD3 не запрещено, но тяжело на глубине 3+']],
      b: [['dev', 'тон по глубине — у Card один filled (surface-container-highest); нужна ступень тона — вопрос Архитектору']],
      c: [['ok', 'без новых компонентов (Divider)']],
    },
    render: v => PAIR('Окно «Фильтрация строк» с вложенной группой OR <span>— datasets/RowFilterDialog.tsx</span>', 660, 0, () => filt(v), 'bgl')
      + PAIR('Конструктор пути XPath <span>— datasets/xpath/XPathBuilder.tsx</span>', 760, 0, () => xpath(v)),
  });
})();
