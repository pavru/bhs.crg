/* Сборка листа варианта: девять независимых секций Р1…Р9, подписанных одинаково во всех трёх файлах. */
(() => {
  const v = window.VARIANT;
  const NAMES = { a: 'А — MD3 буквально', b: 'Б — На месте', c: 'В — Тише' };
  const IDEA = {
    a: 'Каждое место — так, как велит MD3 и docs/UI.md: banner в начале области, ошибка — у поля, значение — чипом, карточка — одна цель, боковая панель — side sheet 400. Места сообщений и действий сдвигаются туда, где их ждёт MD3.',
    b: 'Каждое место остаётся там, где стоит сейчас, и меняет только вид — на готовый компонент: banner у причины, Card на месте рамки, поле на месте плитки, колонка на месте колонки. Раскладка не двигается; цена — отступления от правил и новые общие компоненты.',
    c: 'Каждое место — с меньшим числом контейнеров: текст со знаком вместо плашки, пара «подпись — значение» вместо рамки, строка списка вместо плитки, таблица вместо карточек, лист по кнопке вместо постоянной колонки. Решение, без которого дальше нельзя, — окно.',
  };
  const order = ['r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9'];
  const forks = order.map(id => window.FORKS.find(f => f.id === id));
  const files = [['00 Разбор и вопрос.html', '00 Разбор'], ['А - MD3 буквально.html', 'А'], ['Б - На месте.html', 'Б'], ['В - Тише.html', 'В']];
  const cur = { a: 1, b: 2, c: 3 }[v];
  let h = `<h1>${NAMES[v]}</h1><div class="lead"><p>${IDEA[v]}</p><p>Change <code>sharedui-md3-17-screens</code>, задача 0.3. Секции независимы: вариант выбирается по развилкам вперемешку (например «Р1 — А, Р9 — Б»). В каждой секции: места в коде, решение, пометки (<span class="flag ok">готовый компонент</span><span class="flag dev">отступление или цена</span><span class="flag new">нужен новый компонент или правка shared/ui</span>) и кадры в светлой и тёмной теме.</p></div>`;
  h += `<nav class="nav">${files.map((f, i) => `<a href="${encodeURI(f[0])}" class="${i === cur ? 'cur' : ''}">${f[1]}</a>`).join('')}<span style="width:16px"></span>${forks.map(f => `<a href="#${f.id}">${f.id.replace('r', 'Р')}</a>`).join('')}</nav>`;
  for (const f of forks) {
    h += `<section class="fork" id="${f.id}"><h2><span class="id">${f.id.replace('r', 'Р')}</span>${f.title}</h2>
      <p class="places">${f.places}</p>
      <p class="say">${f.say[v]}</p><div>${(f.flags[v] || []).map(([k, t]) => `<span class="flag ${k}">${t}</span>`).join('')}</div>
      ${f.render(v)}</section>`;
  }
  document.getElementById('root').innerHTML = h;
})();
