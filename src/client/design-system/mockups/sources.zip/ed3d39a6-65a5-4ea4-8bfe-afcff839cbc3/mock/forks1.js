/* Развилки Р1–Р3. Тексты — из кода (файл назван в подписи кадра); числа и имена записей — образец. */
window.FORKS = window.FORKS || [];
(() => {
  const { I, B, IB, IBx, BAN, TF, SEL, CARD, SUP, ST, CB, DIV, PAIR } = window.K;

  // ── Р1 ──
  const warn = 'В ред. 3 не сопоставлено строк: 14 — в план они не войдут. Действующей её можно сделать и сейчас; сопоставленное позже войдёт в план само.';
  const mcFacts = `<p class="bm v">План стройки будет считаться по ред. 3 вместо ред. 2.</p>
    <div class="col g4 bm"><div class="ts v">Что изменится в плане</div>
      <div class="fx"><span class="f1">Изменится объём работ</span><span class="num">12</span></div>
      <div class="fx"><span class="f1">Добавится работ</span><span class="num">6</span></div>
      <div class="fx"><span class="f1">Уйдёт работ</span><span class="num">2</span></div></div>
    <p class="bm v">Себестоимость: 12 480 000,00 ₽ → <span class="fm" style="color:var(--on-surface)">12 915 300,00 ₽</span></p>`;
  const mcFoot = B('Отмена') + B('Сделать действующей', 'filled');
  const mcWin = (v, w, phone) => {
    const top = v === 'a' ? BAN('warning', warn, [], null, phone) : '';
    const mid = v === 'b' ? BAN('warning', warn, [], null, phone) : '';
    const inl = v === 'c' ? SUP('wr', warn, 'warning', true) : '';
    if (phone) return `<div class="col" style="height:100%;background:var(--surface);--bg:var(--surface)">
      <div class="appbar">${IB('close')}<h2>Сделать ред. 3 действующей?</h2>${B('Сделать', 'text')}</div>
      ${top.replace('class="banner', 'class="banner" style="background:var(--surface)" data-x="')}
      <div class="col g16" style="padding:16px">${mcFacts}${inl}</div>${mid}</div>`;
    return `<div style="padding:24px;display:flex;justify-content:center">${'<div class="win" style="width:' + w + 'px"><div class="hd"><h2>Сделать ред. 3 действующей?</h2></div>' + (top ? top.replace('<div class="banner', '<div style="border-top:1px solid var(--outline-variant)" class="banner') : '') + `<div class="bd" style="${top ? 'padding-top:16px' : ''}">${mcFacts}${inl}</div>` + (mid ? `<div style="margin-top:16px;border-top:1px solid var(--outline-variant)">${mid}</div>` : '') + `<div class="ft">${mcFoot}</div></div>`}</div>`;
  };
  const blind = 'Модель «llama3.2» не принимает изображения. Распознавание ею невозможно: картинку она не получит, но ответ придумает. Выберите модель, которая работает с изображениями (например, qwen2.5vl:7b, qwen3-vl, llama3.2-vision), или обновите Ollama.';
  const engine = v => {
    const head = `<div class="fx" style="padding:16px 16px 0">${CB(true)}<span class="bm fm f1">Ollama (локально)</span>${ST('er', 'не видит картинок', 'error')}</div>
      <p class="bs v" style="padding:4px 16px 0 42px">Локальная модель, без ключа. Только изображения.</p>`;
    const model = v === 'a' ? SEL('Модель', 'llama3.2', { err: true, hint: blind }) : SEL('Модель', 'llama3.2');
    const msg = v === 'b' ? `<div style="margin-top:12px;border-top:1px solid var(--outline-variant)">${BAN('error', blind)}</div>` : v === 'c' ? `<div style="padding:12px 16px 0">${SUP('er', blind, 'error')}</div>` : '';
    return `<div style="padding:16px"><div class="card outlined">${head}${msg}<div class="col g16" style="padding:${v === 'b' ? 8 : 16}px 16px 16px">${TF('Адрес сервиса', 'http://localhost:11434')}${model}</div></div></div>`;
  };
  const sl = '<span class="fm">Тип модуля «Исполнительная документация» — расширяемый.</span> Можно добавлять свои НЕОБЯЗАТЕЛЬНЫЕ поля и править их. Поля модуля заперты: их ведёт он сам.';
  const type = v => {
    const fieldRow = (name, key, lock) => `<div class="fx" style="height:48px;padding:0 8px 0 16px;border-bottom:1px solid var(--outline-variant)"><span class="bm f1">${name}</span><span class="bs v mono">${key}</span>${lock ? `<span class="v" style="display:flex">${I('lock')}</span>` : IBx('more_vert')}</div>`;
    return `<div class="col" style="height:100%">
      <div class="fx" style="padding:16px 16px 12px 24px;border-bottom:1px solid var(--outline-variant)"><h2 class="tl f1">АОСР</h2>${IB('more_vert')}</div>
      ${v === 'a' ? BAN('info', sl, [], 'lock') : ''}
      <div class="col g16" style="padding:20px 24px">
        <div class="fx g16">${TF('Наименование', 'Акт освидетельствования скрытых работ', { style: 'flex:1' })}${TF('Код', 'AOSR', { style: 'width:140px', mono: true })}</div>
      </div>
      ${v === 'b' ? `<div style="border-top:1px solid var(--outline-variant)">${BAN('info', sl, [], 'lock')}</div>` : ''}
      <div class="col" style="padding:${v === 'b' ? 16 : 4}px 24px 0">
        <h3 class="tm">Поля</h3>
        ${v === 'c' ? `<div style="margin:4px 0 8px">${SUP('', sl, 'lock')}</div>` : '<div style="height:8px"></div>'}
        <div class="card outlined" style="--x:0"><div>${fieldRow('Номер акта', 'number', true)}${fieldRow('Дата акта', 'date', true)}${fieldRow('Примечание заказчика', 'customerNote')}</div></div>
      </div></div>`;
  };
  const twin = 'Такая запись есть в архиве: «ООО «Электромонтаж»». Совпали поля идентичности. Вернуть ту запись — и ссылки на неё останутся целы, а в справочнике не появится вторая такая же.';
  const org = v => {
    const fields = `<div class="col g16">${TF('Наименование', 'ООО «Электромонтаж»')}<div class="fx g16">${TF('ИНН', '7701234567', { style: 'flex:1' })}${TF('КПП', '770101001', { style: 'flex:1' })}</div>${TF('Юридический адрес', 'г. Москва, ул. Электрозаводская, д. 21')}</div>`;
    const acts = ['Вернуть из архива', 'Создать новую'];
    const ban = BAN('info', twin, acts, 'inventory_2', true);
    const win = `<div class="win" style="width:520px"><div class="hd"><h2>Новая организация</h2></div>
      ${v === 'a' ? `<div style="border-top:1px solid var(--outline-variant)">${ban}</div><div style="height:16px"></div>` : ''}
      <div class="bd">${fields}</div>
      ${v === 'b' ? `<div style="margin-top:16px;border-top:1px solid var(--outline-variant)">${ban}</div>` : ''}
      <div class="ft">${B('Отмена')}${B('Создать', 'filled')}</div></div>`;
    if (v !== 'c') return `<div style="padding:24px;display:flex;justify-content:center">${win}</div>`;
    return `<div style="position:relative;padding:24px;display:flex;justify-content:center">${win}<div class="scrim"></div>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center"><div class="win" style="width:400px"><div class="hd" style="text-align:center"><span class="v" style="display:flex;justify-content:center;margin-bottom:16px">${I('inventory_2', 24)}</span><h2>Такая запись есть в архиве</h2></div>
      <div class="bd"><p class="bm v">«ООО «Электромонтаж»» — совпали поля идентичности. Вернуть ту запись — и ссылки на неё останутся целы, а в справочнике не появится вторая такая же.</p></div>
      <div class="ft">${B('Создать новую')}${B('Вернуть из архива', 'filled')}</div></div></div></div>`;
  };
  window.FORKS.push({
    id: 'r1', title: 'Сообщение в середине области, у причины',
    places: '9 мест: <code>settings/BackupSection.tsx:413, :456</code> · <code>settings/BrandingSection.tsx:286</code> · <code>settings/IntegrationSettingsSection.tsx:208, :215</code> · <code>settings/SchemaLevelBanner.tsx:33</code> · <code>document-sets/catalog/ArchivedTwinNote.tsx:42</code> · <code>costs/IssuedMaterialsDialog.tsx:61</code> · <code>planning/estimates/MakeCurrentDialog.tsx:82</code>. Показаны четыре вида места: тело окна, карточка контрола, тело деталей, форма перед сохранением; остальные места получают то же решение по своему виду (BackupSection, IssuedMaterials — как окно; BrandingSection — как карточка контрола).',
    say: {
      a: 'Состояние области — <b>Banner в начале своей области</b> (под заголовком окна, под шапкой деталей). Сообщение об одном контроле — ошибка этого поля («Модель»: красная рамка и текст под полем). «Запись есть в архиве» — banner вверху формы с двумя действиями. Сообщение уходит от причины вверх.',
      b: '<b>Banner там же, где была плашка</b>, во всю ширину своего блока: после фактов в окне, внутри карточки движка, между свойствами и полями типа, над подвалом формы. Раскладка не меняется, меняется вид.',
      c: '<b>Без плашек.</b> Лёгкое — текст со знаком цвета роли прямо у причины, без заливки (как уже сделан соседний «вытянутый логотип»). То, где без решения дальше нельзя, — окно: «Такая запись есть в архиве» спрашивает при «Создать».',
    },
    flags: {
      a: [['ok', 'готовые Banner и ошибка поля']],
      b: [['dev', 'отступление: banner не в начале области — правило UI.md «что сказать — чем» и [UI-81] переписываются']],
      c: [['new', 'текст у причины вне поля — нужен вид StatusText body-small/medium со знаком или новый компонент (Архитектор)'], ['ok', 'окно — готовый ConfirmDialog']],
    },
    render: v => PAIR('Окно «Сделать ред. 3 действующей?» <span>— planning/estimates/MakeCurrentDialog.tsx (блок «Что изменится» упрощён); так же — окна BackupSection и IssuedMaterialsDialog</span>', 640, 0, () => mcWin(v, 592), 'bgl')
      + PAIR('То же окно на 375 px <span>— уже 768 окно во весь экран, основное действие — в шапке</span>', 375, 640, () => mcWin(v, 0, true))
      + PAIR('Карточка движка распознавания <span>— settings/IntegrationSettingsSection.tsx (так же — отказ построения значков в BrandingSection)</span>', 560, 0, () => engine(v))
      + PAIR('Тело типа документа <span>— settings/TypeDetail.tsx: сейчас SchemaLevelBanner стоит после свойств типа, перед схемой</span>', 640, 0, () => type(v))
      + PAIR('Форма новой записи после «Создать» <span>— document-sets/catalog/index.tsx + ArchivedTwinNote.tsx (сейчас заметка — в конце формы, у подвала)</span>', 600, 0, () => org(v), 'bgl'),
  });

  // ── Р2 ──
  const roleNote = '<span class="fm">Состав этой роли не правится.</span> Он не перечислен: он равен справочнику прав и пополняется вместе с ним — поэтому право следующего обновления достанется ей само. Снятое здесь вернулось бы при ближайшем запуске, а снятое управление пользователями оставило бы систему без администратора. Нужен администратор с ограничениями — заведите отдельную роль и выдайте ей нужные галки.';
  const role = v => {
    const perm = (t, c) => `<div class="fx g12" style="padding:10px 16px;border-bottom:1px solid var(--outline-variant)"><span class="cb on" style="opacity:.38">${I('check')}</span><div class="col"><span class="bm" style="opacity:.38">${t}</span><span class="bs v mono" style="opacity:.6">${c}</span></div></div>`;
    const first = '<p class="bm v">Роль носят 2 чел. Состав этой роли задан не здесь — см. ниже.</p>';
    const note = v === 'b' ? CARD('filled', { body: `<p class="bm">${roleNote}</p>` }) : v === 'c' ? `<p class="bm v">${roleNote}</p>` : '';
    return `<div class="col"><div class="fx" style="padding:16px 16px 12px 24px;border-bottom:1px solid var(--outline-variant)"><h2 class="tl f1">Администратор</h2>${IB('more_vert')}</div>
      ${v === 'a' ? BAN('info', roleNote, [], 'lock') : ''}
      <div class="col g16" style="padding:16px 24px 24px">${first}${note}
        <h3 class="ts v">Ядро</h3>
        <div class="card outlined" style="margin-top:-8px">${perm('Типы и поля — правка', 'core.types.edit')}${perm('Пользователи — управление', 'core.users.manage')}${perm('Настройки экземпляра', 'core.system.manage')}</div></div></div>`;
  };
  const band = v => {
    const txt = 'В периоде есть исправления после закрытия: итоги взглядов различаются.';
    const sw = `<div class="fx g12" style="flex-wrap:wrap"><span class="bs v">Закрытые периоды</span>${window.K.SEG(['С исправлениями', 'На момент закрытия'], 0, true)}<span class="bs v">в другом взгляде итог 3 412 800,00 ₽</span></div>`;
    const expl = '<p class="bs v">Исправления учтены в исправленных месяцах — как в реестре.</p>';
    const line = (n, s, ind) => `<div class="fx" style="height:40px;padding-left:${ind ? 16 : 0}px;border-bottom:1px solid var(--outline-variant)"><span class="bm f1">${n}</span><span class="bm num">${s}</span></div>`;
    const table = `<div class="col"><h2 class="ts v" style="margin-bottom:4px">Затраты за период</h2>${line('Всего', '3 520 400,00 ₽')}${line('Материалы', '2 108 900,00 ₽', 1)}${line('Работы подрядчика', '1 290 000,00 ₽', 1)}${line('Не разнесено', '121 500,00 ₽')}</div>`;
    const filters = `<div class="fx" style="flex-wrap:wrap">${window.K.CHIP('Октябрь 2026', { sel: true, icon: 'calendar_month' })}${window.K.CHIP('ЖК «Северный», корпус 2', { sel: true })}${v === 'c' ? '<span class="f1"></span>' + window.K.SEG(['С исправлениями', 'На момент закрытия'], 0, true) : ''}</div>`;
    if (v === 'a') return `<div class="col">${BAN('info', txt)}<div class="col g16" style="padding:16px 24px 24px">${filters}${sw}${expl}${table}</div></div>`;
    if (v === 'b') return `<div class="col g16" style="padding:16px 24px 24px">${filters}${CARD('filled', { body: `<div class="col g12"><p class="bm">${txt}</p>${sw}${expl}</div>` })}${table}</div>`;
    return `<div class="col g16" style="padding:16px 24px 24px">${filters}<div class="col g4"><p class="bm v">${txt} Взгляд выбирается справа в строке отбора; в другом взгляде итог 3 412 800,00 ₽.</p>${expl}</div>${table}</div>`;
  };
  window.FORKS.push({
    id: 'r2', title: 'Нейтральное пояснение-заметка',
    places: '2 места: <code>settings/RolesPage.tsx:165</code> («Состав этой роли не правится») · <code>costs/CostViewsBand.tsx:35</code> (пояснение + переключатель взглядов, первым на странице затрат стройки).',
    say: {
      a: '<b>Banner info в начале области.</b> Переключатель взглядов в действия banner не встаёт (там до двух text-кнопок) — стоит строкой под ним.',
      b: '<b>Card filled на том же месте</b>: пояснение как сводка, которую читают; переключатель внутри карточки. Ближе всего к нынешнему виду.',
      c: '<b>Абзац без контейнера</b> рядом с соседним абзацем (body-medium on-surface-variant). Переключатель взглядов — в строку отбора над таблицей.',
    },
    flags: { a: [['ok', 'готовый Banner']], b: [['ok', 'готовый Card filled']], c: [['ok', 'без новых компонентов'], ['dev', 'переключатель уходит в строку отбора — меняется место']] },
    render: v => PAIR('Роль, состав которой задан не здесь <span>— settings/RolesPage.tsx (тело деталей роли)</span>', 640, 0, () => role(v))
      + PAIR('Затраты стройки за период <span>— costs/SiteCostsPage.tsx + CostViewsBand.tsx (числа — образец)</span>', 720, 0, () => band(v)),
  });

  // ── Р3 ──
  const ro = (v, label, value, o = {}) => {
    if (v === 'a') return TF(label, value, { ro: true, hint: o.hint, trail: o.icon ? `<span class="v" style="display:flex;padding:0 8px">${I(o.icon, 24)}</span>` : '', mono: o.mono });
    if (v === 'b') return TF(label, value, { ro: true, multi: true, hint: o.hint, trail: o.icon ? `<span class="v" style="display:flex;padding:0 8px">${I(o.icon, 24)}</span>` : '', mono: o.mono });
    return `<div class="col g4"><div class="fx" style="gap:6px"><span class="bs v">${label}</span>${o.icon ? `<span class="v" style="display:flex">${I(o.icon)}</span>` : ''}</div><p class="bl${o.mono ? ' mono' : ''}" style="${o.mono ? 'font-size:14px;line-height:20px' : ''}">${value}</p>${o.hint ? `<p class="bs v">${o.hint}</p>` : ''}</div>`;
  };
  const roFrame = (v, label, value, o) => `<div style="padding:20px 16px 16px">${ro(v, label, value, o)}</div>`;
  window.FORKS.push({
    id: 'r3', title: 'Поле только для чтения, нарисованное div\'ом',
    places: '3 места: <code>datasets/FileProfilesDialog.tsx:95</code> (причину «модуль выключен» обрезать нельзя — так записано в коде) · <code>document-sets/catalog/index.tsx:454</code> (привязанное значение со знаком происхождения) · <code>document-sets/fields/LockedFieldMarks.tsx:44</code> (запертое значение). Кадры узкие (380), чтобы было видно, что делает длинное значение.',
    say: {
      a: '<b>TextField readOnly</b>: одна строка, рамка outline-variant, длинное обрезается — полностью в подсказке по наведению. Как у всех полей формы.',
      b: '<b>TextAreaField readOnly</b> с автовысотой: та же рамка, но значение переносится и не теряется.',
      c: '<b>Пара «подпись — значение» текстом без рамки</b> (dl, как двухстрочный пункт списка MD3): «поле» исчезает, значение просто читают; перенос есть.',
    },
    flags: { a: [['ok', 'готовый TextField readOnly'], ['dev', 'длинная причина обрезается — то, от чего код убегал в FileProfilesDialog']], b: [['ok', 'готовый TextAreaField readOnly']], c: [['ok', 'без новых компонентов'], ['dev', 'рядом с полями формы пара выглядит иначе — строй полей разрывается']] },
    render: v => '<div class="row">' + ['<div>' + PAIR('Спящая привязка профиля <span>— datasets/FileProfilesDialog.tsx</span>', 380, 0, () => roFrame(v, 'Счёт на оплату', 'Счёт по ключам профиля — модуль «Счета и накладные» выключен', { hint: 'Привязка сохранена и начнёт действовать, когда модуль включат.' })) + '</div>',
      '<div>' + PAIR('Привязанное поле записи справочника <span>— document-sets/catalog/index.tsx</span>', 380, 0, () => roFrame(v, 'Юридический адрес', 'г. Москва, ул. Электрозаводская, д. 21, стр. 3, этаж 2, помещение 14', { icon: 'document_scanner' })) + '</div>',
      '<div>' + PAIR('Запертое поле модуля <span>— document-sets/fields/LockedFieldMarks.tsx</span>', 380, 0, () => roFrame(v, 'Реквизиты подрядчика', '{"name":"ООО «Электромонтаж»","inn":"7701234567"}', { icon: 'lock', mono: true })) + '</div>'].join('') + '</div>',
  });
})();
