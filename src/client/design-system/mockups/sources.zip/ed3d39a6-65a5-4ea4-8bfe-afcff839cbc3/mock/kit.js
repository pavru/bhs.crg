/* Детали макета: разметка компонентов shared/ui статичными строками (вид после детей 10–16). */
window.K = (() => {
  const I = (n, s = 18, c = '') => `<span class="sym${s !== 18 ? ' s' + s : ''}${c ? ' ' + c : ''}">${n}</span>`;
  const B = (label, kind = 'text', icon, cls = '') => `<span class="btn ${kind}${icon ? ' ic' : ''} ${cls}">${icon ? I(icon) : ''}${label}</span>`;
  const IB = (icon, cls = '') => `<span class="ib ${cls}">${I(icon, 24)}</span>`;
  const IBx = (icon, cls = '') => `<span class="ib xs ${cls}">${I(icon, 20)}</span>`;
  const TONE = { warning: 'warning', error: 'error', info: 'info', success: 'check_circle' };
  const BAN = (tone, text, acts = [], icon, wrap) => `<div class="banner${wrap ? ' wrap' : ''}"><div class="lft"><span class="circ c-${tone}">${I(icon || TONE[tone], 24)}</span><p class="tx">${text}</p></div>${acts.length ? `<div class="acts">${acts.map(a => B(a, 'text')).join('')}</div>` : ''}</div>`;
  // Поле: форма 56 с подписью в вырезе; плотное 40 — без выреза, хвост ближе к краю.
  const TF = (label, value, o = {}) => `<div class="tf${o.ro ? ' ro' : ''}${o.err ? ' err' : ''}${o.dense ? ' dense' : ''}" style="${o.style || ''}"><div class="box" style="${o.dense ? 'gap:4px;padding-right:8px' : ''}">${o.lead ? `<span class="lead">${I(o.lead, 24)}</span>` : ''}<span class="val${o.multi ? ' multi' : ' trunc'}${o.ph ? ' v' : ''}${o.mono ? ' mono' : ''}">${value}</span>${o.trail || o.err ? `<span class="trail">${o.err ? `<span class="er" style="display:flex;padding:0 8px">${I('error', 24)}</span>` : ''}${o.trail || ''}</span>` : ''}${label && !o.dense ? `<span class="lab">${label}</span>` : ''}</div>${o.hint ? `<div class="hint">${o.hint}</div>` : ''}</div>`;
  const SEL = (label, value, o = {}) => TF(label, value, { ...o, trail: `<span style="display:flex;padding:0 ${o.dense ? 0 : 8}px">${I('arrow_drop_down', 24)}</span>` });
  const CARD = (variant, o = {}) => `<div class="card ${variant}" style="${o.style || ''}">${o.title ? `<div class="chd">${o.lead || ''}${o.icon ? `<span class="v" style="display:flex">${I(o.icon, 24)}</span>` : ''}<div class="f1"><div class="tm">${o.title}</div>${o.sub ? `<div class="bs v">${o.sub}</div>` : ''}</div>${o.head || ''}${o.menu ? IB('more_vert') : ''}</div>` : ''}<div class="cbd${o.title ? '' : ' top'}" style="${o.bodyStyle || ''}">${o.body || ''}</div>${o.actions ? `<div class="cft">${o.actions}</div>` : ''}</div>`;
  const SUP = (tone, text, icon, big) => `<p class="sup ${tone}${big ? ' big' : ''}">${icon ? I(icon) : ''}<span>${text}</span></p>`;
  const ST = (tone, text, icon) => `<span class="stx ${tone}">${icon ? I(icon) : ''}${text}</span>`;
  const CB = on => `<span class="cb${on ? ' on' : ''}">${on ? I('check') : ''}</span>`;
  const DIV = (st = '') => `<div class="div" style="${st}"></div>`;
  const SEG = (items, on, sm) => `<span class="seg${sm ? ' sm' : ''}">${items.map((t, i) => `<span class="${i === on ? 'on' : ''}">${i === on ? I('check') : ''}${t}</span>`).join('')}</span>`;
  const CHIP = (text, o = {}) => `<span class="chip${o.icon ? ' l' : ''}${o.x ? ' r' : ''}${o.sel ? ' sel' : ''}" style="${o.style || ''}">${o.icon ? I(o.icon) : ''}<span class="cl">${text}</span>${o.x ? `<span style="display:flex;width:24px;height:24px;align-items:center;justify-content:center">${I('close')}</span>` : ''}</span>`;
  const WIN = (title, body, foot, w) => `<div class="win" style="width:${w}px"><div class="hd"><h2>${title}</h2></div>${body}<div class="ft">${foot}</div></div>`;
  // Страница PDF — бумага белая в обеих темах (это содержимое файла, не роль).
  const PAGE = (w, rows = 14, st = '') => {
    let l = '';
    for (let i = 0; i < rows; i++) l += `<div style="height:${i === 0 ? 7 : 4}px;margin:${i === 0 ? '0 18% 10px' : '0 0 6px'};width:${i === 0 ? '64%' : (i % 4 === 3 ? 58 : 92) + '%'};background:${i === 0 ? '#606368' : '#b9bcc3'};border-radius:1px"></div>`;
    return `<div style="width:${w}px;aspect-ratio:210/297;background:#fff;padding:${Math.round(w * .1)}px ${Math.round(w * .09)}px;${st}">${l}</div>`;
  };
  const FR = (theme, w, h, inner, cls = '', st = '') => `<div class="md3 fr ${cls}" data-theme="${theme}" style="width:${w}px;${h ? 'height:' + h + 'px;' : ''}${st}">${inner}</div>`;
  const PAIR = (label, w, h, fn, cls = '', st = '') => `<div class="sub">${label}</div><div class="pair">${['light', 'dark'].map(t => `<div><div class="tn">${t === 'light' ? 'светлая' : 'тёмная'}</div>${FR(t, w, h, fn(t), cls, st)}</div>`).join('')}</div>`;
  const MEAS = (x, y, w, text) => `<div class="meas" style="left:${x}px;top:${y}px;width:${w}px"><b>${text}</b></div>`;
  return { I, B, IB, IBx, BAN, TF, SEL, CARD, SUP, ST, CB, DIV, SEG, CHIP, WIN, PAGE, FR, PAIR, MEAS };
})();
