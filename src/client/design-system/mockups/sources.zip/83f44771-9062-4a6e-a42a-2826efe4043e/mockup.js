/* Поле даты: «Очистить» и «Сегодня» (#1463). Рамка поля, календарь и кнопки — компоненты BHS.CRG UI
   (OutlinedField, Calendar, Button, TextField); сегменты и значки повторяют DateInput после PR #1548
   (кнопка календаря 32 px, колонка даты в таблице по умолчанию 140 px). Состояния — по §70.7 разбора Дизайнера. */
(function () {
  var h = React.createElement, F = React.Fragment;
  var UI = window.BhsCrgUi || {};
  var OutlinedField = UI.OutlinedField, Calendar = UI.Calendar, Button = UI.Button, TextField = UI.TextField;

  /* ── значки: прямоугольник и линии, как lucide CalendarDays и X ── */
  function CalIcon(p) {
    var s = p && p.size || 16;
    return h('svg', { width: s, height: s, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' },
      h('rect', { x: 3, y: 5, width: 18, height: 16, rx: 2 }), h('line', { x1: 3, y1: 10, x2: 21, y2: 10 }),
      h('line', { x1: 8, y1: 3, x2: 8, y2: 7 }), h('line', { x1: 16, y1: 3, x2: 16, y2: 7 }));
  }
  function XIcon(p) {
    var s = p && p.size || 16;
    return h('svg', { width: s, height: s, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' },
      h('line', { x1: 6, y1: 6, x2: 18, y2: 18 }), h('line', { x1: 18, y1: 6, x2: 6, y2: 18 }));
  }
  function Ib(p) {
    return h('span', { className: 'ib' + (p.hov ? ' hov' : '') + (p.ghost ? ' ghost' : ''), title: undefined },
      p.kind === 'x' ? h(XIcon, { size: p.size }) : h(CalIcon, { size: p.size }),
      p.tip ? h('span', { className: 'tip' }, p.tip) : null,
      p.cursor ? h('span', { className: 'cursor' }) : null);
  }

  /* ── сегменты ДД.ММ.ГГГГ ── */
  var PH = { d: 'ДД', m: 'ММ', y: 'ГГГГ' };
  function parts(value, precision) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || '');
    var all = { d: m ? m[3] : '', m: m ? m[2] : '', y: m ? m[1] : '' };
    var order = precision === 'month' ? ['m', 'y'] : precision === 'year' ? ['y'] : ['d', 'm', 'y'];
    return order.map(function (k) { return { k: k, v: all[k] }; });
  }
  function Segs(p) {
    var list = p.parts || parts(p.value, p.precision);
    return h('span', { className: 'seg' + (p.err ? ' err' : '') },
      list.map(function (s, i) {
        var sel = p.selAll || (p.selFirst && i === 0);
        return h(F, { key: s.k },
          i > 0 ? h('span', { className: 'sep' }, '.') : null,
          h('span', { className: (s.v ? '' : 'ph') + (sel ? ' sel' : '') }, s.v || PH[s.k]),
          p.caretAfter === i ? h('span', { className: 'caret' }) : null);
      }));
  }

  /* ── поле формы: OutlinedField + сегменты + правые значки ── */
  // x: 'always' — × виден у заполненного (А); 'reveal' — по наведению, фокусу и касанию (В); 'none' — нет (Б).
  function Field(p) {
    var filled = !!p.value || !!p.parts;
    var active = p.state === 'hover' || p.state === 'focus' || p.state === 'touch';
    var showX = !p.required && filled && (p.x === 'always' || (p.x === 'reveal' && active));
    var hovX = p.state === 'hover' && showX;
    return h(OutlinedField, {
      label: p.label, required: p.required, raise: 'always', focused: p.state === 'focus' || p.state === 'touch',
      error: p.error, hint: p.error ? undefined : p.hint,
      trailing: h('span', { className: 'trail' },
        showX ? h(Ib, { kind: 'x', hov: hovX, tip: hovX ? 'Очистить дату' : null, cursor: hovX }) : null,
        h(Ib, { kind: 'cal', hov: p.calHover, cursor: p.state === 'hover' && !showX })),
    },
      h('div', { style: { height: 56, padding: '0 8px 0 16px', display: 'flex', alignItems: 'center', flex: 1, minWidth: 0 } },
        h(Segs, { value: p.value, parts: p.parts, precision: p.precision, err: !!p.error, selAll: p.selAll,
          selFirst: p.state === 'focus' && !p.selAll && filled, caretAfter: p.state === 'focus' && !filled ? -1 : undefined })));
  }

  /* ── календарь с подвалом ── */
  var TODAY = { day: 'Сегодня', month: 'Этот месяц', year: 'Этот год' };
  function Pop(p) {
    var st = React.useState(p.value || '');
    var precision = p.precision || 'day';
    var clear = !p.required && p.clear;
    return h('div', { className: 'pop' },
      h(Calendar, { value: st[0], onSelect: st[1], precision: precision, onClose: function () {} }),
      p.footer === false ? null : h('div', { className: 'pop-f' },
        clear ? h(Button, { variant: 'text', size: 'sm' }, 'Очистить') : null,
        h('span', { className: 'sp' }),
        h(Button, { variant: 'text', size: 'sm' }, TODAY[precision])));
  }

  /* ── ячейка массива ── */
  function Cell(p) {
    var showCal = p.state === 'hover' || p.state === 'focus';
    var showX = p.x === 'always' && !!p.value;
    return h('div', { className: 'gc date' + (p.state === 'focus' ? ' foc' : '') },
      h(Segs, { value: p.value, parts: p.parts, err: p.err, selFirst: p.state === 'focus' }),
      h('span', { style: { display: 'flex', alignItems: 'center' } },
        showX ? h(Ib, { kind: 'x', size: 14 }) : null,
        h(Ib, { kind: 'cal', size: 14, ghost: !showCal, hov: p.state === 'hover', cursor: p.state === 'hover' })));
  }
  function Grid(p) {
    var cols = '32px 168px ' + p.w + 'px';
    var rows = [
      { n: 1, name: 'Кабель ВВГнг-LS 3×2,5', st: 'rest', v: '2026-10-12', cap: 'покой' },
      { n: 2, name: 'Автомат 16 А', st: 'hover', v: '2026-10-14', cap: 'наведение' },
      { n: 3, name: 'Щит ЩРн-12', st: 'focus', v: '2026-10-19', cap: 'фокус' },
      { n: 4, name: 'Короб 40×25', st: 'rest', parts: [{ k: 'd', v: '31' }, { k: 'm', v: '02' }, { k: 'y', v: '2026' }], err: true, cap: 'ошибка' },
    ];
    return h('div', { className: 'grid' },
      h('div', { className: 'grow gh', style: { gridTemplateColumns: cols } },
        h('div', { className: 'gc' }, '№'), h('div', { className: 'gc' }, 'Материал'), h('div', { className: 'gc' }, 'Дата поставки')),
      rows.map(function (r) {
        return h('div', { key: r.n, className: 'grow', style: { gridTemplateColumns: cols } },
          h('div', { className: 'gc', style: { color: 'var(--f-fg3)' } }, r.n),
          h('div', { className: 'gc' }, r.name, h('span', { style: { marginLeft: 6, color: 'var(--f-fg4)', fontSize: 11 } }, '· ' + r.cap)),
          h(Cell, { state: r.st, value: r.v, parts: r.parts, err: r.err, x: p.x }));
      }));
  }

  function Cap(p) { return h('p', { className: 'cap' }, h('i', null, p.k), p.children); }

  /* ── лист одного варианта: одинаковые состояния ── */
  function Sheet(v) {
    var X = v.x;
    return h(F, null,
      h(Opt, { id: v.id + '1', w: 380, label: 'Форма счёта: «Оплатить до» — необязательное',
        note: v.formNote },
        h('div', { className: 'frame', style: { width: 380, boxSizing: 'border-box' } },
          h(Cap, { k: 'заполнено' }), h(Field, { label: 'Оплатить до', value: '2026-11-03', x: X, state: 'rest' }),
          h(Cap, { k: 'наведение' }), h(Field, { label: 'Оплатить до', value: '2026-11-03', x: X, state: 'hover' }),
          h(Cap, { k: 'фокус' }), h(Field, { label: 'Оплатить до', value: '2026-11-03', x: X, state: 'focus' }),
          h(Cap, { k: 'пусто' }), h(Field, { label: 'Оплатить до', value: '', x: X, state: 'rest', hint: 'срок из договора' }),
          h(Cap, { k: 'ошибка' }), h(Field, { label: 'Оплатить до', x: X, state: 'rest', error: 'Дата не дописана',
            parts: [{ k: 'd', v: '03' }, { k: 'm', v: '' }, { k: 'y', v: '2026' }] }))),
      h(Opt, { id: v.id + '2', w: 320, label: 'Календарь из «Оплатить до»', note: v.calNote },
        h(Pop, { value: '2026-11-03', clear: v.footerClear })),
      h(Opt, { id: v.id + '3', w: 320, label: 'Точность «месяц»', note: h(F, null, '«Сегодня» по точности: ', h('b', null, '«Этот месяц»'), ' ставит ГГГГ-ММ-01, «Этот год» — ГГГГ-01-01. День — компании.') },
        h(Pop, { value: '2026-11-01', precision: 'month', clear: v.footerClear })),
      h(Opt, { id: v.id + '4', w: v.cellW + 220, label: 'Ячейка массива — ' + v.cellW + ' px', note: v.cellNote },
        h(Grid, { w: v.cellW, x: X === 'always' ? 'always' : 'none' })),
      h(Opt, { id: v.id + '5', w: 390, label: 'Телефон 390 px: касание, календарь', note: v.phoneNote },
        h(Phone, { x: X, clear: v.footerClear })),
      h(Opt, { id: v.id + '6', w: 380, label: 'Тёмная тема', note: 'Те же токены, что у приложения в тёмной теме. Подвал — кнопки text, без своей заливки.' },
        h('div', { className: 'frame dk', 'data-theme': 'dark', style: { width: 380, boxSizing: 'border-box' } },
          h(Field, { label: 'Оплатить до', value: '2026-11-03', x: X, state: 'focus' }),
          h(Pop, { value: '2026-11-03', clear: v.footerClear }))));
  }

  function Phone(p) {
    return h('div', { className: 'phone' },
      h('div', { className: 'ph-bar' }, h('span', { className: 'ib' }, h(XIcon, { size: 20 })), h('span', { className: 'ph-t' }, 'Счёт № ЦБ-734')),
      h('div', { className: 'ph-b' },
        h(TextField, { label: 'Номер', value: 'ЦБ-734', onChange: function () {} }),
        h(Field, { label: 'Дата счёта', value: '2026-10-02', required: true, x: p.x, state: 'rest' }),
        h(Field, { label: 'Оплатить до', value: '2026-11-03', x: p.x, state: 'touch' })),
      h('div', { className: 'ph-pop', style: { top: 278 } }, h(Pop, { value: '2026-11-03', clear: p.clear })),
      h('span', { className: 'finger', style: { left: 326, top: 222 } }));
  }

  function Opt(p) {
    return h('div', { className: 'dv-opt', id: p.id, style: { '--w': p.w + 'px' } },
      h('div', { className: 'dv-olabel' }, h('a', { className: 'dv-oid', href: '#' + p.id }, p.id), p.label, p.tag),
      p.children,
      p.note ? h('p', { className: 'dv-note' }, p.note) : null);
  }
  function Tag(k, t) { return h('span', { className: 'tag ' + k }, t); }

  var VARIANTS = [
    { id: 'А', name: 'Крестик в поле', tag: Tag('alt', 'вариант'), x: 'always', footerClear: false, cellW: 170,
      sub: h(F, null, h('b', null, 'Trailing icon по MD3.'), ' У необязательного заполненного поля × виден всегда, рядом со значком календаря; оба прижаты к правому краю. «Сегодня» — внизу календаря. Очистка — только в поле, в календаре её нет.'),
      pc: [h(F, null, h('b', null, '+'), ' очистка на виду, один щелчок, привычна по полям поиска'), h(F, null, h('b', null, '−'), ' крестики в каждой длинной форме; колонку даты расширять ещё до ~170 px; в отборе sm (h-7) кнопка не помещается')],
      formNote: h(F, null, h('b', null, '× виден всегда'), ', когда есть что стирать. У пустого поля и у обязательного его нет. Tab: сегменты → × → календарь.'),
      calNote: 'Подвал: только «Сегодня». Очистить — крестиком в поле.',
      cellNote: h(F, null, 'Колонка 140 px вмещает сегменты и один значок; ', h('b', null, 'для × она расширена до ~170 px'), ' — во всех таблицах документов.'),
      phoneNote: '× виден всегда у заполненного необязательного поля; календарь — по значку.' },
    { id: 'Б', name: 'Всё в календаре', tag: Tag('alt', 'запасной'), x: 'none', footerClear: true, cellW: 140,
      sub: h(F, null, h('b', null, 'Поле не меняется.'), ' Внизу календаря строка действий: «Очистить» слева, «Сегодня» справа — одна модель для формы, ячейки, отбора (#1464) и телефона. С клавиатуры — Ctrl+A → Delete.'),
      pc: [h(F, null, h('b', null, '+'), ' плотность не тронута, нечего прятать по наведению, одно место для обоих действий'), h(F, null, h('b', null, '−'), ' очистка спрятана за календарём: в «Оплатить до» её трудно найти')],
      formNote: h(F, null, h('b', null, 'Поле как сейчас'), ' — значок календаря и только. Стереть: открыть календарь → «Очистить», или Ctrl+A → Delete.'),
      calNote: h(F, null, 'Подвал: ', h('b', null, '«Очистить»'), ' — у необязательного поля, где есть что стирать; ', h('b', null, '«Сегодня»'), ' — всегда.'),
      cellNote: 'Ячейка не меняется: 140 px, значок календаря по наведению и фокусу. Очистка — в календаре или Ctrl+A → Delete.',
      phoneNote: 'Касание поля — ввод; очистка и «Сегодня» — в календаре по значку.' },
    { id: 'В', name: 'Календарь + × как ускоритель', tag: Tag('ok', 'рекомендует Дизайнер'), x: 'reveal', footerClear: true, cellW: 140,
      sub: h(F, null, h('b', null, 'Б плюс ускоритель в форме.'), ' Подвал календаря — как в Б. В поле формы × появляется по наведению, фокусу и на касании — та же модель, что у TypePickerField в тех же формах. В ячейке и отборе sm крестика нет. Наведение прячет только ускоритель: действие всегда видно в календаре.'),
      pc: [h(F, null, h('b', null, '+'), ' быстрая очистка там, где форма просторная; ячейка и отбор не тронуты'), h(F, null, h('b', null, '−'), ' две точки входа для одного действия; × в Tab по фокусу поля')],
      formNote: h(F, null, h('b', null, '× по наведению, фокусу и касанию'), '; в покое — только значок календаря. Tab: сегменты → × → календарь.'),
      calNote: 'Подвал как в Б: «Очистить» слева, «Сегодня» справа.',
      cellNote: 'Ячейка как в Б: 140 px, без крестика. Очистка — в календаре или Ctrl+A → Delete.',
      phoneNote: 'Касание поля показывает ×; календарь — по значку, с тем же подвалом.' },
  ];

  function Common() {
    return h('section', { className: 'dv-turn', id: 't0' },
      h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t0' }, '0'), h('span', { className: 'dv-tname' }, 'Общее для всех вариантов')),
      h('p', { className: 'dv-tsub' }, 'Варианты различаются только тем, где живёт «Очистить». Ниже — то, что одинаково: обязательное поле, клавиатура, «Сегодня» по поясу компании.'),
      h('div', { className: 'dv-opts' },
        h(Opt, { id: '0a', w: 420, label: 'Окно «Оплата»: обязательная «Дата платежа»',
          note: h(F, null, h('b', null, 'У обязательного поля «Очистить» нет нигде'), ' — ни крестика, ни кнопки в календаре. «Сегодня» ставит день компании; для чтения с экрана — «Сегодня, 19 октября 2026»: около полуночи он может разойтись с часами компьютера.') },
          h('div', { className: 'frame', style: { width: 420, boxSizing: 'border-box' } },
            h(Field, { label: 'Дата платежа', value: '2026-10-19', required: true, x: 'always', state: 'focus' }),
            h(Pop, { value: '2026-10-19', required: true }))),
        h(Opt, { id: '0b', w: 380, label: 'Клавиатура: Ctrl+A → Delete',
          note: h(F, null, h('span', { className: 'kbd' }, 'Ctrl+A'), ' в любом сегменте выделяет всю дату. ', h('span', { className: 'kbd' }, 'Delete'), ' очищает (у необязательного поля), цифра начинает дату заново, ', h('span', { className: 'kbd' }, 'Esc'), ' снимает выделение. Esc после очистки возвращает прежнюю дату.') },
          h('div', { className: 'frame', style: { width: 380, boxSizing: 'border-box' } },
            h(Cap, { k: 'Ctrl+A' }), h(Field, { label: 'Оплатить до', value: '2026-11-03', x: 'none', state: 'focus', selAll: true }),
            h(Cap, { k: 'Delete' }), h(Field, { label: 'Оплатить до', value: '', x: 'none', state: 'focus', hint: 'срок из договора' }))),
        h(Opt, { id: '0c', w: 360, label: 'Что сейчас: стёрт один сегмент',
          note: h(F, null, h('b', null, 'Не «молча возвращается»'), ', как сказано в задаче: после #1460 под полем «Дата не дописана». Но форма держит прежнюю дату, и сохранение запишет её. Стереть дату целиком сегодня можно, только опустошив все сегменты — это и чинит «Очистить».') },
          h('div', { className: 'frame', style: { width: 360, boxSizing: 'border-box' } },
            h(Field, { label: 'Оплатить до', x: 'none', state: 'rest', error: 'Дата не дописана',
              parts: [{ k: 'd', v: '' }, { k: 'm', v: '11' }, { k: 'y', v: '2026' }] }))))
    );
  }

  function App() {
    return h(F, null,
      h(Common),
      VARIANTS.map(function (v, i) {
        return h('section', { key: v.id, className: 'dv-turn', id: 't' + (i + 1) },
          h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t' + (i + 1) }, v.id), h('span', { className: 'dv-tname' }, v.name), v.tag),
          h('p', { className: 'dv-tsub' }, v.sub),
          h('div', { className: 'pc' }, v.pc.map(function (x, j) { return h('span', { key: j }, x); })),
          h('div', { className: 'dv-opts' }, h(Sheet, v)));
      }));
  }

  if (!OutlinedField || !Calendar || !Button) {
    document.getElementById('root').textContent = '⚠ BhsCrgUi не загрузился';
  } else {
    ReactDOM.createRoot(document.getElementById('root')).render(h(App));
  }
})();
