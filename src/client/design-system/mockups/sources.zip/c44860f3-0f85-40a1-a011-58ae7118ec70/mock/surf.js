/* Экраны трёх макетов change sharedui-md3-16-surfaces. Один набор экранов на три варианта; числа
   варианта — переменные в <style> страницы и mock/surf.css. Оси (разбор Дизайнера и Архитектора 03.11.2026):
   - панель просмотрщика: docked 64 одной плоскостью с холстом (А) / 48 с холстом тоном ниже (Б) / плавающая 56 (В);
   - календарь: docked дословно со списками (А) / сетки на общем слое уровня 2 (Б) / строки 40 при мыши (В);
   - редактор: surface и системные роли (А) / «колодец» с success и warning (Б) / «бумага» surface-container-lowest (В). */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'MD3 буквально', float: 0, suffix: 1, calList: 1,
      rule: 'Панель — docked toolbar 64 (M3 Expressive) на surface-container без черты, одной плоскостью с холстом: граница видна там, где о панель обрезается лист. Поле номера — плотное 40 с суффиксом «/ 12», между группами — промежуток 16 вместо черты. Календарь — docked date picker дословно: два селектора «‹ ноя ▾ ›  ‹ 2026 ▾ ›», месяц и год — списком с галочкой, surface-container-high, возвышение 3, строка 48. Редактор — фон surface, текущая строка surface-container, выделение primary 16 %, синтаксис только системными ролями (primary, tertiary, secondary).' },
    b: { key: 'b', name: 'Б', title: 'Плотно', float: 0, suffix: 0, calList: 0,
      rule: 'Панель 48, как сегодня, на surface-container без черты; холст на ступень тона ниже (surface-container-low) — панель и холст не сливаются. Поле номера — плотное 40, «из 12» снаружи. Календарь — спецификация как написана: 360, клетка 40, строка 48; стрелки по краям, в центре «ноябрь ▾» и «2026 ▾», месяц и год — сеткой (как сегодня), слой — общий с меню (surface-container, уровень 2, В11). Редактор — «колодец» surface-container-low, полоса номеров surface-container, текущая строка обводкой, выделение secondary-container; строки — success, числа — warning. Отступления D8: панель 48 (В7: «плотных панелей нет»), цвета сигнала в коде.' },
    v: { key: 'v', name: 'В', title: 'Плавающая панель', float: 1, suffix: 1, calList: 0,
      rule: 'Панель — floating toolbar M3 Expressive: пилюля 56 на surface-container-high, возвышение 3, в 16 от нижнего края; холст во всю высоту, лист прокручивается под ней. В узкой колонке масштаб и поворот уходят в «⋮». Пересматривает выбор от 25.10.2026 («панель не плавает»). Календарь — 360, строки 40 при мыши и 48 при касании (уже названное отступление «цель по основному указателю»), шапка «Ноябрь 2026 ▾» слева и стрелки справа, месяц и год — сеткой. Редактор — «бумага» surface-container-lowest, номер текущей строки primary, выделение primary-container, подсветка минимальная.' },
  };
  const V = VARS[window.VARIANT || 'a'];
  document.body.classList.add('v-' + V.key);
  const Q = new URLSearchParams(location.search);
  const ST = { theme: Q.get('theme') || 'both', h: Q.get('h') === '633' ? 633 : 768 };
  document.body.style.setProperty('--lh', ST.h + 'px');

  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c) => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}'>${s(n)}</span>`;
  const btn = (t, v, n) => `<span class='btn ${v}'>${n ? s(n) : ''}${t}</span>`;
  const chip = (t) => `<span class='chip'>${t}${s('arrow_drop_down')}</span>`;
  const thm = (t) => t === 'dark' ? 'тёмная' : 'светлая';
  const themes = () => ST.theme === 'both' ? ['light', 'dark'] : [ST.theme];
  const cap = (t) => `<div class='cap'>${t}</div>`;
  const sec = (h, t, body) => `<h2>${h}</h2>${t ? cap(t) : ''}${body}`;
  const each = (fn) => `<div class='two'>${themes().map(fn).join('')}</div>`;
  const md3 = (theme, label, inner, style) => `<div class='md3' data-theme='${theme}' data-screen-label='${label} (${thm(theme)})'${style ? ` style='${style}'` : ''}>${inner}</div>`;

  /* ---- панель просмотрщика ---- */
  const pfield = () => V.suffix
    ? `<span class='pf'>3<span class='sf'>/ 12</span></span>`
    : `<span class='pf'>3</span><span class='of'>из 12</span>`;
  const toolbar = (narrow) => {
    const pages = `${ib('chevron_left', 'Предыдущая')}${pfield()}${ib('chevron_right', 'Следующая')}<span class='gp'></span>`;
    if (V.float && narrow) return `<div class='tb'>${pages}${ib('more_vert', 'Масштаб и поворот')}</div>`;
    const zoom = narrow ? chip('86 %') : `${ib('remove', 'Уменьшить')}${chip('По ширине')}${ib('add', 'Увеличить')}`;
    return `<div class='tb'>${pages}${zoom}${V.float ? '<span class="gp"></span>' : "<span class='sp'></span>"}${ib('rotate_right', 'Повернуть')}</div>`;
  };
  const page = () => `<div class='pg'><div class='l' style='width:40%'></div><div class='l' style='width:62%'></div><div class='l' style='width:55%'></div>` +
    `<h4>Счёт на оплату № 1018 от 25.10.2026</h4><div class='l' style='width:80%'></div><div class='l' style='width:70%'></div>` +
    `<table>${Array.from({ length: 9 }, (_, i) => `<tr><td style='width:6%'>${i + 1}</td><td>Кабель ВВГнг(А)-LS 3×${[1.5, 2.5, 4][i % 3]}</td><td style='width:12%'>${(i + 2) * 50} м</td><td style='width:18%'>${((i + 3) * 1873.4).toFixed(2)}</td></tr>`).join('')}</table>` +
    `<div class='l' style='width:35%;margin-left:auto'></div><div class='l' style='width:45%;margin-left:auto'></div><div class='l' style='width:60%;margin-top:14px'></div><div class='l' style='width:50%'></div><span class='stamp'></span></div>`;
  const menuItems = (narrow) => {
    const it = (t, on, k, ic) => `<div class='mi${on ? ' on' : ''}'><span class='ck'>${ic ? s(ic, 's24') : (on ? s('check', 's24') : '')}</span>${t}${k ? `<span class='k'>${k}</span>` : ''}</div>`;
    return it('По ширине', 1, 'Ctrl 0') + it('Страница целиком') + `<div class='dv'></div>` +
      ['50 %', '75 %', '100 %', '150 %', '200 %'].map(z => it(z)).join('') +
      (narrow ? `<div class='dv'></div>` + it('Уменьшить', 0, 'Ctrl −', 'remove') + it('Увеличить', 0, 'Ctrl +', 'add') : '') +
      (V.float && narrow ? `<div class='dv'></div>` + it('Повернуть', 0, '', 'rotate_right') : '');
  };
  /* Меню — слой вверх от панели; у правого края колонки его сдвигает проверка столкновений Radix. */
  const viewer = (narrow, menu) => `<div class='vw' data-vw><div class='cv'>${page()}${page()}</div>${toolbar(narrow)}` +
    (menu ? `<div class='menu' style='right:8px;bottom:calc(${V.float ? '16px + ' : ''}var(--tbh) + 6px)'>${menuItems(narrow)}</div>` : '') + `<span class='cnt' data-cnt></span></div>`;

  /* ---- ноутбук: оболочка (выбор 15 — А) и экран счёта ---- */
  const RAIL = [['apartment', 'Стройки'], ['database', 'Данные'], ['calculate', 'Затраты'], ['assignment', 'Планы']];
  const rail = `<nav class='rail'><div class='brand'><span class='logo'>${s('bolt', 's20 fill')}</span></div>` +
    RAIL.map(([n, t]) => `<div class='it${t === 'Затраты' ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === 'Затраты' ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const sub = `<aside class='sub'><div class='t'>Учёт затрат</div><div class='h'>Счета, накладные, закрытие месяца</div>` +
    ['Счета', 'Накладные', 'Реестр счетов', 'Затраты по стройке'].map((t, i) => `<div class='li${i === 0 ? ' on' : ''}'>${t}</div>`).join('') + '</aside>';
  const bar = `<header class='bar'><span class='door'>${s('search', 's24')}Найти счёт, стройку или действие</span><span class='sp'></span>${ib('notifications', 'Активность')}<span class='ava'>АП</span></header>`;
  const SUP = ['АО «Светотехника»', 'ЭТМ «Север»', 'Кабельный завод «Проводник»', 'ООО «Электромонтаж»', 'ИП Семёнов', 'ООО «Щитовые системы»'];
  const list = `<div class='lst'>` + Array.from({ length: 10 }, (_, i) => `<div class='r${i === 0 ? ' on' : ''}'><b>№ ${1018 - i} · ${SUP[i % 6]}</b><span>${String(25 - i).padStart(2, '0')}.10.2026 · ${(((i * 7919) % 97 + 3) * 4131.7).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ₽</span></div>`).join('') + '</div>';
  const fld = (l, v, ic, foc) => `<div class='fld${foc ? ' foc' : ''}'><i>${l}</i>${v}${ic ? s(ic, 's24 muted') : ''}</div>`;
  const form = `<div class='frm'>${fld('Поставщик', 'АО «Светотехника»', 'arrow_drop_down')}${fld('Номер', '1018')}${fld('Дата', '25.10.2026', 'calendar_today')}${fld('Раздел', 'Корпус 2 · ЭОМ', 'arrow_drop_down')}${fld('Сумма с НДС, ₽', '184 233,40')}</div>`;
  const scan = (menu) => `<div class='scan'><div class='frow'>${s('description', 'muted')}<span class='fn'>Счёт_1018_Светотехника.pdf</span>${btn('Открыть', 'text', 'open_in_new')}</div>${viewer(true, menu)}</div>`;
  const ph = `<div class='ph' style='min-height:71px;border-bottom:1px solid var(--outline-variant)'><div><h1>Счёт № 1018</h1></div><span class='sub'>АО «Светотехника» · ЖК «Северный»</span><span class='sp'></span>${btn('Оплата', 'tonal', 'payments')}</div>`;
  const laptop = (theme, label, o) => md3(theme, label, `<div class='lap'>${rail}${sub}<div class='col'>${bar}<div class='work'>${ph}<div class='ld'>${list}${form}${o.scan === false ? '' : scan(o.menu)}</div></div></div>${o.over || ''}${o.cnt ? "<span class='cnt' data-calcnt style='z-index:30'></span>" : ''}</div>`);

  /* ---- календарь: ноябрь 2026 (шесть недель — худший случай), сегодня 3-е ---- */
  const MON = ['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'];
  const MSH = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const head = (mode) => {
    const hide = (cond) => cond ? 'style="visibility:hidden"' : '';
    if (V.key === 'a') {
      // docked MD3: пока открыт список месяцев или лет, остаётся только его селектор, стрелки скрыты
      const m = mode === 'month', y = mode === 'year';
      return `<div class='hd'><span ${hide(m || y)}>${ib('chevron_left', 'Предыдущий месяц')}</span><span class='hb${m ? ' on' : ''}' ${hide(y)}>ноя${s(m ? 'arrow_drop_up' : 'arrow_drop_down')}</span><span ${hide(m || y)}>${ib('chevron_right', 'Следующий месяц')}</span>` +
        `<span class='sp'></span><span ${hide(m || y)}>${ib('chevron_left', 'Предыдущий год')}</span><span class='hb${y ? ' on' : ''}' ${hide(m)}>2026${s(y ? 'arrow_drop_up' : 'arrow_drop_down')}</span><span ${hide(m || y)}>${ib('chevron_right', 'Следующий год')}</span></div>`;
    }
    const lbl = mode === 'year' ? '2020 – 2035' : mode === 'month' ? '2026' : 'Ноябрь 2026';
    if (V.key === 'b') {
      const mid = mode === 'day' || mode === 'range' ? `<span class='hb'>ноябрь${s('arrow_drop_down')}</span><span class='hb'>2026${s('arrow_drop_down')}</span>` : `<span class='hb on'>${lbl}${s('arrow_drop_up')}</span>`;
      return `<div class='hd'>${ib('chevron_left', 'Назад')}<span class='sp'></span>${mid}<span class='sp'></span>${ib('chevron_right', 'Вперёд')}</div>`;
    }
    return `<div class='hd'><span class='hb${mode === 'day' || mode === 'range' ? '' : ' on'}'>${lbl}${s(mode === 'day' || mode === 'range' ? 'arrow_drop_down' : 'arrow_drop_up')}</span><span class='sp'></span>${ib('chevron_left', 'Назад')}${ib('chevron_right', 'Вперёд')}</div>`;
  };
  const days = (o) => {
    let h = `<div class='g'>` + ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(d => `<span class='wd'>${d}</span>`).join('');
    for (let i = 0; i < 6; i++) h += `<span class='d'></span>`;
    for (let d = 1; d <= 30; d++) {
      const c = [d === 3 ? 'td' : '', d === o.sel ? 'sel' : '', d === o.foc ? 'foc' : '',
        o.r && d === o.r[0] ? 'sel s' : '', o.r && d === o.r[1] ? 'sel e' : '', o.r && d > o.r[0] && d < o.r[1] ? 'in' : ''].filter(Boolean).join(' ');
      h += `<span class='d ${c}'><b>${d}</b></span>`;
    }
    return h + `</div>`;
  };
  const footer = (today) => `<div class='ft'>${btn('Очистить', 'text')}${btn(today || 'Сегодня', 'text')}</div>`;
  const monthsBody = () => V.calList
    ? `<div class='ls'>${MON.slice(7).concat(MON.slice(0, 1)).map((m, i) => { const on = m === 'октябрь'; return `<div class='o${on ? ' on' : ''}'>${on ? s('check', 's24') : "<span style='width:24px'></span>"}${m[0].toUpperCase() + m.slice(1)}</div>`; }).join('')}</div>`
    : `<div class='mg' style='grid-template-columns:repeat(3,1fr)'>${MSH.map(m => `<span class='${m === 'окт' ? 'on' : m === 'ноя' ? 'td' : ''}'>${m}</span>`).join('')}</div>`;
  const yearsBody = () => V.calList
    ? `<div class='ls'>${[2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030].map(y => `<div class='o${y === 2026 ? ' on' : ''}'>${y === 2026 ? s('check', 's24') : "<span style='width:24px'></span>"}${y}</div>`).join('')}</div>`
    : `<div class='mg' style='grid-template-columns:repeat(4,1fr)'>${Array.from({ length: 16 }, (_, i) => 2020 + i).map(y => `<span class='${y === 2026 ? 'on' : ''}'>${y}</span>`).join('')}</div>`;
  const cal = (mode, o = {}) => `<div class='cal' data-cal>${head(mode)}` +
    (mode === 'month' ? monthsBody() + footer('Этот месяц') : mode === 'year' ? yearsBody() + footer('Этот год') : days(o) + footer()) + `</div>`;
  const calCell = (lab, html) => `<div><div class='lab'>${lab} · <span data-calh></span></div>${html}</div>`;

  /* ---- окно «Оплата» с календарём ---- */
  const payWin = `<div class='scr'></div><div class='ctr'><div class='win' style='width:896px'><div class='hd'><h2>Оплата счёта № 1018</h2></div>` +
    `<div class='bd' style='padding-top:8px'><div style='display:flex;gap:16px'><div style='width:220px' data-anchor>${fld('Дата оплаты', '12.11.2026', 'calendar_today', 1)}</div><div style='flex:1'>${fld('Сумма, ₽', '184 233,40')}</div><div style='width:240px'>${fld('Способ', 'Платёжное поручение', 'arrow_drop_down')}</div></div>` +
    `${fld('Номер платёжного документа', '4512')}${fld('Комментарий', '<span class="muted">Необязательно</span>')}</div>` +
    `<div class='ft'>${btn('Отмена', 'text')}${btn('Сохранить', 'filled')}</div></div></div><div data-floatcal style='position:absolute;z-index:20'>${cal('day', { sel: 12, foc: 12 })}</div>`;

  /* ---- редактор шаблона ---- */
  const k = (c, t) => `<span class='${c}'>${t}</span>`;
  const CODE = [
    k('cm', '// Акт освидетельствования скрытых работ (АОСР)'),
    `${k('kw', '#import')} ${k('str', '"userlib.typ"')}: *`,
    `${k('kw', '#let')} d = ${k('fn', 'json')}(${k('str', '"data.json"')})`,
    '',
    `${k('kw', '#set')} ${k('fn', 'page')}(paper: ${k('str', '"a4"')}, margin: (x: ${k('nm', '20mm')}, y: ${k('nm', '15mm')}))`,
    `${k('kw', '#set')} ${k('fn', 'text')}(font: ${k('str', '"Times New Roman"')}, size: ${k('nm', '12pt')}, lang: ${k('str', '"ru"')})`,
    '',
    `${k('fn', '#align')}(center)[*АКТ № #d.number*]<span class='cr'></span>`,
    `${k('fn', '#align')}(center)[освидетельствования скрытых работ]`,
    '',
    `${k('fn', '#table')}(columns: (${k('nm', '1fr')}, ${k('nm', '2fr')}),`,
    `  [Объект], [<span class='sl'>#d.object.name</span>],`,
    `  [Работы], [#d.works.${k('er', 'jion')}(${k('str', '", "')})],`,
    ')',
    `${k('mt', '$ sum_(i=1)^n l_i = #d.total "м" $')}`,
    `${k('cm', '// подписи — из userlib: подпись(роль, лицо)')}`,
    `${k('fn', '#подпись')}(${k('str', '"Технадзор"')}, d.supervisor)`,
  ];
  const editor = () => `<div class='ed'><div class='tabs'><span class='on'>Шаблон</span><span>typeblocks.typ</span><span>userlib.typ</span><span class='sp'></span></div>` +
    `<div class='code'><div class='gut'>${CODE.map((_, i) => `<div class='${i === 7 ? 'cur' : ''}'>${i + 1}</div>`).join('')}</div>` +
    `<div class='src'>${CODE.map((l, i) => `<div class='${i === 7 ? 'cur' : ''}'>${l || ' '}</div>`).join('')}</div>` +
    `<div class='sug'><div class='on'>${s('function', 'muted')}join<span class='k'>array.join(sep)</span></div><div>${s('function', 'muted')}len<span class='k'>array.len()</span></div><div>${s('function', 'muted')}first<span class='k'>array.first()</span></div></div></div></div>`;

  /* ---- страница ---- */
  const ctl = () => { const b = (k2, v, t) => { const q = new URLSearchParams(location.search); q.set(k2, v); const on = String(ST[k2]) === String(v); return `<button class='${on ? 'on' : ''}' onclick="location.search='${q}'">${t}</button>`; };
    return `<div class='ctl'>${b('theme', 'both', 'Обе темы')}${b('theme', 'light', 'Светлая')}${b('theme', 'dark', 'Тёмная')}<span style='width:12px'></span>${b('h', 768, '1366×768 (как e2e)')}${b('h', 633, '1366×633 (настоящий ноутбук)')}` +
      `<span class='nav'><a href='00%20%D0%A0%D0%B0%D0%B7%D0%B1%D0%BE%D1%80%20%D0%B8%20%D0%B2%D0%BE%D0%BF%D1%80%D0%BE%D1%81.html'>00 Разбор</a>` +
      [['a', 'А - MD3 буквально'], ['b', 'Б - Плотно'], ['v', 'В - Плавающая панель']].map(([kk, f]) => `<a class='${kk === V.key ? 'cur' : ''}' href='${encodeURIComponent(f)}.html${location.search}'>${f}</a>`).join('') + `</span></div>`; };

  document.getElementById('root').innerHTML =
    `<h1>${V.name} — ${V.title}${V.key === 'a' ? "<span class='tag star'>рекомендация Дизайнера для просмотрщика и редактора</span>" : ''}</h1>` +
    `<div class='lead'><p>${V.rule}</p><p>Общее для всех трёх: лист белый в любой теме (светлая — возвышение 1, тёмная — обводка outline-variant, уже в коде); в узкой колонке чип масштаба показывает процент, режим — галочкой в меню; «Очистить / Сегодня» и сегменты времени — отступления D8; тема редактора читается из ролей и перекрашивается при смене темы без перезагрузки.</p></div>` + ctl() +
    sec('1. Экран счёта со сканом — колонка 340', 'Колонка скана на 1366 — 340 (минимум: рейл 80 + подпанель 240 + список 320), то есть узкая панель — обычный случай, а не исключение. Счётчик в углу холста — высота холста под листы, высота панели и доля листа A4, видная без прокрутки (для плавающей панели — не закрытая ею). Строка файла над просмотрщиком (57) — как сегодня. Переключите высоту на 633 — так выглядит развёрнутый Chrome на ноутбуке 1366×768.',
      each(t => laptop(t, 'Счёт со сканом', {}))) +
    sec('2. Меню масштаба открыто', V.float ? 'Из «⋮» плавающей панели: режимы, проценты, ± и поворот — второй щелчок.' : 'Общий Menu dense вверх (surface-container, уровень 2): режим — галочкой, в узкой колонке — «Уменьшить» и «Увеличить» с клавишами.',
      each(t => laptop(t, 'Меню масштаба', { menu: 1 }))) +
    sec('3. Предпросмотр документа — широкая панель', 'Панель редактора комплекта, 560: «− По ширине +» на месте.',
      `<div class='row'>${themes().map(t => md3(t, 'Предпросмотр', `<div class='card' style='width:560px;height:620px'><div class='phd'>Предпросмотр · АОСР № 12<span class='sp'></span>${ib('refresh', 'Обновить')}${ib('close', 'Закрыть')}</div>${viewer(false)}</div>`)).join('')}</div>`) +
    sec('4. Окно «Оплата» — календарь у поля даты', 'Ноябрь 2026 — шесть недель, худший случай. Календарь — слой над окном (#1521). Счётчик в углу: входит ли календарь под полем. Переключите высоту на 633: окно ниже, поле даты выше — а места под ним меньше.',
      each(t => laptop(t, 'Окно «Оплата»', { scan: false, over: payWin, cnt: 1 }))) +
    sec('5. Календарь: день, месяц, год, период', '«Сегодня» (3-е) — обводка 1 px primary; выбранный — круг primary; фокус — кольцо 3 px secondary (В14); период — лента secondary-container. Высота каждого состояния — над ним.' + (V.calList ? ' Месяц и год — списком, как в docked MD3: день из другого месяца — два щелчка, список 12 месяцев прокручивается; клавиши списка — ↑↓ по одному (сегодня в сетке — на три), и прежние тесты клавиатуры меняют смысл.' : ''),
      themes().map(t => md3(t, 'Календарь', `<div class='row' style='padding:16px;background:var(--surface);border-radius:12px;margin-bottom:16px'>` +
        calCell('День', cal('day', { sel: 12, foc: 12 })) + calCell('Точность «месяц»', cal('month')) + calCell('Точность «год»', cal('year')) + calCell('Период (DateRange)', cal('range', { r: [9, 20] })) + `</div>`)).join('')) +
    sec('6. Редактор шаблона (Monaco, тема bhs)', 'Текущая строка — 8, выделение — в 12-й, ошибка — волна error в 13-й, открыты подсказки (виджет — слой surface-container). Сейчас в пяти местах стоит встроенная vs / vs-dark.',
      each(t => md3(t, 'Редактор шаблона', editor())));

  /* ---- замеры ---- */
  const measure = () => {
    document.querySelectorAll('[data-vw]').forEach(vw => {
      const cv = vw.querySelector('.cv'), pg = vw.querySelector('.pg'), tb = vw.querySelector('.tb'), c = vw.querySelector('[data-cnt]');
      const canvas = V.float ? vw.clientHeight : vw.clientHeight - tb.offsetHeight;
      const free = V.float ? canvas - 10 - tb.offsetHeight - 16 : canvas - 10;
      c.textContent = `холст ${canvas} · панель ${tb.offsetHeight} · видно листа ${Math.min(100, Math.round(free / pg.offsetHeight * 100))} %`;
    });
    document.querySelectorAll('[data-floatcal]').forEach(fc => {
      const lap = fc.closest('.lap'), a = lap.querySelector('[data-anchor]');
      const lr = lap.getBoundingClientRect(), ar = a.getBoundingClientRect();
      fc.style.left = (ar.left - lr.left) + 'px'; fc.style.top = (ar.bottom - lr.top + 4) + 'px';
      const cr = fc.firstElementChild.getBoundingClientRect(), over = Math.round(cr.bottom - lr.bottom);
      const c = lap.querySelector('[data-calcnt]');
      c.textContent = over > 0 ? `календарь ${Math.round(cr.height)} · низ срезан на ${over} px` : `календарь ${Math.round(cr.height)} · входит, запас ${-over} px`;
      c.classList.toggle('bad', over > 0);
    });
    document.querySelectorAll('[data-calh]').forEach(h => { h.textContent = Math.round(h.closest('div').parentElement.querySelector('[data-cal]').getBoundingClientRect().height) + ' px'; });
  };
  // rAF стоит в скрытой вкладке — замеряем по таймеру и после шрифтов
  setTimeout(measure, 200);
  if (document.fonts) document.fonts.ready.then(() => setTimeout(measure, 0));
})();
