/* Лист варианта: одна и та же форма реквизитов, три вида значения из источника и под замком.
   Привязанные и запертые поля живут в секции «Заполняются автоматически» (AutoFieldsSection), свёрнутой по
   умолчанию, — не в общей сетке с редактируемыми (RequisitesTab.renderFields). */
(() => {
  const v = window.VARIANT; // now | a | b | c
  const S = n => `<span class="sym">${n}</span>`;
  const F = {
    cust: { t: 'Заказчик', req: true, edit: true, v: 'ООО «Энергосеть»' },
    obj:  { t: 'Объект строительства', edit: true, v: 'Жилой дом, корпус 2' },
    num:  { t: 'Номер договора', type: 'string', req: true, bound: true, rec: true, v: '17/2026-ЭМ' },
    sum:  { t: 'Сумма договора', type: 'primitive', prim: 'Деньги', bound: true, stale: true, v: '1 248 300,00 р.',
            issue: 'Значение не по типу «Деньги»' },
    date: { t: 'Дата подписания акта приёмки', type: 'date', bound: true, v: '12.05.2026' },
    kind: { t: 'Вид работ', type: 'enum', locked: true, v: 'Электромонтажные работы' },
    jr:   { t: 'Номер в журнале модуля', type: 'string', locked: true, bound: true, stale: true, v: 'ЖР-2026-0042' },
    resp: { t: 'Ответственный за монтаж', type: 'string', bound: true, empty: true, v: '' },
    hid:  { t: 'Скрытые работы', type: 'boolean', locked: true, v: true },
    crew: { t: 'Состав бригады', type: 'complex', locked: true, wide: true, v: '{"мастер":"Петров А. В.","электромонтажников":4}' },
    subj: { t: 'Предмет договора', type: 'text', bound: true, rec: true, wide: true,
            v: 'Выполнение электромонтажных работ на объекте «Жилой дом, корпус 2», этажи 1–5, в объёме рабочей документации 114-ЭМ и локальной сметы 114-СМ. Работы ведутся без остановки эксплуатации первого этажа.' },
  };
  const NORMAL = ['cust', 'obj'];
  const AUTO = ['num', 'sum', 'date', 'kind', 'jr', 'resp', 'hid', 'crew', 'subj'];
  const LOCK_HINT = 'Заполняет модуль — вручную не правится';

  const origin = f => (f.rec || f.stale)
    ? `<span class="mk ${f.stale ? 'w' : 'p'}" title="${f.rec ? 'Распознано со скана' : 'Из источника'}${f.stale ? ' · источник устарел' : ''}">${S(f.rec ? 'document_scanner' : 'database')}</span>` : '';
  const lock = f => f.locked ? `<span class="mk v" title="${LOCK_HINT}">${S('lock')}</span>` : '';
  const lens = (f, cls) => f.bound ? `<span class="ib xs on ${cls}" title="Привязка к источнику">${S('database')}</span>` : '';
  // А: кнопка привязки и знак происхождения — один значок: форма — происхождение, цвет — состояние.
  const lensMerged = f => f.bound ? `<span class="ib xs ${f.stale ? 'w' : 'on'}" title="Привязка к источнику${f.rec ? ' · распознано со скана' : ''}${f.stale ? ' · устарело' : ''}">${S(f.rec ? 'document_scanner' : 'database')}</span>` : '';
  const lensHover = cls => `<span class="ib xs ${cls}" style="opacity:0">${S('database')}</span>`;
  const issue = f => f.issue ? `<div class="fnote wr">${S('warning')}${f.issue}</div>` : '';

  // Редактируемое поле — одинаково во всех вариантах: подпись в вырезе, 56.
  function editable(f) {
    return `<div class="cell"><div class="tf"><div class="box"><span class="lab">${f.t}${f.req ? ' <span class="er">*</span>' : ''}</span>
      <span class="val trunc">${f.v}</span></div></div>${lensHover('lens corner')}</div>`;
  }
  // Флажок и запертое составное (LockedFieldValue, Р3 md3-17) — одинаково во всех вариантах.
  function checkbox(f) {
    return `<div class="cell"><div class="cbrow"><span class="cb ro on">${S('check')}</span><span class="bm v">${f.t}</span>${lock(f)}</div>
      <div class="fnote">${S('lock')}${LOCK_HINT}</div></div>`;
  }
  function lockedValue(f) {
    return `<div class="cell w"><div class="tf ro"><div class="box"><span class="lab">${f.t}</span><span class="val trunc">${f.v}</span>
      <span class="trail">${lock(f)}</span></div></div><div class="fnote">${S('lock')}${LOCK_HINT}</div></div>`;
  }
  // Подпись строкой над полем (сейчас, Б, В).
  function labelRow(f) {
    const mark = f.locked ? lock(f) : f.req ? '<span class="st">*</span>' : '';
    return `<div class="lrow"><span class="nm">${f.t}</span>${mark}${f.prim ? `<span class="pn">· ${f.prim}</span>` : ''}${origin(f)}</div>`;
  }
  const notesBelow = f => (f.empty ? '<div class="fnote it">Источник не дал значения</div>' : '')
    + (f.locked ? `<div class="fnote">${S('lock')}${LOCK_HINT}</div>` : '') + issue(f);

  function cellA(f, focus) {
    const multi = f.type === 'text';
    const hint = f.empty ? '<div class="hint it">Источник не дал значения</div>'
      : f.locked ? `<div class="hint">${LOCK_HINT}</div>`
      : f.prim ? `<div class="hint">${f.prim}</div>` : '';
    const lab = f.empty ? `<span class="lab rest">${f.t}</span>` : `<span class="lab">${f.t}</span>`;
    const trail = lock(f) + lensMerged(f);
    return `<div class="cell${f.wide ? ' w' : ''}"><div class="tf ro${focus ? ' focus' : ''}"><div class="box${multi ? ' top' : ''}">${lab}
      <span class="val ${multi ? 'multi' : 'trunc'}">${focus ? `<span class="sel">${f.v}</span>` : f.v}</span>${trail ? `<span class="trail">${trail}</span>` : ''}</div>${hint}</div>${issue(f)}</div>`;
  }
  function cellB(f, focus) {
    const multi = f.type === 'text';
    return `<div class="cell${f.wide ? ' w' : ''}">${labelRow(f)}${lens(f, 'lens')}
      <div class="tf ro dense${focus ? ' focus' : ''}"><div class="box${multi ? ' top' : ''}"><span class="val ${multi ? 'multi' : 'trunc'}">${focus ? `<span class="sel">${f.v || ''}</span>` : (f.v || '')}</span></div></div>${notesBelow(f)}</div>`;
  }
  function cellRaw(f, now, focus) {
    const multi = f.type === 'text';
    return `<div class="cell${f.wide ? ' w' : ''}">${labelRow(f)}${lens(f, 'lens')}
      <span class="raw${now ? ' now' : ''}${multi ? ' multi' : ''}${focus ? ' focus' : ''}">${focus ? `<span class="sel">${f.v}</span>` : (f.v || '&nbsp;')}</span>${notesBelow(f)}</div>`;
  }
  function cell(k, focus) {
    const f = F[k];
    if (f.edit) return editable(f);
    if (f.type === 'boolean') return checkbox(f);
    if (f.type === 'complex') return lockedValue(f);
    if (v === 'a') return cellA(f, focus);
    if (v === 'b') return cellB(f, focus);
    return cellRaw(f, v === 'now', focus);
  }
  const autoHead = (open, n, scans, stale, mod) => `<div class="ah">${S(open ? 'keyboard_arrow_up' : 'keyboard_arrow_down')}${S('database')}<span class="f1">Заполняются автоматически</span>
    <span>${n} п.${scans ? `<span class="p"> · со сканов: ${scans}</span>` : ''}${stale ? `<span class="w"> · устарело: ${stale}</span>` : ''}${mod ? ` · от модуля: ${mod}` : ''}</span></div>`;
  const form = () => `<p class="sect">Договор подряда</p><div class="fgrid">${NORMAL.map(k => cell(k)).join('')}</div>
    <div class="auto">${autoHead(true, 9, 2, 2, 4)}<div class="ab"><div class="fgrid">${AUTO.map(k => cell(k)).join('')}</div></div></div>
    <p class="sect" style="margin-top:24px">Сроки работ</p><div class="fgrid">${editable({ t: 'Начало работ', req: true, v: '01.06.2026' })}${editable({ t: 'Окончание работ', req: true, v: '30.09.2026' })}</div>
    <div class="auto">${autoHead(false, 3, 0, 0, 3)}</div>`;

  function desktop(theme) {
    return `<div class="md3 fr" data-theme="${theme}" style="width:1366px">
      <div class="appbar" style="border-bottom:1px solid var(--outline-variant)"><span class="ib">${S('arrow_back')}</span><h2>АОСР № 14 · Корпус 2, ЭМ</h2><span class="btn filled">Сформировать PDF</span></div>
      <div class="shell">
        <div class="rail"><span class="dot">${S('home')}</span><span class="dot on">${S('description')}</span><span class="dot">${S('database')}</span><span class="dot">${S('settings')}</span></div>
        <div class="sub"><div class="it">Титульный лист</div><div class="it on">АОСР № 14</div><div class="it">АОСР № 15</div><div class="it">Протокол изоляции</div></div>
        <div class="col" style="width:680px;flex:none;border-right:1px solid var(--outline-variant)">
          <div class="tabs"><span class="on">Реквизиты</span><span>Источники</span><span>Качество</span></div>
          <div style="padding:24px">${form()}</div>
        </div>
        <div class="prev"><div class="pg">предпросмотр PDF</div></div>
      </div></div>`;
  }
  function phone(theme) {
    return `<div class="md3 fr phone" data-theme="${theme}">
      <div class="appbar"><span class="ib">${S('arrow_back')}</span><h2>АОСР № 14</h2><span class="ib">${S('more_vert')}</span></div>
      <div class="tabs" style="padding:0"><span class="on">Реквизиты</span><span>Источники</span><span>Качество</span></div>
      <div style="padding:16px 16px 24px">${form()}</div></div>`;
  }
  function worst(theme) {
    return `<div class="md3 fr" data-theme="${theme}" style="width:330px;padding:20px 16px 16px"><div class="fgrid" style="grid-template-columns:1fr">${cell('jr')}${cell('sum')}${cell('num', true)}</div></div>`;
  }

  const NAMES = { now: 'Сейчас — для сравнения', a: 'А — Подпись в вырезе', b: 'Б — Плотное поле под своей подписью', c: 'В — Исключение без подложки' };
  const IDEA = {
    now: 'Как форма реквизитов выглядит сегодня: значение из источника и под замком — сырой <code>&lt;input&gt;</code> с подложкой <code>surface-container</code> под строкой подписи (дата — уже плотный <code>DateInput</code>). Такие поля собраны в секцию «Заполняются автоматически», свёрнутую по умолчанию (на кадрах первая раскрыта, вторая свёрнута). Подложка нарушает [UI-69] «контур без подложки», храповик этого поля не видит.',
    a: 'Значение из источника и под замком — то же поле, что у редактируемых и у запертого составного рядом (Р3 md3-17, <code>LockedFieldValue</code>): <code>TextField</code> / <code>TextAreaField readOnly</code>, имя реквизита в вырезе рамки, высота 56. Дата — тоже <code>TextField readOnly</code> с готовым значением: у <code>DateField</code> своего хвоста нет. В хвосте — замок и кнопка привязки, слитая со знаком происхождения: форма значка — происхождение (скан / источник), цвет — состояние (норма / устарело). Имя примитива и пояснение замка — подсказкой под полем. Строка подписи над полем уходит.',
    b: 'Раскладка формы не меняется: подпись остаётся строкой над полем — со звёздочкой или замком, именем примитива и знаком происхождения, кнопка привязки — в углу строки. Само значение — плотное поле <code>shared/ui</code> только для чтения (<code>density="dense"</code>, 40), как уже сегодня у даты. Диктор читает подпись плотного поля (у него она скрыта для глаза).',
    c: 'Вид почти не меняется: остаётся сырое поле <code>fieldInputClass</code>, снимается только подложка ([UI-69]) и добавляется <code>aria-label</code>. Храповик учится видеть класс и держит эти места объявленным исключением с причиной (уровень правила — не ноль).',
  };
  const FLAGS = {
    now: [['dev', 'подложка surface-container — нарушение [UI-69]'], ['dev', 'raw-field этого не видит'], ['dev', 'у строки и числа нет имени для диктора: внешняя подпись без htmlFor']],
    a: [['ok', 'TextField readOnly — готовый компонент'], ['ok', 'один вид с редактируемыми и с LockedFieldValue в той же секции'], ['ok', 'знаков меньше: кнопка привязки = знак происхождения, не больше двух в хвосте'], ['ok', 'RequisitesTab худеет: две строки подписи уходят'],
        ['new', 'PR 0: trailing у TextAreaField и второй размер хвоста в fieldBox (два знака — 48 против 44)'], ['dev', 'кнопка привязки у привязанного — в хвосте, у редактируемого — в углу (в углу она накрыла бы хвост)'],
        ['dev', 'длинное имя в вырезе обрезается; на 375 колонка ~150'], ['dev', 'звёздочки у привязанного больше нет (read-only, #958)']],
    b: [['ok', 'раскладка секции та же; дата уже сегодня такая'], ['ok', 'TextField density="dense" — готовый компонент'],
        ['new', 'PR 0: плотного TextAreaField нет (и в MD3 его нет) — или широкий текст по А'], ['dev', 'в той же секции LockedFieldValue 56 с вырезом рядом с плотными 40 — расходится с [UI-70] «форма — 56»'],
        ['dev', 'два вида подписи в одной секции'], ['dev', 'строка подписи на узкой колонке заходит под кнопку привязки (старый дефект остаётся)']],
    c: [['ok', 'ноль правки вида'], ['dev', 'raw-field не в ноль — объявленная самоделка'], ['dev', 'фокус — кольцо браузера, а не MD3; ошибка и наведение обходят оболочку поля'],
        ['dev', 'расходится со сценарием «Запертое поле модуля» [UI-81] md3-17']],
  };
  const files = [['00 Разбор и вопрос.html', '00 Разбор'], ['0 Сейчас.html', 'Сейчас'], ['А - Подпись в вырезе.html', 'А'], ['Б - Плотное под подписью.html', 'Б'], ['В - Исключение.html', 'В']];
  const cur = { now: 1, a: 2, b: 3, c: 4 }[v];
  let h = `<h1>${NAMES[v]}</h1><div class="lead"><p>${IDEA[v]}</p><p>Change <code>sharedui-md3-19-requisite-fields</code>, задача 0.2. Одна и та же форма во всех файлах. В секции «Заполняются автоматически»: «Номер договора» распознан со скана; «Сумма» из источника, устарела и расходится с типом; дата с длинным именем; «Вид работ» — запертое перечисление; «Номер в журнале» — худший случай (заперт модулем, привязка досталась от прежней версии типа и устарела); «Ответственный» — источник не дал значения; флажок и запертое составное не меняются; «Предмет договора» — многострочный текст со скана. Редактируемые поля выше секции — одинаковы во всех вариантах.</p></div>`;
  h += `<nav class="nav">${files.map((f, i) => `<a href="${encodeURI(f[0])}" class="${i === cur ? 'cur' : ''}">${f[1]}</a>`).join('')}<span style="width:16px"></span><a href="#d">1366</a><a href="#p">375</a><a href="#w">Худший случай</a></nav>`;
  h += `<div>${FLAGS[v].map(([k, t]) => `<span class="flag ${k}">${t}</span>`).join('')}</div>`;
  h += `<section class="fork" id="d"><h2>Рабочий стол 1366</h2><p class="places">Условная раскладка редактора документа: форма шириной 680, справа предпросмотр. Первая секция «Заполняются автоматически» раскрыта, вторая — свёрнута, как по умолчанию.</p>
    <p class="tn">Светлая</p>${desktop('light')}<p class="tn" style="margin-top:16px">Тёмная</p>${desktop('dark')}</section>`;
  h += `<section class="fork" id="p"><h2>Телефон 375</h2><p class="places">Сетка формы и на телефоне в две колонки (<code>grid-cols-2</code> без точки перелома) — внутри секции колонка около 150 px.</p>
    <div class="pair"><div><p class="tn">Светлая</p>${phone('light')}</div><div><p class="tn">Тёмная</p>${phone('dark')}</div></div></section>`;
  h += `<section class="fork" id="w"><h2>Худший случай и фокус — крупно (×1.5)</h2><p class="places">Сверху — запертое поле с устаревшей привязкой (замок, «устарело», кнопка привязки), под ним — значение с именем примитива и расхождением с типом. Снизу — поле в фокусе с выделенным значением: Tab в него заходит, значение копируется.</p>
    <div class="pair"><div class="zbox" style="width:500px;height:440px"><div class="zoom">${worst('light')}</div></div><div class="zbox" style="width:500px;height:440px"><div class="zoom">${worst('dark')}</div></div></div></section>`;
  document.getElementById('root').innerHTML = h;
})();
