/* Экраны трёх макетов change sharedui-md3-15-shell (оболочка). Один набор экранов на три варианта;
   числа варианта — переменные в mock/shell.css. Оси (разбор Дизайнера и Архитектора 03.11.2026):
   - высота полосы и поиска-двери: 64/56 (А) / 48/40 (Б) / 64 с заголовком страницы и поиском 48 (В);
   - где заголовок страницы: в рабочей области (А, Б) / в полосе (В);
   - угол рабочей области 16 (А, В) / 12 (Б);
   - столбец списка list-detail: surface с чертой (А) / surface-container (Б) / часть рамки, угол у подробностей (В);
   - пункт подпанели 48 (А, В) / 40 (Б); поиск над списком 56 (А, В) / 40 (Б);
   - телефон: полоса 64 с search bar 56 (А) / 48 с дверью 48 (Б) / 64 с заголовком-кнопкой и знаком поиска (В). */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'MD3 буквально', star: 1,
      rule: 'Полоса — top app bar 64 на surface-container-low без черты; поиск-дверь — search bar 56, форма full, surface-container-high, знак 24, не шире 720. Рабочая область — surface с углом 16; заголовок страницы — в ней, title-large. Подпанель — на поверхности рейла, пункты 48 label-large. Столбец списка list-detail — surface с чертой справа, поиск над ним — search bar 56. Палитра — docked search view на месте двери, поле 56. Отступлений от MD3 нет.',
      nums: ['64', '56, до 720', 'в рабочей области', '16', '48, label-large', 'surface + черта; поиск 56', '56', '64: знак, search bar 56, аватар; заголовок — строкой ниже', 'нет'] },
    b: { key: 'b', name: 'Б', title: 'Тонкая полоса',
      rule: 'Как вариант Г эпика: полоса 48 и поиск 40 шириной до 480 — высота экрана не теряется совсем. Угол 12, пункты подпанели 40 (как сегодня, body-medium), поиск над списком 40. Столбец списка — surface-container без черты (тоном внутри рабочей области). Палитра — docked на месте двери, поле 48. На телефоне — полоса 48 с дверью 48 (цель касания). Полоса, поиск, угол и пункты — отступления D8.',
      nums: ['48', '40, до 480', 'в рабочей области', '12', '40, body-medium', 'surface-container; поиск 40', '48', '48: знак, дверь 48, аватар; заголовок — строкой ниже', 'полоса 48, поиск 40, угол 12, пункт 40, поле палитры 48'] },
    v: { key: 'v', name: 'В', title: 'Заголовок в полосе',
      rule: 'Полоса 64 — настоящий top app bar страницы: слева заголовок title-large с подписью, справа действия страницы, поиск 48 шириной 360 и профиль. Строки заголовка в рабочей области нет — на 1366×768 это плюс одна строка реестра. В list-detail список становится частью рамки (surface-container-low), угол 16 — у подробностей. Палитра — docked шириной 560 у правого края. Телефон — полоса 64 с заголовком-кнопкой и знаком поиска (рекомендация Дизайнера для телефона). Цена — PageHeader переезжает в полосу на всех 26 страницах (портал заголовка и действий — работа сверх «вида»).',
      nums: ['64', '48, 360', 'в полосе', '16 (у подробностей в list-detail)', '48, label-large', 'часть рамки; поиск 56', '56', '64: знак, заголовок-кнопка, знак поиска 48, аватар', 'поиск-дверь 48 (не 56)'] },
  };
  const V = VARS[window.VARIANT || 'a'];
  document.body.classList.add('v-' + V.key);
  const Q = new URLSearchParams(location.search);
  const ST = { theme: Q.get('theme') || 'both', h: Q.get('h') === '650' ? 650 : 768, ph: Q.get('ph') === '667' ? 667 : 812 };
  document.body.style.setProperty('--lh', ST.h + 'px');
  document.body.style.setProperty('--ph', ST.ph + 'px');

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c) => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}'>${s(n)}</span>`;
  const t48 = (n, l) => `<span class='t48' aria-label='${l}'>${s(n)}</span>`;
  const btn = (t, v, n) => `<span class='btn ${v}'>${n ? s(n) : ''}${t}</span>`;
  const chip = (t, o = {}) => `<span class='chip${o.sel ? ' sel' : ''}'>${o.sel ? s('check') : ''}${t}${o.dd ? s('arrow_drop_down') : ''}</span>`;
  const ICO = { ok: 'check_circle', warn: 'warning', err: 'error', q: '' };
  const stx = (k, t) => `<span class='st ${k}'>${ICO[k] ? s(ICO[k]) : ''}${t}</span>`;
  const thm = (t) => t === 'dark' ? 'тёмная' : 'светлая';
  const themes = () => ST.theme === 'both' ? ['light', 'dark'] : [ST.theme];
  const cap = (t) => `<div class='cap'>${t}</div>`;
  const sec = (h, t, body) => `<h2>${h}</h2>${t ? cap(t) : ''}${body}`;
  const each = (fn, row) => `<div class='two${row ? ' row' : ''}'>${themes().map(fn).join('')}</div>`;
  const money = (n) => n.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  /* ---- рейл и подпанель ---- */
  const RAIL = [['apartment', 'Стройки'], ['database', 'Данные'], ['calculate', 'Затраты'], ['assignment', 'Планы']];
  const rail = (on) => `<nav class='rail'><div class='brand'><span class='logo'>${s('bolt', 's20 fill')}</span><span>БХС</span></div>` +
    RAIL.map(([n, t]) => `<div class='it${t === on ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') +
    `<div class='div'></div><div class='it${on === 'Система' ? ' on' : ''}'><span class='pill'>${s('build', 's24')}</span>Система</div></nav>`;
  const PANELS = {
    'Затраты': ['Учёт затрат', 'Счета, накладные, закрытие месяца',
      [['', ['Счета', 'Накладные']], ['Отчёты и закрытие месяца', ['Реестр счетов', 'Затраты по стройке', 'Учётный период']]]],
    'Данные': ['Данные', 'Справочники, наборы данных и сверка',
      [['', ['Общие данные', 'Наборы данных', 'Документы качества', 'Сверка']]]],
  };
  const sub = (sec, on, hov) => { const [t, h, groups] = PANELS[sec];
    return `<aside class='sub'><div class='t'>${t}</div><div class='h'>${h}</div>` + groups.map(([g, items]) =>
      (g ? `<div class='g'>${g}</div>` : '') + items.map(i => `<div class='li${i === on ? ' on' : ''}${i === hov ? ' hov' : ''}'>${i}</div>`).join('')).join('') + '</aside>'; };

  /* ---- полоса ---- */
  const door = (txt) => `<span class='door' data-door>${s('search', V.key === 'b' ? 's20' : 's24')}<span class='t'>${txt || 'Найти счёт, стройку или действие'}</span><kbd>Ctrl K</kbd></span>`;
  const ws = `<span class='ws'>${s('grid_view')}Счета и накладные${s('keyboard_arrow_down')}</span>`;
  const tail = `${ib('notifications', 'Активность')}${ib('help', 'Справка')}<span class='ava'>АП</span>`;
  const bar = (page) => V.key === 'v'
    ? `<header class='bar'><div class='ttl2'><h1>${page.title}</h1><span class='sub2'>${page.sub}</span></div><span class='sp'></span>${page.barActs || ''}${door('Найти счёт или действие')}${ws}${tail}</header>`
    : `<header class='bar'>${ws}${door()}<span class='sp'></span>${tail}</header>`;
  const ph = (page) => V.key === 'v' ? '' :
    `<div class='ph'><div><h1>${page.title}</h1></div><span class='sub'>${page.sub}</span><span class='sp'></span>${page.acts || ''}</div>`;

  const laptop = (label, theme, o) => `<div class='md3' data-theme='${theme}' data-screen-label='${label} (${thm(theme)})'>` +
    `<div class='app laptop lh'>${rail(o.rail)}${sub(o.rail, o.on, o.hov)}<div class='col'>${bar(o.page)}` +
    `<div class='work${o.split ? ' split' : ''}'>${ph(o.page)}${o.body}</div></div>${o.over || ''}${o.count ? `<span class='cnt' data-cnt></span>` : ''}</div></div>`;

  /* ---- 1. реестр счетов ---- */
  const SUP = ['ЭТМ «Север»', 'Кабельный завод «Проводник»', 'ООО «Электромонтаж»', 'АО «Светотехника»', 'ИП Семёнов', 'ООО «Щитовые системы»'];
  const SEC = ['Корпус 1 · ЭОМ', 'Корпус 2 · ЭОМ', 'Паркинг · ЭОМ', 'Наружные сети', 'Корпус 2 · СКС'];
  const STS = [['q', 'Черновик'], ['err', 'Не распознан'], ['q', 'Ждёт оплаты'], ['warn', 'Расхождение сумм'], ['ok', 'Оплачен'], ['ok', 'Оплачен'], ['q', 'Ждёт оплаты'], ['ok', 'Оплачен']];
  const REG = Array.from({ length: 22 }, (_, i) => [String(1036 - i), `${String(30 - i).padStart(2, '0')}.10.2026`, SUP[i % SUP.length], SEC[i % SEC.length],
    Math.round((((i * 7919) % 97) + 3) * 4131.7 * 100) / 100, STS[i % STS.length]]);
  const regBody = () => `<div class='tidy'>${s('cleaning_services', 's20')}<span class='t'>Навести порядок: 3 счёта без раздела, 1 не распознан</span>${btn('Разобрать', 'text')}</div>` +
    `<div class='fbar'>${chip('Стройка: ЖК «Северный»', { sel: 1, dd: 1 })}${chip('Октябрь 2026', { sel: 1, dd: 1 })}${chip('Состояние', { dd: 1 })}${chip('Поставщик', { dd: 1 })}<span class='sp'></span>${V.key === 'v' ? '' : btn('Представление', 'text', 'view_column')}</div>` +
    `<div class='tblw'><div class='sc'><table class='dt'><colgroup><col style='width:72px'><col style='width:112px'><col><col style='width:160px'><col style='width:150px'><col style='width:176px'><col style='width:52px'></colgroup>` +
    `<thead><tr><th>№</th><th>Дата</th><th>Поставщик</th><th>Раздел</th><th class='num'>Сумма с НДС, ₽</th><th>Состояние</th><th></th></tr></thead><tbody>` +
    REG.map((r, i) => `<tr class='${i === 2 ? 'sel' : ''}'><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td class='num'>${money(r[4])}</td><td>${stx(...r[5])}</td><td class='acts'>${ib('more_vert', 'Действия', 'xs')}</td></tr>`).join('') +
    `</tbody></table></div><div class='pager'>Строк на странице: 50 · 1–50 из 214 ${ib('chevron_left', 'Назад')}${ib('chevron_right', 'Вперёд')}</div></div><div class='low'></div>`;
  const REGP = { title: 'Реестр счетов', sub: 'ЖК «Северный» · октябрь 2026',
    acts: btn('Распознать пакет', 'tonal', 'upload_file'), barActs: btn('Представление', 'text', 'view_column') + btn('Распознать пакет', 'tonal', 'upload_file') };
  const regScreen = (theme) => laptop('Реестр счетов', theme, { rail: 'Затраты', on: 'Реестр счетов', hov: 'Накладные', page: REGP, body: regBody(), count: 1 });

  /* ---- 2. палитра — docked search view на месте двери ---- */
  const pr = (n, b, t, act) => `<div class='pr${act ? ' act' : ''}'>${s(n, 's24')}<span class='x'><b>${b}</b>${t ? `<span>${t}</span>` : ''}</span>${act ? '<kbd>Enter</kbd>' : ''}</div>`;
  const palette = () => `<div class='scrim'></div><div class='pal' data-pal><div class='pf'>${s('search', 's24')}<span class='q'>1018<i></i></span>${ib('close', 'Очистить')}</div><div class='dv'></div>` +
    `<div class='pg'>Счета</div>${pr('receipt_long', 'Счёт № 1018', 'АО «Светотехника» · 25.10.2026 · Корпус 2 · ЭОМ', 1)}${pr('receipt_long', 'Счёт № 10184', 'ЭТМ «Север» · 02.09.2026')}` +
    `<div class='pg'>Страницы</div>${pr('table', 'Реестр счетов', 'Затраты')}${pr('bar_chart', 'Затраты по стройке', 'Затраты')}` +
    `<div class='pg'>Действия</div>${pr('upload_file', 'Распознать пакет счетов')}` +
    `<div class='ft'><span><kbd>↑</kbd> <kbd>↓</kbd> выбор</span><span><kbd>Enter</kbd> открыть</span><span><kbd>Esc</kbd> закрыть</span></div></div>`;
  const palScreen = (theme) => laptop('Палитра', theme, { rail: 'Затраты', on: 'Реестр счетов', page: REGP, body: regBody(), over: palette() });

  /* ---- 3. list-detail — как живёт угол рядом со столбцом списка ---- */
  const ORGS = [['АО «Светотехника»', 'Поставщик · ИНН 7701234567'], ['ЭТМ «Север»', 'Поставщик · ИНН 7805123987'], ['ООО «Стройинвест»', 'Заказчик · ИНН 7728456123'],
    ['ООО «Технадзор-Проект»', 'Технадзор · ИНН 7713987456'], ['ИП Семёнов', 'Поставщик · ИНН 503212345678'], ['АО «Мосэнергосбыт»', 'Сетевая организация'], ['ООО «Щитовые системы»', 'Поставщик'], ['ООО «Электромонтаж»', 'Подрядчик']];
  const ldBody = () => `<div class='ld'><div class='list'><div class='ls'>${s('search', V.key === 'b' ? 's20' : 's24')}Найти организацию</div>` +
    ORGS.map((o, i) => `<div class='li2${i === 0 ? ' on' : ''}'><b>${o[0]}</b><span>${o[1]}</span></div>`).join('') + `</div>` +
    `<div class='det'><div class='dh'>АО «Светотехника»</div><div class='kv'><div>Роль</div><div>Поставщик</div><div>ИНН / КПП</div><div>7701234567 / 770101001</div>` +
    `<div>Адрес</div><div>115280, Москва, ул. Ленинская Слобода, 19</div><div>Руководитель</div><div>Кузнецов С. В.</div><div>Счетов за год</div><div>38</div></div></div></div>`;
  const LDP = { title: 'Общие данные', sub: 'Организации · 214', acts: btn('Добавить', 'filled', 'add'), barActs: btn('Добавить', 'filled', 'add') };
  const ldScreen = (theme) => laptop('List-detail', theme, { rail: 'Данные', on: 'Общие данные', page: LDP, body: ldBody(), split: 1 });

  /* ---- 4. телефон 375 ---- */
  const BNAV = [['apartment', 'Стройки'], ['database', 'Данные'], ['calculate', 'Затраты'], ['assignment', 'Планы']];
  const bnav = `<nav class='bnav'>` + BNAV.map(([n, t]) => `<div class='it${t === 'Затраты' ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === 'Затраты' ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const logo = `<span class='t48' aria-label='На главную'><span class='logo'>${s('bolt', 's20 fill')}</span></span>`;
  const ava = `<span class='t48'><span class='ava' style='margin:0'>АП</span></span>`;
  const tbtn = (open) => `<span class='tbtn${open ? ' open' : ''}'>Счета${s('keyboard_arrow_down', 's24')}</span>`;
  const pbar = (open) => V.key === 'v'
    ? `<header class='pbar'>${logo}${tbtn(open)}${t48('search', 'Поиск')}${ava}</header>`
    : `<header class='pbar'>${logo}<span class='door'>${s('search', 's24')}<span class='t'>Найти счёт…</span></span>${ava}</header>`;
  const ptitle = (open) => V.key === 'v' ? '' : `<div class='pt'>${tbtn(open)}</div>`;
  const PL = REG.slice(0, 14);
  const plist = () => `<div class='ps'>${s('search', 's24')}Поиск по номеру</div><div class='chips'>${chip('Октябрь', { sel: 1, dd: 1 })}${chip('Состояние', { dd: 1 })}${chip('Поставщик', { dd: 1 })}</div>` +
    `<div class='lst' data-plist>` + PL.map(r => `<div class='li2'><span class='x'><b>№ ${r[0]} · ${r[2]}</b><span>${r[1]} · ${r[5][1]}</span></span><span class='amt'>${money(r[4])}</span></div>`).join('') + '</div>';
  const MENU = `<div class='menu'><div class='mi on'>Счета</div><div class='mi'>Накладные</div><div class='mg'>Отчёты и закрытие месяца</div><div class='mi'>Реестр счетов</div><div class='mi'>Затраты по стройке</div><div class='mi'>Учётный период</div></div>`;
  const fpr = (n, b, t) => `<div class='pr'>${s(n, 's24')}<span class='x'><b>${b}</b>${t ? `<span>${t}</span>` : ''}</span></div>`;
  const FSP = `<div class='fsp'><div class='pf'>${t48('arrow_back', 'Назад')}<span class='q'>1018<i></i></span>${t48('close', 'Очистить')}</div><div class='dv' style='height:1px;background:var(--outline-variant)'></div>` +
    `<div class='pg'>Счета</div>${fpr('receipt_long', 'Счёт № 1018', 'АО «Светотехника» · 25.10.2026')}${fpr('receipt_long', 'Счёт № 10184', 'ЭТМ «Север»')}<div class='pg'>Страницы</div>${fpr('table', 'Реестр счетов', 'Затраты')}${fpr('bar_chart', 'Затраты по стройке', 'Затраты')}</div>`;
  const phone = (label, theme, mode) => `<div><div class='md3' data-theme='${theme}' data-screen-label='Телефон: ${label} (${thm(theme)})'>` +
    `<div class='app phone' style='position:relative'>${pbar(mode === 'menu')}${ptitle(mode === 'menu')}${plist()}${bnav}` +
    `<span class='fab'>${s('upload_file')}Распознать</span>${mode === 'menu' ? `<div class='scrim' style='background:transparent'></div>${MENU}` : ''}${mode === 'pal' ? FSP : ''}` +
    `${mode ? '' : `<span class='cnt' data-pcnt></span>`}</div></div>${cap(label + ' — ' + thm(theme))}</div>`;
  const phones = (theme) => `<div class='phones'>${phone('список счетов', theme)}${phone('открыто меню раздела', theme, 'menu')}${phone('палитра во весь экран', theme, 'pal')}</div>`;

  /* ---- лист ---- */
  const OTHER = Object.values(VARS).filter(x => x.key !== V.key);
  const FILE = { a: 'А - MD3 буквально.html', b: 'Б - Тонкая полоса.html', v: 'В - Заголовок в полосе.html' };
  const link = (k, p) => { const q = new URLSearchParams(location.search); Object.entries(p).forEach(([a, b]) => q.set(a, b)); return `${encodeURI(FILE[k])}?${q}`; };
  const tbtnS = (t, p, on) => `<button class='${on ? 'on' : ''}' onclick="location.href='${link(V.key, p)}'">${t}</button>`;
  const ROWS = ['Полоса', 'Поиск-дверь', 'Заголовок страницы', 'Угол рабочей области', 'Пункт подпанели', 'Столбец списка list-detail', 'Поле палитры', 'Телефон: полоса', 'Отступления D8'];
  const nums = `<table class='cmp nums'><tr><th></th>${Object.values(VARS).map(x => `<th${x.key === V.key ? " class='rec'" : ''}>${x.name} — ${x.title}</th>`).join('')}</tr>` +
    ROWS.map((r, i) => `<tr><td>${r}</td>${Object.values(VARS).map(x => `<td>${x.nums[i]}</td>`).join('')}</tr>`).join('') + '</table>';
  const common = `<div class='note'><b>Общее для всех трёх</b> (не развилка): рейл 80 на surface-container-low, знак 24, у выбранного — с заливкой, индикатор 56×32, подпись label-medium одним весом; черты у рейла, подпанели и полосы нет; подпанель 240 на поверхности рейла, заголовок раздела title-medium, группы title-small; заголовок страницы title-large 22/28/400; палитра — surface-container-high, радиус 28, затемнение без размытия, на телефоне — во весь экран со стрелкой «Назад»; нижняя навигация 80 на surface-container без черты, индикатор 64×32; extended FAB 56, радиус 16, primary-container; цели касания оболочки на телефоне — 48 (и у знака экземпляра, и у поиска); таблица — как выбрано в 14 (шапка 56, строка 48).</div>`;

  document.getElementById('root').innerHTML =
    `<h1>${V.name} — ${V.title}${V.star ? "<span class='tag star'>рекомендация Дизайнера для рабочего стола</span>" : ''}</h1>` +
    `<div class='ctl'>Тема: ${tbtnS('обе', { theme: 'both' }, ST.theme === 'both')}${tbtnS('светлая', { theme: 'light' }, ST.theme === 'light')}${tbtnS('тёмная', { theme: 'dark' }, ST.theme === 'dark')}` +
    `  Высота окна: ${tbtnS('768', { h: '768' }, ST.h === 768)}${tbtnS('650 (с панелями браузера)', { h: '650' }, ST.h === 650)}` +
    `  Телефон: ${tbtnS('812', { ph: '812' }, ST.ph === 812)}${tbtnS('667', { ph: '667' }, ST.ph === 667)}` +
    `<span class='nav'><a href='${encodeURI('00 Разбор и вопрос.html')}'>Разбор и вопрос</a>${Object.values(VARS).map(x => `<a class='${x.key === V.key ? 'cur' : ''}' href='${link(x.key, {})}'>${x.name} — ${x.title}</a>`).join('')}</span></div>` +
    `<div class='lead'><p>${V.rule}</p></div>${common}` +
    sec('1. Реестр счетов на 1366×' + ST.h, 'Рейл, подпанель «Учёт затрат» (наведение на «Накладные»), полоса с поиском, рабочая область со скруглённым углом. <b>Счётчик в углу — сколько строк реестра видно целиком</b>; «650» — настоящий ноутбук с панелью задач и панелями Chrome.', each(regScreen)) +
    sec('2. Открытая палитра (Ctrl K)', 'Docked search view: раскрывается из поиска-двери, поле — на её месте, ширина — большее из двери и 560. Затемнение без размытия.', each(palScreen)) +
    sec('3. List-detail: угол и столбец списка', 'Сегодня столбец списка — surface-container-low, как рейл: рядом с полосой того же цвета угол исчез бы, а список прочёлся бы частью рамки (находка Архитектора). Каждый вариант решает это по-своему; строки списка — по выбору 14 (две строки 64).', each(ldScreen)) +
    sec('4. Телефон 375×' + ST.ph, 'Нижняя навигация, заголовок-кнопка (открытое меню — secondary-container), FAB над нижней навигацией, палитра во весь экран. <b>Счётчик — строки списка целиком и из них не закрытые FAB</b>.', themes().map(phones).join('')) +
    sec('Числа трёх вариантов', '', nums);

  /* счётчики и якорь палитры — по реальной раскладке */
  const place = () => {
    document.querySelectorAll('.laptop').forEach(app => {
      const sc = app.querySelector('.tblw .sc'), c = app.querySelector('[data-cnt]');
      if (sc && c) { const rows = [...sc.querySelectorAll('tbody tr')], b = sc.getBoundingClientRect().bottom;
        c.textContent = 'Строк реестра целиком: ' + rows.filter(r => r.getBoundingClientRect().bottom <= b + .5).length; }
      const pal = app.querySelector('[data-pal]'), d = app.querySelector('[data-door]');
      if (pal && d) { const a = app.getBoundingClientRect(), r = d.getBoundingClientRect(), w = Math.max(r.width, 560);
        const left = Math.min(r.left - a.left, a.width - w - 16), top = r.top - a.top + (r.height - parseFloat(getComputedStyle(pal.querySelector('.pf')).height)) / 2;
        Object.assign(pal.style, { left: left + 'px', top: top + 'px', width: w + 'px', maxHeight: (a.height - top - 24) + 'px' }); }
    });
    document.querySelectorAll('.phone').forEach(app => {
      const l = app.querySelector('[data-plist]'), c = app.querySelector('[data-pcnt]'), f = app.querySelector('.fab');
      if (!l || !c) return; const b = l.getBoundingClientRect().bottom, ft = f.getBoundingClientRect().top;
      const rows = [...l.children].filter(r => r.getBoundingClientRect().bottom <= b + .5);
      c.textContent = `Строк: ${rows.length}, без FAB: ${rows.filter(r => r.getBoundingClientRect().bottom <= ft + .5).length}`;
      c.style.bottom = '88px'; c.style.right = 'auto'; c.style.left = '12px';
    });
  };
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(place);
  window.addEventListener('resize', place);
})();
