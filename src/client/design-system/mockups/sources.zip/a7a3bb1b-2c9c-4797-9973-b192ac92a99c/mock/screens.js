/* Экраны трёх макетов change sharedui-md3-14-data (таблица данных, сетка правки, списки; В5 принято).
   Один набор экранов на три варианта; вид задают классы v-a / v-b / v-v (mock/dt.css). Оси (разбор
   Дизайнера 02.11.2026):
   - высота: страница 56/48, окно 48/40 (А, В) / 48/40 и на странице — правка таблицы D7 (Б);
   - шапка: без заливки, заливка при прокрутке (А, В) / на заливке surface-container всегда (Б);
   - выбор строки: заливка secondary-container (А) / черта 3 px и лёгкая заливка (Б) / заливка и черта (В);
   - итог: заливка без черты (А) / черта без заливки (Б) / заливка и черта (В);
   - поле в клетке: подчёркивание без черты в покое (А) / плотное поле, рамка на фокусе (Б) / черта outline в покое (В);
   - лист массива: подчёркивание (А) / рамка клетки (Б, В);
   - список: прямоугольник в две строки 64 (А) / одна строка 48 (Б) / пилюля 48, две строки 56 (В);
   - таблица в окне: 4 строки, как сегодня (А, Б) / окно растёт по содержимому (В). */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'Data table буквально', grow: 0,
      rule: 'Data table Material 2 на токенах MD3, как записано в design.md. Страница — шапка 56 и строка 48, окно и лист — 48 и 40. Шапка без заливки, при прокрутке под ней заливка surface-container. Открытая строка — заливка secondary-container (пометка под ней не видна, как сегодня). Итог — заливка surface-container без черты. Поле в клетке без рамки и без черты в покое: подчёркивание primary у фокуса, error у ошибки. Лист массива — строка 40, линии колонок, фокус — подчёркиванием. Списки — прямоугольник во всю ширину, две строки 64. Окна с таблицей держат нынешнюю высоту.' },
    b: { key: 'b', name: 'Б', title: 'Рабочий реестр', grow: 0,
      rule: 'Плотнее: строка 40 и шапка 48 и на странице, и в окне — это правка таблицы плотности D7 (сейчас там 48 на странице). Шапка на заливке surface-container всегда. Открытая строка — ведущая черта 3 px primary и заливка primary 8 %: помеченная строка остаётся помеченной. Итог — черта outline сверху без заливки. Поле в клетке — плотное поле на подложке, рамка 2 px появляется только на фокусе и ошибке. Лист — рамка клетки. Списки — одна строка 48 без второй строки, выбранная — черта и цвет primary.' },
    v: { key: 'v', name: 'В', title: 'По месту', grow: 1,
      rule: 'Таблица D7 как есть: страница 56/48, окно 48/40. Шапка — как в А. Открытая строка — заливка secondary-container и ведущая черта: у помеченной остаётся её тон, «открыта» говорит черта. Итог — заливка и черта. Поле в клетке без рамки, но с чертой outline в покое (как сегодня у NumberInput) — правимое отличимо от неправимого; у фокуса — primary 2 px. Лист — рамка клетки 2 px, как в электронной таблице. Списки — пилюля 48, две строки 56 там, где есть пояснение. Окна с таблицей растут по содержимому, а не держат 4 строки.' },
  };
  const V = VARS[window.VARIANT || 'a'];
  document.body.classList.add('v-' + V.key);
  const Q = new URLSearchParams(location.search);
  const ST = { theme: Q.get('theme') === 'dark' ? 'dark' : 'light', h: Q.get('h') === '650' ? 650 : 768 };
  document.body.style.setProperty('--lh', ST.h + 'px');

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c) => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}'>${s(n)}</span>`;
  const btn = (t, v, n) => `<span class='btn ${v}'>${n ? s(n) : ''}${t}</span>`;
  const chip = (t, o = {}) => `<span class='chip${o.sel ? ' sel' : ''}'>${o.sel ? s('check') : ''}${t}${o.dd ? s('arrow_drop_down') : ''}</span>`;
  const ICO = { ok: 'check_circle', warn: 'warning', err: 'error', q: '' };
  const stx = (k, t) => `<span class='st ${k}'>${ICO[k] ? s(ICO[k]) : ''}${t}</span>`;
  const cf = (v, o = {}) => `<span class='cf${o.num ? ' num' : ''}${o.foc ? ' foc' : ''}${o.bad ? ' bad' : ''}${o.ph ? ' ph' : ''}'>${v}${o.bad ? s('error', 's20') : ''}${o.trail ? s(o.trail, 's24') : ''}</span>`;
  const dd = (v) => `<span class='sel-dd'><span style='overflow:hidden;text-overflow:ellipsis'>${v}</span>${s('arrow_drop_down', 's24')}</span>`;
  const cols = (w) => `<colgroup>${w.map(x => `<col${x ? ` style='width:${x}px'` : ''}>`).join('')}</colgroup>`;
  const th = (t, c) => `<th${c ? ` class='${c}'` : ''}>${t}</th>`;

  const RAIL = [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['apartment', 'Стройки'],
    ['folder_open', 'Комплекты'], ['table_chart', 'Таблицы'], ['settings', 'Настройки']];
  const rail = (on) => `<nav class='rail'>` + RAIL.map(([n, t]) =>
    `<div class='it${t === on ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const thm = (t) => t === 'dark' ? 'тёмная' : 'светлая';
  const laptop = (label, on, inner, top, theme) => `<div class='md3' data-theme='${theme}' data-screen-label='${label} (${thm(theme)})'><div class='app laptop'>${rail(on)}<div class='work'>${inner}</div>${top || ''}</div></div>`;
  const cap = (t) => `<div class='cap'>${t}</div>`;
  const sec = (h, t, body) => `<h2>${h}</h2>${t ? cap(t) : ''}${body}`;
  const both = (fn) => `<div class='two'>${fn('light')}${fn('dark')}</div>`;

  /* ---- 1. реестр счетов (таблица на странице, лист строки) ---- */
  const SUP = ['ЭТМ «Север»', 'Кабельный завод «Проводник»', 'ООО «Электромонтаж»', 'АО «Светотехника»', 'ИП Семёнов', 'ООО «Щитовые системы»'];
  const SEC = ['Корпус 1 · ЭОМ', 'Корпус 2 · ЭОМ', 'Паркинг · ЭОМ', 'Наружные сети', 'Корпус 2 · СКС'];
  const STS = [['q', 'Черновик'], ['err', 'Не распознан'], ['q', 'Ждёт оплаты'], ['warn', 'Расхождение сумм'], ['ok', 'Оплачен'], ['ok', 'Оплачен'], ['q', 'Ждёт оплаты'], ['ok', 'Оплачен']];
  const money = (n) => n.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const REG = Array.from({ length: 22 }, (_, i) => {
    const sum = Math.round((((i * 7919) % 97) + 3) * 4131.7 * 100) / 100;
    const st = STS[i % STS.length];
    return [String(1036 - i), `${String(30 - i).padStart(2, '0')}.10.2026`, SUP[i % SUP.length], SEC[i % SEC.length],
      sum, st[1] === 'Оплачен' ? sum : (st[1] === 'Расхождение сумм' ? sum - 1240 : 0), st];
  });
  const OPEN = 3, MARK = [3, 7], HOV = 6;
  const regTable = () => {
    const w = [64, 104, 0, 150, 140, 156, 48];
    const tot = REG.reduce((a, r) => a + r[4], 0);
    return `<div class='dtc scrolled' data-count style='flex:1;margin:0 0 16px 24px'><div class='scroll'><table class='dt'>${cols(w)}` +
      `<thead><tr>${th('№')}${th('Дата')}${th('Поставщик')}${th('Раздел')}${th('Сумма с НДС, ₽', 'num')}${th('Состояние')}${th('')}</tr></thead><tbody>` +
      REG.map((r, i) => `<tr class='${[i === OPEN ? 'sel' : '', MARK.includes(i) ? 'mark' : '', i === HOV ? 'hov' : ''].join(' ')}'>` +
        `<td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td class='num'>${money(r[4])}</td>` +
        `<td>${stx(...r[6])}</td><td class='acts'>${ib('more_vert', 'Действия', 'xs')}</td></tr>`).join('') +
      `</tbody></table></div><table class='dt'>${cols(w)}<tbody><tr class='tot'><td colspan='4'>Итого: ${REG.length} счета</td><td class='num'>${money(tot)}</td><td colspan='2'></td></tr></tbody></table></div>`;
  };
  const rowSheet = () => { const r = REG[OPEN];
    return `<aside class='ssh' aria-label='Строка: счёт'><div class='sh'><h3>Счёт № ${r[0]}</h3>${ib('open_in_new', 'Открыть счёт')}${ib('close', 'Закрыть строку')}</div>` +
      `<div class='kv'><div>Поставщик</div><div>${r[2]}</div><div>Дата</div><div>${r[1]}</div><div>Раздел</div><div>${r[3]}</div><div>Сумма с НДС</div><div>${money(r[4])} ₽</div>` +
      `<div>Оплачено</div><div>${money(r[5])} ₽</div><div>Состояние</div><div>${stx(...r[6])}</div></div></aside>`; };
  const registry = (sheet) => `<div class='ph'><h1>Счета</h1><span class='sub'>ЖК «Северный», корпус 2</span><span class='sp'></span>` +
    `<span class='search'>${s('search')}Поиск по номеру и поставщику</span>${btn('Распознать пакет', 'tonal', 'upload_file')}</div>` +
    `<div class='fbar'>${chip('Стройка: ЖК «Северный»', { sel: 1, dd: 1 })}${chip('Октябрь 2026', { sel: 1, dd: 1 })}${chip('Состояние', { dd: 1 })}${chip('Поставщик', { dd: 1 })}<span class='sp'></span>${btn('Представление', 'text', 'view_column')}</div>` +
    `<div class='row-x'>${regTable()}${sheet ? rowSheet() : '<div style="width:16px"></div>'}</div>`;
  const regScreen = (theme) => laptop('Реестр счетов', 'Счета', registry(true), '', theme);

  /* ---- 2. строки счёта (сетка правки на странице) ---- */
  const LINES = [
    ['Кабель ВВГнг(А)-LS 5×16', 'ВВГ-516', 'м', '320', '412,00', '20', 'Кабель ВВГнг(А)-LS 5×16', 'Корпус 2 · ЭОМ'],
    ['Кабель ВВГнг(А)-LS 3×2,5', 'ВВГ-325', 'м', '1 200', '64,30', '20', 'Кабель ВВГнг(А)-LS 3×2,5', 'Корпус 2 · ЭОМ'],
    ['Автомат ВА47-29 1P 16А C', 'MVA20-1-016-C', 'шт', '48', '286,00', '20', 'Выключатель автоматический 1P 16А', '3 раздела'],
    ['Щит ЩРН-24 IP41', 'MKP42-N-24-41', 'шт', '6', '3 912,00', '20', '— выбрать —', 'Корпус 2 · ЭОМ'],
    ['Гофра ПВХ 20 мм с зондом', 'PR02.0006', 'м', '600', '', '20', 'Труба гофрированная ПВХ 20', 'не разнесено'],
    ['Коробка распаечная 100×100', 'KM41234', 'шт', '120', '58,40', '20', 'Коробка распаечная 100×100 IP54', 'Корпус 2 · ЭОМ'],
    ['Светильник LED 36 Вт 595×595', 'LP-ECO-36', 'шт', '84', '1 140,00', '20', 'Светильник светодиодный 36 Вт', 'Корпус 2 · ЭОМ'],
    ['Розетка 2P+E скрытая', 'EPH2350121', 'шт', '210', '198,60', '20', 'Розетка 2P+E', 'Корпус 2 · ЭОМ'],
    ['Доставка', '', 'усл', '1', '4 500,00', '20', '—', 'весь счёт'],
  ];
  const num = (t) => parseFloat(String(t).replace(/\s/g, '').replace(',', '.')) || 0;
  const linesGrid = () => {
    const w = [44, 0, 120, 60, 92, 112, 132, 220, 136, 48];
    let tv = 0, ta = 0;
    const rows = LINES.map((l, i) => {
      const amt = num(l[3]) * num(l[4]), vat = amt / 6; tv += vat; ta += amt;
      const foc = i === 1, bad = i === 4;
      return `<tr class='${i === 2 ? 'hov' : ''}'><td class='ro num muted'>${i + 1}</td><td>${cf(l[0])}</td><td>${cf(l[1] || '—', { ph: !l[1] })}</td><td>${cf(l[2])}</td>` +
        `<td>${cf(l[3], { num: 1, foc })}</td><td>${cf(l[4] || 'нет цены', { num: 1, bad, ph: !l[4] })}</td>` +
        `<td class='ro num'>${amt ? money(amt) : '—'}</td><td>${dd(l[6])}</td>` +
        `<td class='ro'>${l[7] === 'не разнесено' ? stx('warn', 'не разнесено') : `<span class='muted'>${l[7]}</span>`}</td><td class='acts'>${ib('delete', 'Удалить строку', 'xs')}</td></tr>`;
    }).join('');
    return `<div class='dtc' data-count style='margin:0 24px'><div class='scroll'><table class='dt eg'>${cols(w)}` +
      `<thead><tr>${th('№', 'num')}${th('Наименование в счёте')}${th('Артикул')}${th('Ед.')}${th('Кол-во', 'num')}${th('Цена, ₽', 'num')}${th('Сумма, ₽', 'num')}${th('Позиция номенклатуры')}${th('Разноска')}${th('')}</tr></thead>` +
      `<tbody>${rows}<tr class='tot'><td></td><td colspan='5' style='padding-left:12px'>Итого: ${LINES.length} строк · НДС ${money(tv)}</td><td class='num'>${money(ta)}</td><td colspan='3'></td></tr></tbody></table></div></div>` +
      `<div style='padding:8px 24px'>${btn('Добавить строку', 'text', 'add')}</div>`;
  };
  const invoice = () => `<div class='ph'>${ib('arrow_back', 'Назад')}<h1>Счёт № 1018</h1><span class='sub'>АО «Светотехника» · 25.10.2026 · НДС сверху</span><span class='sp'></span>` +
    `${btn('Состояние счёта', 'tonal', 'checklist')}${btn('Сохранить', 'filled')}</div><div class='ttl'>Строки счёта<span class='hint'>— ячейка «Кол-во» второй строки в фокусе, у пятой нет цены</span></div>` + linesGrid();
  const linesScreen = (theme) => laptop('Строки счёта', 'Счета', invoice(), '', theme);

  /* ---- 3. матрица разноски (full-screen dialog, сетка правки с вводом в шапке) ---- */
  const TGT = [['ЖК «Северный», корпус 1', 'Секция А · ЭОМ', '40'], ['ЖК «Северный», корпус 2', '— вся стройка —', '40'], ['ЖК «Северный», паркинг', 'Паркинг · ЭОМ', '20']];
  const MX = [
    ['Кабель ВВГнг(А)-LS 5×16', '320 м · 158 167,04 с НДС', ['128', '128', '64'], 'q', '0 м'],
    ['Кабель ВВГнг(А)-LS 3×2,5', '1 200 м · 92 592,00 с НДС', ['480', '480', '240'], 'q', '0 м'],
    ['Автомат ВА47-29 1P 16А C', '48 шт · 16 473,60 с НДС', ['20', '', '8'], 'warn', '20 шт'],
    ['Щит ЩРН-24 IP41', '6 шт · 28 166,40 с НДС', ['2', '2', '2'], 'q', '0 шт'],
    ['Гофра ПВХ 20 мм с зондом', '600 м · суммы нет', ['300', '360', ''], 'err', '−60 м'],
    ['Коробка распаечная 100×100', '120 шт · 8 409,60 с НДС', ['48', '48', '24'], 'q', '0 шт'],
    ['Доставка', '5 400,00', null, 'q', '5 400,00'],
    ['Светильник LED 36 Вт 595×595', '84 шт · 114 912,00 с НДС', ['', '', ''], 'warn', '84 шт'],
  ];
  const matrix = () => {
    const head = TGT.map((t, i) => `<th style='height:auto;padding:8px;vertical-align:top'><div style='display:flex;gap:4px;align-items:center'>${dd(t[0])}${ib('delete', 'Убрать объект ' + (i + 1), 'xs err')}</div>` +
      `<div style='display:flex;gap:4px;margin-top:4px'>${dd(t[1])}<span class='sel-dd' style='width:72px;flex:none;justify-content:flex-end;padding-right:8px'>${t[2]} %</span></div></th>`).join('');
    const body = MX.map((r, i) => `<tr><td class='pin start ro' style='height:auto;padding:6px 12px;min-height:48px'><div>${r[0]}</div><div class='t-bs muted'>${r[1]}</div></td>` +
      (r[2] ? r[2].map((v, j) => `<td>${cf(v || '0', { num: 1, ph: !v, foc: i === 2 && j === 1, bad: i === 4 && j === 1 })}</td>`).join('')
        : `<td class='ro muted' colspan='3'>строка без количества — разносится только весь счёт на раздел</td>`) +
      `<td class='pin end ro num'>${r[3] === 'q' ? `<span class='muted'>${r[4]}</span>` : stx(r[3], r[4])}</td></tr>`).join('');
    return `<div class='dtc' data-count style='margin:0 24px 24px;flex:1'><div class='scroll'><table class='dt eg'>${cols([300, 0, 0, 0, 150])}` +
      `<thead><tr><th class='pin start' style='height:auto;vertical-align:bottom;padding:12px'>Строка</th>${head}<th class='pin end num' style='height:auto;vertical-align:bottom;padding:12px'>Не разнесено</th></tr></thead>` +
      `<tbody>${body}</tbody></table></div></div>`;
  };
  const allocScreen = (theme) => laptop('Матрица разноски', 'Счета', invoice(),
    `<div class='fs' role='dialog' aria-label='Разноска по объектам'><div class='top'>${ib('close', 'Закрыть')}<h2>Разноска по объектам: счёт № 1018</h2>` +
    `${btn('Поровну', 'text')}${btn('По %', 'text')}${btn('Применить', 'text')}${ib('more_vert', 'Ещё')}</div>` +
    `<div class='sub2'>Делится сумма с НДС · 8 строк · 3 объекта · ${btn('Добавить объект', 'text', 'add')}</div>${matrix()}</div>`, theme);

  /* ---- 4. таблица в окне (DataGrid compact) ---- */
  const PURGE = [['Счёт № 0987 от 02.09.2026', 'Счёт', '28.10.2026', 'Петрова А. В.'], ['Накладная № 771', 'Накладная', '28.10.2026', 'Петрова А. В.'],
    ['Счёт без номера (scan_0412.pdf)', 'Счёт', '27.10.2026', 'Кузнецов И. С.'], ['Комплект «Корпус 1, ЭОМ, август»', 'Комплект', '25.10.2026', 'Кузнецов И. С.'],
    ['Счёт № 0961 от 21.08.2026', 'Счёт', '24.10.2026', 'Петрова А. В.'], ['АОСР № 14 (черновик)', 'Документ', '24.10.2026', 'Орлов Д. Н.'],
    ['Накладная № 702', 'Накладная', '22.10.2026', 'Петрова А. В.'], ['Счёт № 0944 от 14.08.2026', 'Счёт', '20.10.2026', 'Кузнецов И. С.'],
    ['Протокол изоляции № 3', 'Документ', '19.10.2026', 'Орлов Д. Н.'], ['Счёт № 0930 от 09.08.2026', 'Счёт', '18.10.2026', 'Петрова А. В.'],
    ['Накладная № 688', 'Накладная', '17.10.2026', 'Петрова А. В.'], ['Ведомость материалов № 2', 'Документ', '16.10.2026', 'Орлов Д. Н.']];
  const purgeWin = () => `<div class='win' style='width:720px' role='dialog'><div class='hd'><h2>Очистить корзину: ${PURGE.length} записей</h2></div>` +
    `<div class='bd'><p style='margin:0'>Записи удалятся навсегда, вместе с файлами. Отменить это нельзя.</p>` +
    `<div class='dtc' data-count style='${V.grow ? '' : 'max-height:224px'}'><div class='scroll'><table class='dt cmp'>${cols([0, 120, 120, 150])}` +
    `<thead><tr>${th('Запись')}${th('Вид')}${th('Удалена')}${th('Кем')}</tr></thead><tbody>` +
    PURGE.map((r, i) => `<tr class='${i === 1 ? 'hov' : ''}'><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td></tr>`).join('') + `</tbody></table></div></div></div>` +
    `<div class='ft'>${btn('Отмена', 'text')}${btn('Удалить навсегда', 'filled danger')}</div></div>`;
  const dlgScreen = (theme) => laptop('Таблица в окне', 'Счета', registry(false), `<div class='scr'></div><div class='ctr'>${purgeWin()}</div>`, theme);

  /* ---- 5. список list-detail (типы документов) ---- */
  const TYPES = [['Исполнительная', [['АОСР', 'Акт освидетельствования скрытых работ · 24 поля'], ['Кабельный журнал', '18 полей · массив «Кабели»'],
    ['Журнал прокладки кабеля', '15 полей'], ['Ведомость материалов', '9 полей · набор данных «Материалы»'], ['Реестр документов', '6 полей'], ['Титульный лист', '11 полей']]],
  ['Измерения', [['Протокол измерения изоляции', '21 поле · массив «Линии»'], ['Протокол измерения заземления', '17 полей'], ['Протокол «фаза — ноль»', '19 полей']]],
  ['ПНР', [['Акт ПНР', '12 полей'], ['Программа ПНР', '8 полей']]]];
  const FIELDS = [['Номер акта', 'Строка', 'да'], ['Дата акта', 'Дата', 'да'], ['Объект', 'Ссылка: Стройка', 'да'], ['Застройщик', 'Ссылка: Организация', 'да'],
    ['Лицо, осуществляющее строительство', 'Ссылка: Организация', 'да'], ['Предъявленные работы', 'Текст', 'да'], ['Проектная документация', 'Строка', 'нет'],
    ['Материалы', 'Массив: Материал', 'нет'], ['Документы качества', 'Набор данных', 'нет'], ['Разрешается производство работ', 'Текст', 'нет']];
  const list = () => `<div class='ldl'><div class='lh'><span class='search'>${s('search')}Поиск типа</span>${ib('add', 'Новый тип')}</div><div style='overflow:hidden'>` +
    TYPES.map(([g, items]) => `<div class='grp'>${g}</div>` + items.map(([t, d]) =>
      `<div class='li two${t === 'АОСР' ? ' sel' : ''}${t === 'Ведомость материалов' ? ' hov' : ''}'><div class='b'><div class='t1'>${t}</div><div class='t2'>${d}</div></div></div>`).join('')).join('') + `</div></div>`;
  const typesScreen = (theme) => laptop('Список list-detail', 'Настройки',
    `<div class='ph'><h1>Типы документов</h1><span class='sp'></span>${btn('Импорт', 'text', 'upload')}</div><div class='row-x' style='border-top:1px solid var(--outline-variant)'>${list()}` +
    `<div class='det'><div class='ph'><h1 style='font-size:22px'>АОСР</h1><span class='sub'>Акт освидетельствования скрытых работ</span><span class='sp'></span>${btn('Шаблоны', 'tonal')}${ib('more_vert', 'Ещё')}</div>` +
    `<div class='dtc' data-count style='margin:0 24px 16px;flex:1'><div class='scroll'><table class='dt'>${cols([0, 220, 140])}<thead><tr>${th('Поле')}${th('Тип')}${th('Обязательное')}</tr></thead><tbody>` +
    FIELDS.map((f, i) => `<tr class='${i === 4 ? 'sel' : ''}'><td>${f[0]}</td><td class='muted'>${f[1]}</td><td>${f[2]}</td></tr>`).join('') + `</tbody></table></div></div></div></div>`, '', theme);

  /* ---- 6. лист массива документа (EditGrid sheet в окне) ---- */
  const CAB = [['1', 'ВВГнг(А)-LS 5×16', '16', '42', 'ВРУ-1', 'ЩР-2.1', 'лоток'], ['2', 'ВВГнг(А)-LS 5×10', '10', '38', 'ВРУ-1', 'ЩР-2.2', 'лоток'],
    ['3', 'ВВГнг(А)-LS 3×2,5', '2,5', '64', 'ЩР-2.1', 'гр. 1', 'гофра'], ['4', 'ВВГнг(А)-LS 3×2,5', '2,5', '57', 'ЩР-2.1', 'гр. 2', 'гофра'],
    ['5', 'ВВГнг(А)-LS 3×1,5', '1,5', 'сорок', 'ЩР-2.1', 'гр. 3', 'гофра'], ['6', 'ВВГнг(А)-LS 3×1,5', '1,5', '49', 'ЩР-2.2', 'гр. 1', 'гофра'],
    ['7', 'КВВГнг(А)-LS 7×1', '1', '22', 'ЩР-2.2', 'ЩУ-1', 'лоток'], ['8', '', '', '', '', '', '']];
  const sheetWin = () => `<div class='win' style='width:1040px' role='dialog'><div class='hd'><h2>Строки: Кабельный журнал</h2></div><div class='bd'>` +
    `<div class='dtc' data-count><div class='scroll'><table class='dt sh'>${cols([48, 0, 96, 96, 128, 128, 140])}` +
    `<thead><tr>${th('№', 'num')}${th('Марка кабеля')}${th('Сечение, мм²', 'num')}${th('Длина, м', 'num')}${th('Откуда')}${th('Куда')}${th('Прокладка')}</tr></thead><tbody>` +
    CAB.map((r, i) => `<tr><td class='num muted'>${r[0]}</td><td class='${i === 2 ? 'foc' : ''}'>${r[1]}</td><td class='num'>${r[2]}</td><td class='num${i === 4 ? ' bad' : ''}'>${r[3]}</td><td>${r[4]}</td><td>${r[5]}</td><td>${r[6]}</td></tr>`).join('') +
    `</tbody></table></div></div><span class='hint'>«Марка кабеля» третьей строки в фокусе; у пятой длина не числом.</span></div>` +
    `<div class='ft'>${btn('Добавить строку', 'text', 'add')}<span class='sp'></span>${btn('Отмена', 'text')}${btn('Готово', 'filled')}</div></div>`;
  const sheetScreen = (theme) => laptop('Лист массива документа', 'Комплекты',
    `<div class='ph'>${ib('arrow_back', 'Назад')}<h1>Кабельный журнал № 2</h1><span class='sub'>Корпус 2 · ЭОМ</span></div>`, `<div class='scr'></div><div class='ctr'>${sheetWin()}</div>`, theme);

  /* ---- 7. состояния крупно ---- */
  const board = (theme) => `<div class='md3' data-theme='${theme}' data-screen-label='Состояния (${thm(theme)})' style='flex:1'><div class='board' style='grid-template-columns:1fr'>` +
    `<div><div class='h'>Строки таблицы: обычная · под курсором · открытая · помеченная · открытая и помеченная · итог</div><div class='dtc'><table class='dt'>${cols([0, 140, 160])}<thead><tr>${th('Поставщик')}${th('Сумма, ₽', 'num')}${th('Состояние')}</tr></thead><tbody>` +
    `<tr><td>ЭТМ «Север»</td><td class='num'>57 840,00</td><td>${stx('ok', 'Оплачен')}</td></tr><tr class='hov'><td>ИП Семёнов</td><td class='num'>18 600,00</td><td>${stx('ok', 'Оплачен')}</td></tr>` +
    `<tr class='sel'><td>АО «Светотехника»</td><td class='num'>238 017,40</td><td>${stx('q', 'Ждёт оплаты')}</td></tr><tr class='mark'><td>ООО «Электромонтаж»</td><td class='num'>96 300,00</td><td>${stx('warn', 'Расхождение')}</td></tr>` +
    `<tr class='sel mark'><td>Кабельный завод «Проводник»</td><td class='num'>1 284 900,00</td><td>${stx('warn', 'Расхождение')}</td></tr><tr class='tot'><td>Итого</td><td class='num'>1 695 657,40</td><td></td></tr></tbody></table></div></div>` +
    `<div><div class='h'>Поле в клетке: покой · фокус · ошибка · выбор из списка · только чтение</div><div class='dtc'><table class='dt eg'>${cols([0, 92, 116, 180, 124])}<thead><tr>${th('Наименование')}${th('Кол-во', 'num')}${th('Цена, ₽', 'num')}${th('Позиция')}${th('Сумма, ₽', 'num')}</tr></thead><tbody>` +
    `<tr><td>${cf('Кабель ВВГнг(А)-LS 5×16')}</td><td>${cf('320', { num: 1, foc: 1 })}</td><td>${cf('нет цены', { num: 1, bad: 1, ph: 1 })}</td><td>${dd('Кабель 5×16')}</td><td class='ro num'>131 840,00</td></tr></tbody></table></div></div></div></div>`;

  /* ---- лист ---- */
  const nav = `<span class='nav'><a href='00 Разбор и вопрос.html'>0 Разбор и вопрос</a>` + Object.values(VARS).map(x =>
    `<a href='${x.name} - ${x.title}.html'${x.key === V.key ? " class='cur'" : ''}>${x.name} ${x.title}</a>`).join('') + `</span>`;
  const ctl = `<div class='ctl'><button data-th='light' class='${ST.theme === 'light' ? 'on' : ''}'>Светлая</button><button data-th='dark' class='${ST.theme === 'dark' ? 'on' : ''}'>Тёмная</button>` +
    `<button data-h='768' class='${ST.h === 768 ? 'on' : ''}'>1366×768</button><button data-h='650' class='${ST.h === 650 ? 'on' : ''}'>окно браузера 1366×650</button>${nav}</div>`;
  const one = (fn) => fn(ST.theme);
  const hpage = V.key === 'b' ? '48 / 40' : '56 / 48';

  document.getElementById('root').innerHTML = ctl +
    `<h1>${V.name} — ${V.title}</h1><div class='lead'><p>${V.rule}</p><p class='muted'>Одинаково на всех трёх листах: текст клетки — body-medium 14, подпись шапки — title-small 14/500 on-surface, черты — outline-variant, карточка таблицы — outlined 12; наведение — слой состояния 8 %; кнопка-иконка в клетке — XS 32; поле в клетке — 40 (В6), его черту ведёт само поле; пометка строки — warning-container. Оранжевая метка в углу таблицы считает строки, видимые целиком. Переключатели вверху меняют тему и высоту экрана: 768 — экран ноутбука, 650 — окно развёрнутого браузера на нём.</p></div>` +
    sec('1. Реестр счетов', `Таблица на странице (${hpage}), прокручена — шапка ${V.key === 'b' ? 'на заливке всегда' : 'получила заливку от прокрутки'}. Открыта строка № 1033, помечены № 1033 и № 1029 (расхождение сумм), под курсором — № 1030. Справа — standard side sheet строки (после 13). Итог закреплён внизу.`, both(regScreen)) +
    sec('2. Строки счёта', 'Сетка правки: строка 48, поле 40 в клетке. Шапка 48. «Позиция номенклатуры» — выбор из списка в клетке, «Сумма» — только для чтения, НДС — в итоге.', both(linesScreen)) +
    sec('3. Матрица разноски', 'Full-screen dialog (после 13). Шапка колонки с вводом — плотные поля 40 с рамкой (В5) во всех вариантах; строка в два этажа выше 48 — «не ниже 48». Закреплены первая колонка и «Не разнесено». У строки без количества полей нет — видно, отличимо ли правимое от неправимого.', both(allocScreen)) +
    sec('4. Таблица в окне', V.grow ? 'Плотная таблица (48 / 40) в окне 720: окно растёт по содержимому до края экрана, предела в 4 строки нет. Так же PurgeBatchDialog, сверка вставки строк, PaymentPostingTable, UnplacedReads.' : 'Плотная таблица (48 / 40) в окне 720 держит нынешний предел max-h-56 (224 px): видно 4 строки из 12 (сегодня 7), прочие — прокруткой. Так же PurgeBatchDialog, сверка вставки строк, PaymentPostingTable, UnplacedReads.', both(dlgScreen)) +
    sec('5. Список list-detail', 'Типы документов: список 320 с группами, выбран «АОСР», под курсором — «Ведомость материалов». Справа — таблица полей на странице, выбрана строка. Дизайнер и Архитектор предлагают вынести списки из этого change (общий ListItem) — см. лист 0; здесь выбирается направление.', both(typesScreen)) +
    sec('6. Лист массива документа', 'EditGrid sheet в окне: строка 40 (было 28, В5), линии колонок, текст 14 (было 12). Тема — переключателем вверху.', one(sheetScreen)) +
    sec('7. Состояния крупно', 'Строки и поле в клетке в обеих темах.', `<div style='display:flex;gap:16px;align-items:flex-start'>${board('light')}${board('dark')}</div>`);

  document.querySelectorAll('.ctl button[data-th]').forEach(b => b.onclick = () => {
    const u = new URL(location.href); u.searchParams.set('theme', b.dataset.th); location.href = u.toString(); });
  document.querySelectorAll('.ctl button[data-h]').forEach(b => b.onclick = () => {
    const u = new URL(location.href); u.searchParams.set('h', b.dataset.h); location.href = u.toString(); });

  /* метка «видно строк»: строки тела, целиком попавшие в видимую часть прокрутки */
  const count = () => document.querySelectorAll('.dtc[data-count]').forEach(card => {
    const sc = card.querySelector('.scroll'); if (!sc) return;
    const app = card.closest('.app'); if (app && card.closest('.work') && app.querySelector(':scope > .scr, :scope > .fs')) return;
    const box = sc.getBoundingClientRect(), head = sc.querySelector('thead');
    const top = head ? head.getBoundingClientRect().bottom : box.top;
    const rows = [...sc.querySelectorAll('tbody tr:not(.tot)')];
    const seen = rows.filter(r => { const b = r.getBoundingClientRect(); return b.top >= top - 0.5 && b.bottom <= box.bottom + 0.5; }).length;
    let m = card.querySelector('.cnt'); if (!m) { m = document.createElement('span'); m.className = 'cnt'; card.appendChild(m); }
    m.textContent = `видно строк: ${seen} из ${rows.length}`;
  });
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(count);
})();
