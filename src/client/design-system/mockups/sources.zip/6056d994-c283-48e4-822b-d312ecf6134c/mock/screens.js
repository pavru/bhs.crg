/* Экраны трёх макетов change sharedui-md3-11-inputs. Один набор экранов на три варианта: разница — классы на .md3
   (текст поля, вид плотного поля вне сетки) и выбор в строке отбора. Поле в клетке сетки — без рамки
   во всех трёх (решение change 14). Подписи — с настоящих экранов. */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: '16 в формах, плотное 40 с рамкой, отбор — чипом', t: 't16', dl: 'dl-frame', filter: 'chip', ro: 'a', icon: 1,
      rule: 'Поле формы — 56, текст body-large 16. Плотное поле — 40, текст 14; вне сетки (строки настроек в окнах и панелях, поповер условия) — с рамкой. Выбор в строке отбора — чип с меню (Chip menu из 10).' },
    b: { key: 'b', name: 'Б', title: '14 везде, плотное 40 с подчёркиванием', t: 't14', dl: 'dl-line', filter: 'chip', ro: 'v', icon: 0,
      rule: 'Поле формы — 56, текст 14, как сегодня. Плотное поле — 40 без рамки, с подчёркиванием везде — и в клетках сетки, и в строках настроек окон и панелей, как в макете Г. Выбор в строке отбора — чип с меню.' },
    v: { key: 'v', name: 'В', title: '16, отбор — плотным полем 40 с рамкой', t: 't16', dl: 'dl-frame', filter: 'field', ro: 'b', icon: 0,
      rule: 'Поле формы — 56, текст 16. Плотное поле вне сетки — 40 с рамкой. Чипа с меню нет: выбор в строке отбора и в подвале — то же плотное поле 40.' },
  };
  const V = VARS[window.VARIANT || 'a'];
  const ST = { theme: 'light', ro: V.ro, icon: V.icon };
  const q = new URLSearchParams(location.search);
  if (q.get('theme') === 'dark') ST.theme = 'dark';
  if (q.get('ro')) ST.ro = q.get('ro');
  if (q.get('icon')) ST.icon = q.get('icon') === '1' ? 1 : 0;
  const cls = () => `md3 ${V.t} ${V.dl} ro-${ST.ro}${ST.icon ? ' sw-icon' : ''}`;
  document.head.insertAdjacentHTML('beforeend', `<style>
    .md3 .chip.open>.dd{transform:rotate(180deg)}
    .md3 .chip>.menu{font-weight:400;color:var(--on-surface);letter-spacing:.25px}
    .md3 .egrid .df{border:0;border-bottom:1px solid var(--outline);border-radius:0;padding:0 4px}
    .md3 .egrid .df.foc{border:0;border-bottom:2px solid var(--primary);padding:0 4px}
    .md3 .egrid .df.err{border:0;border-bottom:1px solid var(--error)}
    .md3 .pop{position:absolute;background:var(--sc);border-radius:4px;box-shadow:var(--el2);padding:12px;display:flex;flex-direction:column;gap:8px;z-index:8;--fbg:var(--sc);font-weight:400}
    .md3 .dlg{--fbg:var(--sch)}
  </style>`);

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class='sym${c ? ' ' + c : ''}'>${n}</span>`;
  const ib = (n, l, c) => `<span class='ib${c ? ' ' + c : ''}' aria-label='${l}'>${s(n)}</span>`;
  const btn = (t, v, n) => `<span class='btn ${v}'>${n ? s(n) : ''}${t}</span>`;
  const chip = (t, o = {}) => `<span class='chip${o.sel ? ' sel' : ''}${o.assist ? ' assist' : ''}${o.c ? ' ' + o.c : ''}' style='position:relative'>` +
    `${o.icon ? s(o.icon, o.tone ? 'ic-' + o.tone : '') : ''}${t}${o.x ? s('close', 'x') : ''}${o.dd ? s('arrow_drop_down', 'dd') : ''}${o.menu || ''}</span>`;
  const menu = (items, on, o = {}) => `<div class='menu' style='${o.w ? 'right:auto;min-width:' + o.w + 'px;' : ''}'>` +
    items.map((t, i) => `<div class='${i === on ? 'on' : ''}${i === o.kb ? ' kb' : ''}'>${t}</div>`).join('') + '</div>';
  const of = (label, val, o = {}) => {
    const c = ['of', o.c, o.err ? 'err' : '', o.ro ? 'ro' : '', o.ta ? 'ta' : '', o.menu ? 'open foc' : ''].filter(Boolean).join(' ');
    const tr = o.tr ? s(o.tr, o.tr === 'arrow_drop_down' ? 'dd' : '') : '';
    return `<div class='fw' style='position:relative;${o.span ? 'grid-column:span ' + o.span + ';' : ''}${o.w ? 'width:' + o.w + 'px;' : ''}'>` +
      `<div class='${c}'>${label ? `<span class='lb'>${label}${o.req ? ' *' : ''}</span>` : ''}` +
      `<span class='v${o.num ? ' num' : ''}${o.ph ? ' ph' : ''}'>${val}</span>${o.sfx ? `<span class='sfx'>${o.sfx}</span>` : ''}` +
      `${o.err ? s('error', 'ic-e') : ''}${o.ro ? '' : tr}</div>` +
      `${o.sup != null ? `<div class='sup${o.err ? ' err' : ''}'>${o.sup}</div>` : ''}${o.menu || ''}</div>`;
  };
  const df = (val, o = {}) => {
    const c = ['df', o.c, o.err ? 'err' : '', o.ro ? 'ro' : '', o.menu ? 'open foc' : ''].filter(Boolean).join(' ');
    return `<span class='${c}' style='${o.w ? 'width:' + o.w + 'px;' : ''}${o.grow ? 'flex:1;' : ''}'${o.label ? ` aria-label='${o.label}'` : ''}>` +
      `<span class='v${o.num ? ' num' : ''}${o.ph ? ' ph' : ''}'>${val}</span>${o.sfx ? `<span class='sfx'>${o.sfx}</span>` : ''}` +
      `${o.err ? s('error', 'ic-e') : ''}${o.dd ? s('arrow_drop_down', 'dd') : ''}${o.tr ? s(o.tr) : ''}${o.menu || ''}</span>`;
  };
  /* Выбор в строке отбора: чип с меню (А, Б) или плотное поле 40 (В) */
  const fsel = (label, val, o = {}) => V.filter === 'chip'
    ? chip(val, { dd: 1, sel: o.sel, c: o.menu ? 'open' : '', menu: o.menu })
    : df(val, { dd: 1, w: o.w || 220, menu: o.menu, label });
  const cb = (st = '', l) => `<span class='cb ${st}' role='checkbox'${l ? ` aria-label='${l}'` : ''}><i></i></span>`;
  const ck = (t, st) => `<span class='ck'>${cb(st)}<span>${t}</span></span>`;
  const rb = (st = '') => `<span class='rb ${st}' role='radio'><i></i></span>`;
  const rg = (name, items, on, o = {}) => `<div class='rg${o.col ? ' col' : ''}' role='radiogroup' aria-label='${name}'>` +
    (o.lab ? `<span class='muted' style='margin-right:4px'>${o.lab}</span>` : '') +
    items.map((t, i) => `<span class='ck'>${rb((i === on ? 'on' : '') + (o.kb === i ? ' kb' : '') + (o.dis ? ' dis' : ''))}<span>${t}</span></span>`).join('') + '</div>';
  const sw = (on, c = '') => `<span class='sw${on ? ' on' : ''}${c ? ' ' + c : ''}' role='switch' aria-checked='${!!on}'><i>${s(on ? 'check' : 'close')}</i></span>`;
  const sub = (t) => `<span class='t-bs muted'>${t}</span>`;

  const rail = (on) => `<nav class='rail'>` + [
    ['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['apartment', 'Стройки'],
    ['folder_open', 'Комплекты'], ['table_chart', 'Таблицы'], ['settings', 'Настройки'],
  ].map(([n, t]) => `<div class='it${t === on ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const laptop = (label, on, inner) => `<div class='${cls()}' data-theme='${ST.theme}' data-screen-label='${label}'><div class='app laptop'>${rail(on)}<div class='work'>${inner}</div></div></div>`;
  const pnav = (on) => `<div class='pnav'>` + [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['folder_open', 'Комплекты'], ['menu', 'Ещё']]
    .map(([n, t]) => `<div class='it${t === on ? ' on' : ''}'><span class='pill'>${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</div>';
  const phone = (label, inner, on, nav = true) => `<div class='${cls()}' data-theme='${ST.theme}' data-screen-label='${label}'><div class='app phone'>${inner}${nav ? pnav(on) : ''}</div></div>`;

  /* ---- L1. Форма счёта: реквизиты (InvoiceForm) рядом со сканом ---- */
  function invoiceForm() {
    const F = [
      of('Номер', '1020', { req: 1 }), of('Дата', '31.10.2026', { req: 1, tr: 'calendar_today' }),
      of('Поставщик', 'ООО «ЭТМ» · Санкт-Петербург', { req: 1, span: 2, tr: 'close' }),
      of('Плательщик', 'ООО «БХС»', { tr: 'arrow_drop_down' }), of('Объект счёта', 'ЖК «Северный» › ЭОМ', { tr: 'arrow_drop_down' }),
      of('Сумма к оплате', '624 316,00', { num: 1, sfx: '₽', req: 1 }), of('В том числе НДС', '104 052,67', { num: 1, sfx: '₽' }),
      of('Дата отгрузки', '28.10.2026', { tr: 'calendar_today', sup: 'Отгрузка раньше даты счёта — проверьте дату: от неё считается срок' }),
      of('Отсрочка, дней', '10', { num: 1, c: 'foc' }),
      of('Оплатить до', '07.11.2026', { tr: 'calendar_today' }), of('Основание', 'Договор поставки № 14/26'),
      of('Состояние', 'Разобрать', { ro: 1, sup: 'Двигают действия, не форма' }), of('Оплата', 'Не оплачен', { ro: 1, sup: 'Двигают действия, не форма' }),
      of('Назначение', 'Оплата по счёту № 1020 от 31.10.2026 за кабельную продукцию и аппараты защиты, в т. ч. НДС 20 %', { ta: 1, span: 2 }),
    ].join('');
    return laptop('L1 Форма счёта', 'Счета', `
      <div class='ph'><h1>Счёт № 1020 · ЭТМ</h1><span class='sub'>Разобрать</span><span class='sp'></span>
        ${btn('Разнести по объектам', 'outlined', 'call_split')}${btn('Отметить оплату', 'outlined', 'payments')}${btn('Разобран', 'filled', 'check')}${ib('more_vert', 'Ещё')}</div>
      <div class='split'>
        <div style='width:660px;flex:none;overflow:hidden;padding:12px 24px;display:grid;grid-template-columns:1fr 1fr;gap:16px;align-content:start'>${F}</div>
        <div class='pane ph-img' style='margin:0 16px 16px 0;border-radius:12px'>скан счёта · PDF</div>
      </div>`);
  }

  /* ---- L2. Окна с полями: ошибка, фокус, только для чтения, многострочное с ошибкой ---- */
  function dialogs() {
    return laptop('L2 Окно с полями и ошибкой', 'Счета', `<div class='ph'><h1>Счета</h1></div>
      <div class='scrim' style='gap:24px'>
        <div class='dlg' style='width:560px'><h2>Оплата счёта № 1020</h2>
          <div class='muted'>Счёт уйдёт в оплаченные. Отменить оплату можно позже — с причиной.</div>
          ${of('Сумма к оплате', '624 316,00 ₽', { ro: 1 })}
          ${of('Дата платежа', '01.11.2026', { req: 1, err: 1, tr: 'calendar_today', sup: 'Дата платежа позже сегодняшней (31.10.2026)' })}
          ${of('Платёжный документ', 'п/п № 4471 от 31.10.2026', { c: 'foc', sup: 'Номер и дата платёжного поручения' })}
          <div class='acts'>${btn('Отмена', 'text')}${btn('Отметить оплату', 'filled')}</div></div>
        <div class='dlg' style='width:440px'><h2>Отменить оплату?</h2>
          <div class='muted'>Счёт вернётся в «К оплате», причина останется в истории счёта.</div>
          ${of('Причина отмены', '', { req: 1, err: 1, ta: 1, sup: 'Укажите причину — без неё оплату не отменить' })}
          <div class='acts'>${btn('Не отменять', 'text')}${btn('Отменить оплату', 'filled danger')}</div></div>
      </div>`);
  }

  /* ---- L3. Строка отбора реестра: Журнал действий (отбор по действию) и «Строк на странице» ---- */
  function journal() {
    const recs = [['31.10.2026 14:02', 'А. Иванова', 'Смена ролей', 'П. Петров: + «Бухгалтер»'], ['30.10.2026 17:45', 'А. Иванова', 'Смена ролей', 'М. Соколова: − «Инженер ПТО»'],
      ['29.10.2026 09:12', 'А. Иванова', 'Смена ролей', 'Роль «Прораб»: + work.report.submit'], ['24.10.2026 11:30', 'А. Иванова', 'Смена ролей', 'Д. Кузнецов: + «Прораб»'],
      ['17.10.2026 16:05', 'А. Иванова', 'Смена ролей', 'Роль «Бухгалтер»: + costs.invoice.pay'], ['12.10.2026 10:48', 'А. Иванова', 'Смена ролей', 'П. Петров: − «Прораб»'],
      ['03.10.2026 08:57', 'А. Иванова', 'Смена ролей', 'Роль «Инженер ПТО» создана'], ['28.09.2026 13:20', 'А. Иванова', 'Смена ролей', 'М. Соколова: + «Инженер ПТО»']];
    const rows = recs.map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td></tr>`).join('');
    const m = menu(['Все действия', 'Смена ролей', 'Правка схемы типа', 'Состав модулей'], 1, { w: 240 });
    return laptop('L3 Строка отбора реестра', 'Настройки', `
      <div class='ph'><h1>Журнал действий</h1><span class='sub'>1 284</span><span class='sp'></span>${ib('download', 'Выгрузить')}</div>
      <div class='fbar' style='position:relative;z-index:7'>${fsel('Отбор по действию', 'Смена ролей', { sel: 1, menu: m, w: 240 })}${sub('сейчас — Select md 36 в шапке справа, ширина 256')}</div>
      <div class='tblw' style='border-top:1px solid var(--outline-variant)'><table class='g'><colgroup><col style='width:170px'><col style='width:170px'><col style='width:190px'><col></colgroup>
        <thead><tr><th>Когда</th><th>Кто</th><th>Действие</th><th>Что</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class='tbar' style='border-bottom:0;border-top:1px solid var(--outline-variant);justify-content:flex-end'><span class='muted'>Строк на странице</span>${fsel('Строк на странице', '50', { w: 88 })}<span class='muted' style='margin-left:16px'>1–50 из 1 284</span>${ib('chevron_left', 'Назад')}${ib('chevron_right', 'Вперёд')}</div>`);
  }

  /* ---- L4. Поповер условия отбора (ConditionEditor) над таблицей ---- */
  function condition() {
    const data = [['1020', '31.10.2026', 'ЭТМ', 'ЖК «Северный»', '624 316,00'], ['1012', '24.10.2026', 'ЭТМ', 'Школа № 7', '133 870,00'], ['1009', '22.10.2026', 'ЭТМ', 'ЖК «Северный»', '402 118,00'],
      ['1004', '17.10.2026', 'ЭТМ', 'Склад «Восток»', '57 300,00'], ['0998', '12.10.2026', 'ЭТМ', 'Школа № 7', '18 240,00'], ['0991', '08.10.2026', 'ЭТМ', 'ЖК «Северный»', '211 004,00'], ['0987', '03.10.2026', 'ЭТМ', 'ЖК «Северный»', '76 560,00']]
      .map(r => `<tr><td class='num'>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td class='num'>${r[4]}</td></tr>`).join('');
    const pop = `<div class='pop' style='left:300px;top:44px;width:320px'><span class='t-bs muted'>Условие</span>` +
      `${df('Сумма', { dd: 1, label: 'Колонка' })}${df('больше', { dd: 1, label: 'Оператор' })}${df('10 000', { num: 1, sfx: '₽', c: 'foc', label: 'Значение' })}` +
      `<div style='display:flex;justify-content:flex-end;gap:8px'>${btn('Убрать', 'text')}${btn('Применить', 'filled')}</div></div>`;
    return laptop('L4 Поповер условия отбора', 'Таблицы', `
      <div class='ph'><h1>Счета — мой вид</h1><span class='sub'>· изменено</span>${btn('Сохранить', 'tonal')}${btn('Сбросить', 'text')}<span class='sp'></span>${ib('view_column', 'Колонки')}${ib('download', 'Выгрузить')}</div>
      <div class='fbar' style='position:relative;z-index:8'>${chip('Без статьи · 7', { icon: 'warning', tone: 'err' })}${chip('Поставщик: <b>ЭТМ</b>', { x: 1 })}${chip('Сумма: <b>&gt; 10 000</b>', { x: 1, sel: 1 })}${chip('условие', { assist: 1, icon: 'add' })}${pop}</div>
      <div class='tblw' style='border-top:1px solid var(--outline-variant)'><table class='g'><colgroup><col style='width:90px'><col style='width:130px'><col><col><col style='width:160px'></colgroup>
        <thead><tr><th class='num'>№</th><th>Дата</th><th>Поставщик</th><th>Стройка</th><th class='num'>Сумма</th></tr></thead><tbody>${data}</tbody></table></div>`);
  }

  /* ---- L5. Строки настроек в окне: сопоставление колонок при вставке (PasteMappingModal) — третья категория ---- */
  function mapping() {
    const R = [['Номер', 'B · № п/п', ''], ['Наименование работ', 'C · Наименование', ''], ['Организация', 'D · Подрядчик', 'Наименование'],
      ['Ответственный', 'E · Прораб', 'Ключ'], ['Дата начала', 'F · Начало', ''], ['Дата окончания', '— не выбрана —', '', 1]];
    const grid = `display:grid;grid-template-columns:190px minmax(0,1fr) 200px;gap:12px;align-items:center`;
    const rows = R.map(r => `<div style='${grid};min-height:48px;border-bottom:1px solid var(--outline-variant)'><span>${r[0]}</span>` +
      `${df(r[1], { dd: 1, ph: r[3], label: 'Колонка для «' + r[0] + '»' })}${r[2] ? df(r[2], { dd: 1, label: 'Как сопоставлять «' + r[0] + '»' }) : '<span></span>'}</div>`).join('');
    return laptop('L5 Строки настроек в окне', 'Комплекты', `<div class='ph'><h1>Комплект ИД № 4 — ЭОМ, секция 2</h1></div>
      <div class='scrim'><div class='dlg' style='width:780px;gap:12px'><h2>Вставка строк из таблицы</h2>
        <div class='muted'>Скопировано 24 строки, 6 колонок. Сопоставьте колонки с полями таблицы «Работы».</div>
        <div style='${grid}' class='t-bs muted'><span>Поле</span><span>Колонка</span><span>Как сопоставлять</span></div>
        <div>${rows}</div>
        <div class='acts'>${btn('Отмена', 'text')}${btn('Вставить 24 строки', 'filled')}</div></div></div>`);
  }

  /* ---- L6. Матрица разноски (EditGrid): шапка объекта и NumberInput в клетках — без рамки во всех трёх ---- */
  function matrix() {
    const T = [['ЖК «Северный»', 'ЭОМ', '40'], ['Школа № 7', 'ЭОМ', '35'], ['Склад «Восток»', '— раздел —', '25']];
    const head = T.map((t, i) => `<th class='fld'><div style='display:flex;flex-direction:column;gap:4px'>` +
      `<div style='display:flex;gap:4px;align-items:center'>${df(t[0], { dd: 1, grow: 1, label: 'Объект ' + (i + 1) })}${ib('close', 'Убрать объект ' + (i + 1), 'dense')}</div>` +
      `${df(t[1], { dd: 1, ph: i === 2, label: 'Раздел, объект ' + (i + 1) })}${df(t[2], { num: 1, sfx: '%', label: 'Процент, объект ' + (i + 1) })}</div></th>`).join('');
    const L = [
      ['Кабель ВВГнг(А)-LS 3×2,5', '1 200 м · 110 880,00', 'м', [['480', '44 352,00'], ['420', '38 808,00'], ['300', '27 720,00']], '0 м'],
      ['Щит ЩРН-М-24 встраиваемый', '8 шт · 25 440,00', 'шт', [['4', '12 720,00', 'foc'], ['2', '6 360,00'], ['', '', 'ph']], '≈ 2 шт'],
      ['Гофра ПВХ 20 мм с зондом', '900 м · 10 620,00', 'м', [['400', '4 720,00'], ['600', '7 080,00', 'err'], ['0', '0,00']], 'err'],
      ['Автомат ВА 47-29 1Р 16А С', '64 шт · 13 696,00', 'шт', [['26', '5 564,00'], ['22', '4 708,00'], ['16', '3 424,00']], '0 шт'],
      ['Доставка', '4 500,00', '₽', [['1 800,00', ''], ['1 575,00', ''], ['1 125,00', '']], '0,00'],
    ];
    const rows = L.map(l => `<tr><td style='white-space:normal;vertical-align:top;padding-top:8px'><div>${l[0]}</div><div class='t-bs muted'>${l[1]}</div></td>` +
      l[3].map(c => `<td class='fld' style='vertical-align:top'>${df(c[2] === 'ph' ? '0' : c[0], { num: 1, sfx: l[2], ph: c[2] === 'ph', c: c[2] === 'foc' ? 'foc' : '', err: c[2] === 'err' })}<div class='sub2'>${c[1] || '&nbsp;'}</div></td>`).join('') +
      `<td class='num pin-r' style='vertical-align:top;padding-top:16px'>${l[4] === 'err' ? `<span style='color:var(--error)'>−100 м</span>` : `<span class='muted'>${l[4]}</span>`}</td></tr>`).join('');
    return laptop('L6 Клетка матрицы разноски', 'Счета', `<div class='ph'><h1>Счёт № 1020 · ЭТМ</h1></div>
      <div class='scrim' style='align-items:flex-start;padding-top:12px'><div class='dlg' style='width:1180px;gap:12px;padding:20px 24px'><h2>Разнести по объектам · счёт № 1020</h2>
        <div style='display:flex;gap:8px;align-items:center'>${btn('Поровну', 'outlined')}${btn('По %', 'outlined')}${btn('Объект', 'text', 'add')}<span class='sp'></span>${sub('сейчас: клетки — NumberInput со своей рамкой ~24 px, шапка — Select sm 28')}</div>
        <table class='g egrid'><colgroup><col style='width:250px'><col><col><col><col style='width:130px'></colgroup>
          <thead><tr><th style='vertical-align:bottom'>Строка</th>${head}<th class='num pin-r' style='vertical-align:bottom'>Не разнесено</th></tr></thead><tbody>${rows}</tbody></table>
        <div class='acts'>${btn('Отмена', 'text')}${btn('Сохранить разноску', 'filled')}</div></div></div>`);
  }

  /* ---- L7. Флажки в таблице: ведомость материалов комплекта (MaterialsTable) ---- */
  function materials() {
    const M = [['Кабель ВВГнг(А)-LS 3×2,5', 'м', '1 200', 'Сертификат соответствия', 'on'], ['Кабель ВВГнг(А)-LS 5×10', 'м', '320', '—', ''],
      ['Автомат ВА 47-29 1Р 16А С', 'шт', '64', 'Паспорт качества № 4471', 'on hov'], ['Щит ЩРН-М-24 встраиваемый', 'шт', '8', '—', ''],
      ['Гофра ПВХ 20 мм с зондом', 'м', '900', '—', 'kb'], ['Коробка распаечная 100×100×50', 'шт', '120', 'Декларация ЕАЭС', 'on'],
      ['Розетка с заземлением скрытой установки', 'шт', '240', '—', ''], ['Светильник светодиодный 36 Вт', 'шт', '96', '—', ''],
      ['Выключатель одноклавишный', 'шт', '180', '—', '']];
    const rows = M.map(m => `<tr${m[4].includes('on') ? ` class='sel'` : ''}><td class='acts' style='text-align:left;padding:0 0 0 4px'>${cb(m[4], 'Выбрать «' + m[0] + '»')}</td><td>${m[0]}</td><td>${m[1]}</td><td class='num'>${m[2]}</td><td class='${m[3] === '—' ? 'muted' : ''}'>${m[3]}</td></tr>`).join('');
    const tabs = `<div style='display:flex;border-bottom:1px solid var(--outline-variant);padding:0 16px'>` + ['Документы', 'Данные', 'Материалы', 'Генерация']
      .map((t, i) => `<span style='height:48px;display:inline-flex;align-items:center;padding:0 16px;font-weight:500;${i === 2 ? 'color:var(--primary);box-shadow:inset 0 -3px 0 var(--primary)' : 'color:var(--on-surface-variant)'}'>${t}</span>`).join('') + '</div>';
    return laptop('L7 Флажки в таблице', 'Комплекты', `
      <div style='padding:12px 24px 0' class='t-bs muted'>Стройки › ЖК «Северный» › Раздел ЭОМ</div>
      <div class='ph' style='padding-top:4px'><h1>Комплект ИД № 4 — ЭОМ, секция 2</h1></div>${tabs}
      <div class='tbar'><span class='t-tm'>Ведомость материалов</span><span class='muted'>· 3 выбрано</span><span class='sp'></span>${ck('Только без документа качества', '')}${btn('Подобрать', 'outlined', 'auto_awesome')}${btn('Связать документ качества', 'tonal', 'link')}</div>
      <div class='tblw'><table class='g'><colgroup><col style='width:52px'><col><col style='width:70px'><col style='width:110px'><col style='width:300px'></colgroup>
        <thead><tr><th style='padding:0 0 0 4px'>${cb('mix', 'Выбрать все строки')}</th><th>Материал</th><th>Ед.</th><th class='num'>Количество</th><th>Документ качества</th></tr></thead><tbody>${rows}</tbody></table></div>`);
  }

  /* ---- L8. Радиокнопки: MaterializationDialog (группа с именем) и строка резервной копии ---- */
  function radios() {
    const m = menu(['— не выбрана —', 'Ид документа', 'Номер акта', 'Дата акта', 'Работы'], 1, { kb: 2 });
    return laptop('L8 Группа радиокнопок', 'Таблицы', `<div class='ph'><h1>Наборы данных</h1></div>
      <div class='scrim' style='gap:24px;align-items:flex-start;padding-top:48px'>
        <div class='dlg' style='width:600px'><h2>Сделать документы из набора «Акты скрытых работ»</h2>
          ${of('Тип документа', 'АОСР', { tr: 'arrow_drop_down' })}
          <div style='border:1px solid var(--outline-variant);border-radius:12px;padding:8px 16px 16px;display:flex;flex-direction:column;gap:4px'>
            <span class='t-bs muted' style='padding-top:4px'>Откуда строка берёт документ</span>
            ${rg('Откуда строка берёт документ', ['собрать из колонок', 'существующий документ по Ид'], 1, { kb: 1 })}
            <div style='height:8px'></div>
            ${of('Колонка с идентификатором документа', 'Ид документа', { tr: 'arrow_drop_down', menu: m })}
            <div class='t-bs muted' style='display:flex;gap:4px;align-items:center;padding-top:8px'>${s('info')}строка целиком становится ссылкой на документ — поля берутся из него самого</div>
          </div>
          <div class='acts'>${btn('Отмена', 'text')}${btn('Сделать 24 документа', 'filled')}</div></div>
        <div class='dlg' style='width:520px;background:var(--surface);--fbg:var(--surface)'><h2 style='font-size:22px;line-height:28px'>Резервные копии</h2>
          <div class='t-bs muted'>часть страницы «Настройки» (BackupSection), показана здесь для сравнения</div>
          ${rg('Что включать', ['настройку и проектные данные', 'только настройку'], 0, { lab: 'Что включать:' })}
          <div class='muted'>Размер копии — около 1,2 ГБ</div>
          <div style='display:flex;gap:8px'>${btn('Снять копию', 'filled', 'backup')}${btn('Загрузить копию', 'outlined', 'upload')}</div>
          <div class='t-bs muted' style='margin-top:8px'>Та же группа столбиком и во время съёмки — отключена:</div>
          ${rg('Что включать', ['настройку и проектные данные', 'только настройку'], 0, { col: 1, dis: 1 })}
        </div>
      </div>`);
  }

  /* ---- L9. Переключатели свойств типа (PropertiesEditor, InheritedFieldsPanel) ---- */
  function typeProps() {
    const types = ['АОСР', 'Акт (общий)', 'Кабельный журнал', 'Ведомость материалов', 'Протокол измерения изоляции', 'Титульный лист', 'Организация', 'Сотрудник']
      .map((t, i) => `<div class='li' style='min-height:48px;${i === 0 ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : ''}'><div class='b'><div>${t}</div></div></div>`).join('');
    const inh = [['Номер', 1], ['Дата', 1], ['Объект строительства', 1], ['Застройщик', 0], ['Лицо, осуществляющее строительство', 1], ['Технический заказчик', 0, 'press']]
      .map(f => `<div class='swr' style='border-bottom:1px solid var(--outline-variant);min-height:48px;padding:4px 0'><div class='b'><span class='t'>${f[0]}</span></div>${sw(f[1], f[2] || '')}</div>`).join('');
    return laptop('L9 Переключатели свойств типа', 'Настройки', `
      <div class='ph'><h1>Типы документов</h1><span class='sp'></span>${btn('Новый тип', 'filled', 'add')}</div>
      <div class='split' style='border-top:1px solid var(--outline-variant)'>
        <div style='width:280px;flex:none;overflow:hidden;background:var(--scl)'>${types}</div>
        <div class='pane' style='padding:16px 24px;gap:12px;overflow:hidden'>
          <div class='t-tm'>Свойства</div>
          <div style='display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:760px'>${of('Название', 'Акт освидетельствования скрытых работ', { req: 1 })}${of('Код', 'АОСР', { ro: 1, sup: 'Код существующего типа не меняется' })}</div>
          <div class='t-bs muted'>Переключатель в начале строки (как сегодня) и в конце (как у MD3):</div>
          <div style='display:flex;gap:32px;max-width:760px'><div class='swr' style='gap:12px;min-height:48px'>${sw(0)}<span class='t'>Роль/прокси</span></div><div class='swr' style='gap:12px;min-height:48px'>${sw(1)}<span class='t'>Абстрактный</span></div></div>
          <div style='max-width:760px'><div class='swr' style='border-bottom:1px solid var(--outline-variant);min-height:48px;padding:4px 0'><div class='b'><span class='t'>Роль/прокси</span></div>${sw(0)}</div><div class='swr' style='min-height:48px;padding:4px 0'><div class='b'><span class='t'>Абстрактный</span></div>${sw(1)}</div></div>
          <div class='t-tm' style='margin-top:4px'>Наследуемые поля — от «Акт (общий)»</div>
          <div style='max-width:760px'>${inh}</div>
        </div></div>`);
  }

  /* ---- Телефон ---- */
  function pForm() {
    return phone('P1 Форма счёта, телефон', `<div class='ptop'>${ib('arrow_back', 'Назад')}<h1 style='margin-left:0'>Счёт № 1020</h1>${ib('more_vert', 'Ещё')}</div>
      <div class='pbody' style='padding:8px 16px;gap:16px'>${of('Номер', '1020', { req: 1 })}${of('Дата', '31.10.2026', { req: 1, tr: 'calendar_today' })}${of('Поставщик', 'ООО «ЭТМ» · Санкт-Петербург', { req: 1, tr: 'close' })}
        ${of('Сумма к оплате', '624 316,00', { num: 1, sfx: '₽', req: 1 })}${of('Дата отгрузки', '28.10.2026', { tr: 'calendar_today', sup: 'Отгрузка раньше даты счёта — проверьте дату: от неё считается срок' })}${of('Состояние', 'Разобрать', { ro: 1, sup: 'Двигают действия, не форма' })}</div>`, 'Счета');
  }
  function pJournal() {
    const items = [['Смена ролей', 'П. Петров: + «Бухгалтер»', '31.10.2026 14:02'], ['Смена ролей', 'М. Соколова: − «Инженер ПТО»', '30.10.2026 17:45'], ['Смена ролей', 'Роль «Прораб»: + work.report.submit', '29.10.2026 09:12'], ['Смена ролей', 'Д. Кузнецов: + «Прораб»', '24.10.2026 11:30'], ['Смена ролей', 'Роль «Бухгалтер»: + costs.invoice.pay', '17.10.2026 16:05'], ['Смена ролей', 'П. Петров: − «Прораб»', '12.10.2026 10:48']]
      .map(r => `<div class='li'><div class='b'><div>${r[1]}</div><div class='t-bs muted'>${r[0]} · ${r[2]}</div></div></div>`).join('');
    return phone('P2 Отбор, телефон', `<div class='ptop'><h1>Журнал действий</h1>${ib('more_vert', 'Ещё')}</div>
      <div class='pbody'><div class='chiprow'>${fsel('Отбор по действию', 'Смена ролей', { sel: 1, w: 343 })}</div>${items}</div>`, 'Ещё');
  }
  function pDialog() {
    return phone('P3 Окно на весь экран, телефон', `<div class='ptop'>${ib('close', 'Закрыть')}<h1 style='margin-left:0'>Оплата счёта</h1>${btn('Отметить', 'text')}</div>
      <div class='pbody' style='padding:8px 16px;gap:16px'>${of('Сумма к оплате', '624 316,00 ₽', { ro: 1 })}${of('Дата платежа', '01.11.2026', { req: 1, err: 1, tr: 'calendar_today', sup: 'Дата платежа позже сегодняшней (31.10.2026)' })}${of('Платёжный документ', 'п/п № 4471 от 31.10.2026', { c: 'foc', sup: 'Номер и дата платёжного поручения' })}
        <div class='swr'><div class='b'><span class='t'>Сообщить снабженцу</span></div>${sw(1)}</div>${ck('Приложить платёжное поручение', 'on')}</div>`, 'Счета', false);
  }

  /* ---- Доска «сейчас → станет» ---- */
  function board() {
    const r = (h, a, b) => `<div class='h'>${h}</div><div class='r'>${a}</div><div class='r'>${b}</div>`;
    const old = (label, val, c = '', tr = '') => `<div class='fw' style='width:220px'><div class='of old ${c}'><span class='lb'>${label}</span><span class='v'>${val}</span>${tr ? s(tr) : ''}</div></div>`;
    return `<div class='${cls()}' data-theme='${ST.theme}' data-screen-label='Доска'><div class='board' style='--fbg:var(--surface)'>
      <div class='h'></div><div class='h'><b>Сейчас</b></div><div class='h'><b>Станет — ${V.name}</b></div>
      ${r('Поле формы 56', old('Номер', '1020') + old('Дата', '01.11.2026', 'err', 'calendar_today'), of('Номер', '1020', { w: 220 }) + of('Дата', '01.11.2026', { w: 220, err: 1, tr: 'calendar_today' }))}
      ${r('Только для чтения', old('Состояние', 'Разобрать', 'ro'), of('Состояние', 'Разобрать', { w: 220, ro: 1 }))}
      ${r('Плотное поле 40 вне сетки', `<span class='df old md' style='width:150px'><span class='v'>Select md 36</span>${s('expand_more')}</span><span class='df old' style='width:130px'><span class='v'>Select sm 28</span>${s('expand_more')}</span>`,
        df('C · Наименование', { dd: 1, w: 200 }) + df('Ключ', { dd: 1, w: 120 }))}
      ${r('Поле в клетке сетки', `<span class='df old nin' style='width:80px'><span class='v num'>480</span><span class='sfx'>м</span></span>` + sub('NumberInput ~24'),
        `<span class='egrid' style='display:flex;gap:8px'>${df('480', { num: 1, sfx: 'м', w: 110 })}${df('600', { num: 1, sfx: 'м', w: 110, err: 1 })}</span>` + sub('без рамки во всех трёх — решение change 14'))}
      ${r('Выбор в отборе', `<span class='df old md' style='width:200px'><span class='v'>Все действия</span>${s('expand_more')}</span>`, fsel('Отбор', 'Все действия', { w: 200 }) + fsel('Отбор', 'Смена ролей', { sel: 1, w: 200 }))}
      ${r('Флажок', `<span class='ck'>${cb('old')}<span>нет</span></span><span class='ck'>${cb('old on')}<span>да</span></span>`, cb('') + cb('on') + cb('mix') + cb('hov') + cb('kb on') + cb('err') + cb('err on') + cb('dis') + cb('dis on') + sub('пустой, да, частично, наведение, фокус, ошибка, отключён'))}
      ${r('Радиокнопка', `<span class='ck'>${rb('old on')}<span>собрать</span></span><span class='ck'>${rb('old')}<span>по Ид</span></span>`, rb('on') + rb('') + rb('hov on') + rb('kb') + rb('dis') + sub('да, нет, наведение, фокус, отключена'))}
      ${r('Переключатель', sw(1, 'old') + sw(0, 'old') + sw(1, 'old sm') + sub('44×24 и sm 36×20'), sw(1) + sw(0) + sw(1, 'press') + sw(0, 'press') + sub('вкл, выкл, нажатие (ручка 28)'))}
    </div></div>`;
  }

  /* ---- лист варианта ---- */
  const BORDER = {
    a: 'Текст 16 — в полях форм, окон и свойств; 14 — в плотном поле. Плотное поле вне сетки (строки настроек окна, поповер условия) — с рамкой, в клетке сетки — без рамки (решение 14). В строке отбора и подвале — чип 32 с меню, как соседние чипы.',
    b: 'Текст 14 везде — ширина значений как сегодня. Плотное поле без рамки и вне сетки: смотрите строки настроек окна и поповер условия — читается ли подчёркнутое значение полем. Отбор — чип с меню, как в А.',
    v: 'Текст 16 в формах, как в А. Чипа с меню в отборе нет: выбор — плотное поле 40 с рамкой и стрелкой, то же, что в строках настроек. Один вид выбора на всё, но в строке с чипами условий — два языка.',
  };
  const RO = { a: 'а — контур outline-variant', b: 'б — подложка filled', v: 'в — без рамки, значением' };
  const order = ['a', 'b', 'v'], files = { a: 'А - 16 и чип.html', b: 'Б - 14 и подчёркивание.html', v: 'В - 16 без чипа.html' };
  const nav = `<span class='nav'><a href='${encodeURI('00 Разбор и вопрос.html')}'>0 Разбор</a>` + order.map(k => `<a href='${encodeURI(files[k])}'${k === V.key ? ` class='cur'` : ''}>${VARS[k].name} — ${VARS[k].title}</a>`).join('') + '</span>';
  const sec = (h, cap, body) => `<h2>${h}</h2>${cap ? `<div class='cap'>${cap}</div>` : ''}<div class='row'>${body}</div>`;
  const ctl = () => `<div class='ctl'><button data-t='light'${ST.theme === 'light' ? ` class='on'` : ''}>Светлая</button><button data-t='dark'${ST.theme === 'dark' ? ` class='on'` : ''}>Тёмная</button>
    <span style='margin-left:12px;font-size:13px'>Только для чтения:</span>` + order.map(k => `<button data-ro='${k}'${ST.ro === k ? ` class='on'` : ''}>${RO[k]}</button>`).join('') +
    `<button data-ic='1'${ST.icon ? ` class='on'` : ''} style='margin-left:12px'>Знак на ручке переключателя</button>${nav}</div>`;
  const html = () => `${ctl()}
    <h1>${V.name} — ${V.title}</h1>
    <div class='lead'><p>${V.rule}</p><p><b>Граница:</b> ${BORDER[V.key]}</p>
      <p>Два вопроса, не зависящие от варианта, — кнопками вверху: вид «только для чтения» (а/б/в) и знак на ручке переключателя. У этого листа по умолчанию — ${RO[V.ro]}, знак ${V.icon ? 'есть' : 'нет'}.</p></div>
    ${sec('Сейчас → станет', 'Каждый элемент в своих состояниях. Слева — как сегодня в коде (форма 8, нативный флажок, Switch 44×24).', board())}
    ${sec('Форма счёта — 1366×768', 'Реквизиты InvoiceForm в два столбца рядом со сканом: подсказка под полем, фокус в «Отсрочке», «Состояние» и «Оплата» — только для чтения среди правимых. Смотрите на длинные значения: поставщик, объект, суммы.', invoiceForm())}
    ${sec('Окно с полями и ошибкой — 1366×768', 'Ошибка — цвет error у обводки, подписи и текста под полем плюс знак перед замыкающим (календарь). Справа — многострочное поле с ошибкой пустого значения.', dialogs())}
    ${sec('Строка отбора — 1366×768', '«Журнал действий» — один из пяти настоящих отборов на Select (ещё соответствия поставщика, уровень данных, сверки): отбор по действию с открытым списком (вид списка прежний — его меняет 13), в подвале — «Строк на странице».', journal())}
    ${sec('Поповер условия отбора — 1366×768', 'Ряд отбора таблицы уже на чипах. Внутри поповера условия (ConditionEditor) — три плотных поля: колонка, оператор, значение (сейчас Select sm 28 и самодельное поле).', condition())}
    ${sec('Строки настроек в окне — 1366×768', 'Третья категория мест — и самая частая: около 21 из 32 Select sm стоят в строках сопоставления и настроек окон и панелей (DataSetsTab, PasteMappingModal, FieldBuilder…). Строка 48, поле 40.', mapping())}
    ${sec('Клетка матрицы разноски — 1366×768', 'Матрица — EditGrid: шапка объекта (объект, раздел, процент — это ввод, а не отбор) и NumberInput 40 с единицей суффиксом. В клетках сетки поле без рамки во всех трёх вариантах — это уже решено в change 14. Фокус — в щите, ошибка — гофра разнесена больше строки. Шапка вырастает до ~140 px.', matrix())}
    ${sec('Флажки в таблице — 1366×768', 'Ведомость материалов комплекта: «выбрать все» частичным, строки выбраны, наведение на автомате и фокус клавиатурой на гофре. Флажок 18 с целью 40 — строка 40 не растёт.', materials())}
    ${sec('Группа радиокнопок — 1366×768', '«Сделать документы из набора» (MaterializationDialog) и «Резервные копии» (BackupSection): у группы видимое имя (сегодня его нет), стрелка выбирает, Tab входит один раз. Группа в строку и столбиком. Список колонки открыт — стрелка поля повернута.', radios())}
    ${sec('Переключатели свойств типа — 1366×768', '«Роль/прокси» и «Абстрактный» (сейчас Switch sm 36×20 в начале строки) — в начале и в конце строки; наследуемые поля — строки 48 вместо 28–32. У «Технического заказчика» — ручка в момент нажатия (28).', typeProps())}
    ${sec('Телефон — 375 px', 'Поля в один столбец, выбор в отборе, окно на весь экран с ошибкой, переключателем и флажком.', pForm() + pJournal() + pDialog())}`;

  const root = document.getElementById('root');
  function paint() {
    root.innerHTML = html();
    root.querySelectorAll('.ctl [data-t]').forEach(b => b.addEventListener('click', () => { ST.theme = b.dataset.t; paint(); }));
    root.querySelectorAll('.ctl [data-ro]').forEach(b => b.addEventListener('click', () => { ST.ro = b.dataset.ro; paint(); }));
    root.querySelector('.ctl [data-ic]').addEventListener('click', () => { ST.icon = ST.icon ? 0 : 1; paint(); });
  }
  paint();
})();
