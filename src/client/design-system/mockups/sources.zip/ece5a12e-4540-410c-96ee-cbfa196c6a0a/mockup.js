/* Поле времени TimeField и блок расписания резервной копии (#1468). Поле — слой формы, как DateField:
   outlined h-14, подпись в вырезе рамки, строка пояснения под полем. Варианты различаются одним — есть
   ли выбор, кроме набора с клавиатуры (разбор Дизайнера §72). Пояс компании — Москва (UTC+03:00). */
(function () {
  var h = React.createElement, F = React.Fragment;
  var ZONE = 'По поясу компании: Москва (UTC+03:00)';

  function svg(size, kids) {
    return h('svg', { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' }, kids);
  }
  function Clock(p) { return svg(p.size || 18, [h('circle', { key: 1, cx: 12, cy: 12, r: 9 }), h('polyline', { key: 2, points: '12 7 12 12 15 14' })]); }
  function Check() { return svg(14, h('polyline', { points: '5 12 10 17 19 7' })); }
  function Back() { return svg(20, h('polyline', { points: '15 6 9 12 15 18' })); }

  /* ── сегменты ЧЧ:ММ ── */
  function Segs(p) {
    var ph = p.en ? ['HH', 'MM'] : ['ЧЧ', 'ММ'];
    var v = [p.hh || '', p.mm || ''];
    return h('span', { className: 'seg' + (p.err ? ' err' : '') }, [0, 1].map(function (i) {
      return h(F, { key: i }, i ? h('span', { className: 'sep' }, ':') : null,
        h('span', { className: (v[i] ? '' : 'ph') + (p.sel === i ? ' sel' : '') }, v[i] || ph[i]));
    }));
  }

  /* ── поле слоя формы ── */
  function Field(p) {
    var cls = 'of' + (p.foc ? ' foc' : '') + (p.error ? ' err' : '') + (p.dis ? ' dis' : '');
    return h('div', { className: 'of-wrap', style: { width: p.w } },
      h('div', { className: cls },
        h('span', { className: 'lab' }, p.label, p.req ? h('span', { className: 'req' }, ' *') : null),
        h('span', { className: 'fill' }, p.children),
        p.unit ? h('span', { className: 'unit' }, p.unit) : null,
        p.tail ? h('span', { className: 'ib' + (p.open ? ' on' : '') }, h(Clock, null)) : null),
      p.error ? h('p', { className: 'hint err' }, p.error) : p.hint ? h('p', { className: 'hint' }, p.hint) : null);
  }
  function Time(p) {
    return h(Field, { label: 'Время копии', req: true, w: p.w || (p.tail ? 152 : 128), foc: p.foc, error: p.error, dis: p.dis, tail: p.tail, open: p.open, hint: p.hint === undefined ? ZONE : p.hint },
      h(Segs, { hh: p.hh, mm: p.mm, sel: p.sel, err: !!p.error, en: p.en }));
  }
  function Keep(p) {
    return h(Field, { label: 'Хранить плановых', w: p.w || 168, unit: 'копий', dis: p.dis }, h('span', { style: { fontVariantNumeric: 'tabular-nums' } }, '7'));
  }
  function Ck(p) {
    return h('div', { className: 'ck' }, h('span', { className: 'bx' + (p.off ? ' off' : '') }, p.off ? null : h(Check)),
      h('span', null, 'Снимать копию автоматически', h('small', null, 'Раз в сутки. Пропущенный запуск выполняется при следующем старте; за неделю простоя — одна копия, а не семь.')));
  }

  /* Блок расписания целиком: флажок, время, «хранить», сохранить, ближайшая копия пунктиром. */
  function Block(p) {
    p = p || {};
    return h(F, null,
      h('p', { className: 'h3' }, 'Расписание'),
      h(Ck, { off: p.off }),
      h('div', { className: 'row', style: { flexDirection: p.col ? 'column' : 'row', alignItems: p.col ? 'stretch' : 'flex-start' } },
        p.time || h(Time, { hh: '04', mm: '00', dis: p.off, tail: p.tail, w: p.col ? '100%' : undefined }),
        h(Keep, { dis: p.off, w: p.col ? '100%' : undefined }),
        h('span', { className: 'btn' + (p.dirty ? '' : ' off') }, 'Сохранить')),
      p.off ? null : h('p', { className: 'next' }, 'Ближайшая копия: ', h('b', null, 'сегодня, 04:00'), ' по Москве — нужно поле nextRunAt от сервера'));
  }

  /* ── листы ── */
  function Cap(p) { return h('p', { className: 'cap' }, h('i', null, p.k), p.children); }
  function Opt(p) {
    return h('div', { className: 'dv-opt', id: p.id, style: { '--w': p.w + 'px' } },
      h('div', { className: 'dv-olabel' }, h('a', { className: 'dv-oid', href: '#' + p.id }, p.id), p.label),
      p.children, p.note ? h('p', { className: 'dv-note' }, p.note) : null);
  }
  function Frame(p) { return h('div', { className: 'frame' + (p.dark ? ' dk' : ''), style: { width: p.w } }, p.children); }
  function Tag(k, t) { return h('span', { className: 'tag ' + k }, t); }

  /* ── 0. Общее ── */
  function Common() {
    function S(k, el) { return h(F, { key: k }, h('span', { className: 'k' }, k), el); }
    return h('section', { className: 'dv-turn', id: 't0' },
      h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t0' }, '0'), h('span', { className: 'dv-tname' }, 'Общее для всех вариантов — следует из правил')),
      h('p', { className: 'dv-tsub' }, h('b', null, 'Поле — слой формы, как DateField:'), ' outlined h-14, подпись «Время копии» в вырезе, ', h('b', null, 'пояс — строкой пояснения'), ' (подпись от пояса не зависит: по ней поле находят скринридер и e2e). 24 часа при любом языке, сегмента AM/PM нет. Крестика нет — время обязательно. Набор: «4» → сразу 04 и к минутам; «:», «.» и «,» — переход; вставка «4:44 PM» → 16:44.'),
      h('div', { className: 'dv-opts' },
        h(Opt, { id: '0a', w: 420, label: 'Состояния поля', note: h(F, null, 'Ошибка «не дописано» — после ухода из поля, «такого времени нет» — сразу. Выключенное расписание — ', h('b', null, 'disabled, а не readOnly'), ': значение не действует, а не «кладёт не человек». Строка пояса не гаснет.') },
          h(Frame, { w: 420 }, h('div', { className: 'grid-states' },
            S('покой', h(Time, { hh: '04', mm: '00' })),
            S('фокус в часах', h(Time, { hh: '04', mm: '00', foc: true, sel: 0 })),
            S('пусто', h(Time, {})),
            S('не дописано', h(Time, { hh: '04', error: 'Время не дописано' })),
            S('25:00', h(Time, { hh: '25', mm: '00', error: 'Такого времени нет' })),
            S('расписание выкл.', h(Time, { hh: '04', mm: '00', dis: true })),
            S('язык en-US', h(Time, { hh: '16', mm: '44', en: true, hint: 'By company time zone: Moscow (UTC+03:00)' }))))),
        h(Opt, { id: '0b', w: 420, label: 'Строка пояса — три случая', note: h(F, null, 'Слова те же, что у пункта в выборе пояса («Москва (UTC+03:00)»). Не выбран — ', h('b', null, 'без тона предупреждения'), ': предупреждает сам блок пояса выше. Смещение — на сейчас.') },
          h(Frame, { w: 420 },
            h(Cap, { k: 'выбран' }), h(Time, { hh: '04', mm: '00', w: '100%' }),
            h(Cap, { k: 'не выбран' }), h(Time, { hh: '04', mm: '00', w: '100%', hint: 'Пояс компании не выбран — время по поясу сервера: Etc/UTC (UTC+00:00)' }),
            h(Cap, { k: 'неизвестен машине' }), h(Time, { hh: '04', mm: '00', w: '100%', hint: 'Пояс «Asia/Qostanay» этой машине неизвестен — время по поясу сервера: Etc/UTC (UTC+00:00)' }))),
        h(Opt, { id: '0c', w: 420, label: 'Вопросы владельцу', note: null },
          h(Frame, { w: 420 },
            h('p', { className: 'muted', style: { color: 'var(--f-fg2)' } },
              '1. Подпись «Время копии» и пояс в пояснении (совет Дизайнера) — или «Время копии, по Москве»?', h('br'),
              '2. Путь к поясу: только текст «меняется в разделе «Компания»» (совет) — или кнопка «Сменить пояс»?', h('br'),
              '3. Строка «Ближайшая копия: сегодня, 04:00 по Москве» — новое поле nextRunAt от сервера. Нужна?', h('br'),
              '4. Установки, где время задано по часам сервера: назвать сдвиг в выпуске и ADMIN_GUIDE (совет) — или пересчитать сохранённое время при обновлении?', h('br'),
              '5. Только для Б и В: шаг списка 30 или 15 минут; шаг сетки минут 5.')))));
  }

  /* ── выбор у вариантов ── */
  function List() {
    var items = ['02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00'];
    return h('div', { className: 'pop lst' }, items.map(function (t) {
      return h('span', { key: t, className: t === '04:00' ? 'sel' : t === '04:30' ? 'foc' : '' }, t);
    }));
  }
  function Grids() {
    var hours = [], mins = [];
    for (var i = 0; i < 24; i++) hours.push(String(i).padStart(2, '0'));
    for (var j = 0; j < 60; j += 5) mins.push(String(j).padStart(2, '0'));
    return h('div', { className: 'pop tg' },
      h('h4', null, 'Часы'),
      h('div', { className: 'g', style: { gridTemplateColumns: 'repeat(6,1fr)' } }, hours.map(function (x) { return h('span', { key: x, className: x === '04' ? 'sel' : '' }, x); })),
      h('h4', null, 'Минуты'),
      h('div', { className: 'g', style: { gridTemplateColumns: 'repeat(4,1fr)' } }, mins.map(function (x) { return h('span', { key: x, className: x === '00' ? 'ring' : '' }, x); })),
      h('div', { className: 'pf' }, h('span', { className: 'tb' }, 'Готово')));
  }

  var VARIANTS = [
    { id: 'А', name: 'Только сегменты', tag: Tag('ok', 'Дизайнер советует'),
      sub: h(F, null, h('b', null, 'Четыре цифры с клавиатуры — и всё.'), ' Хвоста у поля нет: ни крестика (время обязательно), ни значка часов — значок выглядел бы кнопкой без действия. Это и есть «input mode» выбора времени у MD3. Хвост свободен: Б или В можно добавить позже, раскладка не изменится.'),
      pc: [h(F, null, h('b', null, '+'), ' самый быстрый ввод; на телефоне цифровая клавиатура; строится дешевле всех — движок + сегменты, без слоя'), h(F, null, h('b', null, '−'), ' нет пути «только мышью»: щелчок в сегмент и ↑/↓ — путь, но не быстрый')],
      pick: function () { return h(Frame, { w: 300 },
        h(Cap, { k: 'набор «444»' }), h(Time, { hh: '04', mm: '4', foc: true, sel: 1 }),
        h(Cap, { k: 'уход' }), h(Time, { hh: '04', mm: '04' }),
        h(Cap, { k: 'вставка «4:44 PM»' }), h(Time, { hh: '16', mm: '44', foc: true })); },
      pickNote: h(F, null, '«4» в часах сразу становится 04 и переводит к минутам: часа 40 не бывает. Одиночная цифра минут при уходе дописывается нулём. Вставку из английского письма ', h('b', null, 'переводим, а не отвергаем'), '.'),
      tail: false },
    { id: 'Б', name: 'Сегменты + список шагом 30 минут', tag: Tag('alt', 'средняя цена'),
      sub: h(F, null, 'Тот же набор и ', h('b', null, 'кнопка «Выбрать время»'), ' у правого края — на месте календаря у даты. Список как у Select: 48 пунктов 00:00 … 23:30, открывается прокрученным к выбранному; ↑/↓ по пунктам, Enter выбирает, набор цифр прыгает к часу. Время не из сетки (04:44) показано в поле, в списке — фокус на ближайшем.'),
      pc: [h(F, null, h('b', null, '+'), ' путь мышью и касанием в одно действие; знакомо по Outlook и Google'), h(F, null, h('b', null, '−'), ' 48 строк ради одного поля; 04:44 выглядит исключением; на телефоне лишний слой («Назад», #1522 открыт)')],
      pick: function () { return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } }, h(Time, { hh: '04', mm: '00', tail: true, open: true, foc: true, hint: null }), h(List)); },
      pickNote: h(F, null, 'Выбранное 04:00 — подложкой, фокус клавиатуры — на 04:30. ', h('b', null, 'Высота до ~300 px'), ' с прокруткой; портал в body, как у календаря (#1521).'),
      tail: true },
    { id: 'В', name: 'Сегменты + сетки часов и минут', tag: Tag('warn', 'дороже всех'),
      sub: h(F, null, 'Тот же хвост со значком часов. Всплывающее w-72, ', h('b', null, 'две сетки в стиле сетки месяцев календаря'), ': часы 6 × 4, минуты 4 × 3 шагом 5. Щелчок по часу ставит час и уводит фокус в минуты, щелчок по минуте ставит время и закрывает. 44 минуты — только в сегментах.'),
      pc: [h(F, null, h('b', null, '+'), ' касанием — два касания без прокрутки; вид из одного семейства с календарём'), h(F, null, h('b', null, '−'), ' две 2D-сетки с клавиатурой, фокус между ними, слой; окупится, только если время появится в типах документов')],
      pick: function () { return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } }, h(Time, { hh: '04', mm: '00', tail: true, open: true, foc: true, hint: null }), h(Grids)); },
      pickNote: h(F, null, 'Час 04 выбран, ', h('b', null, 'фокус — в минутах'), ' (кольцо на 00). Циферблат MD3 отвергнут до листов: у 24 часов два кольца, и с клавиатуры он хуже сегментов.'),
      tail: true },
  ];

  function Phone(v) {
    var open = v.id !== 'А';
    return h('div', { className: 'phone' },
      h('div', { className: 'ph-bar' }, h('span', { className: 'ib' }, h(Back)), h('span', { className: 'ph-t' }, 'Резервное копирование')),
      h('div', { className: 'ph-b' },
        h(Block, { col: true, tail: v.tail, dirty: true,
          time: h(Time, { hh: '04', mm: open ? '00' : '', foc: true, sel: open ? undefined : 1, tail: v.tail, open: open, w: '100%' }) })),
      open ? h('div', { style: { position: 'absolute', left: 16, right: 16, top: 254 } }, v.id === 'Б' ? h(List) : h(Grids)) : null,
      open ? null : h('div', { className: 'kbd' }, ['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(function (k) { return h('span', { key: k }, k); }),
        h('span', { className: 'fn' }, ''), h('span', null, '0'), h('span', { className: 'fn' }, '⌫')));
  }

  function Sheet(v) {
    return h(F, null,
      h(Opt, { id: v.id + '1', w: 560, label: 'Блок расписания (настройки, светлая тема)', note: h(F, null, '«Хранить плановых» — тем же слоем формы, единицей «копий»: иначе outlined h-14 стоит рядом с голым полем h-8. Флажок — Checkbox с описанием. Пунктир — строка, которой пока нет (вопрос 3).') },
        h(Frame, { w: 560 }, h(Block, { tail: v.tail, dirty: true }))),
      h(Opt, { id: v.id + '2', w: 300, label: v.id === 'А' ? 'Набор с клавиатуры' : 'Выбор открыт', note: v.pickNote }, v.pick()),
      h(Opt, { id: v.id + '3', w: 390, label: 'Телефон 390 px', note: v.id === 'А' ? h(F, null, 'Поля столбиком, ', h('b', null, 'цифровая клавиатура'), ': «:» на ней нет, поэтому автопереход к минутам обязателен.') : h(F, null, 'Выбор под полем во всю ширину; с #1522 — нижний лист.') }, h(Phone, v)),
      h(Opt, { id: v.id + '4', w: 560, label: 'Тёмная тема', note: 'Те же токены, что у приложения в тёмной теме.' },
        h(Frame, { w: 560, dark: true }, h(Block, { tail: v.tail, dirty: true }), v.id === 'А' ? null : v.pick())));
  }

  function App() {
    return h(F, null, h(Common),
      VARIANTS.map(function (v, i) {
        return h('section', { key: v.id, className: 'dv-turn', id: 't' + (i + 1) },
          h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t' + (i + 1) }, v.id), h('span', { className: 'dv-tname' }, 'TimeField: ' + v.name), v.tag),
          h('p', { className: 'dv-tsub' }, v.sub),
          h('div', { className: 'pc' }, v.pc.map(function (x, j) { return h('span', { key: j }, x); })),
          h('div', { className: 'dv-opts' }, h(Sheet, v)));
      }));
  }

  ReactDOM.createRoot(document.getElementById('root')).render(h(App));
})();
