/* @ds-bundle: {"namespace":"BhsCrgUi","components":[{"name":"ArchivedMark","sourcePath":"components/shared/ArchivedMark/ArchivedMark.jsx"},{"name":"ArchivedRows","sourcePath":"components/shared/ArchivedRows/ArchivedRows.jsx"},{"name":"Avatar","sourcePath":"components/shared/Avatar/Avatar.jsx"},{"name":"Button","sourcePath":"components/shared/Button/Button.jsx"},{"name":"Calendar","sourcePath":"components/shared/Calendar/Calendar.jsx"},{"name":"Checkbox","sourcePath":"components/shared/Checkbox/Checkbox.jsx"},{"name":"Chip","sourcePath":"components/shared/Chip/Chip.jsx"},{"name":"ConfirmDialog","sourcePath":"components/shared/ConfirmDialog/ConfirmDialog.jsx"},{"name":"DataGrid","sourcePath":"components/shared/DataGrid/DataGrid.jsx"},{"name":"DateField","sourcePath":"components/shared/DateField/DateField.jsx"},{"name":"EditGrid","sourcePath":"components/shared/EditGrid/EditGrid.jsx"},{"name":"EmptyState","sourcePath":"components/shared/EmptyState/EmptyState.jsx"},{"name":"FieldBuilder","sourcePath":"components/settings/FieldBuilder/FieldBuilder.jsx"},{"name":"GroupedFieldsEditor","sourcePath":"components/settings/GroupedFieldsEditor/GroupedFieldsEditor.jsx"},{"name":"IconButton","sourcePath":"components/shared/IconButton/IconButton.jsx"},{"name":"LeaveGuardDialog","sourcePath":"components/shared/LeaveGuardDialog/LeaveGuardDialog.jsx"},{"name":"ListDetailShell","sourcePath":"components/shared/ListDetailShell/ListDetailShell.jsx"},{"name":"Markdown","sourcePath":"components/shared/Markdown/Markdown.jsx"},{"name":"Modal","sourcePath":"components/shared/Modal/Modal.jsx"},{"name":"MoveButtons","sourcePath":"components/shared/MoveButtons/MoveButtons.jsx"},{"name":"NoAccessPage","sourcePath":"components/shared/NoAccessPage/NoAccessPage.jsx"},{"name":"NumberInput","sourcePath":"components/shared/NumberInput/NumberInput.jsx"},{"name":"OutlinedField","sourcePath":"components/shared/OutlinedField/OutlinedField.jsx"},{"name":"PageHeader","sourcePath":"components/shared/PageHeader/PageHeader.jsx"},{"name":"RereadFailedNotice","sourcePath":"components/shared/RereadFailedNotice/RereadFailedNotice.jsx"},{"name":"RowActionsMenu","sourcePath":"components/shared/RowActionsMenu/RowActionsMenu.jsx"},{"name":"ScopeIcon","sourcePath":"components/shared/ScopeIcon/ScopeIcon.jsx"},{"name":"SearchInput","sourcePath":"components/shared/SearchInput/SearchInput.jsx"},{"name":"Select","sourcePath":"components/shared/Select/Select.jsx"},{"name":"ShortcutsHelp","sourcePath":"components/shared/ShortcutsHelp/ShortcutsHelp.jsx"},{"name":"SourceOriginIcon","sourcePath":"components/shared/SourceOriginIcon/SourceOriginIcon.jsx"},{"name":"StatusBadge","sourcePath":"components/shared/StatusBadge/StatusBadge.jsx"},{"name":"Switch","sourcePath":"components/shared/Switch/Switch.jsx"},{"name":"TabPanel","sourcePath":"components/shared/TabPanel/TabPanel.jsx"},{"name":"Tabs","sourcePath":"components/shared/Tabs/Tabs.jsx"},{"name":"TextAreaField","sourcePath":"components/shared/TextAreaField/TextAreaField.jsx"},{"name":"TextField","sourcePath":"components/shared/TextField/TextField.jsx"},{"name":"ToastProvider","sourcePath":"components/shared/ToastProvider/ToastProvider.jsx"},{"name":"Tooltip","sourcePath":"components/shared/Tooltip/Tooltip.jsx"},{"name":"TypePicker","sourcePath":"components/shared/TypePicker/TypePicker.jsx"},{"name":"TypePickerField","sourcePath":"components/shared/TypePickerField/TypePickerField.jsx"},{"name":"ValueIssueBadge","sourcePath":"components/shared/ValueIssueBadge/ValueIssueBadge.jsx"},{"name":"ValueIssueHint","sourcePath":"components/shared/ValueIssueHint/ValueIssueHint.jsx"},{"name":"WindowStep","sourcePath":"components/shared/WindowStep/WindowStep.jsx"}],"sourceHashes":{"components/shared/ArchivedMark/ArchivedMark.jsx":"b6e3c7fb6aff","components/shared/ArchivedMark/ArchivedMark.d.ts":"38df6c1daa81","components/shared/ArchivedMark/ArchivedMark.prompt.md":"e35935d1b65b","components/shared/ArchivedRows/ArchivedRows.jsx":"c893f72ac948","components/shared/ArchivedRows/ArchivedRows.d.ts":"2d69ef681b5f","components/shared/ArchivedRows/ArchivedRows.prompt.md":"c798d316eb29","components/shared/Avatar/Avatar.jsx":"4c3650e58e40","components/shared/Avatar/Avatar.d.ts":"aab92ee12c61","components/shared/Avatar/Avatar.prompt.md":"8864fc644df4","components/shared/Button/Button.jsx":"a2935753a758","components/shared/Button/Button.d.ts":"9b8b4155e9a4","components/shared/Button/Button.prompt.md":"a98ee2ca876e","components/shared/Calendar/Calendar.jsx":"accfd17963cf","components/shared/Calendar/Calendar.d.ts":"3d177b99bfc6","components/shared/Calendar/Calendar.prompt.md":"a7c4cb7d9045","components/shared/Checkbox/Checkbox.jsx":"f0e96d866b9e","components/shared/Checkbox/Checkbox.d.ts":"9fcb01607c3e","components/shared/Checkbox/Checkbox.prompt.md":"d8245cde9cb2","components/shared/Chip/Chip.jsx":"b743bd2b41f4","components/shared/Chip/Chip.d.ts":"1cbb7967e47f","components/shared/Chip/Chip.prompt.md":"c8bdc6d54ef3","components/shared/ConfirmDialog/ConfirmDialog.jsx":"ec0b0859f63e","components/shared/ConfirmDialog/ConfirmDialog.d.ts":"2f4e5c7ba4f3","components/shared/ConfirmDialog/ConfirmDialog.prompt.md":"6c5964f9b076","components/shared/DataGrid/DataGrid.jsx":"34f8490b86a3","components/shared/DataGrid/DataGrid.d.ts":"be90e3e9ebf8","components/shared/DataGrid/DataGrid.prompt.md":"c6829e6a9ff7","components/shared/DateField/DateField.jsx":"33981cd0646d","components/shared/DateField/DateField.d.ts":"1c9f9e21fe28","components/shared/DateField/DateField.prompt.md":"201a3c04a7fa","components/shared/EditGrid/EditGrid.jsx":"39218f2ff829","components/shared/EditGrid/EditGrid.d.ts":"647581fb3a77","components/shared/EditGrid/EditGrid.prompt.md":"49a8b8baf9da","components/shared/EmptyState/EmptyState.jsx":"a166f0284ea5","components/shared/EmptyState/EmptyState.d.ts":"45d220a67f50","components/shared/EmptyState/EmptyState.prompt.md":"b7623fa3332b","components/settings/FieldBuilder/FieldBuilder.jsx":"b24cd35a63e1","components/settings/FieldBuilder/FieldBuilder.d.ts":"dd12e6547b72","components/settings/FieldBuilder/FieldBuilder.prompt.md":"d541cde07336","components/settings/GroupedFieldsEditor/GroupedFieldsEditor.jsx":"942a6af35b18","components/settings/GroupedFieldsEditor/GroupedFieldsEditor.d.ts":"24e0baf16f8e","components/settings/GroupedFieldsEditor/GroupedFieldsEditor.prompt.md":"e5893db309c0","components/shared/IconButton/IconButton.jsx":"1519210b64a7","components/shared/IconButton/IconButton.d.ts":"3db3d9acdb13","components/shared/IconButton/IconButton.prompt.md":"7e35a5de0ad1","components/shared/LeaveGuardDialog/LeaveGuardDialog.jsx":"28c3fc4aa879","components/shared/LeaveGuardDialog/LeaveGuardDialog.d.ts":"255da58ac5a5","components/shared/LeaveGuardDialog/LeaveGuardDialog.prompt.md":"10bd4578caa4","components/shared/ListDetailShell/ListDetailShell.jsx":"a1edf709595f","components/shared/ListDetailShell/ListDetailShell.d.ts":"51328c25044d","components/shared/ListDetailShell/ListDetailShell.prompt.md":"a77ba3ebef1b","components/shared/Markdown/Markdown.jsx":"dab5e7b3a211","components/shared/Markdown/Markdown.d.ts":"994fb3d8b6b9","components/shared/Markdown/Markdown.prompt.md":"4c7a4af59754","components/shared/Modal/Modal.jsx":"7798a6186c1d","components/shared/Modal/Modal.d.ts":"37be11ed2491","components/shared/Modal/Modal.prompt.md":"899170603f5f","components/shared/MoveButtons/MoveButtons.jsx":"761197c5a54d","components/shared/MoveButtons/MoveButtons.d.ts":"7e797ed77b67","components/shared/MoveButtons/MoveButtons.prompt.md":"faee2e3e5e58","components/shared/NoAccessPage/NoAccessPage.jsx":"4b30f8881765","components/shared/NoAccessPage/NoAccessPage.d.ts":"612c3a030283","components/shared/NoAccessPage/NoAccessPage.prompt.md":"4f58f08ee3be","components/shared/NumberInput/NumberInput.jsx":"d138d09d1e78","components/shared/NumberInput/NumberInput.d.ts":"8ad33e87f8d0","components/shared/NumberInput/NumberInput.prompt.md":"93b4eab28207","components/shared/OutlinedField/OutlinedField.jsx":"0185af2cbb08","components/shared/OutlinedField/OutlinedField.d.ts":"9027d4851a84","components/shared/OutlinedField/OutlinedField.prompt.md":"98880f2cd37e","components/shared/PageHeader/PageHeader.jsx":"b76a3f45236f","components/shared/PageHeader/PageHeader.d.ts":"f2d56a5262ed","components/shared/PageHeader/PageHeader.prompt.md":"89e2354fe70d","components/shared/RereadFailedNotice/RereadFailedNotice.jsx":"3aeec7b6e916","components/shared/RereadFailedNotice/RereadFailedNotice.d.ts":"a17b359b9003","components/shared/RereadFailedNotice/RereadFailedNotice.prompt.md":"694f6fccdc1e","components/shared/RowActionsMenu/RowActionsMenu.jsx":"250a329caf32","components/shared/RowActionsMenu/RowActionsMenu.d.ts":"62504d566ba6","components/shared/RowActionsMenu/RowActionsMenu.prompt.md":"2d75264ad2db","components/shared/ScopeIcon/ScopeIcon.jsx":"84fa81da8a94","components/shared/ScopeIcon/ScopeIcon.d.ts":"0a24f788c388","components/shared/ScopeIcon/ScopeIcon.prompt.md":"2918fc237c7e","components/shared/SearchInput/SearchInput.jsx":"f1ab17e2e11c","components/shared/SearchInput/SearchInput.d.ts":"3d431c540071","components/shared/SearchInput/SearchInput.prompt.md":"320bbe5a0edb","components/shared/Select/Select.jsx":"ff19f638f200","components/shared/Select/Select.d.ts":"b299cc554548","components/shared/Select/Select.prompt.md":"76ec55dd8f43","components/shared/ShortcutsHelp/ShortcutsHelp.jsx":"e683deec09b6","components/shared/ShortcutsHelp/ShortcutsHelp.d.ts":"32ac2d9cf0a8","components/shared/ShortcutsHelp/ShortcutsHelp.prompt.md":"a37b07d600a3","components/shared/SourceOriginIcon/SourceOriginIcon.jsx":"ab65e867d6f9","components/shared/SourceOriginIcon/SourceOriginIcon.d.ts":"ab482da6a702","components/shared/SourceOriginIcon/SourceOriginIcon.prompt.md":"38a8e9f775a2","components/shared/StatusBadge/StatusBadge.jsx":"e66e8d1ee954","components/shared/StatusBadge/StatusBadge.d.ts":"a0da122e28e1","components/shared/StatusBadge/StatusBadge.prompt.md":"9966c9e2f39b","components/shared/Switch/Switch.jsx":"a23b0c93bef7","components/shared/Switch/Switch.d.ts":"7d2025faead2","components/shared/Switch/Switch.prompt.md":"9f4e14b6ffbb","components/shared/TabPanel/TabPanel.jsx":"4378c29d7152","components/shared/TabPanel/TabPanel.d.ts":"ec5fb6bf51f3","components/shared/TabPanel/TabPanel.prompt.md":"f259f43979b6","components/shared/Tabs/Tabs.jsx":"bba0e1e3dc94","components/shared/Tabs/Tabs.d.ts":"0d1be7dc7482","components/shared/Tabs/Tabs.prompt.md":"146ae288a22b","components/shared/TextAreaField/TextAreaField.jsx":"6c602b6cbcdd","components/shared/TextAreaField/TextAreaField.d.ts":"7b7be7943087","components/shared/TextAreaField/TextAreaField.prompt.md":"91cc904b98c1","components/shared/TextField/TextField.jsx":"01a022392811","components/shared/TextField/TextField.d.ts":"63275bc3832c","components/shared/TextField/TextField.prompt.md":"da83464126e2","components/shared/ToastProvider/ToastProvider.jsx":"580c8330faad","components/shared/ToastProvider/ToastProvider.d.ts":"678189d64ae1","components/shared/ToastProvider/ToastProvider.prompt.md":"459bace5f0b4","components/shared/Tooltip/Tooltip.jsx":"18b4846bde26","components/shared/Tooltip/Tooltip.d.ts":"b2e16f0b38d9","components/shared/Tooltip/Tooltip.prompt.md":"c2e1dcfbf352","components/shared/TypePicker/TypePicker.jsx":"d268da9702c5","components/shared/TypePicker/TypePicker.d.ts":"2bf63a42acc8","components/shared/TypePicker/TypePicker.prompt.md":"189c4936783c","components/shared/TypePickerField/TypePickerField.jsx":"11df86c94348","components/shared/TypePickerField/TypePickerField.d.ts":"3bc9a54c54d5","components/shared/TypePickerField/TypePickerField.prompt.md":"b487d9a01aa7","components/shared/ValueIssueBadge/ValueIssueBadge.jsx":"df7403eb4731","components/shared/ValueIssueBadge/ValueIssueBadge.d.ts":"515f5ca41662","components/shared/ValueIssueBadge/ValueIssueBadge.prompt.md":"c4889185d5ad","components/shared/ValueIssueHint/ValueIssueHint.jsx":"7bdf4aaf6890","components/shared/ValueIssueHint/ValueIssueHint.d.ts":"190a5ec53980","components/shared/ValueIssueHint/ValueIssueHint.prompt.md":"aec6b4cba104","components/shared/WindowStep/WindowStep.jsx":"f79208cb83eb","components/shared/WindowStep/WindowStep.d.ts":"d5cec5cbbba6","components/shared/WindowStep/WindowStep.prompt.md":"0753b02bb9e8"},"inlinedExternals":["@floating-ui/core","@floating-ui/dom","@floating-ui/react-dom","@floating-ui/utils","@radix-ui/number","@radix-ui/primitive","@radix-ui/react-arrow","@radix-ui/react-collection","@radix-ui/react-compose-refs","@radix-ui/react-context","@radix-ui/react-dialog","@radix-ui/react-direction","@radix-ui/react-dismissable-layer","@radix-ui/react-dropdown-menu","@radix-ui/react-focus-guards","@radix-ui/react-focus-scope","@radix-ui/react-id","@radix-ui/react-menu","@radix-ui/react-popover","@radix-ui/react-popper","@radix-ui/react-portal","@radix-ui/react-presence","@radix-ui/react-primitive","@radix-ui/react-roving-focus","@radix-ui/react-select","@radix-ui/react-slot","@radix-ui/react-toast","@radix-ui/react-use-callback-ref","@radix-ui/react-use-controllable-state","@radix-ui/react-use-effect-event","@radix-ui/react-use-escape-keydown","@radix-ui/react-use-layout-effect","@radix-ui/react-use-previous","@radix-ui/react-use-size","@radix-ui/react-visually-hidden","@tanstack/query-core","@tanstack/react-query","aria-hidden","axios","cookie-es","detect-node-es","get-nonce","lucide-react","react-remove-scroll","react-remove-scroll-bar","react-router","react-style-singleton","tslib","use-callback-ref","use-sidecar"],"builtBy":"cc-design-sync"} */
var BhsCrgUi = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __typeError = (msg) => {
    throw TypeError(msg);
  };
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all3) => {
    for (var name in all3)
      __defProp(target, name, { get: all3[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
  var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
  var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
  var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
  var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
  var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

  // <define:import.meta.env>
  var define_import_meta_env_default;
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
      define_import_meta_env_default = { MODE: "development", DEV: true, PROD: false, SSR: false, BASE_URL: "/" };
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx20(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs3(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx20;
      module.exports.jsxs = jsxs3;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs3 : jsx20)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // shim:react-dom-shim
  var require_react_dom_shim = __commonJS({
    "shim:react-dom-shim"(exports, module) {
      init_define_import_meta_env();
      var D = window.ReactDOM;
      var n = function() {
      };
      module.exports = Object.assign({ preload: n, preinit: n, preconnect: n, prefetchDNS: n, preloadModule: n, preinitModule: n }, D);
    }
  });

  // src/client/.ds-entry.tsx
  var ds_entry_exports = {};
  __export(ds_entry_exports, {
    ArchivedMark: () => ArchivedMark,
    ArchivedRows: () => ArchivedRows,
    Avatar: () => Avatar,
    Button: () => Button,
    Calendar: () => Calendar,
    CascadeList: () => CascadeList,
    Checkbox: () => Checkbox,
    Chip: () => Chip,
    ConfirmDialog: () => ConfirmDialog,
    DataGrid: () => DataGrid,
    DataGridValue: () => DataGridValue,
    DateField: () => DateField,
    DateInput: () => DateInput,
    DetailHeader: () => DetailHeader,
    DetailTitle: () => DetailTitle,
    EditGrid: () => EditGrid,
    EmptyState: () => EmptyState,
    FieldBuilder: () => FieldBuilder,
    GroupedFieldsEditor: () => GroupedFieldsEditor,
    IconButton: () => IconButton,
    LeaveGuardDialog: () => LeaveGuardDialog,
    ListDetailShell: () => ListDetailShell,
    Markdown: () => Markdown,
    Modal: () => Modal,
    ModalExit: () => ModalExit,
    MoveButtons: () => MoveButtons,
    NavItem: () => NavItem,
    NavSearchInput: () => NavSearchInput,
    NavSection: () => NavSection,
    NoAccessPage: () => NoAccessPage,
    NumberInput: () => NumberInput,
    OutlinedField: () => OutlinedField,
    PageHeader: () => PageHeader,
    RereadFailedNotice: () => RereadFailedNotice,
    RowActionsMenu: () => RowActionsMenu,
    ScopeIcon: () => ScopeIcon,
    SearchInput: () => SearchInput,
    Select: () => Select2,
    SelectGroup: () => SelectGroup2,
    SelectItem: () => SelectItem2,
    ShortcutsHelp: () => ShortcutsHelp,
    SourceOriginIcon: () => SourceOriginIcon,
    StatusBadge: () => StatusBadge,
    Switch: () => Switch,
    TabPanel: () => TabPanel,
    Tabs: () => Tabs,
    TextAreaField: () => TextAreaField,
    TextField: () => TextField,
    ToastCtx: () => ToastCtx,
    ToastProvider: () => ToastProvider2,
    Tooltip: () => Tooltip,
    TypePicker: () => TypePicker,
    TypePickerField: () => TypePickerField,
    ValueIssueBadge: () => ValueIssueBadge,
    ValueIssueHint: () => ValueIssueHint,
    WindowStep: () => WindowStep,
    downscaleToDataUri: () => downscaleToDataUri,
    initialsOf: () => initialsOf,
    typeIcon: () => typeIcon,
    useDirtyGuard: () => useDirtyGuard,
    useToast: () => useToast
  });
  init_define_import_meta_env();

  // src/client/src/shared/ui/Button.tsx
  init_define_import_meta_env();
  var import_react6 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/lucide-react/dist/esm/lucide-react.mjs
  init_define_import_meta_env();

  // src/client/node_modules/lucide-react/dist/esm/createLucideIcon.mjs
  init_define_import_meta_env();
  var import_react3 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
  init_define_import_meta_env();
  var mergeClasses = (...classes) => classes.filter((className, index2, array) => {
    return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index2;
  }).join(" ").trim();

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs
  init_define_import_meta_env();
  var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs
  init_define_import_meta_env();

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
  init_define_import_meta_env();
  var toCamelCase = (string) => string.replace(
    /^([A-Z])|[\s-_]+(\w)/g,
    (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
  );

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs
  var toPascalCase = (string) => {
    const camelCase = toCamelCase(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
  };

  // src/client/node_modules/lucide-react/dist/esm/Icon.mjs
  init_define_import_meta_env();
  var import_react2 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/lucide-react/dist/esm/defaultAttributes.mjs
  init_define_import_meta_env();
  var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  };

  // src/client/node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs
  init_define_import_meta_env();
  var hasA11yProp = (props) => {
    for (const prop in props) {
      if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
        return true;
      }
    }
    return false;
  };

  // src/client/node_modules/lucide-react/dist/esm/context.mjs
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim(), 1);
  var LucideContext = (0, import_react.createContext)({});
  var useLucideContext = () => (0, import_react.useContext)(LucideContext);

  // src/client/node_modules/lucide-react/dist/esm/Icon.mjs
  var Icon = (0, import_react2.forwardRef)(
    ({ color, size: size4, strokeWidth, absoluteStrokeWidth, className = "", children, iconNode, ...rest }, ref) => {
      const {
        size: contextSize = 24,
        strokeWidth: contextStrokeWidth = 2,
        absoluteStrokeWidth: contextAbsoluteStrokeWidth = false,
        color: contextColor = "currentColor",
        className: contextClass = ""
      } = useLucideContext() ?? {};
      const calculatedStrokeWidth = absoluteStrokeWidth ?? contextAbsoluteStrokeWidth ? Number(strokeWidth ?? contextStrokeWidth) * 24 / Number(size4 ?? contextSize) : strokeWidth ?? contextStrokeWidth;
      return (0, import_react2.createElement)(
        "svg",
        {
          ref,
          ...defaultAttributes,
          width: size4 ?? contextSize ?? defaultAttributes.width,
          height: size4 ?? contextSize ?? defaultAttributes.height,
          stroke: color ?? contextColor,
          strokeWidth: calculatedStrokeWidth,
          className: mergeClasses("lucide", contextClass, className),
          ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
          ...rest
        },
        [
          ...iconNode.map(([tag, attrs]) => (0, import_react2.createElement)(tag, attrs)),
          ...Array.isArray(children) ? children : [children]
        ]
      );
    }
  );

  // src/client/node_modules/lucide-react/dist/esm/createLucideIcon.mjs
  var createLucideIcon = (iconName, iconNode) => {
    const Component3 = (0, import_react3.forwardRef)(
      ({ className, ...props }, ref) => (0, import_react3.createElement)(Icon, {
        ref,
        iconNode,
        className: mergeClasses(
          `lucide-${toKebabCase(toPascalCase(iconName))}`,
          `lucide-${iconName}`,
          className
        ),
        ...props
      })
    );
    Component3.displayName = toPascalCase(iconName);
    return Component3;
  };

  // src/client/node_modules/lucide-react/dist/esm/icons/archive.mjs
  init_define_import_meta_env();
  var __iconNode = [
    ["rect", { width: "20", height: "5", x: "2", y: "3", rx: "1", key: "1wp1u1" }],
    ["path", { d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8", key: "1s80jp" }],
    ["path", { d: "M10 12h4", key: "a56b0p" }]
  ];
  var Archive = createLucideIcon("archive", __iconNode);

  // src/client/node_modules/lucide-react/dist/esm/icons/arrow-down.mjs
  init_define_import_meta_env();
  var __iconNode2 = [
    ["path", { d: "M12 5v14", key: "s699le" }],
    ["path", { d: "m19 12-7 7-7-7", key: "1idqje" }]
  ];
  var ArrowDown = createLucideIcon("arrow-down", __iconNode2);

  // src/client/node_modules/lucide-react/dist/esm/icons/arrow-left.mjs
  init_define_import_meta_env();
  var __iconNode3 = [
    ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
    ["path", { d: "M19 12H5", key: "x3x0zl" }]
  ];
  var ArrowLeft = createLucideIcon("arrow-left", __iconNode3);

  // src/client/node_modules/lucide-react/dist/esm/icons/arrow-up-right.mjs
  init_define_import_meta_env();
  var __iconNode4 = [
    ["path", { d: "M7 7h10v10", key: "1tivn9" }],
    ["path", { d: "M7 17 17 7", key: "1vkiza" }]
  ];
  var ArrowUpRight = createLucideIcon("arrow-up-right", __iconNode4);

  // src/client/node_modules/lucide-react/dist/esm/icons/arrow-up.mjs
  init_define_import_meta_env();
  var __iconNode5 = [
    ["path", { d: "m5 12 7-7 7 7", key: "hav0vg" }],
    ["path", { d: "M12 19V5", key: "x0mq9r" }]
  ];
  var ArrowUp = createLucideIcon("arrow-up", __iconNode5);

  // src/client/node_modules/lucide-react/dist/esm/icons/ban.mjs
  init_define_import_meta_env();
  var __iconNode6 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M4.929 4.929 19.07 19.071", key: "196cmz" }]
  ];
  var Ban = createLucideIcon("ban", __iconNode6);

  // src/client/node_modules/lucide-react/dist/esm/icons/boxes.mjs
  init_define_import_meta_env();
  var __iconNode7 = [
    [
      "path",
      {
        d: "M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z",
        key: "lc1i9w"
      }
    ],
    ["path", { d: "m7 16.5-4.74-2.85", key: "1o9zyk" }],
    ["path", { d: "m7 16.5 5-3", key: "va8pkn" }],
    ["path", { d: "M7 16.5v5.17", key: "jnp8gn" }],
    [
      "path",
      {
        d: "M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z",
        key: "8zsnat"
      }
    ],
    ["path", { d: "m17 16.5-5-3", key: "8arw3v" }],
    ["path", { d: "m17 16.5 4.74-2.85", key: "8rfmw" }],
    ["path", { d: "M17 16.5v5.17", key: "k6z78m" }],
    [
      "path",
      {
        d: "M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z",
        key: "1xygjf"
      }
    ],
    ["path", { d: "M12 8 7.26 5.15", key: "1vbdud" }],
    ["path", { d: "m12 8 4.74-2.85", key: "3rx089" }],
    ["path", { d: "M12 13.5V8", key: "1io7kd" }]
  ];
  var Boxes = createLucideIcon("boxes", __iconNode7);

  // src/client/node_modules/lucide-react/dist/esm/icons/building-2.mjs
  init_define_import_meta_env();
  var __iconNode8 = [
    ["path", { d: "M10 12h4", key: "a56b0p" }],
    ["path", { d: "M10 8h4", key: "1sr2af" }],
    ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
    [
      "path",
      {
        d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
        key: "secmi2"
      }
    ],
    ["path", { d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16", key: "16ra0t" }]
  ];
  var Building2 = createLucideIcon("building-2", __iconNode8);

  // src/client/node_modules/lucide-react/dist/esm/icons/calendar-days.mjs
  init_define_import_meta_env();
  var __iconNode9 = [
    ["path", { d: "M8 2v4", key: "1cmpym" }],
    ["path", { d: "M16 2v4", key: "4m81vk" }],
    ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
    ["path", { d: "M3 10h18", key: "8toen8" }],
    ["path", { d: "M8 14h.01", key: "6423bh" }],
    ["path", { d: "M12 14h.01", key: "1etili" }],
    ["path", { d: "M16 14h.01", key: "1gbofw" }],
    ["path", { d: "M8 18h.01", key: "lrp35t" }],
    ["path", { d: "M12 18h.01", key: "mhygvu" }],
    ["path", { d: "M16 18h.01", key: "kzsmim" }]
  ];
  var CalendarDays = createLucideIcon("calendar-days", __iconNode9);

  // src/client/node_modules/lucide-react/dist/esm/icons/check.mjs
  init_define_import_meta_env();
  var __iconNode10 = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
  var Check = createLucideIcon("check", __iconNode10);

  // src/client/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs
  init_define_import_meta_env();
  var __iconNode11 = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
  var ChevronDown = createLucideIcon("chevron-down", __iconNode11);

  // src/client/node_modules/lucide-react/dist/esm/icons/chevron-left.mjs
  init_define_import_meta_env();
  var __iconNode12 = [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]];
  var ChevronLeft = createLucideIcon("chevron-left", __iconNode12);

  // src/client/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs
  init_define_import_meta_env();
  var __iconNode13 = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]];
  var ChevronRight = createLucideIcon("chevron-right", __iconNode13);

  // src/client/node_modules/lucide-react/dist/esm/icons/chevron-up.mjs
  init_define_import_meta_env();
  var __iconNode14 = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
  var ChevronUp = createLucideIcon("chevron-up", __iconNode14);

  // src/client/node_modules/lucide-react/dist/esm/icons/circle-check.mjs
  init_define_import_meta_env();
  var __iconNode15 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
  ];
  var CircleCheck = createLucideIcon("circle-check", __iconNode15);

  // src/client/node_modules/lucide-react/dist/esm/icons/cpu.mjs
  init_define_import_meta_env();
  var __iconNode16 = [
    ["path", { d: "M12 20v2", key: "1lh1kg" }],
    ["path", { d: "M12 2v2", key: "tus03m" }],
    ["path", { d: "M17 20v2", key: "1rnc9c" }],
    ["path", { d: "M17 2v2", key: "11trls" }],
    ["path", { d: "M2 12h2", key: "1t8f8n" }],
    ["path", { d: "M2 17h2", key: "7oei6x" }],
    ["path", { d: "M2 7h2", key: "asdhe0" }],
    ["path", { d: "M20 12h2", key: "1q8mjw" }],
    ["path", { d: "M20 17h2", key: "1fpfkl" }],
    ["path", { d: "M20 7h2", key: "1o8tra" }],
    ["path", { d: "M7 20v2", key: "4gnj0m" }],
    ["path", { d: "M7 2v2", key: "1i4yhu" }],
    ["rect", { x: "4", y: "4", width: "16", height: "16", rx: "2", key: "1vbyd7" }],
    ["rect", { x: "8", y: "8", width: "8", height: "8", rx: "1", key: "z9xiuo" }]
  ];
  var Cpu = createLucideIcon("cpu", __iconNode16);

  // src/client/node_modules/lucide-react/dist/esm/icons/database-zap.mjs
  init_define_import_meta_env();
  var __iconNode17 = [
    ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
    ["path", { d: "M3 5V19A9 3 0 0 0 15 21.84", key: "14ibmq" }],
    ["path", { d: "M21 5V8", key: "1marbg" }],
    ["path", { d: "M21 12L18 17H22L19 22", key: "zafso" }],
    ["path", { d: "M3 12A9 3 0 0 0 14.59 14.87", key: "1y4wr8" }]
  ];
  var DatabaseZap = createLucideIcon("database-zap", __iconNode17);

  // src/client/node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.mjs
  init_define_import_meta_env();
  var __iconNode18 = [
    ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
    ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
    ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }]
  ];
  var EllipsisVertical = createLucideIcon("ellipsis-vertical", __iconNode18);

  // src/client/node_modules/lucide-react/dist/esm/icons/eye-off.mjs
  init_define_import_meta_env();
  var __iconNode19 = [
    [
      "path",
      {
        d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
        key: "ct8e1f"
      }
    ],
    ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
    [
      "path",
      {
        d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
        key: "13bj9a"
      }
    ],
    ["path", { d: "m2 2 20 20", key: "1ooewy" }]
  ];
  var EyeOff = createLucideIcon("eye-off", __iconNode19);

  // src/client/node_modules/lucide-react/dist/esm/icons/file-text.mjs
  init_define_import_meta_env();
  var __iconNode20 = [
    [
      "path",
      {
        d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
        key: "1oefj6"
      }
    ],
    ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
    ["path", { d: "M10 9H8", key: "b1mrlr" }],
    ["path", { d: "M16 13H8", key: "t4e002" }],
    ["path", { d: "M16 17H8", key: "z1uh3a" }]
  ];
  var FileText = createLucideIcon("file-text", __iconNode20);

  // src/client/node_modules/lucide-react/dist/esm/icons/folder-open.mjs
  init_define_import_meta_env();
  var __iconNode21 = [
    [
      "path",
      {
        d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
        key: "usdka0"
      }
    ]
  ];
  var FolderOpen = createLucideIcon("folder-open", __iconNode21);

  // src/client/node_modules/lucide-react/dist/esm/icons/grip-vertical.mjs
  init_define_import_meta_env();
  var __iconNode22 = [
    ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }],
    ["circle", { cx: "9", cy: "5", r: "1", key: "hp0tcf" }],
    ["circle", { cx: "9", cy: "19", r: "1", key: "fkjjf6" }],
    ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
    ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
    ["circle", { cx: "15", cy: "19", r: "1", key: "f4zoj3" }]
  ];
  var GripVertical = createLucideIcon("grip-vertical", __iconNode22);

  // src/client/node_modules/lucide-react/dist/esm/icons/info.mjs
  init_define_import_meta_env();
  var __iconNode23 = [
    ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
    ["path", { d: "M12 16v-4", key: "1dtifu" }],
    ["path", { d: "M12 8h.01", key: "e9boi3" }]
  ];
  var Info = createLucideIcon("info", __iconNode23);

  // src/client/node_modules/lucide-react/dist/esm/icons/layers.mjs
  init_define_import_meta_env();
  var __iconNode24 = [
    [
      "path",
      {
        d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
        key: "zw3jo"
      }
    ],
    [
      "path",
      {
        d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
        key: "1wduqc"
      }
    ],
    [
      "path",
      {
        d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
        key: "kqbvx6"
      }
    ]
  ];
  var Layers = createLucideIcon("layers", __iconNode24);

  // src/client/node_modules/lucide-react/dist/esm/icons/link-2.mjs
  init_define_import_meta_env();
  var __iconNode25 = [
    ["path", { d: "M9 17H7A5 5 0 0 1 7 7h2", key: "8i5ue5" }],
    ["path", { d: "M15 7h2a5 5 0 1 1 0 10h-2", key: "1b9ql8" }],
    ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }]
  ];
  var Link2 = createLucideIcon("link-2", __iconNode25);

  // src/client/node_modules/lucide-react/dist/esm/icons/loader-circle.mjs
  init_define_import_meta_env();
  var __iconNode26 = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]];
  var LoaderCircle = createLucideIcon("loader-circle", __iconNode26);

  // src/client/node_modules/lucide-react/dist/esm/icons/lock.mjs
  init_define_import_meta_env();
  var __iconNode27 = [
    ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
    ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
  ];
  var Lock = createLucideIcon("lock", __iconNode27);

  // src/client/node_modules/lucide-react/dist/esm/icons/map-pin.mjs
  init_define_import_meta_env();
  var __iconNode28 = [
    [
      "path",
      {
        d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
        key: "1r0f0z"
      }
    ],
    ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }]
  ];
  var MapPin = createLucideIcon("map-pin", __iconNode28);

  // src/client/node_modules/lucide-react/dist/esm/icons/minus.mjs
  init_define_import_meta_env();
  var __iconNode29 = [["path", { d: "M5 12h14", key: "1ays0h" }]];
  var Minus = createLucideIcon("minus", __iconNode29);

  // src/client/node_modules/lucide-react/dist/esm/icons/package.mjs
  init_define_import_meta_env();
  var __iconNode30 = [
    [
      "path",
      {
        d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
        key: "1a0edw"
      }
    ],
    ["path", { d: "M12 22V12", key: "d0xqtd" }],
    ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
    ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }]
  ];
  var Package = createLucideIcon("package", __iconNode30);

  // src/client/node_modules/lucide-react/dist/esm/icons/plus.mjs
  init_define_import_meta_env();
  var __iconNode31 = [
    ["path", { d: "M5 12h14", key: "1ays0h" }],
    ["path", { d: "M12 5v14", key: "s699le" }]
  ];
  var Plus = createLucideIcon("plus", __iconNode31);

  // src/client/node_modules/lucide-react/dist/esm/icons/refresh-cw.mjs
  init_define_import_meta_env();
  var __iconNode32 = [
    ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
    ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
    ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
    ["path", { d: "M8 16H3v5", key: "1cv678" }]
  ];
  var RefreshCw = createLucideIcon("refresh-cw", __iconNode32);

  // src/client/node_modules/lucide-react/dist/esm/icons/ruler.mjs
  init_define_import_meta_env();
  var __iconNode33 = [
    [
      "path",
      {
        d: "M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",
        key: "icamh8"
      }
    ],
    ["path", { d: "m14.5 12.5 2-2", key: "inckbg" }],
    ["path", { d: "m11.5 9.5 2-2", key: "fmmyf7" }],
    ["path", { d: "m8.5 6.5 2-2", key: "vc6u1g" }],
    ["path", { d: "m17.5 15.5 2-2", key: "wo5hmg" }]
  ];
  var Ruler = createLucideIcon("ruler", __iconNode33);

  // src/client/node_modules/lucide-react/dist/esm/icons/scan-text.mjs
  init_define_import_meta_env();
  var __iconNode34 = [
    ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
    ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
    ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
    ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
    ["path", { d: "M7 8h8", key: "1jbsf9" }],
    ["path", { d: "M7 12h10", key: "b7w52i" }],
    ["path", { d: "M7 16h6", key: "1vyc9m" }]
  ];
  var ScanText = createLucideIcon("scan-text", __iconNode34);

  // src/client/node_modules/lucide-react/dist/esm/icons/search.mjs
  init_define_import_meta_env();
  var __iconNode35 = [
    ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
    ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
  ];
  var Search = createLucideIcon("search", __iconNode35);

  // src/client/node_modules/lucide-react/dist/esm/icons/square-function.mjs
  init_define_import_meta_env();
  var __iconNode36 = [
    ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
    ["path", { d: "M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3", key: "m1af9g" }],
    ["path", { d: "M9 11.2h5.7", key: "3zgcl2" }]
  ];
  var SquareFunction = createLucideIcon("square-function", __iconNode36);

  // src/client/node_modules/lucide-react/dist/esm/icons/trash-2.mjs
  init_define_import_meta_env();
  var __iconNode37 = [
    ["path", { d: "M10 11v6", key: "nco0om" }],
    ["path", { d: "M14 11v6", key: "outv1u" }],
    ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
    ["path", { d: "M3 6h18", key: "d0wm0j" }],
    ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
  ];
  var Trash2 = createLucideIcon("trash-2", __iconNode37);

  // src/client/node_modules/lucide-react/dist/esm/icons/triangle-alert.mjs
  init_define_import_meta_env();
  var __iconNode38 = [
    [
      "path",
      {
        d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
        key: "wmoenq"
      }
    ],
    ["path", { d: "M12 9v4", key: "juzpu7" }],
    ["path", { d: "M12 17h.01", key: "p32p05" }]
  ];
  var TriangleAlert = createLucideIcon("triangle-alert", __iconNode38);

  // src/client/node_modules/lucide-react/dist/esm/icons/unlink.mjs
  init_define_import_meta_env();
  var __iconNode39 = [
    [
      "path",
      {
        d: "m18.84 12.25 1.72-1.71h-.02a5.004 5.004 0 0 0-.12-7.07 5.006 5.006 0 0 0-6.95 0l-1.72 1.71",
        key: "yqzxt4"
      }
    ],
    [
      "path",
      {
        d: "m5.17 11.75-1.71 1.71a5.004 5.004 0 0 0 .12 7.07 5.006 5.006 0 0 0 6.95 0l1.71-1.71",
        key: "4qinb0"
      }
    ],
    ["line", { x1: "8", x2: "8", y1: "2", y2: "5", key: "1041cp" }],
    ["line", { x1: "2", x2: "5", y1: "8", y2: "8", key: "14m1p5" }],
    ["line", { x1: "16", x2: "16", y1: "19", y2: "22", key: "rzdirn" }],
    ["line", { x1: "19", x2: "22", y1: "16", y2: "16", key: "ox905f" }]
  ];
  var Unlink = createLucideIcon("unlink", __iconNode39);

  // src/client/node_modules/lucide-react/dist/esm/icons/user.mjs
  init_define_import_meta_env();
  var __iconNode40 = [
    ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
    ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
  ];
  var User = createLucideIcon("user", __iconNode40);

  // src/client/node_modules/lucide-react/dist/esm/icons/wrench.mjs
  init_define_import_meta_env();
  var __iconNode41 = [
    [
      "path",
      {
        d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
        key: "1ngwbx"
      }
    ]
  ];
  var Wrench = createLucideIcon("wrench", __iconNode41);

  // src/client/node_modules/lucide-react/dist/esm/icons/x.mjs
  init_define_import_meta_env();
  var __iconNode42 = [
    ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
    ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
  ];
  var X = createLucideIcon("x", __iconNode42);

  // src/client/src/shared/ui/Tooltip.tsx
  init_define_import_meta_env();

  // src/client/node_modules/@radix-ui/react-popper/dist/index.mjs
  init_define_import_meta_env();
  var React11 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
  init_define_import_meta_env();

  // src/client/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
  init_define_import_meta_env();

  // src/client/node_modules/@floating-ui/core/dist/floating-ui.core.mjs
  init_define_import_meta_env();

  // src/client/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
  init_define_import_meta_env();
  var sides = ["top", "right", "bottom", "left"];
  var min = Math.min;
  var max = Math.max;
  var round = Math.round;
  var floor = Math.floor;
  var createCoords = (v) => ({
    x: v,
    y: v
  });
  var oppositeSideMap = {
    left: "right",
    right: "left",
    bottom: "top",
    top: "bottom"
  };
  function clamp(start, value, end) {
    return max(start, min(value, end));
  }
  function evaluate(value, param) {
    return typeof value === "function" ? value(param) : value;
  }
  function getSide(placement) {
    return placement.split("-")[0];
  }
  function getAlignment(placement) {
    return placement.split("-")[1];
  }
  function getOppositeAxis(axis) {
    return axis === "x" ? "y" : "x";
  }
  function getAxisLength(axis) {
    return axis === "y" ? "height" : "width";
  }
  function getSideAxis(placement) {
    const firstChar = placement[0];
    return firstChar === "t" || firstChar === "b" ? "y" : "x";
  }
  function getAlignmentAxis(placement) {
    return getOppositeAxis(getSideAxis(placement));
  }
  function getAlignmentSides(placement, rects, rtl) {
    if (rtl === void 0) {
      rtl = false;
    }
    const alignment = getAlignment(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const length = getAxisLength(alignmentAxis);
    let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
    if (rects.reference[length] > rects.floating[length]) {
      mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
    }
    return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
  }
  function getExpandedPlacements(placement) {
    const oppositePlacement = getOppositePlacement(placement);
    return [getOppositeAlignmentPlacement(placement), oppositePlacement, getOppositeAlignmentPlacement(oppositePlacement)];
  }
  function getOppositeAlignmentPlacement(placement) {
    return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
  }
  var lrPlacement = ["left", "right"];
  var rlPlacement = ["right", "left"];
  var tbPlacement = ["top", "bottom"];
  var btPlacement = ["bottom", "top"];
  function getSideList(side, isStart, rtl) {
    switch (side) {
      case "top":
      case "bottom":
        if (rtl) return isStart ? rlPlacement : lrPlacement;
        return isStart ? lrPlacement : rlPlacement;
      case "left":
      case "right":
        return isStart ? tbPlacement : btPlacement;
      default:
        return [];
    }
  }
  function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
    const alignment = getAlignment(placement);
    let list = getSideList(getSide(placement), direction === "start", rtl);
    if (alignment) {
      list = list.map((side) => side + "-" + alignment);
      if (flipAlignment) {
        list = list.concat(list.map(getOppositeAlignmentPlacement));
      }
    }
    return list;
  }
  function getOppositePlacement(placement) {
    const side = getSide(placement);
    return oppositeSideMap[side] + placement.slice(side.length);
  }
  function expandPaddingObject(padding) {
    var _padding$top, _padding$right, _padding$bottom, _padding$left;
    return {
      top: (_padding$top = padding.top) != null ? _padding$top : 0,
      right: (_padding$right = padding.right) != null ? _padding$right : 0,
      bottom: (_padding$bottom = padding.bottom) != null ? _padding$bottom : 0,
      left: (_padding$left = padding.left) != null ? _padding$left : 0
    };
  }
  function getPaddingObject(padding) {
    return typeof padding !== "number" ? expandPaddingObject(padding) : {
      top: padding,
      right: padding,
      bottom: padding,
      left: padding
    };
  }
  function rectToClientRect(rect) {
    const {
      x,
      y,
      width,
      height
    } = rect;
    return {
      width,
      height,
      top: y,
      left: x,
      right: x + width,
      bottom: y + height,
      x,
      y
    };
  }

  // src/client/node_modules/@floating-ui/core/dist/floating-ui.core.mjs
  function computeCoordsFromPlacement(_ref, placement, rtl) {
    let {
      reference,
      floating
    } = _ref;
    const sideAxis = getSideAxis(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const alignLength = getAxisLength(alignmentAxis);
    const side = getSide(placement);
    const isVertical = sideAxis === "y";
    const commonX = reference.x + reference.width / 2 - floating.width / 2;
    const commonY = reference.y + reference.height / 2 - floating.height / 2;
    const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
    let coords;
    switch (side) {
      case "top":
        coords = {
          x: commonX,
          y: reference.y - floating.height
        };
        break;
      case "bottom":
        coords = {
          x: commonX,
          y: reference.y + reference.height
        };
        break;
      case "right":
        coords = {
          x: reference.x + reference.width,
          y: commonY
        };
        break;
      case "left":
        coords = {
          x: reference.x - floating.width,
          y: commonY
        };
        break;
      default:
        coords = {
          x: reference.x,
          y: reference.y
        };
    }
    const alignment = getAlignment(placement);
    if (alignment) {
      coords[alignmentAxis] += commonAlign * (alignment === "end" ? 1 : -1) * (rtl && isVertical ? -1 : 1);
    }
    return coords;
  }
  async function detectOverflow(state, options2) {
    var _await$platform$isEle;
    if (options2 === void 0) {
      options2 = {};
    }
    const {
      x,
      y,
      platform: platform2,
      rects,
      elements,
      strategy
    } = state;
    const {
      boundary = "clippingAncestors",
      rootBoundary = "viewport",
      elementContext = "floating",
      altBoundary = false,
      padding = 0
    } = evaluate(options2, state);
    const paddingObject = getPaddingObject(padding);
    const altContext = elementContext === "floating" ? "reference" : "floating";
    const element = elements[altBoundary ? altContext : elementContext];
    const clippingClientRect = rectToClientRect(await platform2.getClippingRect({
      element: ((_await$platform$isEle = await (platform2.isElement == null ? void 0 : platform2.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform2.getDocumentElement == null ? void 0 : platform2.getDocumentElement(elements.floating)),
      boundary,
      rootBoundary,
      strategy
    }));
    const rect = elementContext === "floating" ? {
      x,
      y,
      width: rects.floating.width,
      height: rects.floating.height
    } : rects.reference;
    const offsetParent = await (platform2.getOffsetParent == null ? void 0 : platform2.getOffsetParent(elements.floating));
    const offsetScale = await (platform2.isElement == null ? void 0 : platform2.isElement(offsetParent)) && await (platform2.getScale == null ? void 0 : platform2.getScale(offsetParent)) || {
      x: 1,
      y: 1
    };
    const elementClientRect = rectToClientRect(platform2.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform2.convertOffsetParentRelativeRectToViewportRelativeRect({
      elements,
      rect,
      offsetParent,
      strategy
    }) : rect);
    return {
      top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
      bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
      left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
      right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
    };
  }
  var MAX_RESET_COUNT = 50;
  var computePosition = async (reference, floating, config) => {
    const {
      placement = "bottom",
      strategy = "absolute",
      middleware = [],
      platform: platform2
    } = config;
    const platformWithDetectOverflow = platform2.detectOverflow ? platform2 : {
      ...platform2,
      detectOverflow
    };
    const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(floating));
    let rects = await platform2.getElementRects({
      reference,
      floating,
      strategy
    });
    let {
      x,
      y
    } = computeCoordsFromPlacement(rects, placement, rtl);
    let statefulPlacement = placement;
    let resetCount = 0;
    const middlewareData = {};
    for (let i = 0; i < middleware.length; i++) {
      const currentMiddleware = middleware[i];
      if (!currentMiddleware) {
        continue;
      }
      const {
        name,
        fn
      } = currentMiddleware;
      const {
        x: nextX,
        y: nextY,
        data,
        reset
      } = await fn({
        x,
        y,
        initialPlacement: placement,
        placement: statefulPlacement,
        strategy,
        middlewareData,
        rects,
        platform: platformWithDetectOverflow,
        elements: {
          reference,
          floating
        }
      });
      x = nextX != null ? nextX : x;
      y = nextY != null ? nextY : y;
      middlewareData[name] = {
        ...middlewareData[name],
        ...data
      };
      if (reset && resetCount < MAX_RESET_COUNT) {
        resetCount++;
        if (typeof reset === "object") {
          if (reset.placement) {
            statefulPlacement = reset.placement;
          }
          if (reset.rects) {
            rects = reset.rects === true ? await platform2.getElementRects({
              reference,
              floating,
              strategy
            }) : reset.rects;
          }
          ({
            x,
            y
          } = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
        }
        i = -1;
      }
    }
    return {
      x,
      y,
      placement: statefulPlacement,
      strategy,
      middlewareData
    };
  };
  var arrow = (options2) => ({
    name: "arrow",
    options: options2,
    async fn(state) {
      const {
        x,
        y,
        placement,
        rects,
        platform: platform2,
        elements,
        middlewareData
      } = state;
      const {
        element,
        padding = 0
      } = evaluate(options2, state) || {};
      if (element == null) {
        return {};
      }
      const paddingObject = getPaddingObject(padding);
      const coords = {
        x,
        y
      };
      const axis = getAlignmentAxis(placement);
      const length = getAxisLength(axis);
      const arrowDimensions = await platform2.getDimensions(element);
      const isYAxis = axis === "y";
      const minProp = isYAxis ? "top" : "left";
      const maxProp = isYAxis ? "bottom" : "right";
      const clientProp = isYAxis ? "clientHeight" : "clientWidth";
      const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
      const startDiff = coords[axis] - rects.reference[axis];
      const arrowOffsetParent = await (platform2.getOffsetParent == null ? void 0 : platform2.getOffsetParent(element));
      let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
      if (!clientSize || !await (platform2.isElement == null ? void 0 : platform2.isElement(arrowOffsetParent))) {
        clientSize = elements.floating[clientProp] || rects.floating[length];
      }
      const centerToReference = endDiff / 2 - startDiff / 2;
      const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
      const minPadding = min(paddingObject[minProp], largestPossiblePadding);
      const maxPadding = min(paddingObject[maxProp], largestPossiblePadding);
      const max2 = clientSize - arrowDimensions[length] - maxPadding;
      const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
      const offset4 = clamp(minPadding, center, max2);
      const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset4 && rects.reference[length] / 2 - (center < minPadding ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
      const alignmentOffset = shouldAddOffset ? center < minPadding ? center - minPadding : center - max2 : 0;
      return {
        [axis]: coords[axis] + alignmentOffset,
        data: {
          [axis]: offset4,
          centerOffset: center - offset4 - alignmentOffset,
          ...shouldAddOffset && {
            alignmentOffset
          }
        },
        reset: shouldAddOffset
      };
    }
  });
  var flip = function(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    return {
      name: "flip",
      options: options2,
      async fn(state) {
        var _middlewareData$arrow, _middlewareData$flip;
        const {
          placement,
          middlewareData,
          rects,
          initialPlacement,
          platform: platform2,
          elements
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = true,
          fallbackPlacements: specifiedFallbackPlacements,
          fallbackStrategy = "bestFit",
          fallbackAxisSideDirection = "none",
          flipAlignment = true,
          ...detectOverflowOptions
        } = evaluate(options2, state);
        if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        const side = getSide(placement);
        const initialSideAxis = getSideAxis(initialPlacement);
        const isBasePlacement = getSide(initialPlacement) === initialPlacement;
        const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating));
        const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
        const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
        if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) {
          fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
        }
        const placements2 = [initialPlacement, ...fallbackPlacements];
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const overflows = [];
        let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
        if (checkMainAxis) {
          overflows.push(overflow[side]);
        }
        if (checkCrossAxis) {
          const sides2 = getAlignmentSides(placement, rects, rtl);
          overflows.push(overflow[sides2[0]], overflow[sides2[1]]);
        }
        overflowsData = [...overflowsData, {
          placement,
          overflows
        }];
        if (!overflows.every((side2) => side2 <= 0)) {
          var _middlewareData$flip2, _overflowsData$filter;
          const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
          const nextPlacement = placements2[nextIndex];
          if (nextPlacement) {
            const ignoreCrossAxisOverflow = checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false;
            if (!ignoreCrossAxisOverflow || // We leave the current main axis only if every placement on that axis
            // overflows the main axis.
            overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) {
              return {
                data: {
                  index: nextIndex,
                  overflows: overflowsData
                },
                reset: {
                  placement: nextPlacement
                }
              };
            }
          }
          let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
          if (!resetPlacement) {
            switch (fallbackStrategy) {
              case "bestFit": {
                var _overflowsData$filter2;
                const placement2 = (_overflowsData$filter2 = overflowsData.filter((d) => {
                  if (hasFallbackAxisSideDirection) {
                    const currentSideAxis = getSideAxis(d.placement);
                    return currentSideAxis === initialSideAxis || // Create a bias to the `y` side axis due to horizontal
                    // reading directions favoring greater width.
                    currentSideAxis === "y";
                  }
                  return true;
                }).map((d) => [d.placement, d.overflows.filter((overflow2) => overflow2 > 0).reduce((acc, overflow2) => acc + overflow2, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
                if (placement2) {
                  resetPlacement = placement2;
                }
                break;
              }
              case "initialPlacement":
                resetPlacement = initialPlacement;
                break;
            }
          }
          if (placement !== resetPlacement) {
            return {
              reset: {
                placement: resetPlacement
              }
            };
          }
        }
        return {};
      }
    };
  };
  function getSideOffsets(overflow, rect) {
    return {
      top: overflow.top - rect.height,
      right: overflow.right - rect.width,
      bottom: overflow.bottom - rect.height,
      left: overflow.left - rect.width
    };
  }
  function isAnySideFullyClipped(overflow) {
    return sides.some((side) => overflow[side] >= 0);
  }
  var hide = function(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    return {
      name: "hide",
      options: options2,
      async fn(state) {
        const {
          rects,
          platform: platform2
        } = state;
        const {
          strategy = "referenceHidden",
          ...detectOverflowOptions
        } = evaluate(options2, state);
        switch (strategy) {
          case "referenceHidden": {
            const overflow = await platform2.detectOverflow(state, {
              ...detectOverflowOptions,
              elementContext: "reference"
            });
            const offsets = getSideOffsets(overflow, rects.reference);
            return {
              data: {
                referenceHiddenOffsets: offsets,
                referenceHidden: isAnySideFullyClipped(offsets)
              }
            };
          }
          case "escaped": {
            const overflow = await platform2.detectOverflow(state, {
              ...detectOverflowOptions,
              altBoundary: true
            });
            const offsets = getSideOffsets(overflow, rects.floating);
            return {
              data: {
                escapedOffsets: offsets,
                escaped: isAnySideFullyClipped(offsets)
              }
            };
          }
          default: {
            return {};
          }
        }
      }
    };
  };
  var originSides = /* @__PURE__ */ new Set(["left", "top"]);
  async function convertValueToCoords(state, options2) {
    const {
      placement,
      platform: platform2,
      elements
    } = state;
    const rtl = await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating));
    const side = getSide(placement);
    const alignment = getAlignment(placement);
    const isVertical = getSideAxis(placement) === "y";
    const mainAxisMulti = originSides.has(side) ? -1 : 1;
    const crossAxisMulti = rtl && isVertical ? -1 : 1;
    const rawValue = evaluate(options2, state);
    let {
      mainAxis,
      crossAxis,
      alignmentAxis
    } = typeof rawValue === "number" ? {
      mainAxis: rawValue,
      crossAxis: 0,
      alignmentAxis: null
    } : {
      mainAxis: rawValue.mainAxis || 0,
      crossAxis: rawValue.crossAxis || 0,
      alignmentAxis: rawValue.alignmentAxis
    };
    if (alignment && typeof alignmentAxis === "number") {
      crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
    }
    return isVertical ? {
      x: crossAxis * crossAxisMulti,
      y: mainAxis * mainAxisMulti
    } : {
      x: mainAxis * mainAxisMulti,
      y: crossAxis * crossAxisMulti
    };
  }
  var offset = function(options2) {
    if (options2 === void 0) {
      options2 = 0;
    }
    return {
      name: "offset",
      options: options2,
      async fn(state) {
        var _middlewareData$offse, _middlewareData$arrow;
        const {
          x,
          y,
          placement,
          middlewareData
        } = state;
        const diffCoords = await convertValueToCoords(state, options2);
        if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
          return {};
        }
        return {
          x: x + diffCoords.x,
          y: y + diffCoords.y,
          data: {
            ...diffCoords,
            placement
          }
        };
      }
    };
  };
  var shift = function(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    return {
      name: "shift",
      options: options2,
      async fn(state) {
        const {
          x,
          y,
          placement,
          platform: platform2
        } = state;
        const {
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = false,
          limiter = {
            fn: (_ref) => {
              let {
                x: x2,
                y: y2
              } = _ref;
              return {
                x: x2,
                y: y2
              };
            }
          },
          ...detectOverflowOptions
        } = evaluate(options2, state);
        const coords = {
          x,
          y
        };
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const crossAxis = getSideAxis(placement);
        const mainAxis = getOppositeAxis(crossAxis);
        let mainAxisCoord = coords[mainAxis];
        let crossAxisCoord = coords[crossAxis];
        const clampCoord = (axis, coord) => clamp(coord + overflow[axis === "y" ? "top" : "left"], coord, coord - overflow[axis === "y" ? "bottom" : "right"]);
        if (checkMainAxis) {
          mainAxisCoord = clampCoord(mainAxis, mainAxisCoord);
        }
        if (checkCrossAxis) {
          crossAxisCoord = clampCoord(crossAxis, crossAxisCoord);
        }
        const limitedCoords = limiter.fn({
          ...state,
          [mainAxis]: mainAxisCoord,
          [crossAxis]: crossAxisCoord
        });
        return {
          ...limitedCoords,
          data: {
            x: limitedCoords.x - x,
            y: limitedCoords.y - y,
            enabled: {
              [mainAxis]: checkMainAxis,
              [crossAxis]: checkCrossAxis
            }
          }
        };
      }
    };
  };
  var limitShift = function(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    return {
      options: options2,
      fn(state) {
        var _rawOffset$mainAxis, _rawOffset$crossAxis;
        const {
          x,
          y,
          placement,
          rects,
          middlewareData
        } = state;
        const {
          offset: offset4 = 0,
          mainAxis: checkMainAxis = true,
          crossAxis: checkCrossAxis = true
        } = evaluate(options2, state);
        const coords = {
          x,
          y
        };
        const crossAxis = getSideAxis(placement);
        const mainAxis = getOppositeAxis(crossAxis);
        let mainAxisCoord = coords[mainAxis];
        let crossAxisCoord = coords[crossAxis];
        const rawOffset = evaluate(offset4, state);
        const computedOffset = typeof rawOffset === "number" ? {
          mainAxis: rawOffset,
          crossAxis: 0
        } : {
          mainAxis: (_rawOffset$mainAxis = rawOffset.mainAxis) != null ? _rawOffset$mainAxis : 0,
          crossAxis: (_rawOffset$crossAxis = rawOffset.crossAxis) != null ? _rawOffset$crossAxis : 0
        };
        if (checkMainAxis) {
          const len = mainAxis === "y" ? "height" : "width";
          const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
          const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
          if (mainAxisCoord < limitMin) {
            mainAxisCoord = limitMin;
          } else if (mainAxisCoord > limitMax) {
            mainAxisCoord = limitMax;
          }
        }
        if (checkCrossAxis) {
          var _middlewareData$offse, _middlewareData$offse2;
          const len = mainAxis === "y" ? "width" : "height";
          const isOriginSide = originSides.has(getSide(placement));
          const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
          const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
          if (crossAxisCoord < limitMin) {
            crossAxisCoord = limitMin;
          } else if (crossAxisCoord > limitMax) {
            crossAxisCoord = limitMax;
          }
        }
        return {
          [mainAxis]: mainAxisCoord,
          [crossAxis]: crossAxisCoord
        };
      }
    };
  };
  var size = function(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    return {
      name: "size",
      options: options2,
      async fn(state) {
        const {
          placement,
          rects,
          platform: platform2,
          elements
        } = state;
        const {
          apply = () => {
          },
          ...detectOverflowOptions
        } = evaluate(options2, state);
        const overflow = await platform2.detectOverflow(state, detectOverflowOptions);
        const side = getSide(placement);
        const alignment = getAlignment(placement);
        const isYAxis = getSideAxis(placement) === "y";
        const {
          width,
          height
        } = rects.floating;
        let heightSide;
        let widthSide;
        if (side === "top" || side === "bottom") {
          heightSide = side;
          widthSide = alignment === (await (platform2.isRTL == null ? void 0 : platform2.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
        } else {
          widthSide = side;
          heightSide = alignment === "end" ? "top" : "bottom";
        }
        const maximumClippingHeight = height - overflow.top - overflow.bottom;
        const maximumClippingWidth = width - overflow.left - overflow.right;
        const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
        const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
        const shiftData = state.middlewareData.shift;
        const noShift = !shiftData;
        let availableHeight = overflowAvailableHeight;
        let availableWidth = overflowAvailableWidth;
        if (shiftData != null && shiftData.enabled.x) {
          availableWidth = maximumClippingWidth;
        }
        if (shiftData != null && shiftData.enabled.y) {
          availableHeight = maximumClippingHeight;
        }
        if (noShift && !alignment) {
          if (isYAxis) {
            availableWidth = width - 2 * max(overflow.left, overflow.right);
          } else {
            availableHeight = height - 2 * max(overflow.top, overflow.bottom);
          }
        }
        await apply({
          ...state,
          availableWidth,
          availableHeight
        });
        const nextDimensions = await platform2.getDimensions(elements.floating);
        if (width !== nextDimensions.width || height !== nextDimensions.height) {
          return {
            reset: {
              rects: true
            }
          };
        }
        return {};
      }
    };
  };

  // src/client/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
  init_define_import_meta_env();
  function hasWindow() {
    return typeof window !== "undefined";
  }
  function getNodeName(node) {
    if (isNode(node)) {
      return (node.nodeName || "").toLowerCase();
    }
    return "#document";
  }
  function getWindow(node) {
    var _node$ownerDocument;
    return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
  }
  function getDocumentElement(node) {
    var _ref;
    return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
  }
  function isNode(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Node || value instanceof getWindow(value).Node;
  }
  function isElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof Element || value instanceof getWindow(value).Element;
  }
  function isHTMLElement(value) {
    if (!hasWindow()) {
      return false;
    }
    return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
  }
  function isShadowRoot(value) {
    if (!hasWindow() || typeof ShadowRoot === "undefined") {
      return false;
    }
    return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
  }
  function isOverflowElement(element) {
    const {
      overflow,
      overflowX,
      overflowY,
      display
    } = getComputedStyle2(element);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
  }
  function isTableElement(element) {
    return /^(table|td|th)$/.test(getNodeName(element));
  }
  function isTopLayer(element) {
    try {
      if (element.matches(":popover-open")) {
        return true;
      }
    } catch (_e) {
    }
    try {
      return element.matches(":modal");
    } catch (_e) {
      return false;
    }
  }
  var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
  var containRe = /paint|layout|strict|content/;
  var isNotNone = (value) => !!value && value !== "none";
  var isWebKitValue;
  function isContainingBlock(elementOrCss) {
    const css = isElement(elementOrCss) ? getComputedStyle2(elementOrCss) : elementOrCss;
    return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
  }
  function getContainingBlock(element) {
    let currentNode = getParentNode(element);
    while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
      if (isContainingBlock(currentNode)) {
        return currentNode;
      } else if (isTopLayer(currentNode)) {
        return null;
      }
      currentNode = getParentNode(currentNode);
    }
    return null;
  }
  function isWebKit() {
    if (isWebKitValue == null) {
      isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
    }
    return isWebKitValue;
  }
  function isLastTraversableNode(node) {
    return /^(html|body|#document)$/.test(getNodeName(node));
  }
  function getComputedStyle2(element) {
    return getWindow(element).getComputedStyle(element);
  }
  function getNodeScroll(element) {
    if (isElement(element)) {
      return {
        scrollLeft: element.scrollLeft,
        scrollTop: element.scrollTop
      };
    }
    return {
      scrollLeft: element.scrollX,
      scrollTop: element.scrollY
    };
  }
  function getParentNode(node) {
    if (getNodeName(node) === "html") {
      return node;
    }
    const result = (
      // Step into the shadow DOM of the parent of a slotted node.
      node.assignedSlot || // DOM Element detected.
      node.parentNode || // ShadowRoot detected.
      isShadowRoot(node) && node.host || // Fallback.
      getDocumentElement(node)
    );
    return isShadowRoot(result) ? result.host : result;
  }
  function getNearestOverflowAncestor(node) {
    const parentNode = getParentNode(node);
    if (isLastTraversableNode(parentNode)) {
      return (node.ownerDocument || node).body;
    }
    if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
      return parentNode;
    }
    return getNearestOverflowAncestor(parentNode);
  }
  function getOverflowAncestors(node, list, traverseIframes) {
    var _node$ownerDocument2;
    if (list === void 0) {
      list = [];
    }
    if (traverseIframes === void 0) {
      traverseIframes = true;
    }
    const scrollableAncestor = getNearestOverflowAncestor(node);
    const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
    const win = getWindow(scrollableAncestor);
    if (isBody) {
      const frameElement = getFrameElement(win);
      return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
    } else {
      return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
    }
  }
  function getFrameElement(win) {
    return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
  }

  // src/client/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
  function getCssDimensions(element) {
    const css = getComputedStyle2(element);
    let width = parseFloat(css.width) || 0;
    let height = parseFloat(css.height) || 0;
    const hasOffset = isHTMLElement(element);
    const offsetWidth = hasOffset ? element.offsetWidth : width;
    const offsetHeight = hasOffset ? element.offsetHeight : height;
    const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
    if (shouldFallback) {
      width = offsetWidth;
      height = offsetHeight;
    }
    return {
      width,
      height,
      $: shouldFallback
    };
  }
  function unwrapElement(element) {
    return !isElement(element) ? element.contextElement : element;
  }
  function getScale(element) {
    const domElement = unwrapElement(element);
    if (!isHTMLElement(domElement)) {
      return createCoords(1);
    }
    const rect = domElement.getBoundingClientRect();
    const {
      width,
      height,
      $
    } = getCssDimensions(domElement);
    let x = ($ ? round(rect.width) : rect.width) / width;
    let y = ($ ? round(rect.height) : rect.height) / height;
    if (!x || !Number.isFinite(x)) {
      x = 1;
    }
    if (!y || !Number.isFinite(y)) {
      y = 1;
    }
    return {
      x,
      y
    };
  }
  var noOffsets = /* @__PURE__ */ createCoords(0);
  function getVisualOffsets(element) {
    const win = getWindow(element);
    if (!isWebKit() || !win.visualViewport) {
      return noOffsets;
    }
    return {
      x: win.visualViewport.offsetLeft,
      y: win.visualViewport.offsetTop
    };
  }
  function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
    if (isFixed === void 0) {
      isFixed = false;
    }
    return !!floatingOffsetParent && isFixed && floatingOffsetParent === getWindow(element);
  }
  function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
    if (includeScale === void 0) {
      includeScale = false;
    }
    if (isFixedStrategy === void 0) {
      isFixedStrategy = false;
    }
    const clientRect = element.getBoundingClientRect();
    const domElement = unwrapElement(element);
    let scale = createCoords(1);
    if (includeScale) {
      if (offsetParent) {
        if (isElement(offsetParent)) {
          scale = getScale(offsetParent);
        }
      } else {
        scale = getScale(element);
      }
    }
    const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
    let x = (clientRect.left + visualOffsets.x) / scale.x;
    let y = (clientRect.top + visualOffsets.y) / scale.y;
    let width = clientRect.width / scale.x;
    let height = clientRect.height / scale.y;
    if (domElement && offsetParent) {
      const win = getWindow(domElement);
      const offsetWin = isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
      let currentWin = win;
      let currentIFrame = getFrameElement(currentWin);
      while (currentIFrame && offsetWin !== currentWin) {
        const iframeScale = getScale(currentIFrame);
        const iframeRect = currentIFrame.getBoundingClientRect();
        const css = getComputedStyle2(currentIFrame);
        const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
        const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
        x *= iframeScale.x;
        y *= iframeScale.y;
        width *= iframeScale.x;
        height *= iframeScale.y;
        x += left;
        y += top;
        currentWin = getWindow(currentIFrame);
        currentIFrame = getFrameElement(currentWin);
      }
    }
    return rectToClientRect({
      width,
      height,
      x,
      y
    });
  }
  function getWindowScrollBarX(element, rect) {
    const leftScroll = getNodeScroll(element).scrollLeft;
    if (!rect) {
      return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
    }
    return rect.left + leftScroll;
  }
  function getHTMLOffset(documentElement, scroll) {
    const htmlRect = documentElement.getBoundingClientRect();
    const x = htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect);
    const y = htmlRect.top + scroll.scrollTop;
    return {
      x,
      y
    };
  }
  function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
    let {
      elements,
      rect,
      offsetParent,
      strategy
    } = _ref;
    const isFixed = strategy === "fixed";
    const documentElement = getDocumentElement(offsetParent);
    const topLayer = elements ? isTopLayer(elements.floating) : false;
    if (offsetParent === documentElement || topLayer && isFixed) {
      return rect;
    }
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    let scale = createCoords(1);
    const offsets = createCoords(0);
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    if (isOffsetParentAnElement || !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent);
        scale = getScale(offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      }
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    return {
      width: rect.width * scale.x,
      height: rect.height * scale.y,
      x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
      y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
    };
  }
  function getClientRects(element) {
    return element.getClientRects ? Array.from(element.getClientRects()) : [];
  }
  function getDocumentRect(html) {
    const scroll = getNodeScroll(html);
    const body = html.ownerDocument.body;
    const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
    const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
    let x = -scroll.scrollLeft + getWindowScrollBarX(html);
    const y = -scroll.scrollTop;
    if (getComputedStyle2(body).direction === "rtl") {
      x += max(html.clientWidth, body.clientWidth) - width;
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  var SCROLLBAR_MAX = 25;
  function getViewportRect(element, strategy, rootBoundary) {
    if (rootBoundary === void 0) {
      rootBoundary = "viewport";
    }
    const isLayoutViewport = rootBoundary === "layoutViewport";
    const win = getWindow(element);
    const html = getDocumentElement(element);
    const visualViewport = win.visualViewport;
    let width = html.clientWidth;
    let height = html.clientHeight;
    let x = 0;
    let y = 0;
    if (visualViewport) {
      const layoutRelativeClientCoords = !isWebKit() || strategy === "fixed";
      if (isLayoutViewport) {
        if (!layoutRelativeClientCoords) {
          x = -visualViewport.offsetLeft;
          y = -visualViewport.offsetTop;
        }
      } else {
        width = visualViewport.width;
        height = visualViewport.height;
        if (layoutRelativeClientCoords) {
          x = visualViewport.offsetLeft;
          y = visualViewport.offsetTop;
        }
      }
    }
    const windowScrollbarX = getWindowScrollBarX(html);
    if (windowScrollbarX <= 0) {
      const doc = html.ownerDocument;
      const body = doc.body;
      const bodyStyles = getComputedStyle(body);
      const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
      const reservedWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
      const gutter = getComputedStyle(html).scrollbarGutter === "stable both-edges" ? reservedWidth / 2 : reservedWidth;
      if (gutter <= SCROLLBAR_MAX) {
        width -= gutter;
      }
    }
    return {
      width,
      height,
      x,
      y
    };
  }
  function getInnerBoundingClientRect(element, strategy) {
    const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
    const top = clientRect.top + element.clientTop;
    const left = clientRect.left + element.clientLeft;
    const scale = getScale(element);
    const width = element.clientWidth * scale.x;
    const height = element.clientHeight * scale.y;
    const x = left * scale.x;
    const y = top * scale.y;
    return {
      width,
      height,
      x,
      y
    };
  }
  function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
    let rect;
    if (clippingAncestor === "viewport" || clippingAncestor === "layoutViewport") {
      rect = getViewportRect(element, strategy, clippingAncestor);
    } else if (clippingAncestor === "document") {
      rect = getDocumentRect(getDocumentElement(element));
    } else if (isElement(clippingAncestor)) {
      rect = getInnerBoundingClientRect(clippingAncestor, strategy);
    } else {
      const visualOffsets = getVisualOffsets(element);
      rect = {
        x: clippingAncestor.x - visualOffsets.x,
        y: clippingAncestor.y - visualOffsets.y,
        width: clippingAncestor.width,
        height: clippingAncestor.height
      };
    }
    return rectToClientRect(rect);
  }
  function getClippingElementAncestors(element, cache) {
    const cachedResult = cache.get(element);
    if (cachedResult) {
      return cachedResult;
    }
    let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
    let lastKeptComputedStyle = null;
    const elementIsFixed = getComputedStyle2(element).position === "fixed";
    let currentNode = elementIsFixed ? getParentNode(element) : element;
    while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
      const computedStyle = getComputedStyle2(currentNode);
      const currentNodeIsContaining = isContainingBlock(currentNode);
      const lastPosition = lastKeptComputedStyle ? lastKeptComputedStyle.position : elementIsFixed ? "fixed" : "";
      const shouldDropCurrentNode = !currentNodeIsContaining && (lastPosition === "fixed" || lastPosition === "absolute" && computedStyle.position === "static");
      if (shouldDropCurrentNode) {
        result = result.filter((ancestor) => ancestor !== currentNode);
      } else {
        lastKeptComputedStyle = computedStyle;
      }
      currentNode = getParentNode(currentNode);
    }
    cache.set(element, result);
    return result;
  }
  function getClippingRect(_ref) {
    let {
      element,
      boundary,
      rootBoundary,
      strategy
    } = _ref;
    const elementClippingAncestors = boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary);
    const clippingAncestors = [...elementClippingAncestors, rootBoundary];
    const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
    let top = firstRect.top;
    let right = firstRect.right;
    let bottom = firstRect.bottom;
    let left = firstRect.left;
    for (let i = 1; i < clippingAncestors.length; i++) {
      const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
      top = max(rect.top, top);
      right = min(rect.right, right);
      bottom = min(rect.bottom, bottom);
      left = max(rect.left, left);
    }
    return {
      width: right - left,
      height: bottom - top,
      x: left,
      y: top
    };
  }
  function getDimensions(element) {
    const {
      width,
      height
    } = getCssDimensions(element);
    return {
      width,
      height
    };
  }
  function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
    const isOffsetParentAnElement = isHTMLElement(offsetParent);
    const documentElement = getDocumentElement(offsetParent);
    const isFixed = strategy === "fixed";
    const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
    let scroll = {
      scrollLeft: 0,
      scrollTop: 0
    };
    const offsets = createCoords(0);
    if (isOffsetParentAnElement || !isFixed) {
      if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) {
        scroll = getNodeScroll(offsetParent);
      }
      if (isOffsetParentAnElement) {
        const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
        offsets.x = offsetRect.x + offsetParent.clientLeft;
        offsets.y = offsetRect.y + offsetParent.clientTop;
      }
    }
    if (!isOffsetParentAnElement && documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
    const x = rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x;
    const y = rect.top + scroll.scrollTop - offsets.y - htmlOffset.y;
    return {
      x,
      y,
      width: rect.width,
      height: rect.height
    };
  }
  function isStaticPositioned(element) {
    return getComputedStyle2(element).position === "static";
  }
  function getTrueOffsetParent(element, polyfill) {
    if (!isHTMLElement(element) || getComputedStyle2(element).position === "fixed") {
      return null;
    }
    if (polyfill) {
      return polyfill(element);
    }
    let rawOffsetParent = element.offsetParent;
    if (getDocumentElement(element) === rawOffsetParent) {
      rawOffsetParent = rawOffsetParent.ownerDocument.body;
    }
    return rawOffsetParent;
  }
  function getOffsetParent(element, polyfill) {
    const win = getWindow(element);
    if (isTopLayer(element)) {
      return win;
    }
    if (!isHTMLElement(element)) {
      let svgOffsetParent = getParentNode(element);
      while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
        if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) {
          return svgOffsetParent;
        }
        svgOffsetParent = getParentNode(svgOffsetParent);
      }
      return win;
    }
    let offsetParent = getTrueOffsetParent(element, polyfill);
    while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) {
      offsetParent = getTrueOffsetParent(offsetParent, polyfill);
    }
    if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) {
      return win;
    }
    return offsetParent || getContainingBlock(element) || win;
  }
  var getElementRects = async function(data) {
    const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
    const getDimensionsFn = this.getDimensions;
    const floatingDimensions = await getDimensionsFn(data.floating);
    return {
      reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
      floating: {
        x: 0,
        y: 0,
        width: floatingDimensions.width,
        height: floatingDimensions.height
      }
    };
  };
  function isRTL(element) {
    return getComputedStyle2(element).direction === "rtl";
  }
  var platform = {
    convertOffsetParentRelativeRectToViewportRelativeRect,
    getDocumentElement,
    getClippingRect,
    getOffsetParent,
    getElementRects,
    getClientRects,
    getDimensions,
    getScale,
    isElement,
    isRTL
  };
  function rectsAreEqual(a, b) {
    return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
  }
  function observeMove(element, onMove, ancestorResize) {
    let io = null;
    let timeoutId;
    const root = getDocumentElement(element);
    function cleanup() {
      var _io;
      clearTimeout(timeoutId);
      (_io = io) == null || _io.disconnect();
      io = null;
    }
    function refresh(skip, threshold) {
      if (skip === void 0) {
        skip = false;
      }
      if (threshold === void 0) {
        threshold = 1;
      }
      cleanup();
      const elementRectForRootMargin = element.getBoundingClientRect();
      const {
        left,
        top,
        width,
        height
      } = elementRectForRootMargin;
      if (!skip) {
        onMove();
      }
      if (!width || !height) {
        return;
      }
      const insetTop = floor(top);
      const insetRight = floor(root.clientWidth - (left + width));
      const insetBottom = floor(root.clientHeight - (top + height));
      const insetLeft = floor(left);
      const rootMargin = -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px";
      const options2 = {
        rootMargin,
        threshold: max(0, min(1, threshold)) || 1
      };
      let isFirstUpdate = true;
      function handleObserve(entries) {
        const ratio = entries[0].intersectionRatio;
        if (!rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) {
          return refresh();
        }
        if (ratio !== threshold) {
          if (!isFirstUpdate) {
            return refresh();
          }
          if (!ratio) {
            timeoutId = setTimeout(() => {
              refresh(false, 1e-7);
            }, 1e3);
          } else {
            refresh(false, ratio);
          }
        }
        isFirstUpdate = false;
      }
      try {
        io = new IntersectionObserver(handleObserve, {
          ...options2,
          // Handle <iframe>s
          root: root.ownerDocument
        });
      } catch (_e) {
        io = new IntersectionObserver(handleObserve, options2);
      }
      io.observe(element);
    }
    const win = getWindow(element);
    const handleResize = () => refresh(ancestorResize);
    win.addEventListener("resize", handleResize);
    refresh(true);
    return () => {
      win.removeEventListener("resize", handleResize);
      cleanup();
    };
  }
  function autoUpdate(reference, floating, update, options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    const {
      ancestorScroll = true,
      ancestorResize = true,
      elementResize = typeof ResizeObserver === "function",
      layoutShift = typeof IntersectionObserver === "function",
      animationFrame = false
    } = options2;
    const referenceEl = unwrapElement(reference);
    const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
    ancestors.forEach((ancestor) => {
      ancestorScroll && ancestor.addEventListener("scroll", update);
      ancestorResize && ancestor.addEventListener("resize", update);
    });
    const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update, ancestorResize) : null;
    let reobserveFrame = -1;
    let resizeObserver = null;
    if (elementResize) {
      resizeObserver = new ResizeObserver((_ref) => {
        let [firstEntry] = _ref;
        if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
          resizeObserver.unobserve(floating);
          cancelAnimationFrame(reobserveFrame);
          reobserveFrame = requestAnimationFrame(() => {
            var _resizeObserver;
            (_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
          });
        }
        update();
      });
      if (referenceEl && !animationFrame) {
        resizeObserver.observe(referenceEl);
      }
      if (floating) {
        resizeObserver.observe(floating);
      }
    }
    let frameId;
    let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
    if (animationFrame) {
      frameLoop();
    }
    function frameLoop() {
      const nextRefRect = getBoundingClientRect(reference);
      if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) {
        update();
      }
      prevRefRect = nextRefRect;
      frameId = requestAnimationFrame(frameLoop);
    }
    update();
    return () => {
      var _resizeObserver2;
      ancestors.forEach((ancestor) => {
        ancestorScroll && ancestor.removeEventListener("scroll", update);
        ancestorResize && ancestor.removeEventListener("resize", update);
      });
      cleanupIo == null || cleanupIo();
      (_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
      resizeObserver = null;
      if (animationFrame) {
        cancelAnimationFrame(frameId);
      }
    };
  }
  var offset2 = offset;
  var shift2 = shift;
  var flip2 = flip;
  var size2 = size;
  var hide2 = hide;
  var arrow2 = arrow;
  var limitShift2 = limitShift;
  var computePosition2 = (reference, floating, options2) => {
    const cache = /* @__PURE__ */ new Map();
    const mergedOptions = options2 != null ? options2 : {};
    const platformWithCache = {
      ...platform,
      ...mergedOptions.platform,
      _c: cache
    };
    return computePosition(reference, floating, {
      ...mergedOptions,
      platform: platformWithCache
    });
  };

  // src/client/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
  var React2 = __toESM(require_react_shim(), 1);
  var import_react4 = __toESM(require_react_shim(), 1);
  var ReactDOM = __toESM(require_react_dom_shim(), 1);
  var isClient = typeof document !== "undefined";
  var noop = function noop2() {
  };
  var index = isClient ? import_react4.useLayoutEffect : noop;
  function deepEqual(a, b) {
    if (a === b) {
      return true;
    }
    if (typeof a !== typeof b) {
      return false;
    }
    if (typeof a === "function" && a.toString() === b.toString()) {
      return true;
    }
    let length;
    let i;
    let keys;
    if (a && b && typeof a === "object") {
      if (Array.isArray(a)) {
        length = a.length;
        if (length !== b.length) return false;
        for (i = length; i-- !== 0; ) {
          if (!deepEqual(a[i], b[i])) {
            return false;
          }
        }
        return true;
      }
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length) {
        return false;
      }
      for (i = length; i-- !== 0; ) {
        if (!{}.hasOwnProperty.call(b, keys[i])) {
          return false;
        }
      }
      for (i = length; i-- !== 0; ) {
        const key = keys[i];
        if (key === "_owner" && a.$$typeof) {
          continue;
        }
        if (!deepEqual(a[key], b[key])) {
          return false;
        }
      }
      return true;
    }
    return a !== a && b !== b;
  }
  function getDPR(element) {
    if (typeof window === "undefined") {
      return 1;
    }
    const win = element.ownerDocument.defaultView || window;
    return win.devicePixelRatio || 1;
  }
  function roundByDPR(element, value) {
    const dpr = getDPR(element);
    return Math.round(value * dpr) / dpr;
  }
  function useLatestRef(value) {
    const ref = React2.useRef(value);
    index(() => {
      ref.current = value;
    });
    return ref;
  }
  function useFloating(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    const {
      placement = "bottom",
      strategy = "absolute",
      middleware = [],
      platform: platform2,
      elements: {
        reference: externalReference,
        floating: externalFloating
      } = {},
      transform = true,
      whileElementsMounted,
      open
    } = options2;
    const [data, setData] = React2.useState({
      x: 0,
      y: 0,
      strategy,
      placement,
      middlewareData: {},
      isPositioned: false
    });
    const [latestMiddleware, setLatestMiddleware] = React2.useState(middleware);
    if (!deepEqual(latestMiddleware, middleware)) {
      setLatestMiddleware(middleware);
    }
    const [_reference, _setReference] = React2.useState(null);
    const [_floating, _setFloating] = React2.useState(null);
    const setReference = React2.useCallback((node) => {
      if (node !== referenceRef.current) {
        referenceRef.current = node;
        _setReference(node);
      }
    }, []);
    const setFloating = React2.useCallback((node) => {
      if (node !== floatingRef.current) {
        floatingRef.current = node;
        _setFloating(node);
      }
    }, []);
    const referenceEl = externalReference || _reference;
    const floatingEl = externalFloating || _floating;
    const referenceRef = React2.useRef(null);
    const floatingRef = React2.useRef(null);
    const dataRef = React2.useRef(data);
    const hasWhileElementsMounted = whileElementsMounted != null;
    const whileElementsMountedRef = useLatestRef(whileElementsMounted);
    const platformRef = useLatestRef(platform2);
    const openRef = useLatestRef(open);
    const update = React2.useCallback(() => {
      if (!referenceRef.current || !floatingRef.current) {
        return;
      }
      const config = {
        placement,
        strategy,
        middleware: latestMiddleware
      };
      if (platformRef.current) {
        config.platform = platformRef.current;
      }
      computePosition2(referenceRef.current, floatingRef.current, config).then((data2) => {
        const fullData = {
          ...data2,
          // The floating element's position may be recomputed while it's closed
          // but still mounted (such as when transitioning out). To ensure
          // `isPositioned` will be `false` initially on the next open, avoid
          // setting it to `true` when `open === false` (must be specified).
          isPositioned: openRef.current !== false
        };
        if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
          dataRef.current = fullData;
          ReactDOM.flushSync(() => {
            setData(fullData);
          });
        }
      });
    }, [latestMiddleware, placement, strategy, platformRef, openRef]);
    index(() => {
      if (open === false && dataRef.current.isPositioned) {
        dataRef.current.isPositioned = false;
        setData((data2) => ({
          ...data2,
          isPositioned: false
        }));
      }
    }, [open]);
    const isMountedRef = React2.useRef(false);
    index(() => {
      isMountedRef.current = true;
      return () => {
        isMountedRef.current = false;
      };
    }, []);
    index(() => {
      if (referenceEl) referenceRef.current = referenceEl;
      if (floatingEl) floatingRef.current = floatingEl;
      if (referenceEl && floatingEl) {
        if (whileElementsMountedRef.current) {
          return whileElementsMountedRef.current(referenceEl, floatingEl, update);
        }
        update();
      }
    }, [referenceEl, floatingEl, update, whileElementsMountedRef, hasWhileElementsMounted]);
    const refs = React2.useMemo(() => ({
      reference: referenceRef,
      floating: floatingRef,
      setReference,
      setFloating
    }), [setReference, setFloating]);
    const elements = React2.useMemo(() => ({
      reference: referenceEl,
      floating: floatingEl
    }), [referenceEl, floatingEl]);
    const floatingStyles = React2.useMemo(() => {
      const initialStyles = {
        position: strategy,
        left: 0,
        top: 0
      };
      if (!elements.floating) {
        return initialStyles;
      }
      const x = roundByDPR(elements.floating, data.x);
      const y = roundByDPR(elements.floating, data.y);
      if (transform) {
        return {
          ...initialStyles,
          transform: "translate(" + x + "px, " + y + "px)",
          ...getDPR(elements.floating) >= 1.5 && {
            willChange: "transform"
          }
        };
      }
      return {
        position: strategy,
        left: x,
        top: y
      };
    }, [strategy, transform, elements.floating, data.x, data.y]);
    return React2.useMemo(() => ({
      ...data,
      update,
      refs,
      elements,
      floatingStyles
    }), [data, update, refs, elements, floatingStyles]);
  }
  var arrow$1 = (options2) => {
    function isRef(value) {
      return {}.hasOwnProperty.call(value, "current");
    }
    return {
      name: "arrow",
      options: options2,
      fn(state) {
        const {
          element,
          padding
        } = typeof options2 === "function" ? options2(state) : options2;
        if (element && isRef(element)) {
          if (element.current != null) {
            return arrow2({
              element: element.current,
              padding
            }).fn(state);
          }
          return {};
        }
        if (element) {
          return arrow2({
            element,
            padding
          }).fn(state);
        }
        return {};
      }
    };
  };
  var offset3 = (options2, deps) => {
    const result = offset2(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var shift3 = (options2, deps) => {
    const result = shift2(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var limitShift3 = (options2, deps) => {
    const result = limitShift2(options2);
    return {
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var flip3 = (options2, deps) => {
    const result = flip2(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var size3 = (options2, deps) => {
    const result = size2(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var hide3 = (options2, deps) => {
    const result = hide2(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };
  var arrow3 = (options2, deps) => {
    const result = arrow$1(options2);
    return {
      name: result.name,
      fn: result.fn,
      options: [options2, deps]
    };
  };

  // src/client/node_modules/@radix-ui/react-arrow/dist/index.mjs
  init_define_import_meta_env();
  var React6 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-primitive/dist/index.mjs
  init_define_import_meta_env();
  var React5 = __toESM(require_react_shim(), 1);
  var ReactDOM2 = __toESM(require_react_dom_shim(), 1);

  // src/client/node_modules/@radix-ui/react-slot/dist/index.mjs
  init_define_import_meta_env();
  var React4 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
  init_define_import_meta_env();
  var React3 = __toESM(require_react_shim(), 1);
  function setRef(ref, value) {
    if (typeof ref === "function") {
      return ref(value);
    } else if (ref !== null && ref !== void 0) {
      ref.current = value;
    }
  }
  function composeRefs(...refs) {
    return (node) => {
      let hasCleanup = false;
      const cleanups = refs.map((ref) => {
        const cleanup = setRef(ref, node);
        if (!hasCleanup && typeof cleanup == "function") {
          hasCleanup = true;
        }
        return cleanup;
      });
      if (hasCleanup) {
        return () => {
          for (let i = 0; i < cleanups.length; i++) {
            const cleanup = cleanups[i];
            if (typeof cleanup == "function") {
              cleanup();
            } else {
              setRef(refs[i], null);
            }
          }
        };
      }
    };
  }
  function useComposedRefs(...refs) {
    return React3.useCallback(composeRefs(...refs), refs);
  }

  // src/client/node_modules/@radix-ui/react-slot/dist/index.mjs
  // @__NO_SIDE_EFFECTS__
  function createSlot(ownerName) {
    const Slot22 = React4.forwardRef((props, forwardedRef) => {
      let { children, ...slotProps } = props;
      let slottableElement = null;
      let hasSlottable = false;
      const newChildren = [];
      if (isLazyComponent(children) && typeof use === "function") {
        children = use(children._payload);
      }
      React4.Children.forEach(children, (maybeSlottable) => {
        if (isSlottable(maybeSlottable)) {
          hasSlottable = true;
          const slottable = maybeSlottable;
          let child = "child" in slottable.props ? slottable.props.child : slottable.props.children;
          if (isLazyComponent(child) && typeof use === "function") {
            child = use(child._payload);
          }
          slottableElement = getSlottableElementFromSlottable(slottable, child);
          newChildren.push(slottableElement?.props?.children);
        } else {
          newChildren.push(maybeSlottable);
        }
      });
      if (slottableElement) {
        slottableElement = React4.cloneElement(slottableElement, void 0, newChildren);
      } else if (
        // A `Slottable` was found but it didn't resolve to a single element (e.g.
        // it wrapped multiple elements, text, or a render-prop `child` that
        // wasn't an element). Don't fall back to treating the `Slottable` wrapper
        // itself as the slot target — throw a descriptive error below instead.
        !hasSlottable && React4.Children.count(children) === 1 && React4.isValidElement(children)
      ) {
        slottableElement = children;
      }
      const slottableElementRef = slottableElement ? getElementRef(slottableElement) : void 0;
      const composedRef = useComposedRefs(forwardedRef, slottableElementRef);
      if (!slottableElement) {
        if (children || children === 0) {
          throw new Error(
            hasSlottable ? createSlottableError(ownerName) : createSlotError(ownerName)
          );
        }
        return children;
      }
      const mergedProps = mergeProps(slotProps, slottableElement.props ?? {});
      if (slottableElement.type !== React4.Fragment) {
        mergedProps.ref = forwardedRef ? composedRef : slottableElementRef;
      }
      return React4.cloneElement(slottableElement, mergedProps);
    });
    Slot22.displayName = `${ownerName}.Slot`;
    return Slot22;
  }
  var SLOTTABLE_IDENTIFIER = /* @__PURE__ */ Symbol.for("radix.slottable");
  var getSlottableElementFromSlottable = (slottable, child) => {
    if ("child" in slottable.props) {
      const child2 = slottable.props.child;
      if (!React4.isValidElement(child2)) return null;
      return React4.cloneElement(child2, void 0, slottable.props.children(child2.props.children));
    }
    return React4.isValidElement(child) ? child : null;
  };
  function mergeProps(slotProps, childProps) {
    const overrideProps = { ...childProps };
    for (const propName in childProps) {
      const slotPropValue = slotProps[propName];
      const childPropValue = childProps[propName];
      const isHandler = /^on[A-Z]/.test(propName);
      if (isHandler) {
        if (slotPropValue && childPropValue) {
          overrideProps[propName] = (...args) => {
            const result = childPropValue(...args);
            slotPropValue(...args);
            return result;
          };
        } else if (slotPropValue) {
          overrideProps[propName] = slotPropValue;
        }
      } else if (propName === "style") {
        overrideProps[propName] = { ...slotPropValue, ...childPropValue };
      } else if (propName === "className") {
        overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
      }
    }
    return { ...slotProps, ...overrideProps };
  }
  function getElementRef(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
    let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.ref;
    }
    getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
    mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.props.ref;
    }
    return element.props.ref || element.ref;
  }
  function isSlottable(child) {
    return React4.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER;
  }
  var REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy");
  function isLazyComponent(element) {
    return element != null && typeof element === "object" && "$$typeof" in element && element.$$typeof === REACT_LAZY_TYPE && "_payload" in element && isPromiseLike(element._payload);
  }
  function isPromiseLike(value) {
    return typeof value === "object" && value !== null && "then" in value;
  }
  var createSlotError = (ownerName) => {
    return `${ownerName} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`;
  };
  var createSlottableError = (ownerName) => {
    return `${ownerName} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`;
  };
  var use = React4[" use ".trim().toString()];

  // src/client/node_modules/@radix-ui/react-primitive/dist/index.mjs
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var NODES = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ];
  var Primitive = NODES.reduce((primitive, node) => {
    const Slot5 = createSlot(`Primitive.${node}`);
    const Node2 = React5.forwardRef((props, forwardedRef) => {
      const { asChild, ...primitiveProps } = props;
      const Comp = asChild ? Slot5 : node;
      if (typeof window !== "undefined") {
        window[/* @__PURE__ */ Symbol.for("radix-ui")] = true;
      }
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, { ...primitiveProps, ref: forwardedRef });
    });
    Node2.displayName = `Primitive.${node}`;
    return { ...primitive, [node]: Node2 };
  }, {});
  function dispatchDiscreteCustomEvent(target, event) {
    if (target) ReactDOM2.flushSync(() => target.dispatchEvent(event));
  }

  // src/client/node_modules/@radix-ui/react-arrow/dist/index.mjs
  var import_jsx_runtime2 = __toESM(require_react_shim(), 1);
  var NAME = "Arrow";
  var Arrow = React6.forwardRef((props, forwardedRef) => {
    const { children, width = 10, height = 5, ...arrowProps } = props;
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      Primitive.svg,
      {
        ...arrowProps,
        ref: forwardedRef,
        width,
        height,
        viewBox: "0 0 30 10",
        preserveAspectRatio: "none",
        children: props.asChild ? children : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("polygon", { points: "0,0 30,0 15,10" })
      }
    );
  });
  Arrow.displayName = NAME;
  var Root = Arrow;

  // src/client/node_modules/@radix-ui/react-context/dist/index.mjs
  init_define_import_meta_env();
  var React7 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime3 = __toESM(require_react_shim(), 1);
  function createContextScope(scopeName, createContextScopeDeps = []) {
    let defaultContexts = [];
    function createContext32(rootComponentName, defaultContext) {
      const BaseContext = React7.createContext(defaultContext);
      BaseContext.displayName = rootComponentName + "Context";
      const index2 = defaultContexts.length;
      defaultContexts = [...defaultContexts, defaultContext];
      const Provider2 = (props) => {
        const { scope, children, ...context } = props;
        const Context = scope?.[scopeName]?.[index2] || BaseContext;
        const value = React7.useMemo(() => context, Object.values(context));
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Context.Provider, { value, children });
      };
      Provider2.displayName = rootComponentName + "Provider";
      function useContext22(consumerName, scope) {
        const Context = scope?.[scopeName]?.[index2] || BaseContext;
        const context = React7.useContext(Context);
        if (context) return context;
        if (defaultContext !== void 0) return defaultContext;
        throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
      }
      return [Provider2, useContext22];
    }
    const createScope = () => {
      const scopeContexts = defaultContexts.map((defaultContext) => {
        return React7.createContext(defaultContext);
      });
      return function useScope(scope) {
        const contexts = scope?.[scopeName] || scopeContexts;
        return React7.useMemo(
          () => ({ [`__scope${scopeName}`]: { ...scope, [scopeName]: contexts } }),
          [scope, contexts]
        );
      };
    };
    createScope.scopeName = scopeName;
    return [createContext32, composeContextScopes(createScope, ...createContextScopeDeps)];
  }
  function composeContextScopes(...scopes) {
    const baseScope = scopes[0];
    if (scopes.length === 1) return baseScope;
    const createScope = () => {
      const scopeHooks = scopes.map((createScope2) => ({
        useScope: createScope2(),
        scopeName: createScope2.scopeName
      }));
      return function useComposedScopes(overrideScopes) {
        const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
          const scopeProps = useScope(overrideScopes);
          const currentScope = scopeProps[`__scope${scopeName}`];
          return { ...nextScopes2, ...currentScope };
        }, {});
        return React7.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
      };
    };
    createScope.scopeName = baseScope.scopeName;
    return createScope;
  }

  // src/client/node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
  init_define_import_meta_env();
  var React8 = __toESM(require_react_shim(), 1);
  function useCallbackRef(callback) {
    const callbackRef = React8.useRef(callback);
    React8.useEffect(() => {
      callbackRef.current = callback;
    });
    return React8.useMemo(() => ((...args) => callbackRef.current?.(...args)), []);
  }

  // src/client/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
  init_define_import_meta_env();
  var React9 = __toESM(require_react_shim(), 1);
  var useLayoutEffect22 = globalThis?.document ? React9.useLayoutEffect : () => {
  };

  // src/client/node_modules/@radix-ui/react-use-size/dist/index.mjs
  init_define_import_meta_env();
  var React10 = __toESM(require_react_shim(), 1);
  function useSize(element) {
    const [size4, setSize] = React10.useState(void 0);
    useLayoutEffect22(() => {
      if (element) {
        setSize({ width: element.offsetWidth, height: element.offsetHeight });
        const resizeObserver = new ResizeObserver((entries) => {
          if (!Array.isArray(entries)) {
            return;
          }
          if (!entries.length) {
            return;
          }
          const entry = entries[0];
          let width;
          let height;
          if ("borderBoxSize" in entry) {
            const borderSizeEntry = entry["borderBoxSize"];
            const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
            width = borderSize["inlineSize"];
            height = borderSize["blockSize"];
          } else {
            width = element.offsetWidth;
            height = element.offsetHeight;
          }
          setSize({ width, height });
        });
        resizeObserver.observe(element, { box: "border-box" });
        return () => resizeObserver.unobserve(element);
      } else {
        setSize(void 0);
      }
    }, [element]);
    return size4;
  }

  // src/client/node_modules/@radix-ui/react-popper/dist/index.mjs
  var import_jsx_runtime4 = __toESM(require_react_shim(), 1);
  var POPPER_NAME = "Popper";
  var [createPopperContext, createPopperScope] = createContextScope(POPPER_NAME);
  var [PopperProvider, usePopperContext] = createPopperContext(POPPER_NAME);
  var Popper = (props) => {
    const { __scopePopper, children } = props;
    const [anchor, setAnchor] = React11.useState(null);
    const [placementState, setPlacementState] = React11.useState(void 0);
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      PopperProvider,
      {
        scope: __scopePopper,
        anchor,
        onAnchorChange: setAnchor,
        placementState,
        setPlacementState,
        children
      }
    );
  };
  Popper.displayName = POPPER_NAME;
  var ANCHOR_NAME = "PopperAnchor";
  var PopperAnchor = React11.forwardRef(
    (props, forwardedRef) => {
      const { __scopePopper, virtualRef, ...anchorProps } = props;
      const context = usePopperContext(ANCHOR_NAME, __scopePopper);
      const ref = React11.useRef(null);
      const onAnchorChange = context.onAnchorChange;
      const callbackRef = React11.useCallback(
        (node) => {
          ref.current = node;
          if (node) {
            onAnchorChange(node);
          }
        },
        [onAnchorChange]
      );
      const composedRefs = useComposedRefs(forwardedRef, callbackRef);
      const anchorRef = React11.useRef(null);
      React11.useEffect(() => {
        if (!virtualRef) {
          return;
        }
        const previousAnchor = anchorRef.current;
        anchorRef.current = virtualRef.current;
        if (previousAnchor !== anchorRef.current) {
          onAnchorChange(anchorRef.current);
        }
      });
      const sideAndAlign = context.placementState && getSideAndAlignFromPlacement(context.placementState);
      const placedSide = sideAndAlign?.[0];
      const placedAlign = sideAndAlign?.[1];
      return virtualRef ? null : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        Primitive.div,
        {
          "data-radix-popper-side": placedSide,
          "data-radix-popper-align": placedAlign,
          ...anchorProps,
          ref: composedRefs
        }
      );
    }
  );
  PopperAnchor.displayName = ANCHOR_NAME;
  var CONTENT_NAME = "PopperContent";
  var [PopperContentProvider, useContentContext] = createPopperContext(CONTENT_NAME);
  var PopperContent = React11.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopePopper,
        side = "bottom",
        sideOffset = 0,
        align = "center",
        alignOffset = 0,
        arrowPadding = 0,
        avoidCollisions = true,
        collisionBoundary = [],
        collisionPadding: collisionPaddingProp = 0,
        sticky = "partial",
        hideWhenDetached = false,
        updatePositionStrategy = "optimized",
        onPlaced,
        ...contentProps
      } = props;
      const context = usePopperContext(CONTENT_NAME, __scopePopper);
      const [content, setContent] = React11.useState(null);
      const composedRefs = useComposedRefs(forwardedRef, (node) => setContent(node));
      const [arrow4, setArrow] = React11.useState(null);
      const arrowSize = useSize(arrow4);
      const arrowWidth = arrowSize?.width ?? 0;
      const arrowHeight = arrowSize?.height ?? 0;
      const desiredPlacement = side + (align !== "center" ? "-" + align : "");
      const collisionPadding = typeof collisionPaddingProp === "number" ? collisionPaddingProp : { top: 0, right: 0, bottom: 0, left: 0, ...collisionPaddingProp };
      const boundary = Array.isArray(collisionBoundary) ? collisionBoundary : [collisionBoundary];
      const hasExplicitBoundaries = boundary.length > 0;
      const detectOverflowOptions = {
        padding: collisionPadding,
        boundary: boundary.filter(isNotNull),
        // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
        altBoundary: hasExplicitBoundaries
      };
      const { refs, floatingStyles, placement, isPositioned, middlewareData } = useFloating({
        // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
        strategy: "fixed",
        placement: desiredPlacement,
        whileElementsMounted: (...args) => {
          const cleanup = autoUpdate(...args, {
            animationFrame: updatePositionStrategy === "always"
          });
          return cleanup;
        },
        elements: {
          reference: context.anchor
        },
        middleware: [
          offset3({ mainAxis: sideOffset + arrowHeight, alignmentAxis: alignOffset }),
          avoidCollisions && shift3({
            mainAxis: true,
            crossAxis: false,
            limiter: sticky === "partial" ? limitShift3() : void 0,
            ...detectOverflowOptions
          }),
          avoidCollisions && flip3({ ...detectOverflowOptions }),
          size3({
            ...detectOverflowOptions,
            apply: ({ elements, rects, availableWidth, availableHeight }) => {
              const { width: anchorWidth, height: anchorHeight } = rects.reference;
              const contentStyle = elements.floating.style;
              contentStyle.setProperty("--radix-popper-available-width", `${availableWidth}px`);
              contentStyle.setProperty("--radix-popper-available-height", `${availableHeight}px`);
              contentStyle.setProperty("--radix-popper-anchor-width", `${anchorWidth}px`);
              contentStyle.setProperty("--radix-popper-anchor-height", `${anchorHeight}px`);
            }
          }),
          arrow4 && arrow3({ element: arrow4, padding: arrowPadding }),
          transformOrigin({ arrowWidth, arrowHeight }),
          hideWhenDetached && hide3({
            strategy: "referenceHidden",
            ...detectOverflowOptions,
            // `hide` detects whether the anchor (reference) is clipped, so when
            // no explicit `collisionBoundary` is set we fall back to Floating
            // UI's default clipping ancestors (e.g. a scrollable menu). This
            // lets an occluded submenu hide once its anchor scrolls out of view
            // (#3237). The collision/size middlewares deliberately keep the
            // viewport-based default to avoid clamping content rendered inside
            // transformed or overflow-clipping portal containers.
            boundary: hasExplicitBoundaries ? detectOverflowOptions.boundary : void 0
          })
        ]
      });
      const setPlacementState = context.setPlacementState;
      useLayoutEffect22(() => {
        setPlacementState(placement);
        return () => {
          setPlacementState(void 0);
        };
      }, [placement, setPlacementState]);
      const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
      const handlePlaced = useCallbackRef(onPlaced);
      useLayoutEffect22(() => {
        if (isPositioned) {
          handlePlaced?.();
        }
      }, [isPositioned, handlePlaced]);
      const arrowX = middlewareData.arrow?.x;
      const arrowY = middlewareData.arrow?.y;
      const cannotCenterArrow = middlewareData.arrow?.centerOffset !== 0;
      const [contentZIndex, setContentZIndex] = React11.useState();
      useLayoutEffect22(() => {
        if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
      }, [content]);
      return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "div",
        {
          ref: refs.setFloating,
          "data-radix-popper-content-wrapper": "",
          style: {
            ...floatingStyles,
            transform: isPositioned ? floatingStyles.transform : "translate(0, -200%)",
            // keep off the page when measuring
            minWidth: "max-content",
            zIndex: contentZIndex,
            "--radix-popper-transform-origin": [
              middlewareData.transformOrigin?.x,
              middlewareData.transformOrigin?.y
            ].join(" "),
            // hide the content if using the hide middleware and should be hidden
            // set visibility to hidden and disable pointer events so the UI behaves
            // as if the PopperContent isn't there at all
            ...middlewareData.hide?.referenceHidden && {
              visibility: "hidden",
              pointerEvents: "none"
            }
          },
          dir: props.dir,
          children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            PopperContentProvider,
            {
              scope: __scopePopper,
              placedSide,
              placedAlign,
              onArrowChange: setArrow,
              arrowX,
              arrowY,
              shouldHideArrow: cannotCenterArrow,
              children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                Primitive.div,
                {
                  "data-side": placedSide,
                  "data-align": placedAlign,
                  ...contentProps,
                  ref: composedRefs,
                  style: {
                    ...contentProps.style,
                    // if the PopperContent hasn't been placed yet (not all measurements done)
                    // we prevent animations so that users's animation don't kick in too early referring wrong sides
                    animation: !isPositioned ? "none" : void 0
                  }
                }
              )
            }
          )
        }
      );
    }
  );
  PopperContent.displayName = CONTENT_NAME;
  var ARROW_NAME = "PopperArrow";
  var OPPOSITE_SIDE = {
    top: "bottom",
    right: "left",
    bottom: "top",
    left: "right"
  };
  var PopperArrow = React11.forwardRef(function PopperArrow2(props, forwardedRef) {
    const { __scopePopper, ...arrowProps } = props;
    const contentContext = useContentContext(ARROW_NAME, __scopePopper);
    const baseSide = OPPOSITE_SIDE[contentContext.placedSide];
    return (
      // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
      // doesn't report size as we'd expect on SVG elements.
      // it reports their bounding box which is effectively the largest path inside the SVG.
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "span",
        {
          ref: contentContext.onArrowChange,
          style: {
            position: "absolute",
            left: contentContext.arrowX,
            top: contentContext.arrowY,
            [baseSide]: 0,
            transformOrigin: {
              top: "",
              right: "0 0",
              bottom: "center 0",
              left: "100% 0"
            }[contentContext.placedSide],
            transform: {
              top: "translateY(100%)",
              right: "translateY(50%) rotate(90deg) translateX(-50%)",
              bottom: `rotate(180deg)`,
              left: "translateY(50%) rotate(-90deg) translateX(50%)"
            }[contentContext.placedSide],
            visibility: contentContext.shouldHideArrow ? "hidden" : void 0
          },
          children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            Root,
            {
              ...arrowProps,
              ref: forwardedRef,
              style: {
                ...arrowProps.style,
                // ensures the element can be measured correctly (mostly for if SVG)
                display: "block"
              }
            }
          )
        }
      )
    );
  });
  PopperArrow.displayName = ARROW_NAME;
  function isNotNull(value) {
    return value !== null;
  }
  var transformOrigin = (options2) => ({
    name: "transformOrigin",
    options: options2,
    fn(data) {
      const { placement, rects, middlewareData } = data;
      const cannotCenterArrow = middlewareData.arrow?.centerOffset !== 0;
      const isArrowHidden = cannotCenterArrow;
      const arrowWidth = isArrowHidden ? 0 : options2.arrowWidth;
      const arrowHeight = isArrowHidden ? 0 : options2.arrowHeight;
      const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
      const noArrowAlign = { start: "0%", center: "50%", end: "100%" }[placedAlign];
      const arrowXCenter = (middlewareData.arrow?.x ?? 0) + arrowWidth / 2;
      const arrowYCenter = (middlewareData.arrow?.y ?? 0) + arrowHeight / 2;
      let x = "";
      let y = "";
      if (placedSide === "bottom") {
        x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
        y = `${-arrowHeight}px`;
      } else if (placedSide === "top") {
        x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
        y = `${rects.floating.height + arrowHeight}px`;
      } else if (placedSide === "right") {
        x = `${-arrowHeight}px`;
        y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
      } else if (placedSide === "left") {
        x = `${rects.floating.width + arrowHeight}px`;
        y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
      }
      return { data: { x, y } };
    }
  });
  function getSideAndAlignFromPlacement(placement) {
    const [side, align = "center"] = placement.split("-");
    return [side, align];
  }
  var Root2 = Popper;
  var Anchor = PopperAnchor;
  var Content = PopperContent;
  var Arrow2 = PopperArrow;

  // src/client/node_modules/@radix-ui/react-portal/dist/index.mjs
  init_define_import_meta_env();
  var React12 = __toESM(require_react_shim(), 1);
  var ReactDOM3 = __toESM(require_react_dom_shim(), 1);
  var import_jsx_runtime5 = __toESM(require_react_shim(), 1);
  var PORTAL_NAME = "Portal";
  var Portal = React12.forwardRef((props, forwardedRef) => {
    const { container: containerProp, ...portalProps } = props;
    const [mounted, setMounted] = React12.useState(false);
    useLayoutEffect22(() => setMounted(true), []);
    const container = containerProp || mounted && globalThis?.document?.body;
    return container ? ReactDOM3.createPortal(/* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Primitive.div, { ...portalProps, ref: forwardedRef }), container) : null;
  });
  Portal.displayName = PORTAL_NAME;

  // src/client/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
  init_define_import_meta_env();
  var React14 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/primitive/dist/index.mjs
  init_define_import_meta_env();
  var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
  function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
    return function handleEvent(event) {
      originalEventHandler?.(event);
      if (checkForDefaultPrevented === false || !event.defaultPrevented) {
        return ourEventHandler?.(event);
      }
    };
  }

  // src/client/node_modules/@radix-ui/react-use-escape-keydown/dist/index.mjs
  init_define_import_meta_env();
  var React13 = __toESM(require_react_shim(), 1);
  function useEscapeKeydown(onEscapeKeyDownProp, ownerDocument = globalThis?.document) {
    const onEscapeKeyDown = useCallbackRef(onEscapeKeyDownProp);
    React13.useEffect(() => {
      const handleKeyDown = (event) => {
        if (event.key === "Escape") {
          onEscapeKeyDown(event);
        }
      };
      ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
      return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
    }, [onEscapeKeyDown, ownerDocument]);
  }

  // src/client/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
  var import_jsx_runtime6 = __toESM(require_react_shim(), 1);
  var DISMISSABLE_LAYER_NAME = "DismissableLayer";
  var CONTEXT_UPDATE = "dismissableLayer.update";
  var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
  var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
  var originalBodyPointerEvents;
  var DismissableLayerContext = React14.createContext({
    layers: /* @__PURE__ */ new Set(),
    layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
    branches: /* @__PURE__ */ new Set(),
    // Outside elements that belong to a layer's own dismiss affordance (eg, a
    // dialog overlay). Pressing them should dismiss the layer regardless of
    // whether or not they stop propagation.
    //
    // See https://github.com/radix-ui/primitives/issues/3346
    dismissableSurfaces: /* @__PURE__ */ new Set()
  });
  var DismissableLayer = React14.forwardRef(
    (props, forwardedRef) => {
      const {
        disableOutsidePointerEvents = false,
        deferPointerDownOutside = false,
        onEscapeKeyDown,
        onPointerDownOutside,
        onFocusOutside,
        onInteractOutside,
        onDismiss,
        ...layerProps
      } = props;
      const context = React14.useContext(DismissableLayerContext);
      const [node, setNode] = React14.useState(null);
      const ownerDocument = node?.ownerDocument ?? globalThis?.document;
      const [, force] = React14.useState({});
      const composedRefs = useComposedRefs(forwardedRef, (node2) => setNode(node2));
      const layers = Array.from(context.layers);
      const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
      const highestLayerWithOutsidePointerEventsDisabledIndex = layers.indexOf(highestLayerWithOutsidePointerEventsDisabled);
      const index2 = node ? layers.indexOf(node) : -1;
      const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
      const isPointerEventsEnabled = index2 >= highestLayerWithOutsidePointerEventsDisabledIndex;
      const isDeferredPointerDownOutsideRef = React14.useRef(false);
      const pointerDownOutside = usePointerDownOutside(
        (event) => {
          const target = event.target;
          if (!(target instanceof Node)) {
            return;
          }
          const isPointerDownOnBranch = [...context.branches].some(
            (branch) => branch.contains(target)
          );
          if (!isPointerEventsEnabled || isPointerDownOnBranch) return;
          onPointerDownOutside?.(event);
          onInteractOutside?.(event);
          if (!event.defaultPrevented) onDismiss?.();
        },
        {
          ownerDocument,
          deferPointerDownOutside,
          isDeferredPointerDownOutsideRef,
          dismissableSurfaces: context.dismissableSurfaces
        }
      );
      const focusOutside = useFocusOutside((event) => {
        if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) {
          return;
        }
        const target = event.target;
        const isFocusInBranch = [...context.branches].some((branch) => branch.contains(target));
        if (isFocusInBranch) return;
        onFocusOutside?.(event);
        onInteractOutside?.(event);
        if (!event.defaultPrevented) onDismiss?.();
      }, ownerDocument);
      useEscapeKeydown((event) => {
        const isHighestLayer = index2 === context.layers.size - 1;
        if (!isHighestLayer) return;
        onEscapeKeyDown?.(event);
        if (!event.defaultPrevented && onDismiss) {
          event.preventDefault();
          onDismiss();
        }
      }, ownerDocument);
      React14.useEffect(() => {
        if (!node) return;
        if (disableOutsidePointerEvents) {
          if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
            originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
            ownerDocument.body.style.pointerEvents = "none";
          }
          context.layersWithOutsidePointerEventsDisabled.add(node);
        }
        context.layers.add(node);
        dispatchUpdate();
        return () => {
          if (disableOutsidePointerEvents) {
            context.layersWithOutsidePointerEventsDisabled.delete(node);
            if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
              ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
            }
          }
        };
      }, [node, ownerDocument, disableOutsidePointerEvents, context]);
      React14.useEffect(() => {
        return () => {
          if (!node) return;
          context.layers.delete(node);
          context.layersWithOutsidePointerEventsDisabled.delete(node);
          dispatchUpdate();
        };
      }, [node, context]);
      React14.useEffect(() => {
        const handleUpdate = () => force({});
        document.addEventListener(CONTEXT_UPDATE, handleUpdate);
        return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
        Primitive.div,
        {
          ...layerProps,
          ref: composedRefs,
          style: {
            pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
            ...props.style
          },
          onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
          onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
          onPointerDownCapture: composeEventHandlers(
            props.onPointerDownCapture,
            pointerDownOutside.onPointerDownCapture
          )
        }
      );
    }
  );
  DismissableLayer.displayName = DISMISSABLE_LAYER_NAME;
  var BRANCH_NAME = "DismissableLayerBranch";
  var DismissableLayerBranch = React14.forwardRef((props, forwardedRef) => {
    const context = React14.useContext(DismissableLayerContext);
    const ref = React14.useRef(null);
    const composedRefs = useComposedRefs(forwardedRef, ref);
    React14.useEffect(() => {
      const node = ref.current;
      if (node) {
        context.branches.add(node);
        return () => {
          context.branches.delete(node);
        };
      }
    }, [context.branches]);
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Primitive.div, { ...props, ref: composedRefs });
  });
  DismissableLayerBranch.displayName = BRANCH_NAME;
  function useDismissableLayerSurface() {
    const context = React14.useContext(DismissableLayerContext);
    const [node, setNode] = React14.useState(null);
    React14.useEffect(() => {
      if (!node) {
        return;
      }
      context.dismissableSurfaces.add(node);
      return () => {
        context.dismissableSurfaces.delete(node);
      };
    }, [node, context.dismissableSurfaces]);
    return setNode;
  }
  function usePointerDownOutside(onPointerDownOutside, args) {
    const {
      ownerDocument = globalThis?.document,
      deferPointerDownOutside = false,
      isDeferredPointerDownOutsideRef,
      dismissableSurfaces
    } = args;
    const handlePointerDownOutside = useCallbackRef(onPointerDownOutside);
    const isPointerInsideReactTreeRef = React14.useRef(false);
    const isPointerDownOutsideRef = React14.useRef(false);
    const interceptedOutsideInteractionEventsRef = React14.useRef(/* @__PURE__ */ new Map());
    const handleClickRef = React14.useRef(() => {
    });
    React14.useEffect(() => {
      function resetOutsideInteraction() {
        isPointerDownOutsideRef.current = false;
        isDeferredPointerDownOutsideRef.current = false;
        interceptedOutsideInteractionEventsRef.current.clear();
      }
      function isOutsideInteractionIntercepted() {
        return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
      }
      function handleInteractionCapture(event) {
        if (!isPointerDownOutsideRef.current) {
          return;
        }
        const target = event.target;
        const isDismissableSurface = target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target));
        if (!isDismissableSurface) {
          interceptedOutsideInteractionEventsRef.current.set(event.type, true);
        }
        if (event.type === "click") {
          window.setTimeout(() => {
            if (isPointerDownOutsideRef.current) {
              handleClickRef.current();
            }
          }, 0);
        }
      }
      function handleInteractionBubble(event) {
        if (isPointerDownOutsideRef.current) {
          interceptedOutsideInteractionEventsRef.current.set(event.type, false);
        }
      }
      const handlePointerDown = (event) => {
        if (event.target && !isPointerInsideReactTreeRef.current) {
          let handleAndDispatchPointerDownOutsideEvent2 = function() {
            ownerDocument.removeEventListener("click", handleClickRef.current);
            const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
            resetOutsideInteraction();
            if (!wasOutsideInteractionIntercepted) {
              handleAndDispatchCustomEvent(
                POINTER_DOWN_OUTSIDE,
                handlePointerDownOutside,
                eventDetail,
                { discrete: true }
              );
            }
          };
          var handleAndDispatchPointerDownOutsideEvent = handleAndDispatchPointerDownOutsideEvent2;
          const eventDetail = { originalEvent: event };
          isPointerDownOutsideRef.current = true;
          isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
          interceptedOutsideInteractionEventsRef.current.clear();
          if (!deferPointerDownOutside || event.button !== 0) {
            handleAndDispatchPointerDownOutsideEvent2();
          } else {
            ownerDocument.removeEventListener("click", handleClickRef.current);
            handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
            ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
          }
        } else {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          resetOutsideInteraction();
        }
        isPointerInsideReactTreeRef.current = false;
      };
      const outsideInteractionEvents = [
        "pointerup",
        "mousedown",
        "mouseup",
        "touchstart",
        "touchend",
        "click"
      ];
      for (const eventName of outsideInteractionEvents) {
        ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
        ownerDocument.addEventListener(eventName, handleInteractionBubble);
      }
      const timerId = window.setTimeout(() => {
        ownerDocument.addEventListener("pointerdown", handlePointerDown);
      }, 0);
      return () => {
        window.clearTimeout(timerId);
        ownerDocument.removeEventListener("pointerdown", handlePointerDown);
        ownerDocument.removeEventListener("click", handleClickRef.current);
        for (const eventName of outsideInteractionEvents) {
          ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
          ownerDocument.removeEventListener(eventName, handleInteractionBubble);
        }
      };
    }, [
      ownerDocument,
      handlePointerDownOutside,
      deferPointerDownOutside,
      isDeferredPointerDownOutsideRef,
      dismissableSurfaces
    ]);
    return {
      // ensures we check React component tree (not just DOM tree)
      onPointerDownCapture: () => isPointerInsideReactTreeRef.current = true
    };
  }
  function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
    const handleFocusOutside = useCallbackRef(onFocusOutside);
    const isFocusInsideReactTreeRef = React14.useRef(false);
    React14.useEffect(() => {
      const handleFocus = (event) => {
        if (event.target && !isFocusInsideReactTreeRef.current) {
          const eventDetail = { originalEvent: event };
          handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, eventDetail, {
            discrete: false
          });
        }
      };
      ownerDocument.addEventListener("focusin", handleFocus);
      return () => ownerDocument.removeEventListener("focusin", handleFocus);
    }, [ownerDocument, handleFocusOutside]);
    return {
      onFocusCapture: () => isFocusInsideReactTreeRef.current = true,
      onBlurCapture: () => isFocusInsideReactTreeRef.current = false
    };
  }
  function dispatchUpdate() {
    const event = new CustomEvent(CONTEXT_UPDATE);
    document.dispatchEvent(event);
  }
  function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
    const target = detail.originalEvent.target;
    const event = new CustomEvent(name, { bubbles: false, cancelable: true, detail });
    if (handler) target.addEventListener(name, handler, { once: true });
    if (discrete) {
      dispatchDiscreteCustomEvent(target, event);
    } else {
      target.dispatchEvent(event);
    }
  }
  var Root3 = DismissableLayer;
  var Branch = DismissableLayerBranch;

  // src/client/src/shared/ui/Tooltip.tsx
  var import_react5 = __toESM(require_react_shim(), 1);
  var DELAY = 400;
  var SKIP = 300;
  var lastClosed = 0;
  var noteClosed = () => {
    lastClosed = Date.now();
  };
  var justClosed = () => Date.now() - lastClosed < SKIP;
  var layerAutoFocus = false;
  if (typeof document !== "undefined") {
    document.addEventListener("focusScope.autoFocusOnMount", () => {
      layerAutoFocus = true;
      queueMicrotask(() => {
        layerAutoFocus = false;
      });
    }, true);
  }
  function focusVisible(el) {
    try {
      return el.matches(":focus-visible");
    } catch {
      return true;
    }
  }
  var looksDisabled = (cls) => cls.split(/\s+/).filter((c) => c && c !== "disabled:pointer-events-none" && !/^(dark:)?(hover|active):/.test(c)).map((c) => c.replace(/^disabled:/, "")).join(" ");
  function Tooltip({ content, children, name = false, side = "top" }) {
    const [open, setOpen] = (0, import_react5.useState)(false);
    const anchor = (0, import_react5.useRef)(null);
    const timer = (0, import_react5.useRef)(void 0);
    const own2 = children.props;
    const ref = useComposedRefs(anchor, own2.ref);
    (0, import_react5.useEffect)(() => () => clearTimeout(timer.current), []);
    const empty = content == null || content === "" || content === false;
    const text = typeof content === "string" && content !== "" ? content : void 0;
    const aria = !text ? {} : name ? { "aria-label": text } : own2["aria-label"] === text ? {} : { "aria-description": text };
    const reason = !empty && !!own2.disabled && typeof children.type === "string";
    const show = (now) => {
      if (empty) return;
      clearTimeout(timer.current);
      if (now || justClosed()) setOpen(true);
      else timer.current = setTimeout(() => setOpen(true), DELAY);
    };
    const hide4 = () => {
      clearTimeout(timer.current);
      if (open) noteClosed();
      setOpen(false);
    };
    const Element2 = children.type;
    const extra = {
      ref,
      ...aria,
      ...reason && {
        disabled: false,
        "aria-disabled": true,
        className: looksDisabled(own2.className ?? "")
      },
      // Свой обработчик элемента — первым, подсказкин — следом.
      onClick: (e) => {
        if (reason) e.preventDefault();
        else own2.onClick?.(e);
        hide4();
      },
      onPointerEnter: (e) => {
        own2.onPointerEnter?.(e);
        if (e.pointerType !== "touch") show(false);
      },
      onPointerLeave: (e) => {
        own2.onPointerLeave?.(e);
        hide4();
      },
      onPointerDown: (e) => {
        own2.onPointerDown?.(e);
        hide4();
      },
      // Фокус открывает подсказку, только когда он виден — пришёл с клавиатуры. Фокус, который вернуло
      // окно (выход с шага к открывшей его кнопке), иначе открыл бы её сам — и первый Esc достался бы
      // подсказке, а не окну. Фокус, поставленный открывшимся слоем, — тоже не зов (см. `layerAutoFocus`).
      onFocus: (e) => {
        own2.onFocus?.(e);
        if (!layerAutoFocus && focusVisible(e.currentTarget)) show(true);
      },
      onBlur: (e) => {
        own2.onBlur?.(e);
        hide4();
      }
    };
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Element2, { ...own2, ...extra }), open && !empty && /* @__PURE__ */ React.createElement(Layer, { anchor, side, onClose: hide4 }, content));
  }
  function Layer({ anchor, side, onClose, children }) {
    (0, import_react5.useEffect)(() => {
      const onScroll = (e) => {
        if (e.target instanceof Node && anchor.current && e.target.contains(anchor.current)) onClose();
      };
      window.addEventListener("scroll", onScroll, { capture: true });
      return () => window.removeEventListener("scroll", onScroll, { capture: true });
    }, [anchor, onClose]);
    return /* @__PURE__ */ React.createElement(Root2, null, /* @__PURE__ */ React.createElement(Anchor, { virtualRef: anchor }), /* @__PURE__ */ React.createElement(Portal, null, /* @__PURE__ */ React.createElement(
      DismissableLayer,
      {
        asChild: true,
        onEscapeKeyDown: onClose,
        onDismiss: onClose,
        onPointerDownOutside: (e) => e.preventDefault(),
        onFocusOutside: (e) => e.preventDefault()
      },
      /* @__PURE__ */ React.createElement(
        Content,
        {
          role: "tooltip",
          side,
          sideOffset: 6,
          collisionPadding: 8,
          className: "z-[60] max-w-60 rounded bg-surface border border-stroke px-2 py-1 text-caption text-fg1 whitespace-pre-line pointer-events-none select-none",
          style: { boxShadow: "var(--f-shadow16)" }
        },
        children
      )
    )));
  }

  // src/client/src/shared/ui/Button.tsx
  var BASE = "inline-flex items-center justify-center gap-2 rounded-full font-medium select-none transition-[background-color,box-shadow,filter,color,border-color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-base disabled:opacity-40 disabled:pointer-events-none";
  var SIZE = {
    sm: "h-8 px-3 text-xs",
    md: "h-9 px-4 text-sm",
    lg: "h-10 px-6 text-sm"
  };
  var TEXT_SIZE = {
    sm: "h-8 px-2 text-xs",
    md: "h-9 px-3 text-sm",
    lg: "h-10 px-4 text-sm"
  };
  var MULTILINE_SIZE = {
    sm: "min-h-8 px-3 text-xs",
    md: "min-h-9 px-4 text-sm",
    lg: "min-h-10 px-6 text-sm"
  };
  var MULTILINE_TEXT_SIZE = {
    sm: "min-h-8 px-2 text-xs",
    md: "min-h-9 px-3 text-sm",
    lg: "min-h-10 px-4 text-sm"
  };
  function variantClass(variant, danger) {
    switch (variant) {
      case "filled":
        return danger ? "bg-danger text-white shadow-[var(--f-shadow4)] hover:brightness-95 active:brightness-90" : "bg-brand text-on-brand shadow-[var(--f-shadow4)] hover:bg-brand-hover active:bg-brand-pressed";
      case "tonal":
        return "bg-tonal text-on-tonal hover:brightness-[.97] active:brightness-95";
      case "outlined":
        return danger ? "border border-stroke-strong text-danger hover:bg-danger/10 active:bg-danger/15" : "border border-stroke-strong text-brand hover:bg-brand/10 active:bg-brand/15";
      case "text":
        return danger ? "text-danger hover:bg-danger/10 active:bg-danger/15" : "text-brand hover:bg-brand/10 active:bg-brand/15";
    }
  }
  var hasLabel = (children) => import_react6.Children.toArray(children).some((c) => c !== "");
  var Button = (0, import_react6.forwardRef)(function Button2({
    variant = "text",
    size: size4 = "md",
    danger = false,
    loading = false,
    icon,
    trailingIcon,
    fullWidth,
    multiline = false,
    className = "",
    type,
    disabled,
    title,
    children,
    ...rest
  }, ref) {
    const sizeCls = multiline ? `${(variant === "text" ? MULTILINE_TEXT_SIZE : MULTILINE_SIZE)[size4]} py-1.5 whitespace-normal` : `${(variant === "text" ? TEXT_SIZE : SIZE)[size4]} whitespace-nowrap`;
    const labelled = hasLabel(children);
    return (
      // Без подписи имя кнопки — её подсказка, с подписью — описание: браузерный `title` давал их сам.
      /* @__PURE__ */ React.createElement(Tooltip, { content: title, name: !labelled }, /* @__PURE__ */ React.createElement(
        "button",
        {
          ref,
          type: type ?? "button",
          className: `${BASE} ${sizeCls} ${variantClass(variant, danger)} ${fullWidth ? "w-full" : ""} ${className}`,
          ...rest,
          disabled: disabled || loading
        },
        loading ? /* @__PURE__ */ React.createElement(LoaderCircle, { size: 16, className: "animate-spin shrink-0" }) : icon,
        children,
        trailingIcon
      ))
    );
  });
  var ICON_SIZE = {
    sm: "h-8 w-8",
    md: "h-9 w-9",
    lg: "h-10 w-10"
  };
  var IconButton = (0, import_react6.forwardRef)(function IconButton2({ label, size: size4 = "md", danger = false, className = "", type, title, children, ...rest }, ref) {
    const look = danger ? "text-fg3 hover:text-danger hover:bg-danger/10" : "text-fg3 hover:text-fg1 hover:bg-black/5 dark:hover:bg-white/10";
    return /* @__PURE__ */ React.createElement(Tooltip, { content: title ?? (rest.disabled ? void 0 : label) }, /* @__PURE__ */ React.createElement(
      "button",
      {
        ref,
        type: type ?? "button",
        "aria-label": label,
        className: `inline-flex items-center justify-center rounded-full shrink-0 ${ICON_SIZE[size4]} transition-[background-color,color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-base disabled:opacity-40 disabled:pointer-events-none ` + look + ` ${className}`,
        ...rest
      },
      children
    ));
  });

  // src/client/src/shared/ui/Switch.tsx
  init_define_import_meta_env();
  function Switch({ checked, onChange, disabled, label, title, size: size4 = "md" }) {
    const track = size4 === "sm" ? "w-9 h-5" : "w-11 h-6";
    const knobOn = size4 === "sm" ? "w-3.5 h-3.5 right-0.5" : "w-5 h-5 right-0.5";
    const knobOff = size4 === "sm" ? "w-2.5 h-2.5 left-[3px]" : "w-3 h-3 left-1";
    return /* @__PURE__ */ React.createElement(Tooltip, { content: title }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        role: "switch",
        "aria-checked": checked,
        "aria-label": label,
        disabled,
        onClick: () => onChange(!checked),
        className: `relative inline-flex shrink-0 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand disabled:opacity-40 disabled:cursor-not-allowed ${track} ${checked ? "bg-brand" : "bg-surface border-2 border-stroke-strong"}`
      },
      /* @__PURE__ */ React.createElement(
        "span",
        {
          "aria-hidden": "true",
          className: `absolute rounded-full transition-all ${checked ? `bg-white ${knobOn}` : `bg-stroke-strong ${knobOff}`}`
        }
      )
    ));
  }

  // src/client/src/shared/ui/TextField.tsx
  init_define_import_meta_env();
  var import_react7 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/ui/OutlinedField.tsx
  init_define_import_meta_env();
  function OutlinedField({
    label,
    required,
    invalid,
    error,
    hint,
    raise = "auto",
    focused,
    htmlFor,
    labelId,
    readOnly,
    trailing,
    containerClassName = "",
    children
  }) {
    const bad = !!error || invalid;
    const auto = raise === "auto";
    const borderColor = bad ? "border-danger" : auto ? "border-stroke-strong peer-focus:border-brand" : focused ? "border-brand" : "border-stroke-strong";
    const borderWidth = auto ? "peer-focus:border-2" : focused ? "border-2" : "";
    const legendWidth = auto ? "max-w-[0.01px]" : "max-w-full";
    const legendOpener = auto ? "peer-focus:[&>legend]:max-w-full peer-[:not(:placeholder-shown)]:[&>legend]:max-w-full" : "";
    const labelColor = bad ? "text-danger" : auto ? "text-fg4 peer-focus:text-brand" : focused ? "text-brand" : "text-fg4";
    const labelPosition = auto ? "top-1/2 -translate-y-1/2 text-sm peer-focus:top-0 peer-focus:text-xs peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-xs" : "top-0 -translate-y-1/2 text-xs";
    const labelContent = label;
    const star = required ? " after:ml-0.5 after:text-danger after:content-['*']" : "";
    const labelClass = `absolute left-3 px-1 pointer-events-none transition-all block max-w-[calc(100%-1.5rem)] truncate ${labelColor} ${labelPosition}${star}`;
    return /* @__PURE__ */ React.createElement("div", { className: containerClassName }, /* @__PURE__ */ React.createElement("div", { className: readOnly ? "relative isolate" : "relative" }, readOnly && /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, className: "absolute inset-0 -z-10 rounded-md bg-muted" }), children, /* @__PURE__ */ React.createElement(
      "fieldset",
      {
        "aria-hidden": true,
        className: `pointer-events-none absolute inset-x-0 bottom-0 top-[-5px] m-0 rounded-md border px-3 transition-colors ${borderColor} ${borderWidth} ${legendOpener}`
      },
      /* @__PURE__ */ React.createElement("legend", { className: `h-2.5 w-auto whitespace-nowrap p-0 text-xs invisible transition-[max-width] duration-100 ${legendWidth}` }, /* @__PURE__ */ React.createElement("span", { className: "inline-block px-1 opacity-0" }, label, required ? " *" : ""))
    ), htmlFor ? /* @__PURE__ */ React.createElement("label", { id: labelId, htmlFor, className: labelClass }, labelContent) : /* @__PURE__ */ React.createElement("span", { id: labelId, className: labelClass }, labelContent), trailing && /* @__PURE__ */ React.createElement("div", { className: "absolute right-2 top-1/2 -translate-y-1/2 z-10" }, trailing)), error ? /* @__PURE__ */ React.createElement("p", { className: "mt-1 px-1 text-xs text-danger" }, error) : hint ? /* @__PURE__ */ React.createElement("p", { className: "mt-1 px-1 text-xs text-fg4" }, hint) : null);
  }

  // src/client/src/shared/ui/TextField.tsx
  var TextField = (0, import_react7.forwardRef)(function TextField2({ label, error, invalid, hint, trailing, className = "", containerClassName = "", id, required, ...rest }, ref) {
    const autoId = (0, import_react7.useId)();
    const inputId = id ?? autoId;
    return /* @__PURE__ */ React.createElement(
      OutlinedField,
      {
        label,
        required,
        invalid,
        error,
        hint,
        readOnly: rest.readOnly,
        htmlFor: inputId,
        trailing,
        containerClassName
      },
      /* @__PURE__ */ React.createElement(
        "input",
        {
          ref,
          id: inputId,
          placeholder: " ",
          required,
          className: `peer w-full h-14 rounded-md bg-transparent text-sm text-fg1 px-4 outline-none disabled:opacity-50 ${trailing ? "pr-11" : ""} ${className}`,
          ...rest
        }
      )
    );
  });

  // src/client/src/shared/ui/DateInput.tsx
  init_define_import_meta_env();
  var import_react10 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-popover/dist/index.mjs
  init_define_import_meta_env();
  var React29 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-focus-guards/dist/index.mjs
  init_define_import_meta_env();
  var React15 = __toESM(require_react_shim(), 1);
  var count = 0;
  var guards = null;
  function useFocusGuards() {
    React15.useEffect(() => {
      if (!guards) {
        guards = { start: createFocusGuard(), end: createFocusGuard() };
      }
      const { start, end } = guards;
      if (document.body.firstElementChild !== start) {
        document.body.insertAdjacentElement("afterbegin", start);
      }
      if (document.body.lastElementChild !== end) {
        document.body.insertAdjacentElement("beforeend", end);
      }
      count++;
      return () => {
        if (count === 1) {
          guards?.start.remove();
          guards?.end.remove();
          guards = null;
        }
        count = Math.max(0, count - 1);
      };
    }, []);
  }
  function createFocusGuard() {
    const element = document.createElement("span");
    element.setAttribute("data-radix-focus-guard", "");
    element.tabIndex = 0;
    element.style.outline = "none";
    element.style.opacity = "0";
    element.style.position = "fixed";
    element.style.pointerEvents = "none";
    return element;
  }

  // src/client/node_modules/@radix-ui/react-focus-scope/dist/index.mjs
  init_define_import_meta_env();
  var React16 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime7 = __toESM(require_react_shim(), 1);
  var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
  var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
  var EVENT_OPTIONS = { bubbles: false, cancelable: true };
  var FOCUS_SCOPE_NAME = "FocusScope";
  var FocusScope = React16.forwardRef((props, forwardedRef) => {
    const {
      loop = false,
      trapped = false,
      onMountAutoFocus: onMountAutoFocusProp,
      onUnmountAutoFocus: onUnmountAutoFocusProp,
      ...scopeProps
    } = props;
    const [container, setContainer] = React16.useState(null);
    const onMountAutoFocus = useCallbackRef(onMountAutoFocusProp);
    const onUnmountAutoFocus = useCallbackRef(onUnmountAutoFocusProp);
    const lastFocusedElementRef = React16.useRef(null);
    const composedRefs = useComposedRefs(forwardedRef, (node) => setContainer(node));
    const focusScope = React16.useRef({
      paused: false,
      pause() {
        this.paused = true;
      },
      resume() {
        this.paused = false;
      }
    }).current;
    React16.useEffect(() => {
      if (trapped) {
        let handleFocusIn2 = function(event) {
          if (focusScope.paused || !container) return;
          const target = event.target;
          if (container.contains(target)) {
            lastFocusedElementRef.current = target;
          } else {
            focus(lastFocusedElementRef.current, { select: true });
          }
        }, handleFocusOut2 = function(event) {
          if (focusScope.paused || !container) return;
          const relatedTarget = event.relatedTarget;
          if (relatedTarget === null) return;
          if (!container.contains(relatedTarget)) {
            focus(lastFocusedElementRef.current, { select: true });
          }
        }, handleMutations2 = function(mutations) {
          const focusedElement = document.activeElement;
          if (focusedElement !== document.body) return;
          for (const mutation of mutations) {
            if (mutation.removedNodes.length > 0) focus(container);
          }
        };
        var handleFocusIn = handleFocusIn2, handleFocusOut = handleFocusOut2, handleMutations = handleMutations2;
        document.addEventListener("focusin", handleFocusIn2);
        document.addEventListener("focusout", handleFocusOut2);
        const mutationObserver = new MutationObserver(handleMutations2);
        if (container) mutationObserver.observe(container, { childList: true, subtree: true });
        return () => {
          document.removeEventListener("focusin", handleFocusIn2);
          document.removeEventListener("focusout", handleFocusOut2);
          mutationObserver.disconnect();
        };
      }
    }, [trapped, container, focusScope.paused]);
    React16.useEffect(() => {
      if (container) {
        focusScopesStack.add(focusScope);
        const previouslyFocusedElement = document.activeElement;
        const hasFocusedCandidate = container.contains(previouslyFocusedElement);
        if (!hasFocusedCandidate) {
          const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
          container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
          container.dispatchEvent(mountEvent);
          if (!mountEvent.defaultPrevented) {
            focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
            if (document.activeElement === previouslyFocusedElement) {
              focus(container);
            }
          }
        }
        return () => {
          container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
          setTimeout(() => {
            const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
            container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
            container.dispatchEvent(unmountEvent);
            if (!unmountEvent.defaultPrevented) {
              focus(previouslyFocusedElement ?? document.body, { select: true });
            }
            container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
            focusScopesStack.remove(focusScope);
          }, 0);
        };
      }
    }, [container, onMountAutoFocus, onUnmountAutoFocus, focusScope]);
    const handleKeyDown = React16.useCallback(
      (event) => {
        if (!loop && !trapped) return;
        if (focusScope.paused) return;
        const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
        const focusedElement = document.activeElement;
        if (isTabKey && focusedElement) {
          const container2 = event.currentTarget;
          const [first, last] = getTabbableEdges(container2);
          const hasTabbableElementsInside = first && last;
          if (!hasTabbableElementsInside) {
            if (focusedElement === container2) event.preventDefault();
          } else {
            if (!event.shiftKey && focusedElement === last) {
              event.preventDefault();
              if (loop) focus(first, { select: true });
            } else if (event.shiftKey && focusedElement === first) {
              event.preventDefault();
              if (loop) focus(last, { select: true });
            }
          }
        }
      },
      [loop, trapped, focusScope.paused]
    );
    return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Primitive.div, { tabIndex: -1, ...scopeProps, ref: composedRefs, onKeyDown: handleKeyDown });
  });
  FocusScope.displayName = FOCUS_SCOPE_NAME;
  function focusFirst(candidates, { select = false } = {}) {
    const previouslyFocusedElement = document.activeElement;
    for (const candidate of candidates) {
      focus(candidate, { select });
      if (document.activeElement !== previouslyFocusedElement) return;
    }
  }
  function getTabbableEdges(container) {
    const candidates = getTabbableCandidates(container);
    const first = findVisible(candidates, container);
    const last = findVisible(candidates.reverse(), container);
    return [first, last];
  }
  function getTabbableCandidates(container) {
    const nodes = [];
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (node) => {
        const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
        if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
        return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }
  function findVisible(elements, container) {
    for (const element of elements) {
      if (!isHidden(element, { upTo: container })) return element;
    }
  }
  function isHidden(node, { upTo }) {
    if (getComputedStyle(node).visibility === "hidden") return true;
    while (node) {
      if (upTo !== void 0 && node === upTo) return false;
      if (getComputedStyle(node).display === "none") return true;
      node = node.parentElement;
    }
    return false;
  }
  function isSelectableInput(element) {
    return element instanceof HTMLInputElement && "select" in element;
  }
  function focus(element, { select = false } = {}) {
    if (element && element.focus) {
      const previouslyFocusedElement = document.activeElement;
      element.focus({ preventScroll: true });
      if (element !== previouslyFocusedElement && isSelectableInput(element) && select)
        element.select();
    }
  }
  var focusScopesStack = createFocusScopesStack();
  function createFocusScopesStack() {
    let stack = [];
    return {
      add(focusScope) {
        const activeFocusScope = stack[0];
        if (focusScope !== activeFocusScope) {
          activeFocusScope?.pause();
        }
        stack = arrayRemove(stack, focusScope);
        stack.unshift(focusScope);
      },
      remove(focusScope) {
        stack = arrayRemove(stack, focusScope);
        stack[0]?.resume();
      }
    };
  }
  function arrayRemove(array, item) {
    const updatedArray = [...array];
    const index2 = updatedArray.indexOf(item);
    if (index2 !== -1) {
      updatedArray.splice(index2, 1);
    }
    return updatedArray;
  }
  function removeLinks(items) {
    return items.filter((item) => item.tagName !== "A");
  }

  // src/client/node_modules/@radix-ui/react-id/dist/index.mjs
  init_define_import_meta_env();
  var React17 = __toESM(require_react_shim(), 1);
  var useReactId = React17[" useId ".trim().toString()] || (() => void 0);
  var count2 = 0;
  function useId2(deterministicId) {
    const [id, setId] = React17.useState(useReactId());
    useLayoutEffect22(() => {
      if (!deterministicId) setId((reactId) => reactId ?? String(count2++));
    }, [deterministicId]);
    return deterministicId || (id ? `radix-${id}` : "");
  }

  // src/client/node_modules/@radix-ui/react-presence/dist/index.mjs
  init_define_import_meta_env();
  var React22 = __toESM(require_react_shim(), 1);
  var React18 = __toESM(require_react_shim(), 1);
  function useStateMachine(initialState, machine) {
    return React18.useReducer((state, event) => {
      const nextState = machine[state][event];
      return nextState ?? state;
    }, initialState);
  }
  var Presence = (props) => {
    const { present, children } = props;
    const presence = usePresence(present);
    const child = typeof children === "function" ? children({ present: presence.isPresent }) : React22.Children.only(children);
    const ref = useStableComposedRefs(presence.ref, getElementRef2(child));
    const forceMount = typeof children === "function";
    return forceMount || presence.isPresent ? React22.cloneElement(child, { ref }) : null;
  };
  Presence.displayName = "Presence";
  function usePresence(present) {
    const [node, setNode] = React22.useState();
    const stylesRef = React22.useRef(null);
    const prevPresentRef = React22.useRef(present);
    const prevAnimationNameRef = React22.useRef("none");
    const initialState = present ? "mounted" : "unmounted";
    const [state, send] = useStateMachine(initialState, {
      mounted: {
        UNMOUNT: "unmounted",
        ANIMATION_OUT: "unmountSuspended"
      },
      unmountSuspended: {
        MOUNT: "mounted",
        ANIMATION_END: "unmounted"
      },
      unmounted: {
        MOUNT: "mounted"
      }
    });
    React22.useEffect(() => {
      const currentAnimationName = getAnimationName(stylesRef.current);
      prevAnimationNameRef.current = state === "mounted" ? currentAnimationName : "none";
    }, [state]);
    useLayoutEffect22(() => {
      const styles = stylesRef.current;
      const wasPresent = prevPresentRef.current;
      const hasPresentChanged = wasPresent !== present;
      if (hasPresentChanged) {
        const prevAnimationName = prevAnimationNameRef.current;
        const currentAnimationName = getAnimationName(styles);
        if (present) {
          send("MOUNT");
        } else if (currentAnimationName === "none" || styles?.display === "none") {
          send("UNMOUNT");
        } else {
          const isAnimating = prevAnimationName !== currentAnimationName;
          if (wasPresent && isAnimating) {
            send("ANIMATION_OUT");
          } else {
            send("UNMOUNT");
          }
        }
        prevPresentRef.current = present;
      }
    }, [present, send]);
    useLayoutEffect22(() => {
      if (node) {
        let timeoutId;
        const ownerWindow = node.ownerDocument.defaultView ?? window;
        const handleAnimationEnd = (event) => {
          const currentAnimationName = getAnimationName(stylesRef.current);
          const isCurrentAnimation = currentAnimationName.includes(CSS.escape(event.animationName));
          if (event.target === node && isCurrentAnimation) {
            send("ANIMATION_END");
            if (!prevPresentRef.current) {
              const currentFillMode = node.style.animationFillMode;
              node.style.animationFillMode = "forwards";
              timeoutId = ownerWindow.setTimeout(() => {
                if (node.style.animationFillMode === "forwards") {
                  node.style.animationFillMode = currentFillMode;
                }
              });
            }
          }
        };
        const handleAnimationStart = (event) => {
          if (event.target === node) {
            prevAnimationNameRef.current = getAnimationName(stylesRef.current);
          }
        };
        node.addEventListener("animationstart", handleAnimationStart);
        node.addEventListener("animationcancel", handleAnimationEnd);
        node.addEventListener("animationend", handleAnimationEnd);
        return () => {
          ownerWindow.clearTimeout(timeoutId);
          node.removeEventListener("animationstart", handleAnimationStart);
          node.removeEventListener("animationcancel", handleAnimationEnd);
          node.removeEventListener("animationend", handleAnimationEnd);
        };
      } else {
        send("ANIMATION_END");
      }
    }, [node, send]);
    return {
      isPresent: ["mounted", "unmountSuspended"].includes(state),
      ref: React22.useCallback((node2) => {
        stylesRef.current = node2 ? getComputedStyle(node2) : null;
        setNode(node2);
      }, [])
    };
  }
  function setRef2(ref, value) {
    if (typeof ref === "function") {
      return ref(value);
    } else if (ref !== null && ref !== void 0) {
      ref.current = value;
    }
  }
  function useStableComposedRefs(...refs) {
    const refsRef = React22.useRef(refs);
    refsRef.current = refs;
    return React22.useCallback((node) => {
      const currentRefs = refsRef.current;
      let hasCleanup = false;
      const cleanups = currentRefs.map((ref) => {
        const cleanup = setRef2(ref, node);
        if (!hasCleanup && typeof cleanup === "function") {
          hasCleanup = true;
        }
        return cleanup;
      });
      if (hasCleanup) {
        return () => {
          for (let i = 0; i < cleanups.length; i++) {
            const cleanup = cleanups[i];
            if (typeof cleanup === "function") {
              cleanup();
            } else {
              setRef2(currentRefs[i], null);
            }
          }
        };
      }
    }, []);
  }
  function getAnimationName(styles) {
    return styles?.animationName || "none";
  }
  function getElementRef2(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
    let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.ref;
    }
    getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
    mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.props.ref;
    }
    return element.props.ref || element.ref;
  }

  // src/client/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
  init_define_import_meta_env();
  var React19 = __toESM(require_react_shim(), 1);
  var React23 = __toESM(require_react_shim(), 1);
  var useInsertionEffect = React19[" useInsertionEffect ".trim().toString()] || useLayoutEffect22;
  function useControllableState({
    prop,
    defaultProp,
    onChange = () => {
    },
    caller
  }) {
    const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
      defaultProp,
      onChange
    });
    const isControlled = prop !== void 0;
    const value = isControlled ? prop : uncontrolledProp;
    if (true) {
      const isControlledRef = React19.useRef(prop !== void 0);
      React19.useEffect(() => {
        const wasControlled = isControlledRef.current;
        if (wasControlled !== isControlled) {
          const from = wasControlled ? "controlled" : "uncontrolled";
          const to = isControlled ? "controlled" : "uncontrolled";
          console.warn(
            `${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`
          );
        }
        isControlledRef.current = isControlled;
      }, [isControlled, caller]);
    }
    const setValue = React19.useCallback(
      (nextValue) => {
        if (isControlled) {
          const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
          if (value2 !== prop) {
            onChangeRef.current?.(value2);
          }
        } else {
          setUncontrolledProp(nextValue);
        }
      },
      [isControlled, prop, setUncontrolledProp, onChangeRef]
    );
    return [value, setValue];
  }
  function useUncontrolledState({
    defaultProp,
    onChange
  }) {
    const [value, setValue] = React19.useState(defaultProp);
    const prevValueRef = React19.useRef(value);
    const onChangeRef = React19.useRef(onChange);
    useInsertionEffect(() => {
      onChangeRef.current = onChange;
    }, [onChange]);
    React19.useEffect(() => {
      if (prevValueRef.current !== value) {
        onChangeRef.current?.(value);
        prevValueRef.current = value;
      }
    }, [value, prevValueRef]);
    return [value, setValue, onChangeRef];
  }
  function isFunction(value) {
    return typeof value === "function";
  }

  // src/client/node_modules/aria-hidden/dist/es2015/index.js
  init_define_import_meta_env();
  var getDefaultParent = function(originalTarget) {
    if (typeof document === "undefined") {
      return null;
    }
    var sampleTarget = Array.isArray(originalTarget) ? originalTarget[0] : originalTarget;
    return sampleTarget.ownerDocument.body;
  };
  var counterMap = /* @__PURE__ */ new WeakMap();
  var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
  var markerMap = {};
  var lockCount = 0;
  var unwrapHost = function(node) {
    return node && (node.host || unwrapHost(node.parentNode));
  };
  var correctTargets = function(parent, targets) {
    return targets.map(function(target) {
      if (parent.contains(target)) {
        return target;
      }
      var correctedTarget = unwrapHost(target);
      if (correctedTarget && parent.contains(correctedTarget)) {
        return correctedTarget;
      }
      console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
      return null;
    }).filter(function(x) {
      return Boolean(x);
    });
  };
  var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
    var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
    if (!markerMap[markerName]) {
      markerMap[markerName] = /* @__PURE__ */ new WeakMap();
    }
    var markerCounter = markerMap[markerName];
    var hiddenNodes = [];
    var elementsToKeep = /* @__PURE__ */ new Set();
    var elementsToStop = new Set(targets);
    var keep = function(el) {
      if (!el || elementsToKeep.has(el)) {
        return;
      }
      elementsToKeep.add(el);
      keep(el.parentNode);
    };
    targets.forEach(keep);
    var deep = function(parent) {
      if (!parent || elementsToStop.has(parent)) {
        return;
      }
      Array.prototype.forEach.call(parent.children, function(node) {
        if (elementsToKeep.has(node)) {
          deep(node);
        } else {
          try {
            var attr = node.getAttribute(controlAttribute);
            var alreadyHidden = attr !== null && attr !== "false";
            var counterValue = (counterMap.get(node) || 0) + 1;
            var markerValue = (markerCounter.get(node) || 0) + 1;
            counterMap.set(node, counterValue);
            markerCounter.set(node, markerValue);
            hiddenNodes.push(node);
            if (counterValue === 1 && alreadyHidden) {
              uncontrolledNodes.set(node, true);
            }
            if (markerValue === 1) {
              node.setAttribute(markerName, "true");
            }
            if (!alreadyHidden) {
              node.setAttribute(controlAttribute, "true");
            }
          } catch (e) {
            console.error("aria-hidden: cannot operate on ", node, e);
          }
        }
      });
    };
    deep(parentNode);
    elementsToKeep.clear();
    lockCount++;
    return function() {
      hiddenNodes.forEach(function(node) {
        var counterValue = counterMap.get(node) - 1;
        var markerValue = markerCounter.get(node) - 1;
        counterMap.set(node, counterValue);
        markerCounter.set(node, markerValue);
        if (!counterValue) {
          if (!uncontrolledNodes.has(node)) {
            node.removeAttribute(controlAttribute);
          }
          uncontrolledNodes.delete(node);
        }
        if (!markerValue) {
          node.removeAttribute(markerName);
        }
      });
      lockCount--;
      if (!lockCount) {
        counterMap = /* @__PURE__ */ new WeakMap();
        counterMap = /* @__PURE__ */ new WeakMap();
        uncontrolledNodes = /* @__PURE__ */ new WeakMap();
        markerMap = {};
      }
    };
  };
  var hideOthers = function(originalTarget, parentNode, markerName) {
    if (markerName === void 0) {
      markerName = "data-aria-hidden";
    }
    var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
    var activeParentNode = parentNode || getDefaultParent(originalTarget);
    if (!activeParentNode) {
      return function() {
        return null;
      };
    }
    targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
    return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
  };

  // src/client/node_modules/react-remove-scroll/dist/es2015/index.js
  init_define_import_meta_env();

  // src/client/node_modules/react-remove-scroll/dist/es2015/Combination.js
  init_define_import_meta_env();

  // src/client/node_modules/tslib/tslib.es6.mjs
  init_define_import_meta_env();
  var __assign = function() {
    __assign = Object.assign || function __assign2(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  }
  function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  }

  // src/client/node_modules/react-remove-scroll/dist/es2015/Combination.js
  var React28 = __toESM(require_react_shim());

  // src/client/node_modules/react-remove-scroll/dist/es2015/UI.js
  init_define_import_meta_env();
  var React24 = __toESM(require_react_shim());

  // src/client/node_modules/react-remove-scroll-bar/dist/es2015/constants.js
  init_define_import_meta_env();
  var zeroRightClassName = "right-scroll-bar-position";
  var fullWidthClassName = "width-before-scroll-bar";
  var noScrollbarsClassName = "with-scroll-bars-hidden";
  var removedBarSizeVariable = "--removed-body-scroll-bar-size";

  // src/client/node_modules/use-callback-ref/dist/es2015/index.js
  init_define_import_meta_env();

  // src/client/node_modules/use-callback-ref/dist/es2015/assignRef.js
  init_define_import_meta_env();
  function assignRef(ref, value) {
    if (typeof ref === "function") {
      ref(value);
    } else if (ref) {
      ref.current = value;
    }
    return ref;
  }

  // src/client/node_modules/use-callback-ref/dist/es2015/useRef.js
  init_define_import_meta_env();
  var import_react8 = __toESM(require_react_shim());
  function useCallbackRef2(initialValue, callback) {
    var ref = (0, import_react8.useState)(function() {
      return {
        // value
        value: initialValue,
        // last callback
        callback,
        // "memoized" public interface
        facade: {
          get current() {
            return ref.value;
          },
          set current(value) {
            var last = ref.value;
            if (last !== value) {
              ref.value = value;
              ref.callback(value, last);
            }
          }
        }
      };
    })[0];
    ref.callback = callback;
    return ref.facade;
  }

  // src/client/node_modules/use-callback-ref/dist/es2015/useMergeRef.js
  init_define_import_meta_env();
  var React20 = __toESM(require_react_shim());
  var useIsomorphicLayoutEffect = typeof window !== "undefined" ? React20.useLayoutEffect : React20.useEffect;
  var currentValues = /* @__PURE__ */ new WeakMap();
  function useMergeRefs(refs, defaultValue) {
    var callbackRef = useCallbackRef2(defaultValue || null, function(newValue) {
      return refs.forEach(function(ref) {
        return assignRef(ref, newValue);
      });
    });
    useIsomorphicLayoutEffect(function() {
      var oldValue = currentValues.get(callbackRef);
      if (oldValue) {
        var prevRefs_1 = new Set(oldValue);
        var nextRefs_1 = new Set(refs);
        var current_1 = callbackRef.current;
        prevRefs_1.forEach(function(ref) {
          if (!nextRefs_1.has(ref)) {
            assignRef(ref, null);
          }
        });
        nextRefs_1.forEach(function(ref) {
          if (!prevRefs_1.has(ref)) {
            assignRef(ref, current_1);
          }
        });
      }
      currentValues.set(callbackRef, refs);
    }, [refs]);
    return callbackRef;
  }

  // src/client/node_modules/react-remove-scroll/dist/es2015/medium.js
  init_define_import_meta_env();

  // src/client/node_modules/use-sidecar/dist/es2015/index.js
  init_define_import_meta_env();

  // src/client/node_modules/use-sidecar/dist/es2015/medium.js
  init_define_import_meta_env();
  function ItoI(a) {
    return a;
  }
  function innerCreateMedium(defaults2, middleware) {
    if (middleware === void 0) {
      middleware = ItoI;
    }
    var buffer2 = [];
    var assigned = false;
    var medium = {
      read: function() {
        if (assigned) {
          throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
        }
        if (buffer2.length) {
          return buffer2[buffer2.length - 1];
        }
        return defaults2;
      },
      useMedium: function(data) {
        var item = middleware(data, assigned);
        buffer2.push(item);
        return function() {
          buffer2 = buffer2.filter(function(x) {
            return x !== item;
          });
        };
      },
      assignSyncMedium: function(cb) {
        assigned = true;
        while (buffer2.length) {
          var cbs = buffer2;
          buffer2 = [];
          cbs.forEach(cb);
        }
        buffer2 = {
          push: function(x) {
            return cb(x);
          },
          filter: function() {
            return buffer2;
          }
        };
      },
      assignMedium: function(cb) {
        assigned = true;
        var pendingQueue = [];
        if (buffer2.length) {
          var cbs = buffer2;
          buffer2 = [];
          cbs.forEach(cb);
          pendingQueue = buffer2;
        }
        var executeQueue = function() {
          var cbs2 = pendingQueue;
          pendingQueue = [];
          cbs2.forEach(cb);
        };
        var cycle = function() {
          return Promise.resolve().then(executeQueue);
        };
        cycle();
        buffer2 = {
          push: function(x) {
            pendingQueue.push(x);
            cycle();
          },
          filter: function(filter2) {
            pendingQueue = pendingQueue.filter(filter2);
            return buffer2;
          }
        };
      }
    };
    return medium;
  }
  function createSidecarMedium(options2) {
    if (options2 === void 0) {
      options2 = {};
    }
    var medium = innerCreateMedium(null);
    medium.options = __assign({ async: true, ssr: false }, options2);
    return medium;
  }

  // src/client/node_modules/use-sidecar/dist/es2015/exports.js
  init_define_import_meta_env();
  var React21 = __toESM(require_react_shim());
  var SideCar = function(_a6) {
    var sideCar = _a6.sideCar, rest = __rest(_a6, ["sideCar"]);
    if (!sideCar) {
      throw new Error("Sidecar: please provide `sideCar` property to import the right car");
    }
    var Target = sideCar.read();
    if (!Target) {
      throw new Error("Sidecar medium not found");
    }
    return React21.createElement(Target, __assign({}, rest));
  };
  SideCar.isSideCarExport = true;
  function exportSidecar(medium, exported) {
    medium.useMedium(exported);
    return SideCar;
  }

  // src/client/node_modules/react-remove-scroll/dist/es2015/medium.js
  var effectCar = createSidecarMedium();

  // src/client/node_modules/react-remove-scroll/dist/es2015/UI.js
  var nothing = function() {
    return;
  };
  var RemoveScroll = React24.forwardRef(function(props, parentRef) {
    var ref = React24.useRef(null);
    var _a6 = React24.useState({
      onScrollCapture: nothing,
      onWheelCapture: nothing,
      onTouchMoveCapture: nothing
    }), callbacks = _a6[0], setCallbacks = _a6[1];
    var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]);
    var SideCar2 = sideCar;
    var containerRef = useMergeRefs([ref, parentRef]);
    var containerProps = __assign(__assign({}, rest), callbacks);
    return React24.createElement(
      React24.Fragment,
      null,
      enabled && React24.createElement(SideCar2, { sideCar: effectCar, removeScrollBar, shards, noRelative, noIsolation, inert, setCallbacks, allowPinchZoom: !!allowPinchZoom, lockRef: ref, gapMode }),
      forwardProps ? React24.cloneElement(React24.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : React24.createElement(Container, __assign({}, containerProps, { className, ref: containerRef }), children)
    );
  });
  RemoveScroll.defaultProps = {
    enabled: true,
    removeScrollBar: true,
    inert: false
  };
  RemoveScroll.classNames = {
    fullWidth: fullWidthClassName,
    zeroRight: zeroRightClassName
  };

  // src/client/node_modules/react-remove-scroll/dist/es2015/sidecar.js
  init_define_import_meta_env();

  // src/client/node_modules/react-remove-scroll/dist/es2015/SideEffect.js
  init_define_import_meta_env();
  var React27 = __toESM(require_react_shim());

  // src/client/node_modules/react-remove-scroll-bar/dist/es2015/index.js
  init_define_import_meta_env();

  // src/client/node_modules/react-remove-scroll-bar/dist/es2015/component.js
  init_define_import_meta_env();
  var React26 = __toESM(require_react_shim());

  // src/client/node_modules/react-style-singleton/dist/es2015/index.js
  init_define_import_meta_env();

  // src/client/node_modules/react-style-singleton/dist/es2015/component.js
  init_define_import_meta_env();

  // src/client/node_modules/react-style-singleton/dist/es2015/hook.js
  init_define_import_meta_env();
  var React25 = __toESM(require_react_shim());

  // src/client/node_modules/react-style-singleton/dist/es2015/singleton.js
  init_define_import_meta_env();

  // src/client/node_modules/get-nonce/dist/es2015/index.js
  init_define_import_meta_env();
  var currentNonce;
  var getNonce = function() {
    if (currentNonce) {
      return currentNonce;
    }
    if (typeof __webpack_nonce__ !== "undefined") {
      return __webpack_nonce__;
    }
    return void 0;
  };

  // src/client/node_modules/react-style-singleton/dist/es2015/singleton.js
  function makeStyleTag() {
    if (!document)
      return null;
    var tag = document.createElement("style");
    tag.type = "text/css";
    var nonce = getNonce();
    if (nonce) {
      tag.setAttribute("nonce", nonce);
    }
    return tag;
  }
  function injectStyles(tag, css) {
    if (tag.styleSheet) {
      tag.styleSheet.cssText = css;
    } else {
      tag.appendChild(document.createTextNode(css));
    }
  }
  function insertStyleTag(tag) {
    var head = document.head || document.getElementsByTagName("head")[0];
    head.appendChild(tag);
  }
  var stylesheetSingleton = function() {
    var counter2 = 0;
    var stylesheet = null;
    return {
      add: function(style) {
        if (counter2 == 0) {
          if (stylesheet = makeStyleTag()) {
            injectStyles(stylesheet, style);
            insertStyleTag(stylesheet);
          }
        }
        counter2++;
      },
      remove: function() {
        counter2--;
        if (!counter2 && stylesheet) {
          stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
          stylesheet = null;
        }
      }
    };
  };

  // src/client/node_modules/react-style-singleton/dist/es2015/hook.js
  var styleHookSingleton = function() {
    var sheet = stylesheetSingleton();
    return function(styles, isDynamic) {
      React25.useEffect(function() {
        sheet.add(styles);
        return function() {
          sheet.remove();
        };
      }, [styles && isDynamic]);
    };
  };

  // src/client/node_modules/react-style-singleton/dist/es2015/component.js
  var styleSingleton = function() {
    var useStyle = styleHookSingleton();
    var Sheet = function(_a6) {
      var styles = _a6.styles, dynamic = _a6.dynamic;
      useStyle(styles, dynamic);
      return null;
    };
    return Sheet;
  };

  // src/client/node_modules/react-remove-scroll-bar/dist/es2015/utils.js
  init_define_import_meta_env();
  var zeroGap = {
    left: 0,
    top: 0,
    right: 0,
    gap: 0
  };
  var parse = function(x) {
    return parseInt(x || "", 10) || 0;
  };
  var getOffset = function(gapMode) {
    var cs = window.getComputedStyle(document.body);
    var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
    var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
    var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
    return [parse(left), parse(top), parse(right)];
  };
  var getGapWidth = function(gapMode) {
    if (gapMode === void 0) {
      gapMode = "margin";
    }
    if (typeof window === "undefined") {
      return zeroGap;
    }
    var offsets = getOffset(gapMode);
    var documentWidth = document.documentElement.clientWidth;
    var windowWidth = window.innerWidth;
    return {
      left: offsets[0],
      top: offsets[1],
      right: offsets[2],
      gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
    };
  };

  // src/client/node_modules/react-remove-scroll-bar/dist/es2015/component.js
  var Style = styleSingleton();
  var lockAttribute = "data-scroll-locked";
  var getStyles = function(_a6, allowRelative, gapMode, important) {
    var left = _a6.left, top = _a6.top, right = _a6.right, gap = _a6.gap;
    if (gapMode === void 0) {
      gapMode = "margin";
    }
    return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
      allowRelative && "position: relative ".concat(important, ";"),
      gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
      gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
    ].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
  };
  var getCurrentUseCounter = function() {
    var counter2 = parseInt(document.body.getAttribute(lockAttribute) || "0", 10);
    return isFinite(counter2) ? counter2 : 0;
  };
  var useLockAttribute = function() {
    React26.useEffect(function() {
      document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
      return function() {
        var newCounter = getCurrentUseCounter() - 1;
        if (newCounter <= 0) {
          document.body.removeAttribute(lockAttribute);
        } else {
          document.body.setAttribute(lockAttribute, newCounter.toString());
        }
      };
    }, []);
  };
  var RemoveScrollBar = function(_a6) {
    var noRelative = _a6.noRelative, noImportant = _a6.noImportant, _b = _a6.gapMode, gapMode = _b === void 0 ? "margin" : _b;
    useLockAttribute();
    var gap = React26.useMemo(function() {
      return getGapWidth(gapMode);
    }, [gapMode]);
    return React26.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
  };

  // src/client/node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
  init_define_import_meta_env();
  var passiveSupported = false;
  if (typeof window !== "undefined") {
    try {
      options = Object.defineProperty({}, "passive", {
        get: function() {
          passiveSupported = true;
          return true;
        }
      });
      window.addEventListener("test", options, options);
      window.removeEventListener("test", options, options);
    } catch (err) {
      passiveSupported = false;
    }
  }
  var options;
  var nonPassive = passiveSupported ? { passive: false } : false;

  // src/client/node_modules/react-remove-scroll/dist/es2015/handleScroll.js
  init_define_import_meta_env();
  var alwaysContainsScroll = function(node) {
    return node.tagName === "TEXTAREA";
  };
  var elementCanBeScrolled = function(node, overflow) {
    if (!(node instanceof Element)) {
      return false;
    }
    var styles = window.getComputedStyle(node);
    return (
      // not-not-scrollable
      styles[overflow] !== "hidden" && // contains scroll inside self
      !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible")
    );
  };
  var elementCouldBeVScrolled = function(node) {
    return elementCanBeScrolled(node, "overflowY");
  };
  var elementCouldBeHScrolled = function(node) {
    return elementCanBeScrolled(node, "overflowX");
  };
  var locationCouldBeScrolled = function(axis, node) {
    var ownerDocument = node.ownerDocument;
    var current = node;
    do {
      if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) {
        current = current.host;
      }
      var isScrollable = elementCouldBeScrolled(axis, current);
      if (isScrollable) {
        var _a6 = getScrollVariables(axis, current), scrollHeight = _a6[1], clientHeight = _a6[2];
        if (scrollHeight > clientHeight) {
          return true;
        }
      }
      current = current.parentNode;
    } while (current && current !== ownerDocument.body);
    return false;
  };
  var getVScrollVariables = function(_a6) {
    var scrollTop = _a6.scrollTop, scrollHeight = _a6.scrollHeight, clientHeight = _a6.clientHeight;
    return [
      scrollTop,
      scrollHeight,
      clientHeight
    ];
  };
  var getHScrollVariables = function(_a6) {
    var scrollLeft = _a6.scrollLeft, scrollWidth = _a6.scrollWidth, clientWidth = _a6.clientWidth;
    return [
      scrollLeft,
      scrollWidth,
      clientWidth
    ];
  };
  var elementCouldBeScrolled = function(axis, node) {
    return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
  };
  var getScrollVariables = function(axis, node) {
    return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
  };
  var getDirectionFactor = function(axis, direction) {
    return axis === "h" && direction === "rtl" ? -1 : 1;
  };
  var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
    var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
    var delta = directionFactor * sourceDelta;
    var target = event.target;
    var targetInLock = endTarget.contains(target);
    var shouldCancelScroll = false;
    var isDeltaPositive = delta > 0;
    var availableScroll = 0;
    var availableScrollTop = 0;
    do {
      if (!target) {
        break;
      }
      var _a6 = getScrollVariables(axis, target), position = _a6[0], scroll_1 = _a6[1], capacity = _a6[2];
      var elementScroll = scroll_1 - capacity - directionFactor * position;
      if (position || elementScroll) {
        if (elementCouldBeScrolled(axis, target)) {
          availableScroll += elementScroll;
          availableScrollTop += position;
        }
      }
      var parent_1 = target.parentNode;
      target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
    } while (
      // portaled content
      !targetInLock && target !== document.body || // self content
      targetInLock && (endTarget.contains(target) || endTarget === target)
    );
    if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) {
      shouldCancelScroll = true;
    } else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) {
      shouldCancelScroll = true;
    }
    return shouldCancelScroll;
  };

  // src/client/node_modules/react-remove-scroll/dist/es2015/SideEffect.js
  var getTouchXY = function(event) {
    return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
  };
  var getDeltaXY = function(event) {
    return [event.deltaX, event.deltaY];
  };
  var extractRef = function(ref) {
    return ref && "current" in ref ? ref.current : ref;
  };
  var deltaCompare = function(x, y) {
    return x[0] === y[0] && x[1] === y[1];
  };
  var generateStyle = function(id) {
    return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
  };
  var idCounter = 0;
  var lockStack = [];
  function RemoveScrollSideCar(props) {
    var shouldPreventQueue = React27.useRef([]);
    var touchStartRef = React27.useRef([0, 0]);
    var activeAxis = React27.useRef();
    var id = React27.useState(idCounter++)[0];
    var Style2 = React27.useState(styleSingleton)[0];
    var lastProps = React27.useRef(props);
    React27.useEffect(function() {
      lastProps.current = props;
    }, [props]);
    React27.useEffect(function() {
      if (props.inert) {
        document.body.classList.add("block-interactivity-".concat(id));
        var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
        allow_1.forEach(function(el) {
          return el.classList.add("allow-interactivity-".concat(id));
        });
        return function() {
          document.body.classList.remove("block-interactivity-".concat(id));
          allow_1.forEach(function(el) {
            return el.classList.remove("allow-interactivity-".concat(id));
          });
        };
      }
      return;
    }, [props.inert, props.lockRef.current, props.shards]);
    var shouldCancelEvent = React27.useCallback(function(event, parent) {
      if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) {
        return !lastProps.current.allowPinchZoom;
      }
      var touch = getTouchXY(event);
      var touchStart = touchStartRef.current;
      var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
      var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
      var currentAxis;
      var target = event.target;
      var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
      if ("touches" in event && moveDirection === "h" && target.type === "range") {
        return false;
      }
      var selection = window.getSelection();
      var anchorNode = selection && selection.anchorNode;
      var isTouchingSelection = anchorNode ? anchorNode === target || anchorNode.contains(target) : false;
      if (isTouchingSelection) {
        return false;
      }
      var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
      if (!canBeScrolledInMainDirection) {
        return true;
      }
      if (canBeScrolledInMainDirection) {
        currentAxis = moveDirection;
      } else {
        currentAxis = moveDirection === "v" ? "h" : "v";
        canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
      }
      if (!canBeScrolledInMainDirection) {
        return false;
      }
      if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) {
        activeAxis.current = currentAxis;
      }
      if (!currentAxis) {
        return true;
      }
      var cancelingAxis = activeAxis.current || currentAxis;
      return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
    }, []);
    var shouldPrevent = React27.useCallback(function(_event) {
      var event = _event;
      if (!lockStack.length || lockStack[lockStack.length - 1] !== Style2) {
        return;
      }
      var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
      var sourceEvent = shouldPreventQueue.current.filter(function(e) {
        return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
      })[0];
      if (sourceEvent && sourceEvent.should) {
        if (event.cancelable) {
          event.preventDefault();
        }
        return;
      }
      if (!sourceEvent) {
        var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
          return node.contains(event.target);
        });
        var shouldStop = shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation;
        if (shouldStop) {
          if (event.cancelable) {
            event.preventDefault();
          }
        }
      }
    }, []);
    var shouldCancel = React27.useCallback(function(name, delta, target, should) {
      var event = { name, delta, target, should, shadowParent: getOutermostShadowParent(target) };
      shouldPreventQueue.current.push(event);
      setTimeout(function() {
        shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
          return e !== event;
        });
      }, 1);
    }, []);
    var scrollTouchStart = React27.useCallback(function(event) {
      touchStartRef.current = getTouchXY(event);
      activeAxis.current = void 0;
    }, []);
    var scrollWheel = React27.useCallback(function(event) {
      shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
    }, []);
    var scrollTouchMove = React27.useCallback(function(event) {
      shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
    }, []);
    React27.useEffect(function() {
      lockStack.push(Style2);
      props.setCallbacks({
        onScrollCapture: scrollWheel,
        onWheelCapture: scrollWheel,
        onTouchMoveCapture: scrollTouchMove
      });
      document.addEventListener("wheel", shouldPrevent, nonPassive);
      document.addEventListener("touchmove", shouldPrevent, nonPassive);
      document.addEventListener("touchstart", scrollTouchStart, nonPassive);
      return function() {
        lockStack = lockStack.filter(function(inst) {
          return inst !== Style2;
        });
        document.removeEventListener("wheel", shouldPrevent, nonPassive);
        document.removeEventListener("touchmove", shouldPrevent, nonPassive);
        document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
      };
    }, []);
    var removeScrollBar = props.removeScrollBar, inert = props.inert;
    return React27.createElement(
      React27.Fragment,
      null,
      inert ? React27.createElement(Style2, { styles: generateStyle(id) }) : null,
      removeScrollBar ? React27.createElement(RemoveScrollBar, { noRelative: props.noRelative, gapMode: props.gapMode }) : null
    );
  }
  function getOutermostShadowParent(node) {
    var shadowParent = null;
    while (node !== null) {
      if (node instanceof ShadowRoot) {
        shadowParent = node.host;
        node = node.host;
      }
      node = node.parentNode;
    }
    return shadowParent;
  }

  // src/client/node_modules/react-remove-scroll/dist/es2015/sidecar.js
  var sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);

  // src/client/node_modules/react-remove-scroll/dist/es2015/Combination.js
  var ReactRemoveScroll = React28.forwardRef(function(props, ref) {
    return React28.createElement(RemoveScroll, __assign({}, props, { ref, sideCar: sidecar_default }));
  });
  ReactRemoveScroll.classNames = RemoveScroll.classNames;
  var Combination_default = ReactRemoveScroll;

  // src/client/node_modules/@radix-ui/react-popover/dist/index.mjs
  var import_jsx_runtime8 = __toESM(require_react_shim(), 1);
  var POPOVER_NAME = "Popover";
  var [createPopoverContext, createPopoverScope] = createContextScope(POPOVER_NAME, [
    createPopperScope
  ]);
  var usePopperScope = createPopperScope();
  var [PopoverProvider, usePopoverContext] = createPopoverContext(POPOVER_NAME);
  var Popover = (props) => {
    const {
      __scopePopover,
      children,
      open: openProp,
      defaultOpen,
      onOpenChange,
      modal = false
    } = props;
    const popperScope = usePopperScope(__scopePopover);
    const triggerRef = React29.useRef(null);
    const [hasCustomAnchor, setHasCustomAnchor] = React29.useState(false);
    const [open, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen ?? false,
      onChange: onOpenChange,
      caller: POPOVER_NAME
    });
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Root2, { ...popperScope, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
      PopoverProvider,
      {
        scope: __scopePopover,
        contentId: useId2(),
        triggerRef,
        open,
        onOpenChange: setOpen,
        onOpenToggle: React29.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
        hasCustomAnchor,
        onCustomAnchorAdd: React29.useCallback(() => setHasCustomAnchor(true), []),
        onCustomAnchorRemove: React29.useCallback(() => setHasCustomAnchor(false), []),
        modal,
        children
      }
    ) });
  };
  Popover.displayName = POPOVER_NAME;
  var ANCHOR_NAME2 = "PopoverAnchor";
  var PopoverAnchor = React29.forwardRef(
    (props, forwardedRef) => {
      const { __scopePopover, ...anchorProps } = props;
      const context = usePopoverContext(ANCHOR_NAME2, __scopePopover);
      const popperScope = usePopperScope(__scopePopover);
      const { onCustomAnchorAdd, onCustomAnchorRemove } = context;
      React29.useEffect(() => {
        onCustomAnchorAdd();
        return () => onCustomAnchorRemove();
      }, [onCustomAnchorAdd, onCustomAnchorRemove]);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Anchor, { ...popperScope, ...anchorProps, ref: forwardedRef });
    }
  );
  PopoverAnchor.displayName = ANCHOR_NAME2;
  var TRIGGER_NAME = "PopoverTrigger";
  var PopoverTrigger = React29.forwardRef(
    (props, forwardedRef) => {
      const { __scopePopover, ...triggerProps } = props;
      const context = usePopoverContext(TRIGGER_NAME, __scopePopover);
      const popperScope = usePopperScope(__scopePopover);
      const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
      const trigger = /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        Primitive.button,
        {
          type: "button",
          "aria-haspopup": "dialog",
          "aria-expanded": context.open,
          "aria-controls": context.open ? context.contentId : void 0,
          "data-state": getState(context.open),
          ...triggerProps,
          ref: composedTriggerRef,
          onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
        }
      );
      return context.hasCustomAnchor ? trigger : /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Anchor, { asChild: true, ...popperScope, children: trigger });
    }
  );
  PopoverTrigger.displayName = TRIGGER_NAME;
  var PORTAL_NAME2 = "PopoverPortal";
  var [PortalProvider, usePortalContext] = createPopoverContext(PORTAL_NAME2, {
    forceMount: void 0
  });
  var PopoverPortal = (props) => {
    const { __scopePopover, forceMount, children, container } = props;
    const context = usePopoverContext(PORTAL_NAME2, __scopePopover);
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(PortalProvider, { scope: __scopePopover, forceMount, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Portal, { asChild: true, container, children }) }) });
  };
  PopoverPortal.displayName = PORTAL_NAME2;
  var CONTENT_NAME2 = "PopoverContent";
  var PopoverContent = React29.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext(CONTENT_NAME2, props.__scopePopover);
      const { forceMount = portalContext.forceMount, ...contentProps } = props;
      const context = usePopoverContext(CONTENT_NAME2, props.__scopePopover);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Presence, { present: forceMount || context.open, children: context.modal ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(PopoverContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(PopoverContentNonModal, { ...contentProps, ref: forwardedRef }) });
    }
  );
  PopoverContent.displayName = CONTENT_NAME2;
  var Slot = createSlot("PopoverContent.RemoveScroll");
  var PopoverContentModal = React29.forwardRef(
    (props, forwardedRef) => {
      const context = usePopoverContext(CONTENT_NAME2, props.__scopePopover);
      const contentRef = React29.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, contentRef);
      const isRightClickOutsideRef = React29.useRef(false);
      React29.useEffect(() => {
        const content = contentRef.current;
        if (content) return hideOthers(content);
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Combination_default, { as: Slot, allowPinchZoom: true, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        PopoverContentImpl,
        {
          ...props,
          ref: composedRefs,
          trapFocus: context.open,
          disableOutsidePointerEvents: true,
          onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
            event.preventDefault();
            if (!isRightClickOutsideRef.current) context.triggerRef.current?.focus();
          }),
          onPointerDownOutside: composeEventHandlers(
            props.onPointerDownOutside,
            (event) => {
              const originalEvent = event.detail.originalEvent;
              const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
              const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
              isRightClickOutsideRef.current = isRightClick;
            },
            { checkForDefaultPrevented: false }
          ),
          onFocusOutside: composeEventHandlers(
            props.onFocusOutside,
            (event) => event.preventDefault(),
            { checkForDefaultPrevented: false }
          )
        }
      ) });
    }
  );
  var PopoverContentNonModal = React29.forwardRef(
    (props, forwardedRef) => {
      const context = usePopoverContext(CONTENT_NAME2, props.__scopePopover);
      const hasInteractedOutsideRef = React29.useRef(false);
      const hasPointerDownOutsideRef = React29.useRef(false);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        PopoverContentImpl,
        {
          ...props,
          ref: forwardedRef,
          trapFocus: false,
          disableOutsidePointerEvents: false,
          onCloseAutoFocus: (event) => {
            props.onCloseAutoFocus?.(event);
            if (!event.defaultPrevented) {
              if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
              event.preventDefault();
            }
            hasInteractedOutsideRef.current = false;
            hasPointerDownOutsideRef.current = false;
          },
          onInteractOutside: (event) => {
            props.onInteractOutside?.(event);
            if (!event.defaultPrevented) {
              hasInteractedOutsideRef.current = true;
              if (event.detail.originalEvent.type === "pointerdown") {
                hasPointerDownOutsideRef.current = true;
              }
            }
            const target = event.target;
            const targetIsTrigger = context.triggerRef.current?.contains(target);
            if (targetIsTrigger) event.preventDefault();
            if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
              event.preventDefault();
            }
          }
        }
      );
    }
  );
  var PopoverContentImpl = React29.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopePopover,
        trapFocus,
        onOpenAutoFocus,
        onCloseAutoFocus,
        disableOutsidePointerEvents,
        onEscapeKeyDown,
        onPointerDownOutside,
        onFocusOutside,
        onInteractOutside,
        ...contentProps
      } = props;
      const context = usePopoverContext(CONTENT_NAME2, __scopePopover);
      const popperScope = usePopperScope(__scopePopover);
      useFocusGuards();
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        FocusScope,
        {
          asChild: true,
          loop: true,
          trapped: trapFocus,
          onMountAutoFocus: onOpenAutoFocus,
          onUnmountAutoFocus: onCloseAutoFocus,
          children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
            DismissableLayer,
            {
              asChild: true,
              disableOutsidePointerEvents,
              onInteractOutside,
              onEscapeKeyDown,
              onPointerDownOutside,
              onFocusOutside,
              onDismiss: () => context.onOpenChange(false),
              deferPointerDownOutside: true,
              children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
                Content,
                {
                  "data-state": getState(context.open),
                  role: "dialog",
                  id: context.contentId,
                  ...popperScope,
                  ...contentProps,
                  ref: forwardedRef,
                  style: {
                    ...contentProps.style,
                    // re-namespace exposed content custom properties
                    ...{
                      "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                      "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                      "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                      "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                      "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                    }
                  }
                }
              )
            }
          )
        }
      );
    }
  );
  var CLOSE_NAME = "PopoverClose";
  var PopoverClose = React29.forwardRef(
    (props, forwardedRef) => {
      const { __scopePopover, ...closeProps } = props;
      const context = usePopoverContext(CLOSE_NAME, __scopePopover);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(
        Primitive.button,
        {
          type: "button",
          ...closeProps,
          ref: forwardedRef,
          onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
        }
      );
    }
  );
  PopoverClose.displayName = CLOSE_NAME;
  var ARROW_NAME2 = "PopoverArrow";
  var PopoverArrow = React29.forwardRef(
    (props, forwardedRef) => {
      const { __scopePopover, ...arrowProps } = props;
      const popperScope = usePopperScope(__scopePopover);
      return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(Arrow2, { ...popperScope, ...arrowProps, ref: forwardedRef });
    }
  );
  PopoverArrow.displayName = ARROW_NAME2;
  function getState(open) {
    return open ? "open" : "closed";
  }
  var Root22 = Popover;
  var Anchor2 = PopoverAnchor;
  var Trigger = PopoverTrigger;
  var Portal2 = PopoverPortal;
  var Content2 = PopoverContent;

  // src/client/src/shared/ui/Calendar.tsx
  init_define_import_meta_env();
  var import_react9 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/utils/date.ts
  init_define_import_meta_env();
  var MONTHS_RU = [
    "\u042F\u043D\u0432\u0430\u0440\u044C",
    "\u0424\u0435\u0432\u0440\u0430\u043B\u044C",
    "\u041C\u0430\u0440\u0442",
    "\u0410\u043F\u0440\u0435\u043B\u044C",
    "\u041C\u0430\u0439",
    "\u0418\u044E\u043D\u044C",
    "\u0418\u044E\u043B\u044C",
    "\u0410\u0432\u0433\u0443\u0441\u0442",
    "\u0421\u0435\u043D\u0442\u044F\u0431\u0440\u044C",
    "\u041E\u043A\u0442\u044F\u0431\u0440\u044C",
    "\u041D\u043E\u044F\u0431\u0440\u044C",
    "\u0414\u0435\u043A\u0430\u0431\u0440\u044C"
  ];
  var MONTHS_RU_SHORT = [
    "\u042F\u043D\u0432",
    "\u0424\u0435\u0432",
    "\u041C\u0430\u0440",
    "\u0410\u043F\u0440",
    "\u041C\u0430\u0439",
    "\u0418\u044E\u043D",
    "\u0418\u044E\u043B",
    "\u0410\u0432\u0433",
    "\u0421\u0435\u043D",
    "\u041E\u043A\u0442",
    "\u041D\u043E\u044F",
    "\u0414\u0435\u043A"
  ];
  var WEEKDAYS_RU = ["\u041F\u043D", "\u0412\u0442", "\u0421\u0440", "\u0427\u0442", "\u041F\u0442", "\u0421\u0431", "\u0412\u0441"];
  function parseISO(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso ?? "");
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }
  function toISO(y, m, d) {
    const p = (n) => String(n).padStart(2, "0");
    return `${p(y)}-${p(m)}-${p(d)}`;
  }
  function daysInMonth(y, m) {
    return new Date(y, m, 0).getDate();
  }
  function monthMatrix(y, m) {
    const total = daysInMonth(y, m);
    const firstDow = (new Date(y, m - 1, 1).getDay() + 6) % 7;
    const cells = Array(firstDow).fill(null);
    for (let d = 1; d <= total; d++) cells.push(d);
    while (cells.length % 7 !== 0) cells.push(null);
    const weeks = [];
    for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
    return weeks;
  }

  // src/client/src/shared/ui/Calendar.tsx
  var MIN_YEAR = 1900;
  var MAX_YEAR = 2100;
  var clampYear = (y) => Math.min(MAX_YEAR, Math.max(MIN_YEAR, y));
  function Calendar({ value, onSelect, precision = "day", onClose }) {
    const now = /* @__PURE__ */ new Date();
    const sel = parseISO(value);
    const start = sel ?? { y: now.getFullYear(), m: now.getMonth() + 1, d: now.getDate() };
    const terminalView = precision === "year" ? "years" : precision === "month" ? "months" : "days";
    const [view, setView] = (0, import_react9.useState)(terminalView);
    const [fy, setFy] = (0, import_react9.useState)(clampYear(start.y));
    const [fm, setFm] = (0, import_react9.useState)(start.m);
    const [fd, setFd] = (0, import_react9.useState)(start.d);
    const gridRef = (0, import_react9.useRef)(null);
    (0, import_react9.useLayoutEffect)(() => {
      gridRef.current?.querySelector('[data-focus="true"]')?.focus();
    }, [fy, fm, fd, view]);
    const todayISO = toISO(now.getFullYear(), now.getMonth() + 1, now.getDate());
    function selectDay(y, m, d) {
      onSelect(toISO(y, m, d));
      onClose?.();
    }
    function selectMonth(y, m) {
      onSelect(toISO(y, m, 1));
      onClose?.();
    }
    function selectYear(y) {
      if (precision === "year") {
        onSelect(toISO(y, 1, 1));
        onClose?.();
        return;
      }
      setFy(y);
      setView(precision === "month" ? "months" : "days");
    }
    function shiftDay(delta) {
      const dt = new Date(fy, fm - 1, fd);
      dt.setDate(dt.getDate() + delta);
      const y = clampYear(dt.getFullYear());
      setFy(y);
      setFm(dt.getMonth() + 1);
      setFd(dt.getDate());
    }
    function shiftMonth(delta) {
      const dt = new Date(fy, fm - 1 + delta, 1);
      const y = clampYear(dt.getFullYear()), m = dt.getMonth() + 1;
      setFy(y);
      setFm(m);
      setFd(Math.min(fd, daysInMonth(y, m)));
    }
    function onDaysKey(e) {
      switch (e.key) {
        case "ArrowLeft":
          shiftDay(-1);
          break;
        case "ArrowRight":
          shiftDay(1);
          break;
        case "ArrowUp":
          shiftDay(-7);
          break;
        case "ArrowDown":
          shiftDay(7);
          break;
        case "Home":
          shiftDay(-((new Date(fy, fm - 1, fd).getDay() + 6) % 7));
          break;
        // к понедельнику недели
        case "End":
          shiftDay(6 - (new Date(fy, fm - 1, fd).getDay() + 6) % 7);
          break;
        // к воскресенью
        case "PageUp":
          shiftMonth(e.shiftKey ? -12 : -1);
          break;
        case "PageDown":
          shiftMonth(e.shiftKey ? 12 : 1);
          break;
        case "Enter":
        case " ":
          selectDay(fy, fm, fd);
          break;
        default:
          return;
      }
      e.preventDefault();
    }
    function onMonthsKey(e) {
      let m = fm, y = fy;
      switch (e.key) {
        case "ArrowLeft":
          if (m > 1) m--;
          else {
            m = 12;
            y = clampYear(y - 1);
          }
          break;
        case "ArrowRight":
          if (m < 12) m++;
          else {
            m = 1;
            y = clampYear(y + 1);
          }
          break;
        case "ArrowUp":
          if (m > 4) m -= 4;
          break;
        case "ArrowDown":
          if (m <= 8) m += 4;
          break;
        case "PageUp":
          y = clampYear(y - 1);
          break;
        case "PageDown":
          y = clampYear(y + 1);
          break;
        case "Enter":
        case " ":
          selectMonth(fy, fm);
          e.preventDefault();
          return;
        default:
          return;
      }
      setFm(m);
      setFy(y);
      e.preventDefault();
    }
    const YEARS_PER_PAGE = 16;
    const pageStart = Math.floor((fy - MIN_YEAR) / YEARS_PER_PAGE) * YEARS_PER_PAGE + MIN_YEAR;
    function onYearsKey(e) {
      switch (e.key) {
        case "ArrowLeft":
          setFy((y) => clampYear(y - 1));
          break;
        case "ArrowRight":
          setFy((y) => clampYear(y + 1));
          break;
        case "ArrowUp":
          setFy((y) => clampYear(y - 4));
          break;
        case "ArrowDown":
          setFy((y) => clampYear(y + 4));
          break;
        case "PageUp":
          setFy((y) => clampYear(y - YEARS_PER_PAGE));
          break;
        case "PageDown":
          setFy((y) => clampYear(y + YEARS_PER_PAGE));
          break;
        case "Enter":
        case " ":
          selectYear(fy);
          break;
        default:
          return;
      }
      e.preventDefault();
    }
    const cellBase = "flex items-center justify-center rounded-full text-sm transition-colors focus:outline-none disabled:opacity-30 disabled:pointer-events-none";
    const focusRing = (isFocus, isSel) => !isFocus ? "" : isSel ? "ring-2 ring-white/70 ring-inset" : "ring-2 ring-brand ring-inset";
    const HEADER_BTN = "flex items-center justify-center h-8 w-8 rounded-full text-fg3 hover:text-fg1 hover:bg-black/5 dark:hover:bg-white/10 transition-colors";
    const header = /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between mb-2 px-1" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        "aria-label": "\u041D\u0430\u0437\u0430\u0434",
        className: HEADER_BTN,
        onClick: () => view === "years" ? setFy((y) => clampYear(y - YEARS_PER_PAGE)) : view === "months" ? setFy((y) => clampYear(y - 1)) : shiftMonth(-1)
      },
      /* @__PURE__ */ React.createElement(ChevronLeft, { size: 18 })
    ), view === "years" ? /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium text-fg1 tabular-nums" }, clampYear(pageStart), "\u2013", clampYear(pageStart + YEARS_PER_PAGE - 1)) : /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0433\u043E\u0434" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => setView("years"),
        className: "flex items-center gap-1 px-2 h-8 rounded-full text-sm font-medium text-fg1 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
      },
      view === "days" ? `${MONTHS_RU[fm - 1]} ${fy}` : fy,
      /* @__PURE__ */ React.createElement(ChevronDown, { size: 14, className: "text-fg4" })
    )), /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        "aria-label": "\u0412\u043F\u0435\u0440\u0451\u0434",
        className: HEADER_BTN,
        onClick: () => view === "years" ? setFy((y) => clampYear(y + YEARS_PER_PAGE)) : view === "months" ? setFy((y) => clampYear(y + 1)) : shiftMonth(1)
      },
      /* @__PURE__ */ React.createElement(ChevronRight, { size: 18 })
    ));
    let body;
    if (view === "days") {
      const weeks = monthMatrix(fy, fm);
      body = /* @__PURE__ */ React.createElement("div", { ref: gridRef, role: "grid", "aria-label": "\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C", onKeyDown: onDaysKey }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-7 mb-1" }, WEEKDAYS_RU.map((w) => /* @__PURE__ */ React.createElement("div", { key: w, className: "h-7 flex items-center justify-center text-xs text-fg4" }, w))), weeks.map((week, wi) => /* @__PURE__ */ React.createElement("div", { key: wi, role: "row", className: "grid grid-cols-7" }, week.map((d, di) => {
        if (d == null) return /* @__PURE__ */ React.createElement("div", { key: di, className: "h-9" });
        const iso = toISO(fy, fm, d);
        const isSel = !!sel && sel.y === fy && sel.m === fm && sel.d === d;
        const isToday = iso === todayISO;
        const isFocus = d === fd;
        return /* @__PURE__ */ React.createElement("div", { key: di, role: "gridcell", className: "h-9 flex items-center justify-center" }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            "data-focus": isFocus,
            tabIndex: isFocus ? 0 : -1,
            "aria-selected": isSel,
            "aria-current": isToday ? "date" : void 0,
            onClick: () => selectDay(fy, fm, d),
            className: `${cellBase} h-9 w-9 ${focusRing(isFocus, isSel)} ${isSel ? "bg-brand text-white font-medium" : isToday ? `text-brand hover:bg-brand-subtle ${isFocus ? "" : "ring-1 ring-brand"}` : "text-fg1 hover:bg-black/5 dark:hover:bg-white/10"}`
          },
          d
        ));
      }))));
    } else if (view === "months") {
      body = /* @__PURE__ */ React.createElement("div", { ref: gridRef, role: "grid", "aria-label": "\u0412\u044B\u0431\u043E\u0440 \u043C\u0435\u0441\u044F\u0446\u0430", onKeyDown: onMonthsKey, className: "grid grid-cols-4 gap-1" }, MONTHS_RU_SHORT.map((mn, i) => {
        const m = i + 1;
        const isSel = !!sel && sel.y === fy && sel.m === m && precision === "month";
        const isCur = now.getFullYear() === fy && now.getMonth() + 1 === m;
        const isFocus = m === fm;
        return /* @__PURE__ */ React.createElement(
          "button",
          {
            key: mn,
            type: "button",
            "data-focus": isFocus,
            tabIndex: isFocus ? 0 : -1,
            "aria-selected": isSel,
            onClick: () => selectMonth(fy, m),
            className: `${cellBase} h-11 ${focusRing(isFocus, isSel)} ${isSel ? "bg-brand text-white font-medium" : isCur ? `text-brand hover:bg-brand-subtle ${isFocus ? "" : "ring-1 ring-brand"}` : "text-fg1 hover:bg-black/5 dark:hover:bg-white/10"}`
          },
          mn
        );
      }));
    } else {
      body = /* @__PURE__ */ React.createElement("div", { ref: gridRef, role: "grid", "aria-label": "\u0412\u044B\u0431\u043E\u0440 \u0433\u043E\u0434\u0430", onKeyDown: onYearsKey, className: "grid grid-cols-4 gap-1" }, Array.from({ length: YEARS_PER_PAGE }, (_, i) => pageStart + i).filter((y) => y <= MAX_YEAR).map((y) => {
        const isSel = !!sel && sel.y === y && precision === "year";
        const isCur = y === now.getFullYear();
        const isFocus = y === fy;
        return /* @__PURE__ */ React.createElement(
          "button",
          {
            key: y,
            type: "button",
            "data-focus": isFocus,
            tabIndex: isFocus ? 0 : -1,
            "aria-selected": isSel,
            onClick: () => selectYear(y),
            className: `${cellBase} h-11 tabular-nums ${focusRing(isFocus, isSel)} ${isSel ? "bg-brand text-white font-medium" : isCur ? `text-brand hover:bg-brand-subtle ${isFocus ? "" : "ring-1 ring-brand"}` : "text-fg1 hover:bg-black/5 dark:hover:bg-white/10"}`
          },
          y
        );
      }));
    }
    return /* @__PURE__ */ React.createElement("div", { className: "w-72 p-2 select-none" }, header, body);
  }

  // src/client/src/shared/ui/DateInput.tsx
  var EMPTY_SEGMENTS = { d: "", m: "", y: "" };
  function DateInput({ value, onChange, precision = "day", className = "", disabled = false, readOnly = false, required = false, calendar = true, compact = false }) {
    const [typed, setTyped] = (0, import_react10.useState)(null);
    const [focused, setFocused] = (0, import_react10.useState)(false);
    const [pickerOpen, setPickerOpen] = (0, import_react10.useState)(false);
    const anchorRef = (0, import_react10.useRef)(null);
    const [portalContainer, setPortalContainer] = (0, import_react10.useState)(null);
    const showMonth = precision !== "year";
    const showDay = precision === "day";
    const dayRef = (0, import_react10.useRef)(null);
    const monRef = (0, import_react10.useRef)(null);
    const yrRef = (0, import_react10.useRef)(null);
    const blurTimer = (0, import_react10.useRef)(void 0);
    const parsed = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value ?? "");
    const fromValue = parsed ? { d: parsed[3], m: parsed[2], y: parsed[1] } : EMPTY_SEGMENTS;
    const shown = focused ? typed ?? fromValue : fromValue;
    const { d, m, y } = shown;
    const setSeg = (key, v) => setTyped((prev) => ({ ...prev ?? fromValue, [key]: v }));
    const setD = (v) => setSeg("d", v);
    const setM = (v) => setSeg("m", v);
    const setY = (v) => setSeg("y", v);
    function onFocus() {
      clearTimeout(blurTimer.current);
      setFocused(true);
    }
    function onBlur() {
      blurTimer.current = setTimeout(() => {
        setFocused(false);
        setTyped(null);
      }, 120);
    }
    function emit(dd, mm, yyyy) {
      if (precision === "year") {
        if (yyyy.length === 4) onChange(`${yyyy}-01-01`);
        else if (!yyyy) onChange("");
        return;
      }
      if (precision === "month") {
        if (mm.length === 2 && yyyy.length === 4) onChange(`${yyyy}-${mm}-01`);
        else if (!mm && !yyyy) onChange("");
        return;
      }
      if (dd.length === 2 && mm.length === 2 && yyyy.length === 4) {
        onChange(`${yyyy}-${mm}-${dd}`);
      } else if (!dd && !mm && !yyyy) {
        onChange("");
      }
    }
    function advance(ref) {
      ref.current?.focus();
      setTimeout(() => ref.current?.select(), 0);
    }
    function handleD(raw) {
      const v = raw.replace(/\D/g, "").slice(0, 2);
      if (v.length === 2 && d.length < 2) {
        setD(v);
        advance(monRef);
        emit(v, m, y);
      } else if (v.length === 1 && d === "" && +v > 3) {
        const p = "0" + v;
        setD(p);
        advance(monRef);
        emit(p, m, y);
      } else {
        setD(v);
        emit(v, m, y);
      }
    }
    function handleM(raw) {
      const v = raw.replace(/\D/g, "").slice(0, 2);
      if (v.length === 2 && m.length < 2) {
        setM(v);
        advance(yrRef);
        emit(d, v, y);
      } else if (v.length === 1 && m === "" && +v > 1) {
        const p = "0" + v;
        setM(p);
        advance(yrRef);
        emit(d, p, y);
      } else {
        setM(v);
        emit(d, v, y);
      }
    }
    function handleY(raw) {
      const v = raw.replace(/\D/g, "").slice(0, 4);
      setY(v);
      emit(d, m, v);
    }
    function onDayKey(e) {
      if ((e.key === "." || e.key === "/") && d) {
        e.preventDefault();
        advance(monRef);
      }
    }
    function onMonKey(e) {
      if (e.key === "Backspace" && m === "") {
        advance(dayRef);
      } else if ((e.key === "." || e.key === "/") && m) {
        e.preventDefault();
        advance(yrRef);
      }
    }
    function onYrKey(e) {
      if (e.key === "Backspace" && y === "") {
        advance(monRef);
      }
    }
    function blurD() {
      const cur = dayRef.current?.value ?? d;
      if (cur.length === 1) {
        const p = "0" + cur;
        setD(p);
        emit(p, m, y);
      }
    }
    function blurM() {
      const cur = monRef.current?.value ?? m;
      if (cur.length === 1) {
        const p = "0" + cur;
        setM(p);
        emit(d, p, y);
      }
    }
    const seg = [
      "border-0 outline-none bg-transparent text-center min-w-0 p-0",
      disabled ? "cursor-not-allowed" : "focus:bg-brand-subtle",
      "rounded-sm tabular-nums"
    ].join(" ");
    const showCalendar = calendar && !readOnly;
    function onContainerKey(e) {
      if (showCalendar && !disabled && e.altKey && e.key === "ArrowDown") {
        e.preventDefault();
        setPickerOpen(true);
      }
    }
    const segments = /* @__PURE__ */ React.createElement("div", { ref: anchorRef, className: `flex items-center group ${className}`, onKeyDown: onContainerKey }, showDay && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
      "input",
      {
        ref: dayRef,
        type: "text",
        inputMode: "numeric",
        placeholder: "\u0414\u0414",
        maxLength: 2,
        style: { width: "2.2ch" },
        value: d,
        disabled,
        readOnly,
        "aria-required": required || void 0,
        onChange: (e) => handleD(e.target.value),
        onKeyDown: onDayKey,
        onFocus,
        onBlur: () => {
          blurD();
          onBlur();
        },
        className: seg
      }
    ), /* @__PURE__ */ React.createElement("span", { className: "text-fg4 select-none" }, ".")), showMonth && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
      "input",
      {
        ref: monRef,
        type: "text",
        inputMode: "numeric",
        placeholder: "\u041C\u041C",
        maxLength: 2,
        style: { width: "2.2ch" },
        value: m,
        disabled,
        readOnly,
        "aria-required": required || void 0,
        onChange: (e) => handleM(e.target.value),
        onKeyDown: onMonKey,
        onFocus,
        onBlur: () => {
          blurM();
          onBlur();
        },
        className: seg
      }
    ), /* @__PURE__ */ React.createElement("span", { className: "text-fg4 select-none" }, ".")), /* @__PURE__ */ React.createElement(
      "input",
      {
        ref: yrRef,
        type: "text",
        inputMode: "numeric",
        placeholder: "\u0413\u0413\u0413\u0413",
        maxLength: 4,
        style: { width: "4ch" },
        value: y,
        disabled,
        readOnly,
        "aria-required": required || void 0,
        onChange: (e) => handleY(e.target.value),
        onKeyDown: onYrKey,
        onFocus,
        onBlur,
        className: seg
      }
    ), showCalendar && /* @__PURE__ */ React.createElement(Trigger, { asChild: true }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        disabled,
        "aria-label": "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C",
        className: `ml-1 shrink-0 flex items-center justify-center h-5 w-5 rounded-full text-fg4 hover:text-brand hover:bg-black/5 dark:hover:bg-white/10 transition disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand ${compact ? "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 data-[state=open]:opacity-100" : ""}`
      },
      /* @__PURE__ */ React.createElement(CalendarDays, { size: compact ? 13 : 14 })
    )));
    if (!showCalendar) return segments;
    function handleOpenChange(o) {
      if (o) setPortalContainer(anchorRef.current?.closest('[role="dialog"]') ?? null);
      setPickerOpen(o);
    }
    return /* @__PURE__ */ React.createElement(Root22, { open: pickerOpen, onOpenChange: handleOpenChange }, /* @__PURE__ */ React.createElement(Anchor2, { asChild: true }, segments), /* @__PURE__ */ React.createElement(Portal2, { container: portalContainer ?? void 0 }, /* @__PURE__ */ React.createElement(
      Content2,
      {
        align: "start",
        sideOffset: 6,
        className: "z-50 rounded-2xl bg-surface border border-stroke focus:outline-none",
        style: { boxShadow: "var(--f-shadow16)" }
      },
      /* @__PURE__ */ React.createElement(
        Calendar,
        {
          value,
          precision,
          onSelect: (iso) => onChange(iso),
          onClose: () => setPickerOpen(false)
        }
      )
    )));
  }

  // src/client/src/shared/ui/DateField.tsx
  init_define_import_meta_env();
  var import_react11 = __toESM(require_react_shim(), 1);
  function DateField({
    label,
    value,
    onChange,
    precision,
    required,
    hint,
    invalid,
    disabled,
    readOnly
  }) {
    const [focused, setFocused] = (0, import_react11.useState)(false);
    return /* @__PURE__ */ React.createElement(
      OutlinedField,
      {
        label,
        required,
        invalid,
        hint,
        raise: "always",
        focused,
        readOnly
      },
      /* @__PURE__ */ React.createElement(
        "div",
        {
          className: `h-14 rounded-md px-4 flex items-center text-sm text-fg1 ${disabled ? "opacity-50" : ""}`,
          onFocus: () => setFocused(true),
          onBlur: (e) => {
            if (!e.currentTarget.contains(e.relatedTarget)) setFocused(false);
          }
        },
        /* @__PURE__ */ React.createElement(
          DateInput,
          {
            value,
            onChange,
            precision,
            disabled,
            readOnly,
            required
          }
        )
      )
    );
  }

  // src/client/src/shared/ui/Select.tsx
  init_define_import_meta_env();

  // src/client/node_modules/@radix-ui/react-select/dist/index.mjs
  init_define_import_meta_env();
  var React34 = __toESM(require_react_shim(), 1);
  var ReactDOM4 = __toESM(require_react_dom_shim(), 1);

  // src/client/node_modules/@radix-ui/number/dist/index.mjs
  init_define_import_meta_env();
  function clamp2(value, [min2, max2]) {
    return Math.min(max2, Math.max(min2, value));
  }

  // src/client/node_modules/@radix-ui/react-collection/dist/index.mjs
  init_define_import_meta_env();
  var React30 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime9 = __toESM(require_react_shim(), 1);
  var React210 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime10 = __toESM(require_react_shim(), 1);
  function createCollection(name) {
    const PROVIDER_NAME3 = name + "CollectionProvider";
    const [createCollectionContext, createCollectionScope5] = createContextScope(PROVIDER_NAME3);
    const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(
      PROVIDER_NAME3,
      { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
    );
    const CollectionProvider = (props) => {
      const { scope, children } = props;
      const ref = React30.useRef(null);
      const itemMap = React30.useRef(/* @__PURE__ */ new Map()).current;
      return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(CollectionProviderImpl, { scope, itemMap, collectionRef: ref, children });
    };
    CollectionProvider.displayName = PROVIDER_NAME3;
    const COLLECTION_SLOT_NAME = name + "CollectionSlot";
    const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
    const CollectionSlot = React30.forwardRef(
      (props, forwardedRef) => {
        const { scope, children } = props;
        const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
        const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
        return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(CollectionSlotImpl, { ref: composedRefs, children });
      }
    );
    CollectionSlot.displayName = COLLECTION_SLOT_NAME;
    const ITEM_SLOT_NAME = name + "CollectionItemSlot";
    const ITEM_DATA_ATTR = "data-radix-collection-item";
    const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
    const CollectionItemSlot = React30.forwardRef(
      (props, forwardedRef) => {
        const { scope, children, ...itemData } = props;
        const ref = React30.useRef(null);
        const composedRefs = useComposedRefs(forwardedRef, ref);
        const context = useCollectionContext(ITEM_SLOT_NAME, scope);
        React30.useEffect(() => {
          context.itemMap.set(ref, { ref, ...itemData });
          return () => void context.itemMap.delete(ref);
        });
        return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(CollectionItemSlotImpl, { ...{ [ITEM_DATA_ATTR]: "" }, ref: composedRefs, children });
      }
    );
    CollectionItemSlot.displayName = ITEM_SLOT_NAME;
    function useCollection5(scope) {
      const context = useCollectionContext(name + "CollectionConsumer", scope);
      const getItems = React30.useCallback(() => {
        const collectionNode = context.collectionRef.current;
        if (!collectionNode) return [];
        const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
        const items = Array.from(context.itemMap.values());
        const orderedItems = items.sort(
          (a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current)
        );
        return orderedItems;
      }, [context.collectionRef, context.itemMap]);
      return getItems;
    }
    return [
      { Provider: CollectionProvider, Slot: CollectionSlot, ItemSlot: CollectionItemSlot },
      useCollection5,
      createCollectionScope5
    ];
  }

  // src/client/node_modules/@radix-ui/react-direction/dist/index.mjs
  init_define_import_meta_env();
  var React31 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime11 = __toESM(require_react_shim(), 1);
  var DirectionContext = React31.createContext(void 0);
  function useDirection(localDir) {
    const globalDir = React31.useContext(DirectionContext);
    return localDir || globalDir || "ltr";
  }

  // src/client/node_modules/@radix-ui/react-use-previous/dist/index.mjs
  init_define_import_meta_env();
  var React32 = __toESM(require_react_shim(), 1);
  function usePrevious(value) {
    const ref = React32.useRef({ value, previous: value });
    return React32.useMemo(() => {
      if (ref.current.value !== value) {
        ref.current.previous = ref.current.value;
        ref.current.value = value;
      }
      return ref.current.previous;
    }, [value]);
  }

  // src/client/node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
  init_define_import_meta_env();
  var React33 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime12 = __toESM(require_react_shim(), 1);
  var VISUALLY_HIDDEN_STYLES = Object.freeze({
    // See: https://github.com/twbs/bootstrap/blob/main/scss/mixins/_visually-hidden.scss
    position: "absolute",
    border: 0,
    width: 1,
    height: 1,
    padding: 0,
    margin: -1,
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    wordWrap: "normal"
  });
  var NAME2 = "VisuallyHidden";
  var VisuallyHidden = React33.forwardRef(
    (props, forwardedRef) => {
      return /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
        Primitive.span,
        {
          ...props,
          ref: forwardedRef,
          style: { ...VISUALLY_HIDDEN_STYLES, ...props.style }
        }
      );
    }
  );
  VisuallyHidden.displayName = NAME2;

  // src/client/node_modules/@radix-ui/react-select/dist/index.mjs
  var import_jsx_runtime13 = __toESM(require_react_shim(), 1);
  var OPEN_KEYS = [" ", "Enter", "ArrowUp", "ArrowDown"];
  var SELECTION_KEYS = [" ", "Enter"];
  var SELECT_NAME = "Select";
  var [Collection, useCollection, createCollectionScope] = createCollection(SELECT_NAME);
  var [createSelectContext, createSelectScope] = createContextScope(SELECT_NAME, [
    createCollectionScope,
    createPopperScope
  ]);
  var usePopperScope2 = createPopperScope();
  var [SelectProviderImpl, useSelectContext] = createSelectContext(SELECT_NAME);
  var [SelectNativeOptionsProvider, useSelectNativeOptionsContext] = createSelectContext(SELECT_NAME);
  var PROVIDER_NAME = "SelectProvider";
  function SelectProvider(props) {
    const {
      __scopeSelect,
      children,
      open: openProp,
      defaultOpen,
      onOpenChange,
      value: valueProp,
      defaultValue,
      onValueChange,
      dir,
      name,
      autoComplete,
      disabled,
      required,
      form,
      // @ts-expect-error internal render prop used by `Select` to compose its default parts
      internal_do_not_use_render
    } = props;
    const popperScope = usePopperScope2(__scopeSelect);
    const [trigger, setTrigger] = React34.useState(null);
    const [valueNode, setValueNode] = React34.useState(null);
    const [valueNodeHasChildren, setValueNodeHasChildren] = React34.useState(false);
    const direction = useDirection(dir);
    const [open, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen ?? false,
      onChange: onOpenChange,
      caller: SELECT_NAME
    });
    const [value, setValue] = useControllableState({
      prop: valueProp,
      defaultProp: defaultValue,
      onChange: onValueChange,
      caller: SELECT_NAME
    });
    const triggerPointerDownPosRef = React34.useRef(null);
    const isFormControl = trigger ? !!form || !!trigger.closest("form") : true;
    const [nativeOptionsSet, setNativeOptionsSet] = React34.useState(/* @__PURE__ */ new Set());
    const contentId = useId2();
    const nativeSelectKey = Array.from(nativeOptionsSet).map((option) => option.props.value).join(";");
    const handleNativeOptionAdd = React34.useCallback((option) => {
      setNativeOptionsSet((prev) => new Set(prev).add(option));
    }, []);
    const handleNativeOptionRemove = React34.useCallback((option) => {
      setNativeOptionsSet((prev) => {
        const optionsSet = new Set(prev);
        optionsSet.delete(option);
        return optionsSet;
      });
    }, []);
    const context = {
      required,
      trigger,
      onTriggerChange: setTrigger,
      valueNode,
      onValueNodeChange: setValueNode,
      valueNodeHasChildren,
      onValueNodeHasChildrenChange: setValueNodeHasChildren,
      contentId,
      value,
      onValueChange: setValue,
      open,
      onOpenChange: setOpen,
      dir: direction,
      triggerPointerDownPosRef,
      disabled,
      name,
      autoComplete,
      form,
      nativeOptions: nativeOptionsSet,
      nativeSelectKey,
      isFormControl
    };
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Root2, { ...popperScope, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(SelectProviderImpl, { scope: __scopeSelect, ...context, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Collection.Provider, { scope: __scopeSelect, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      SelectNativeOptionsProvider,
      {
        scope: __scopeSelect,
        onNativeOptionAdd: handleNativeOptionAdd,
        onNativeOptionRemove: handleNativeOptionRemove,
        children: isFunction2(internal_do_not_use_render) ? internal_do_not_use_render(context) : children
      }
    ) }) }) });
  }
  SelectProvider.displayName = PROVIDER_NAME;
  var Select = (props) => {
    const { __scopeSelect, children, ...providerProps } = props;
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      SelectProvider,
      {
        __scopeSelect,
        ...providerProps,
        internal_do_not_use_render: ({ isFormControl }) => /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(import_jsx_runtime13.Fragment, { children: [
          children,
          isFormControl ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
            SelectBubbleInput,
            {
              __scopeSelect
            }
          ) : null
        ] })
      }
    );
  };
  Select.displayName = SELECT_NAME;
  var TRIGGER_NAME2 = "SelectTrigger";
  var SelectTrigger = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, disabled = false, ...triggerProps } = props;
      const popperScope = usePopperScope2(__scopeSelect);
      const context = useSelectContext(TRIGGER_NAME2, __scopeSelect);
      const isDisabled = context.disabled || disabled;
      const composedRefs = useComposedRefs(forwardedRef, context.onTriggerChange);
      const getItems = useCollection(__scopeSelect);
      const pointerTypeRef = React34.useRef("touch");
      const [searchRef, handleTypeaheadSearch, resetTypeahead] = useTypeaheadSearch((search) => {
        const enabledItems = getItems().filter((item) => !item.disabled);
        const currentItem = enabledItems.find((item) => item.value === context.value);
        const nextItem = findNextItem(enabledItems, search, currentItem);
        if (nextItem !== void 0) {
          context.onValueChange(nextItem.value);
        }
      });
      const handleOpen = (pointerEvent) => {
        if (!isDisabled) {
          context.onOpenChange(true);
          resetTypeahead();
        }
        if (pointerEvent) {
          context.triggerPointerDownPosRef.current = {
            x: Math.round(pointerEvent.pageX),
            y: Math.round(pointerEvent.pageY)
          };
        }
      };
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Anchor, { asChild: true, ...popperScope, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        Primitive.button,
        {
          type: "button",
          role: "combobox",
          "aria-controls": context.open ? context.contentId : void 0,
          "aria-expanded": context.open,
          "aria-required": context.required,
          "aria-autocomplete": "none",
          dir: context.dir,
          "data-state": context.open ? "open" : "closed",
          disabled: isDisabled,
          "data-disabled": isDisabled ? "" : void 0,
          "data-placeholder": shouldShowPlaceholder(context.value) ? "" : void 0,
          ...triggerProps,
          ref: composedRefs,
          onClick: composeEventHandlers(triggerProps.onClick, (event) => {
            event.currentTarget.focus();
            if (pointerTypeRef.current !== "mouse") {
              handleOpen(event);
            }
          }),
          onPointerDown: composeEventHandlers(triggerProps.onPointerDown, (event) => {
            pointerTypeRef.current = event.pointerType;
            const target = event.target;
            if (target.hasPointerCapture(event.pointerId)) {
              target.releasePointerCapture(event.pointerId);
            }
            if (event.button === 0 && event.ctrlKey === false && event.pointerType === "mouse") {
              handleOpen(event);
              event.preventDefault();
            }
          }),
          onKeyDown: composeEventHandlers(triggerProps.onKeyDown, (event) => {
            const isTypingAhead = searchRef.current !== "";
            const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
            if (!isModifierKey && event.key.length === 1) handleTypeaheadSearch(event.key);
            if (isTypingAhead && event.key === " ") return;
            if (OPEN_KEYS.includes(event.key)) {
              handleOpen();
              event.preventDefault();
            }
          })
        }
      ) });
    }
  );
  SelectTrigger.displayName = TRIGGER_NAME2;
  var VALUE_NAME = "SelectValue";
  var SelectValue = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, className, style, children, placeholder = "", ...valueProps } = props;
      const context = useSelectContext(VALUE_NAME, __scopeSelect);
      const { onValueNodeHasChildrenChange } = context;
      const hasChildren = children !== void 0;
      const composedRefs = useComposedRefs(forwardedRef, context.onValueNodeChange);
      useLayoutEffect22(() => {
        onValueNodeHasChildrenChange(hasChildren);
      }, [onValueNodeHasChildrenChange, hasChildren]);
      const showPlaceholder = shouldShowPlaceholder(context.value);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        Primitive.span,
        {
          ...valueProps,
          asChild: showPlaceholder ? false : valueProps.asChild,
          ref: composedRefs,
          style: { pointerEvents: "none" },
          children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(React34.Fragment, { children: showPlaceholder ? placeholder : children }, showPlaceholder ? "placeholder" : "value")
        }
      );
    }
  );
  SelectValue.displayName = VALUE_NAME;
  var ICON_NAME = "SelectIcon";
  var SelectIcon = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, children, ...iconProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.span, { "aria-hidden": true, ...iconProps, ref: forwardedRef, children: children || "\u25BC" });
    }
  );
  SelectIcon.displayName = ICON_NAME;
  var PORTAL_NAME3 = "SelectPortal";
  var [PortalProvider2, usePortalContext2] = createSelectContext(PORTAL_NAME3, {
    forceMount: void 0
  });
  var SelectPortal = (props) => {
    const { __scopeSelect, forceMount, ...portalProps } = props;
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(PortalProvider2, { scope: props.__scopeSelect, forceMount, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Portal, { asChild: true, ...portalProps }) });
  };
  SelectPortal.displayName = PORTAL_NAME3;
  var CONTENT_NAME3 = "SelectContent";
  var SelectContent = React34.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext2(CONTENT_NAME3, props.__scopeSelect);
      const { forceMount = portalContext.forceMount, ...contentProps } = props;
      const context = useSelectContext(CONTENT_NAME3, props.__scopeSelect);
      const [fragment, setFragment] = React34.useState();
      useLayoutEffect22(() => {
        setFragment(new DocumentFragment());
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Presence, { present: forceMount || context.open, children: ({ present }) => present ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(SelectContentImpl, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(SelectContentFragment, { ...contentProps, fragment }) });
    }
  );
  SelectContent.displayName = CONTENT_NAME3;
  var SelectContentFragment = React34.forwardRef((props, forwardedRef) => {
    const { __scopeSelect, children, fragment } = props;
    if (!fragment) return null;
    return ReactDOM4.createPortal(
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(SelectContentProvider, { scope: __scopeSelect, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Collection.Slot, { scope: __scopeSelect, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { ref: forwardedRef, children }) }) }),
      fragment
    );
  });
  SelectContentFragment.displayName = "SelectContentFragment";
  var CONTENT_MARGIN = 10;
  var [SelectContentProvider, useSelectContentContext] = createSelectContext(CONTENT_NAME3);
  var CONTENT_IMPL_NAME = "SelectContentImpl";
  var Slot2 = createSlot("SelectContent.RemoveScroll");
  var SelectContentImpl = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect } = props;
      const {
        position = "item-aligned",
        onCloseAutoFocus,
        onEscapeKeyDown,
        onPointerDownOutside,
        //
        // PopperContent props
        side,
        sideOffset,
        align,
        alignOffset,
        arrowPadding,
        collisionBoundary,
        collisionPadding,
        sticky,
        hideWhenDetached,
        avoidCollisions,
        //
        ...contentProps
      } = props;
      const context = useSelectContext(CONTENT_NAME3, __scopeSelect);
      const [content, setContent] = React34.useState(null);
      const [viewport, setViewport] = React34.useState(null);
      const composedRefs = useComposedRefs(forwardedRef, (node) => setContent(node));
      const [selectedItem, setSelectedItem] = React34.useState(null);
      const [selectedItemText, setSelectedItemText] = React34.useState(
        null
      );
      const getItems = useCollection(__scopeSelect);
      const [isPositioned, setIsPositioned] = React34.useState(false);
      const firstValidItemFoundRef = React34.useRef(false);
      React34.useEffect(() => {
        if (content) return hideOthers(content);
      }, [content]);
      useFocusGuards();
      const focusFirst5 = React34.useCallback(
        (candidates) => {
          const [firstItem, ...restItems] = getItems().map((item) => item.ref.current);
          const [lastItem] = restItems.slice(-1);
          const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
          for (const candidate of candidates) {
            if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
            candidate?.scrollIntoView({ block: "nearest" });
            if (candidate === firstItem && viewport) viewport.scrollTop = 0;
            if (candidate === lastItem && viewport) viewport.scrollTop = viewport.scrollHeight;
            candidate?.focus();
            if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
          }
        },
        [getItems, viewport]
      );
      const focusSelectedItem = React34.useCallback(
        () => focusFirst5([selectedItem, content]),
        [focusFirst5, selectedItem, content]
      );
      React34.useEffect(() => {
        if (isPositioned) {
          focusSelectedItem();
        }
      }, [isPositioned, focusSelectedItem]);
      const { onOpenChange, triggerPointerDownPosRef } = context;
      React34.useEffect(() => {
        if (content) {
          let pointerMoveDelta = { x: 0, y: 0 };
          const handlePointerMove = (event) => {
            pointerMoveDelta = {
              x: Math.abs(Math.round(event.pageX) - (triggerPointerDownPosRef.current?.x ?? 0)),
              y: Math.abs(Math.round(event.pageY) - (triggerPointerDownPosRef.current?.y ?? 0))
            };
          };
          const handlePointerUp = (event) => {
            if (pointerMoveDelta.x <= 10 && pointerMoveDelta.y <= 10) {
              event.preventDefault();
            } else {
              if (!event.composedPath().includes(content)) {
                onOpenChange(false);
              }
            }
            document.removeEventListener("pointermove", handlePointerMove);
            triggerPointerDownPosRef.current = null;
          };
          if (triggerPointerDownPosRef.current !== null) {
            document.addEventListener("pointermove", handlePointerMove);
            document.addEventListener("pointerup", handlePointerUp, { capture: true, once: true });
          }
          return () => {
            document.removeEventListener("pointermove", handlePointerMove);
            document.removeEventListener("pointerup", handlePointerUp, { capture: true });
          };
        }
      }, [content, onOpenChange, triggerPointerDownPosRef]);
      React34.useEffect(() => {
        const close = () => onOpenChange(false);
        window.addEventListener("blur", close);
        window.addEventListener("resize", close);
        return () => {
          window.removeEventListener("blur", close);
          window.removeEventListener("resize", close);
        };
      }, [onOpenChange]);
      const [searchRef, handleTypeaheadSearch] = useTypeaheadSearch((search) => {
        const enabledItems = getItems().filter((item) => !item.disabled);
        const currentItem = enabledItems.find((item) => item.ref.current === document.activeElement);
        const nextItem = findNextItem(enabledItems, search, currentItem);
        if (nextItem) {
          setTimeout(() => nextItem.ref.current?.focus());
        }
      });
      const itemRefCallback = React34.useCallback(
        (node, value, disabled) => {
          const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
          const isSelectedItem = context.value !== void 0 && context.value === value;
          if (isSelectedItem || isFirstValidItem) {
            setSelectedItem(node);
            if (isFirstValidItem) firstValidItemFoundRef.current = true;
          }
        },
        [context.value]
      );
      const handleItemLeave = React34.useCallback(() => content?.focus(), [content]);
      const itemTextRefCallback = React34.useCallback(
        (node, value, disabled) => {
          const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
          const isSelectedItem = context.value !== void 0 && context.value === value;
          if (isSelectedItem || isFirstValidItem) {
            setSelectedItemText(node);
          }
        },
        [context.value]
      );
      const SelectPosition = position === "popper" ? SelectPopperPosition : SelectItemAlignedPosition;
      const popperContentProps = SelectPosition === SelectPopperPosition ? {
        side,
        sideOffset,
        align,
        alignOffset,
        arrowPadding,
        collisionBoundary,
        collisionPadding,
        sticky,
        hideWhenDetached,
        avoidCollisions
      } : {};
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        SelectContentProvider,
        {
          scope: __scopeSelect,
          content,
          viewport,
          onViewportChange: setViewport,
          itemRefCallback,
          selectedItem,
          onItemLeave: handleItemLeave,
          itemTextRefCallback,
          focusSelectedItem,
          selectedItemText,
          position,
          isPositioned,
          searchRef,
          children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Combination_default, { as: Slot2, allowPinchZoom: true, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
            FocusScope,
            {
              asChild: true,
              trapped: context.open,
              onMountAutoFocus: (event) => {
                event.preventDefault();
              },
              onUnmountAutoFocus: composeEventHandlers(onCloseAutoFocus, (event) => {
                context.trigger?.focus({ preventScroll: true });
                event.preventDefault();
              }),
              children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
                DismissableLayer,
                {
                  asChild: true,
                  disableOutsidePointerEvents: true,
                  onEscapeKeyDown,
                  onPointerDownOutside,
                  onFocusOutside: (event) => event.preventDefault(),
                  onDismiss: () => context.onOpenChange(false),
                  children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
                    SelectPosition,
                    {
                      role: "listbox",
                      id: context.contentId,
                      "data-state": context.open ? "open" : "closed",
                      dir: context.dir,
                      onContextMenu: (event) => event.preventDefault(),
                      ...contentProps,
                      ...popperContentProps,
                      onPlaced: () => setIsPositioned(true),
                      ref: composedRefs,
                      style: {
                        // flex layout so we can place the scroll buttons properly
                        display: "flex",
                        flexDirection: "column",
                        // reset the outline by default as the content MAY get focused
                        outline: "none",
                        ...contentProps.style
                      },
                      onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
                        const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
                        if (event.key === "Tab") event.preventDefault();
                        if (!isModifierKey && event.key.length === 1) handleTypeaheadSearch(event.key);
                        if (["ArrowUp", "ArrowDown", "Home", "End"].includes(event.key)) {
                          const items = getItems().filter((item) => !item.disabled);
                          let candidateNodes = items.map((item) => item.ref.current);
                          if (["ArrowUp", "End"].includes(event.key)) {
                            candidateNodes = candidateNodes.slice().reverse();
                          }
                          if (["ArrowUp", "ArrowDown"].includes(event.key)) {
                            const currentElement = event.target;
                            const currentIndex = candidateNodes.indexOf(currentElement);
                            candidateNodes = candidateNodes.slice(currentIndex + 1);
                          }
                          setTimeout(() => focusFirst5(candidateNodes));
                          event.preventDefault();
                        }
                      })
                    }
                  )
                }
              )
            }
          ) })
        }
      );
    }
  );
  SelectContentImpl.displayName = CONTENT_IMPL_NAME;
  var ITEM_ALIGNED_POSITION_NAME = "SelectItemAlignedPosition";
  var SelectItemAlignedPosition = React34.forwardRef((props, forwardedRef) => {
    const { __scopeSelect, onPlaced, ...popperProps } = props;
    const context = useSelectContext(CONTENT_NAME3, __scopeSelect);
    const contentContext = useSelectContentContext(CONTENT_NAME3, __scopeSelect);
    const [contentWrapper, setContentWrapper] = React34.useState(null);
    const [content, setContent] = React34.useState(null);
    const composedRefs = useComposedRefs(forwardedRef, (node) => setContent(node));
    const getItems = useCollection(__scopeSelect);
    const shouldExpandOnScrollRef = React34.useRef(false);
    const shouldRepositionRef = React34.useRef(true);
    const { viewport, selectedItem, selectedItemText, focusSelectedItem } = contentContext;
    const position = React34.useCallback(() => {
      if (context.trigger && context.valueNode && contentWrapper && content && viewport && selectedItem && selectedItemText) {
        const triggerRect = context.trigger.getBoundingClientRect();
        const contentRect = content.getBoundingClientRect();
        const valueNodeRect = context.valueNode.getBoundingClientRect();
        const itemTextRect = selectedItemText.getBoundingClientRect();
        if (context.dir !== "rtl") {
          const itemTextOffset = itemTextRect.left - contentRect.left;
          const left = valueNodeRect.left - itemTextOffset;
          const leftDelta = triggerRect.left - left;
          const minContentWidth = triggerRect.width + leftDelta;
          const contentWidth = Math.max(minContentWidth, contentRect.width);
          const rightEdge = window.innerWidth - CONTENT_MARGIN;
          const clampedLeft = clamp2(left, [
            CONTENT_MARGIN,
            // Prevents the content from going off the starting edge of the
            // viewport. It may still go off the ending edge, but this can be
            // controlled by the user since they may want to manage overflow in a
            // specific way.
            // https://github.com/radix-ui/primitives/issues/2049
            Math.max(CONTENT_MARGIN, rightEdge - contentWidth)
          ]);
          contentWrapper.style.minWidth = minContentWidth + "px";
          contentWrapper.style.left = clampedLeft + "px";
        } else {
          const itemTextOffset = contentRect.right - itemTextRect.right;
          const right = window.innerWidth - valueNodeRect.right - itemTextOffset;
          const rightDelta = window.innerWidth - triggerRect.right - right;
          const minContentWidth = triggerRect.width + rightDelta;
          const contentWidth = Math.max(minContentWidth, contentRect.width);
          const leftEdge = window.innerWidth - CONTENT_MARGIN;
          const clampedRight = clamp2(right, [
            CONTENT_MARGIN,
            Math.max(CONTENT_MARGIN, leftEdge - contentWidth)
          ]);
          contentWrapper.style.minWidth = minContentWidth + "px";
          contentWrapper.style.right = clampedRight + "px";
        }
        const items = getItems();
        const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
        const itemsHeight = viewport.scrollHeight;
        const contentStyles = window.getComputedStyle(content);
        const contentBorderTopWidth = parseInt(contentStyles.borderTopWidth, 10);
        const contentPaddingTop = parseInt(contentStyles.paddingTop, 10);
        const contentBorderBottomWidth = parseInt(contentStyles.borderBottomWidth, 10);
        const contentPaddingBottom = parseInt(contentStyles.paddingBottom, 10);
        const fullContentHeight = contentBorderTopWidth + contentPaddingTop + itemsHeight + contentPaddingBottom + contentBorderBottomWidth;
        const minContentHeight = Math.min(selectedItem.offsetHeight * 5, fullContentHeight);
        const viewportStyles = window.getComputedStyle(viewport);
        const viewportPaddingTop = parseInt(viewportStyles.paddingTop, 10);
        const viewportPaddingBottom = parseInt(viewportStyles.paddingBottom, 10);
        const topEdgeToTriggerMiddle = triggerRect.top + triggerRect.height / 2 - CONTENT_MARGIN;
        const triggerMiddleToBottomEdge = availableHeight - topEdgeToTriggerMiddle;
        const selectedItemHalfHeight = selectedItem.offsetHeight / 2;
        const itemOffsetMiddle = selectedItem.offsetTop + selectedItemHalfHeight;
        const contentTopToItemMiddle = contentBorderTopWidth + contentPaddingTop + itemOffsetMiddle;
        const itemMiddleToContentBottom = fullContentHeight - contentTopToItemMiddle;
        const willAlignWithoutTopOverflow = contentTopToItemMiddle <= topEdgeToTriggerMiddle;
        if (willAlignWithoutTopOverflow) {
          const isLastItem = items.length > 0 && selectedItem === items[items.length - 1].ref.current;
          contentWrapper.style.bottom = "0px";
          const viewportOffsetBottom = content.clientHeight - viewport.offsetTop - viewport.offsetHeight;
          const clampedTriggerMiddleToBottomEdge = Math.max(
            triggerMiddleToBottomEdge,
            selectedItemHalfHeight + // viewport might have padding bottom, include it to avoid a scrollable viewport
            (isLastItem ? viewportPaddingBottom : 0) + viewportOffsetBottom + contentBorderBottomWidth
          );
          const height = contentTopToItemMiddle + clampedTriggerMiddleToBottomEdge;
          contentWrapper.style.height = height + "px";
        } else {
          const isFirstItem = items.length > 0 && selectedItem === items[0].ref.current;
          contentWrapper.style.top = "0px";
          const clampedTopEdgeToTriggerMiddle = Math.max(
            topEdgeToTriggerMiddle,
            contentBorderTopWidth + viewport.offsetTop + // viewport might have padding top, include it to avoid a scrollable viewport
            (isFirstItem ? viewportPaddingTop : 0) + selectedItemHalfHeight
          );
          const height = clampedTopEdgeToTriggerMiddle + itemMiddleToContentBottom;
          contentWrapper.style.height = height + "px";
          viewport.scrollTop = contentTopToItemMiddle - topEdgeToTriggerMiddle + viewport.offsetTop;
        }
        contentWrapper.style.margin = `${CONTENT_MARGIN}px 0`;
        contentWrapper.style.minHeight = minContentHeight + "px";
        contentWrapper.style.maxHeight = availableHeight + "px";
        onPlaced?.();
        requestAnimationFrame(() => shouldExpandOnScrollRef.current = true);
      }
    }, [
      getItems,
      context.trigger,
      context.valueNode,
      contentWrapper,
      content,
      viewport,
      selectedItem,
      selectedItemText,
      context.dir,
      onPlaced
    ]);
    useLayoutEffect22(() => position(), [position]);
    const [contentZIndex, setContentZIndex] = React34.useState();
    useLayoutEffect22(() => {
      if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
    }, [content]);
    const handleScrollButtonChange = React34.useCallback(
      (node) => {
        if (node && shouldRepositionRef.current === true) {
          position();
          focusSelectedItem?.();
          shouldRepositionRef.current = false;
        }
      },
      [position, focusSelectedItem]
    );
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      SelectViewportProvider,
      {
        scope: __scopeSelect,
        contentWrapper,
        shouldExpandOnScrollRef,
        onScrollButtonChange: handleScrollButtonChange,
        children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
          "div",
          {
            ref: setContentWrapper,
            style: {
              display: "flex",
              flexDirection: "column",
              position: "fixed",
              zIndex: contentZIndex
            },
            children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
              Primitive.div,
              {
                ...popperProps,
                ref: composedRefs,
                style: {
                  // When we get the height of the content, it includes borders. If we were to set
                  // the height without having `boxSizing: 'border-box'` it would be too big.
                  boxSizing: "border-box",
                  // We need to ensure the content doesn't get taller than the wrapper
                  maxHeight: "100%",
                  ...popperProps.style
                }
              }
            )
          }
        )
      }
    );
  });
  SelectItemAlignedPosition.displayName = ITEM_ALIGNED_POSITION_NAME;
  var POPPER_POSITION_NAME = "SelectPopperPosition";
  var SelectPopperPosition = React34.forwardRef((props, forwardedRef) => {
    const {
      __scopeSelect,
      align = "start",
      collisionPadding = CONTENT_MARGIN,
      ...popperProps
    } = props;
    const popperScope = usePopperScope2(__scopeSelect);
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      Content,
      {
        ...popperScope,
        ...popperProps,
        ref: forwardedRef,
        align,
        collisionPadding,
        style: {
          // Ensure border-box for floating-ui calculations
          boxSizing: "border-box",
          ...popperProps.style,
          // re-namespace exposed content custom properties
          ...{
            "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
            "--radix-select-content-available-width": "var(--radix-popper-available-width)",
            "--radix-select-content-available-height": "var(--radix-popper-available-height)",
            "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
            "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
          }
        }
      }
    );
  });
  SelectPopperPosition.displayName = POPPER_POSITION_NAME;
  var [SelectViewportProvider, useSelectViewportContext] = createSelectContext(CONTENT_NAME3, {});
  var VIEWPORT_NAME = "SelectViewport";
  var SelectViewport = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, nonce, ...viewportProps } = props;
      const contentContext = useSelectContentContext(VIEWPORT_NAME, __scopeSelect);
      const viewportContext = useSelectViewportContext(VIEWPORT_NAME, __scopeSelect);
      const composedRefs = useComposedRefs(forwardedRef, contentContext.onViewportChange);
      const prevScrollTopRef = React34.useRef(0);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(import_jsx_runtime13.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
          "style",
          {
            dangerouslySetInnerHTML: {
              __html: `[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}`
            },
            nonce
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Collection.Slot, { scope: __scopeSelect, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
          Primitive.div,
          {
            "data-radix-select-viewport": "",
            role: "presentation",
            ...viewportProps,
            ref: composedRefs,
            style: {
              // we use position: 'relative' here on the `viewport` so that when we call
              // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
              // (independent of the scrollUpButton).
              position: "relative",
              flex: 1,
              // Viewport should only be scrollable in the vertical direction.
              // This won't work in vertical writing modes, so we'll need to
              // revisit this if/when that is supported
              // https://developer.chrome.com/blog/vertical-form-controls
              overflow: "hidden auto",
              ...viewportProps.style
            },
            onScroll: composeEventHandlers(viewportProps.onScroll, (event) => {
              const viewport = event.currentTarget;
              const { contentWrapper, shouldExpandOnScrollRef } = viewportContext;
              if (shouldExpandOnScrollRef?.current && contentWrapper) {
                const scrolledBy = Math.abs(prevScrollTopRef.current - viewport.scrollTop);
                if (scrolledBy > 0) {
                  const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
                  const cssMinHeight = parseFloat(contentWrapper.style.minHeight);
                  const cssHeight = parseFloat(contentWrapper.style.height);
                  const prevHeight = Math.max(cssMinHeight, cssHeight);
                  if (prevHeight < availableHeight) {
                    const nextHeight = prevHeight + scrolledBy;
                    const clampedNextHeight = Math.min(availableHeight, nextHeight);
                    const heightDiff = nextHeight - clampedNextHeight;
                    contentWrapper.style.height = clampedNextHeight + "px";
                    if (contentWrapper.style.bottom === "0px") {
                      viewport.scrollTop = heightDiff > 0 ? heightDiff : 0;
                      contentWrapper.style.justifyContent = "flex-end";
                    }
                  }
                }
              }
              prevScrollTopRef.current = viewport.scrollTop;
            })
          }
        ) })
      ] });
    }
  );
  SelectViewport.displayName = VIEWPORT_NAME;
  var GROUP_NAME = "SelectGroup";
  var [SelectGroupContextProvider, useSelectGroupContext] = createSelectContext(GROUP_NAME);
  var SelectGroup = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, ...groupProps } = props;
      const groupId = useId2();
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(SelectGroupContextProvider, { scope: __scopeSelect, id: groupId, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.div, { role: "group", "aria-labelledby": groupId, ...groupProps, ref: forwardedRef }) });
    }
  );
  SelectGroup.displayName = GROUP_NAME;
  var LABEL_NAME = "SelectLabel";
  var SelectLabel = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, ...labelProps } = props;
      const groupContext = useSelectGroupContext(LABEL_NAME, __scopeSelect);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.div, { id: groupContext.id, ...labelProps, ref: forwardedRef });
    }
  );
  SelectLabel.displayName = LABEL_NAME;
  var ITEM_NAME = "SelectItem";
  var [SelectItemContextProvider, useSelectItemContext] = createSelectContext(ITEM_NAME);
  var SelectItem = React34.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopeSelect,
        value,
        disabled = false,
        textValue: textValueProp,
        ...itemProps
      } = props;
      const context = useSelectContext(ITEM_NAME, __scopeSelect);
      const contentContext = useSelectContentContext(ITEM_NAME, __scopeSelect);
      const isSelected = context.value === value;
      const [textValue, setTextValue] = React34.useState(textValueProp ?? "");
      const [isFocused, setIsFocused] = React34.useState(false);
      const composedRefs = useComposedRefs(
        forwardedRef,
        (node) => contentContext.itemRefCallback?.(node, value, disabled)
      );
      const textId = useId2();
      const pointerTypeRef = React34.useRef("touch");
      const handleSelect = () => {
        if (!disabled) {
          context.onValueChange(value);
          context.onOpenChange(false);
        }
      };
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
        SelectItemContextProvider,
        {
          scope: __scopeSelect,
          value,
          disabled,
          textId,
          isSelected,
          onItemTextChange: React34.useCallback((node) => {
            setTextValue((prevTextValue) => prevTextValue || (node?.textContent ?? "").trim());
          }, []),
          children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
            Collection.ItemSlot,
            {
              scope: __scopeSelect,
              value,
              disabled,
              textValue,
              children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
                Primitive.div,
                {
                  role: "option",
                  "aria-labelledby": textId,
                  "data-highlighted": isFocused ? "" : void 0,
                  "aria-selected": isSelected && isFocused,
                  "data-state": isSelected ? "checked" : "unchecked",
                  "aria-disabled": disabled || void 0,
                  "data-disabled": disabled ? "" : void 0,
                  tabIndex: disabled ? void 0 : -1,
                  ...itemProps,
                  ref: composedRefs,
                  onFocus: composeEventHandlers(itemProps.onFocus, () => setIsFocused(true)),
                  onBlur: composeEventHandlers(itemProps.onBlur, () => setIsFocused(false)),
                  onClick: composeEventHandlers(itemProps.onClick, () => {
                    if (pointerTypeRef.current !== "mouse") handleSelect();
                  }),
                  onPointerUp: composeEventHandlers(itemProps.onPointerUp, () => {
                    if (pointerTypeRef.current === "mouse") handleSelect();
                  }),
                  onPointerDown: composeEventHandlers(itemProps.onPointerDown, (event) => {
                    pointerTypeRef.current = event.pointerType;
                  }),
                  onPointerMove: composeEventHandlers(itemProps.onPointerMove, (event) => {
                    pointerTypeRef.current = event.pointerType;
                    if (disabled) {
                      contentContext.onItemLeave?.();
                    } else if (pointerTypeRef.current === "mouse") {
                      event.currentTarget.focus({ preventScroll: true });
                    }
                  }),
                  onPointerLeave: composeEventHandlers(itemProps.onPointerLeave, (event) => {
                    if (event.currentTarget === document.activeElement) {
                      contentContext.onItemLeave?.();
                    }
                  }),
                  onKeyDown: composeEventHandlers(itemProps.onKeyDown, (event) => {
                    const isTypingAhead = contentContext.searchRef?.current !== "";
                    if (isTypingAhead && event.key === " ") return;
                    if (SELECTION_KEYS.includes(event.key)) handleSelect();
                    if (event.key === " ") event.preventDefault();
                  })
                }
              )
            }
          )
        }
      );
    }
  );
  SelectItem.displayName = ITEM_NAME;
  var ITEM_TEXT_NAME = "SelectItemText";
  var SelectItemText = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, className, style, ...itemTextProps } = props;
      const context = useSelectContext(ITEM_TEXT_NAME, __scopeSelect);
      const contentContext = useSelectContentContext(ITEM_TEXT_NAME, __scopeSelect);
      const itemContext = useSelectItemContext(ITEM_TEXT_NAME, __scopeSelect);
      const nativeOptionsContext = useSelectNativeOptionsContext(ITEM_TEXT_NAME, __scopeSelect);
      const [itemTextNode, setItemTextNode] = React34.useState(null);
      const composedRefs = useComposedRefs(
        forwardedRef,
        (node) => setItemTextNode(node),
        itemContext.onItemTextChange,
        (node) => contentContext.itemTextRefCallback?.(node, itemContext.value, itemContext.disabled)
      );
      const textContent = itemTextNode?.textContent;
      const nativeOption = React34.useMemo(
        () => /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("option", { value: itemContext.value, disabled: itemContext.disabled, children: textContent }, itemContext.value),
        [itemContext.disabled, itemContext.value, textContent]
      );
      const { onNativeOptionAdd, onNativeOptionRemove } = nativeOptionsContext;
      useLayoutEffect22(() => {
        onNativeOptionAdd(nativeOption);
        return () => onNativeOptionRemove(nativeOption);
      }, [onNativeOptionAdd, onNativeOptionRemove, nativeOption]);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(import_jsx_runtime13.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.span, { id: itemContext.textId, ...itemTextProps, ref: composedRefs }),
        itemContext.isSelected && context.valueNode && !context.valueNodeHasChildren && !shouldShowPlaceholder(context.value) ? ReactDOM4.createPortal(itemTextProps.children, context.valueNode) : null
      ] });
    }
  );
  SelectItemText.displayName = ITEM_TEXT_NAME;
  var ITEM_INDICATOR_NAME = "SelectItemIndicator";
  var SelectItemIndicator = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, ...itemIndicatorProps } = props;
      const itemContext = useSelectItemContext(ITEM_INDICATOR_NAME, __scopeSelect);
      return itemContext.isSelected ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.span, { "aria-hidden": true, ...itemIndicatorProps, ref: forwardedRef }) : null;
    }
  );
  SelectItemIndicator.displayName = ITEM_INDICATOR_NAME;
  var SCROLL_UP_BUTTON_NAME = "SelectScrollUpButton";
  var SelectScrollUpButton = React34.forwardRef((props, forwardedRef) => {
    const contentContext = useSelectContentContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
    const viewportContext = useSelectViewportContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
    const [canScrollUp, setCanScrollUp] = React34.useState(false);
    const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
    useLayoutEffect22(() => {
      if (contentContext.viewport && contentContext.isPositioned) {
        let handleScroll22 = function() {
          const canScrollUp2 = viewport.scrollTop > 0;
          setCanScrollUp(canScrollUp2);
        };
        var handleScroll2 = handleScroll22;
        const viewport = contentContext.viewport;
        handleScroll22();
        viewport.addEventListener("scroll", handleScroll22);
        return () => viewport.removeEventListener("scroll", handleScroll22);
      }
    }, [contentContext.viewport, contentContext.isPositioned]);
    return canScrollUp ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      SelectScrollButtonImpl,
      {
        ...props,
        ref: composedRefs,
        onAutoScroll: () => {
          const { viewport, selectedItem } = contentContext;
          if (viewport && selectedItem) {
            viewport.scrollTop = viewport.scrollTop - selectedItem.offsetHeight;
          }
        }
      }
    ) : null;
  });
  SelectScrollUpButton.displayName = SCROLL_UP_BUTTON_NAME;
  var SCROLL_DOWN_BUTTON_NAME = "SelectScrollDownButton";
  var SelectScrollDownButton = React34.forwardRef((props, forwardedRef) => {
    const contentContext = useSelectContentContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
    const viewportContext = useSelectViewportContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
    const [canScrollDown, setCanScrollDown] = React34.useState(false);
    const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
    useLayoutEffect22(() => {
      if (contentContext.viewport && contentContext.isPositioned) {
        let handleScroll22 = function() {
          const maxScroll = viewport.scrollHeight - viewport.clientHeight;
          const canScrollDown2 = Math.ceil(viewport.scrollTop) < maxScroll;
          setCanScrollDown(canScrollDown2);
        };
        var handleScroll2 = handleScroll22;
        const viewport = contentContext.viewport;
        handleScroll22();
        viewport.addEventListener("scroll", handleScroll22);
        return () => viewport.removeEventListener("scroll", handleScroll22);
      }
    }, [contentContext.viewport, contentContext.isPositioned]);
    return canScrollDown ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      SelectScrollButtonImpl,
      {
        ...props,
        ref: composedRefs,
        onAutoScroll: () => {
          const { viewport, selectedItem } = contentContext;
          if (viewport && selectedItem) {
            viewport.scrollTop = viewport.scrollTop + selectedItem.offsetHeight;
          }
        }
      }
    ) : null;
  });
  SelectScrollDownButton.displayName = SCROLL_DOWN_BUTTON_NAME;
  var SelectScrollButtonImpl = React34.forwardRef((props, forwardedRef) => {
    const { __scopeSelect, onAutoScroll, ...scrollIndicatorProps } = props;
    const contentContext = useSelectContentContext("SelectScrollButton", __scopeSelect);
    const autoScrollTimerRef = React34.useRef(null);
    const getItems = useCollection(__scopeSelect);
    const clearAutoScrollTimer = React34.useCallback(() => {
      if (autoScrollTimerRef.current !== null) {
        window.clearInterval(autoScrollTimerRef.current);
        autoScrollTimerRef.current = null;
      }
    }, []);
    React34.useEffect(() => {
      return () => clearAutoScrollTimer();
    }, [clearAutoScrollTimer]);
    useLayoutEffect22(() => {
      const activeItem = getItems().find((item) => item.ref.current === document.activeElement);
      activeItem?.ref.current?.scrollIntoView({ block: "nearest" });
    }, [getItems]);
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(
      Primitive.div,
      {
        "aria-hidden": true,
        ...scrollIndicatorProps,
        ref: forwardedRef,
        style: { flexShrink: 0, ...scrollIndicatorProps.style },
        onPointerDown: composeEventHandlers(scrollIndicatorProps.onPointerDown, () => {
          if (autoScrollTimerRef.current === null) {
            autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
          }
        }),
        onPointerMove: composeEventHandlers(scrollIndicatorProps.onPointerMove, () => {
          contentContext.onItemLeave?.();
          if (autoScrollTimerRef.current === null) {
            autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
          }
        }),
        onPointerLeave: composeEventHandlers(scrollIndicatorProps.onPointerLeave, () => {
          clearAutoScrollTimer();
        })
      }
    );
  });
  var SEPARATOR_NAME = "SelectSeparator";
  var SelectSeparator = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, ...separatorProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Primitive.div, { "aria-hidden": true, ...separatorProps, ref: forwardedRef });
    }
  );
  SelectSeparator.displayName = SEPARATOR_NAME;
  var ARROW_NAME3 = "SelectArrow";
  var SelectArrow = React34.forwardRef(
    (props, forwardedRef) => {
      const { __scopeSelect, ...arrowProps } = props;
      const popperScope = usePopperScope2(__scopeSelect);
      const contentContext = useSelectContentContext(ARROW_NAME3, __scopeSelect);
      return contentContext.position === "popper" ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Arrow2, { ...popperScope, ...arrowProps, ref: forwardedRef }) : null;
    }
  );
  SelectArrow.displayName = ARROW_NAME3;
  var BUBBLE_INPUT_NAME = "SelectBubbleInput";
  var SelectBubbleInput = React34.forwardRef(
    ({ __scopeSelect, ...props }, forwardedRef) => {
      const context = useSelectContext(BUBBLE_INPUT_NAME, __scopeSelect);
      const { value, onValueChange, required, disabled, name, autoComplete, form } = context;
      const { nativeOptions, nativeSelectKey } = context;
      const ref = React34.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      const selectValue = value ?? "";
      const prevValue = usePrevious(selectValue);
      const hasEmptyValueOption = Array.from(nativeOptions).some(
        (option) => (option.props.value ?? "") === ""
      );
      React34.useEffect(() => {
        const select = ref.current;
        if (!select) return;
        const selectProto = window.HTMLSelectElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(
          selectProto,
          "value"
        );
        const setValue = descriptor.set;
        if (prevValue !== selectValue && setValue) {
          const event = new Event("change", { bubbles: true });
          setValue.call(select, selectValue);
          select.dispatchEvent(event);
        }
      }, [prevValue, selectValue]);
      return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(
        Primitive.select,
        {
          "aria-hidden": true,
          required,
          tabIndex: -1,
          name,
          autoComplete,
          disabled,
          form,
          onChange: (event) => onValueChange(event.target.value),
          ...props,
          style: { ...VISUALLY_HIDDEN_STYLES, ...props.style },
          ref: composedRefs,
          defaultValue: selectValue,
          children: [
            shouldShowPlaceholder(value) && !hasEmptyValueOption ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("option", { value: "" }) : null,
            Array.from(nativeOptions)
          ]
        },
        nativeSelectKey
      );
    }
  );
  SelectBubbleInput.displayName = BUBBLE_INPUT_NAME;
  function isFunction2(value) {
    return typeof value === "function";
  }
  function shouldShowPlaceholder(value) {
    return value === "" || value === void 0;
  }
  function useTypeaheadSearch(onSearchChange) {
    const handleSearchChange = useCallbackRef(onSearchChange);
    const searchRef = React34.useRef("");
    const timerRef = React34.useRef(0);
    const handleTypeaheadSearch = React34.useCallback(
      (key) => {
        const search = searchRef.current + key;
        handleSearchChange(search);
        (function updateSearch(value) {
          searchRef.current = value;
          window.clearTimeout(timerRef.current);
          if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
        })(search);
      },
      [handleSearchChange]
    );
    const resetTypeahead = React34.useCallback(() => {
      searchRef.current = "";
      window.clearTimeout(timerRef.current);
    }, []);
    React34.useEffect(() => {
      return () => window.clearTimeout(timerRef.current);
    }, []);
    return [searchRef, handleTypeaheadSearch, resetTypeahead];
  }
  function findNextItem(items, search, currentItem) {
    const isRepeated = search.length > 1 && Array.from(search).every((char) => char === search[0]);
    const normalizedSearch = isRepeated ? search[0] : search;
    const currentItemIndex = currentItem ? items.indexOf(currentItem) : -1;
    let wrappedItems = wrapArray(items, Math.max(currentItemIndex, 0));
    const excludeCurrentItem = normalizedSearch.length === 1;
    if (excludeCurrentItem) wrappedItems = wrappedItems.filter((v) => v !== currentItem);
    const nextItem = wrappedItems.find(
      (item) => item.textValue.toLowerCase().startsWith(normalizedSearch.toLowerCase())
    );
    return nextItem !== currentItem ? nextItem : void 0;
  }
  function wrapArray(array, startIndex) {
    return array.map((_, index2) => array[(startIndex + index2) % array.length]);
  }

  // src/client/src/shared/ui/Select.tsx
  var import_react12 = __toESM(require_react_shim(), 1);
  var TRIGGER = "inline-flex items-center justify-between gap-2 rounded-md border transition-colors data-[placeholder]:text-fg4 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand data-[state=open]:ring-2 data-[state=open]:ring-brand disabled:opacity-50 disabled:pointer-events-none";
  var FRAMED_TRIGGER = "inline-flex items-center justify-between gap-2 w-full h-14 px-4 rounded-md bg-transparent text-sm text-fg1 data-[placeholder]:text-fg4 outline-none disabled:opacity-50 disabled:pointer-events-none";
  var BOXED = "border-stroke-strong bg-surface text-fg1";
  var SIZE2 = {
    md: `h-9 px-3 text-sm ${BOXED}`,
    sm: `h-7 px-2 gap-1 text-xs ${BOXED}`,
    inline: "gap-0.5 border-transparent bg-transparent text-inherit"
  };
  var EMPTY = "\u2205";
  function Select2({
    value,
    onValueChange,
    placeholder,
    disabled,
    required,
    name,
    className = "",
    size: size4 = "md",
    emptyItem,
    label,
    invalid,
    error,
    hint,
    containerClassName = "",
    stayOpenOn,
    children,
    ...aria
  }) {
    const [open, setOpen] = (0, import_react12.useState)(false);
    const staying = (0, import_react12.useRef)(false);
    const [focused, setFocused] = (0, import_react12.useState)(false);
    const labelId = (0, import_react12.useId)();
    const framed = label !== void 0;
    const control = /* @__PURE__ */ React.createElement(
      Select,
      {
        value: !value && emptyItem !== void 0 ? EMPTY : value ?? "",
        disabled,
        required: framed ? void 0 : required,
        name,
        open,
        onValueChange: (next) => {
          staying.current = next === stayOpenOn;
          onValueChange(next === EMPTY ? "" : next);
        },
        onOpenChange: (next) => {
          if (!next && staying.current) {
            staying.current = false;
            return;
          }
          setOpen(next);
        }
      },
      /* @__PURE__ */ React.createElement(
        SelectTrigger,
        {
          className: framed ? `${FRAMED_TRIGGER} ${className}` : `${TRIGGER} ${SIZE2[size4]} ${size4 === "inline" || /(^|\s)w-/.test(className) ? "" : "w-full "}${className}`,
          "aria-label": framed ? void 0 : aria["aria-label"],
          "aria-labelledby": framed ? labelId : void 0,
          "aria-required": framed && required ? true : void 0,
          onFocus: () => setFocused(true),
          onBlur: () => setFocused(false)
        },
        /* @__PURE__ */ React.createElement("span", { className: "min-w-0 flex-1 truncate text-left" }, /* @__PURE__ */ React.createElement(SelectValue, { placeholder })),
        /* @__PURE__ */ React.createElement(SelectIcon, { className: "text-fg4 shrink-0" }, /* @__PURE__ */ React.createElement(ChevronDown, { size: 15 }))
      ),
      /* @__PURE__ */ React.createElement(SelectPortal, null, /* @__PURE__ */ React.createElement(
        SelectContent,
        {
          position: "popper",
          sideOffset: 4,
          className: "z-50 min-w-[var(--radix-select-trigger-width)] max-h-[var(--radix-select-content-available-height)] overflow-hidden rounded-md border border-stroke bg-surface shadow-[var(--f-shadow16)]"
        },
        /* @__PURE__ */ React.createElement(SelectViewport, { className: "p-1" }, emptyItem !== void 0 && /* @__PURE__ */ React.createElement(SelectItem2, { value: EMPTY }, emptyItem), children)
      ))
    );
    if (!framed) return control;
    return /* @__PURE__ */ React.createElement(
      OutlinedField,
      {
        label,
        required,
        invalid,
        error,
        hint,
        raise: "always",
        focused: focused || open,
        labelId,
        containerClassName
      },
      control
    );
  }
  var ITEM = "relative flex items-center gap-2 pl-3 pr-8 py-1.5 rounded text-sm text-fg1 select-none cursor-pointer outline-none data-[highlighted]:bg-brand-subtle data-[highlighted]:text-brand-hover data-[state=checked]:font-medium data-[disabled]:opacity-40 data-[disabled]:pointer-events-none";
  var SelectItem2 = (0, import_react12.forwardRef)(
    function SelectItem3({ value, disabled, children, className = "" }, ref) {
      return /* @__PURE__ */ React.createElement(SelectItem, { ref, value, disabled, className: `${ITEM} ${className}` }, /* @__PURE__ */ React.createElement(SelectItemText, null, children), /* @__PURE__ */ React.createElement(SelectItemIndicator, { className: "absolute right-2 inline-flex text-brand" }, /* @__PURE__ */ React.createElement(Check, { size: 14 })));
    }
  );
  function SelectGroup2({ label, children }) {
    return /* @__PURE__ */ React.createElement(SelectGroup, null, /* @__PURE__ */ React.createElement(SelectLabel, { className: "px-3 pt-2 pb-1 text-caption font-semibold uppercase tracking-wide text-fg4" }, label), children);
  }

  // src/client/src/shared/ui/Modal.tsx
  init_define_import_meta_env();

  // src/client/node_modules/@radix-ui/react-dialog/dist/index.mjs
  init_define_import_meta_env();
  var React35 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime14 = __toESM(require_react_shim(), 1);
  var DIALOG_NAME = "Dialog";
  var [createDialogContext, createDialogScope] = createContextScope(DIALOG_NAME);
  var [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
  var Dialog = (props) => {
    const {
      __scopeDialog,
      children,
      open: openProp,
      defaultOpen,
      onOpenChange,
      modal = true
    } = props;
    const triggerRef = React35.useRef(null);
    const contentRef = React35.useRef(null);
    const [open, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen ?? false,
      onChange: onOpenChange,
      caller: DIALOG_NAME
    });
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      DialogProvider,
      {
        scope: __scopeDialog,
        triggerRef,
        contentRef,
        contentId: useId2(),
        titleId: useId2(),
        descriptionId: useId2(),
        open,
        onOpenChange: setOpen,
        onOpenToggle: React35.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
        modal,
        children
      }
    );
  };
  Dialog.displayName = DIALOG_NAME;
  var TRIGGER_NAME3 = "DialogTrigger";
  var DialogTrigger = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, ...triggerProps } = props;
      const context = useDialogContext(TRIGGER_NAME3, __scopeDialog);
      const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        Primitive.button,
        {
          type: "button",
          "aria-haspopup": "dialog",
          "aria-expanded": context.open,
          "aria-controls": context.open ? context.contentId : void 0,
          "data-state": getState2(context.open),
          ...triggerProps,
          ref: composedTriggerRef,
          onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
        }
      );
    }
  );
  DialogTrigger.displayName = TRIGGER_NAME3;
  var PORTAL_NAME4 = "DialogPortal";
  var [PortalProvider3, usePortalContext3] = createDialogContext(PORTAL_NAME4, {
    forceMount: void 0
  });
  var DialogPortal = (props) => {
    const { __scopeDialog, forceMount, children, container } = props;
    const context = useDialogContext(PORTAL_NAME4, __scopeDialog);
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(PortalProvider3, { scope: __scopeDialog, forceMount, children: React35.Children.map(children, (child) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Portal, { asChild: true, container, children: child }) })) });
  };
  DialogPortal.displayName = PORTAL_NAME4;
  var OVERLAY_NAME = "DialogOverlay";
  var DialogOverlay = React35.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext3(OVERLAY_NAME, props.__scopeDialog);
      const { forceMount = portalContext.forceMount, ...overlayProps } = props;
      const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
      return context.modal ? /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(DialogOverlayImpl, { ...overlayProps, ref: forwardedRef }) }) : null;
    }
  );
  DialogOverlay.displayName = OVERLAY_NAME;
  var Slot3 = createSlot("DialogOverlay.RemoveScroll");
  var DialogOverlayImpl = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, ...overlayProps } = props;
      const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
      const registerDismissableSurface = useDismissableLayerSurface();
      const composedRefs = useComposedRefs(forwardedRef, registerDismissableSurface);
      return (
        // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
        // ie. when `Overlay` and `Content` are siblings
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Combination_default, { as: Slot3, allowPinchZoom: true, shards: [context.contentRef], children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
          Primitive.div,
          {
            "data-state": getState2(context.open),
            ...overlayProps,
            ref: composedRefs,
            style: { pointerEvents: "auto", ...overlayProps.style }
          }
        ) })
      );
    }
  );
  var CONTENT_NAME4 = "DialogContent";
  var DialogContent = React35.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext3(CONTENT_NAME4, props.__scopeDialog);
      const { forceMount = portalContext.forceMount, ...contentProps } = props;
      const context = useDialogContext(CONTENT_NAME4, props.__scopeDialog);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Presence, { present: forceMount || context.open, children: context.modal ? /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(DialogContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(DialogContentNonModal, { ...contentProps, ref: forwardedRef }) });
    }
  );
  DialogContent.displayName = CONTENT_NAME4;
  var DialogContentModal = React35.forwardRef(
    (props, forwardedRef) => {
      const context = useDialogContext(CONTENT_NAME4, props.__scopeDialog);
      const contentRef = React35.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, context.contentRef, contentRef);
      React35.useEffect(() => {
        const content = contentRef.current;
        if (content) return hideOthers(content);
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        DialogContentImpl,
        {
          ...props,
          ref: composedRefs,
          trapFocus: context.open,
          disableOutsidePointerEvents: context.open,
          onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
            event.preventDefault();
            context.triggerRef.current?.focus();
          }),
          onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
            const originalEvent = event.detail.originalEvent;
            const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
            const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
            if (isRightClick) event.preventDefault();
          }),
          onFocusOutside: composeEventHandlers(
            props.onFocusOutside,
            (event) => event.preventDefault()
          )
        }
      );
    }
  );
  var DialogContentNonModal = React35.forwardRef(
    (props, forwardedRef) => {
      const context = useDialogContext(CONTENT_NAME4, props.__scopeDialog);
      const hasInteractedOutsideRef = React35.useRef(false);
      const hasPointerDownOutsideRef = React35.useRef(false);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        DialogContentImpl,
        {
          ...props,
          ref: forwardedRef,
          trapFocus: false,
          disableOutsidePointerEvents: false,
          onCloseAutoFocus: (event) => {
            props.onCloseAutoFocus?.(event);
            if (!event.defaultPrevented) {
              if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
              event.preventDefault();
            }
            hasInteractedOutsideRef.current = false;
            hasPointerDownOutsideRef.current = false;
          },
          onInteractOutside: (event) => {
            props.onInteractOutside?.(event);
            if (!event.defaultPrevented) {
              hasInteractedOutsideRef.current = true;
              if (event.detail.originalEvent.type === "pointerdown") {
                hasPointerDownOutsideRef.current = true;
              }
            }
            const target = event.target;
            const targetIsTrigger = context.triggerRef.current?.contains(target);
            if (targetIsTrigger) event.preventDefault();
            if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
              event.preventDefault();
            }
          }
        }
      );
    }
  );
  var DialogContentImpl = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, ...contentProps } = props;
      const context = useDialogContext(CONTENT_NAME4, __scopeDialog);
      useFocusGuards();
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_jsx_runtime14.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        FocusScope,
        {
          asChild: true,
          loop: true,
          trapped: trapFocus,
          onMountAutoFocus: onOpenAutoFocus,
          onUnmountAutoFocus: onCloseAutoFocus,
          children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
            DismissableLayer,
            {
              role: "dialog",
              id: context.contentId,
              "aria-describedby": context.descriptionId,
              "aria-labelledby": context.titleId,
              "data-state": getState2(context.open),
              ...contentProps,
              ref: forwardedRef,
              deferPointerDownOutside: true,
              onDismiss: () => context.onOpenChange(false)
            }
          )
        }
      ) });
    }
  );
  var TITLE_NAME = "DialogTitle";
  var DialogTitle = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, ...titleProps } = props;
      const context = useDialogContext(TITLE_NAME, __scopeDialog);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Primitive.h2, { id: context.titleId, ...titleProps, ref: forwardedRef });
    }
  );
  DialogTitle.displayName = TITLE_NAME;
  var DESCRIPTION_NAME = "DialogDescription";
  var DialogDescription = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, ...descriptionProps } = props;
      const context = useDialogContext(DESCRIPTION_NAME, __scopeDialog);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Primitive.p, { id: context.descriptionId, ...descriptionProps, ref: forwardedRef });
    }
  );
  DialogDescription.displayName = DESCRIPTION_NAME;
  var CLOSE_NAME2 = "DialogClose";
  var DialogClose = React35.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDialog, ...closeProps } = props;
      const context = useDialogContext(CLOSE_NAME2, __scopeDialog);
      return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
        Primitive.button,
        {
          type: "button",
          ...closeProps,
          ref: forwardedRef,
          onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
        }
      );
    }
  );
  DialogClose.displayName = CLOSE_NAME2;
  function getState2(open) {
    return open ? "open" : "closed";
  }

  // src/client/src/shared/ui/Modal.tsx
  var import_react14 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/ui/modalControl.ts
  init_define_import_meta_env();
  var import_react13 = __toESM(require_react_shim(), 1);
  var ModalControlContext = (0, import_react13.createContext)(null);
  function useModalControl() {
    const control = (0, import_react13.useContext)(ModalControlContext);
    if (!control) throw new Error("ModalExit \u0436\u0438\u0432\u0451\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u043D\u0443\u0442\u0440\u0438 Modal");
    return control;
  }
  var WindowStepContext = (0, import_react13.createContext)(null);

  // src/client/src/shared/ui/modalDismissal.ts
  init_define_import_meta_env();
  function modalState(f) {
    if (f.busy) return "busy";
    if (f.acknowledge) return "result";
    if (f.isDirty) return "dirty";
    if (f.nothingToLose) return "light";
    if (f.touched && f.isDirty === void 0) return "touched";
    return "plain";
  }
  var DISMISSAL = {
    // При запросе отклика нет нарочно: кнопка действия уже крутится, и кольцо вокруг мёртвой
    // «Отмены» звало бы нажать то, что не нажимается.
    busy: { outside: "dead", escape: "dead", exit: "dead" },
    result: { outside: "hint", escape: "focusExit", exit: "close" },
    dirty: { outside: "hint", escape: "focusExit", exit: "ask" },
    // «Тронуто» слабее «правки есть»: диалог видел ввод, но не знает, сохранён ли он (список со
    // строчной правкой сохраняет сразу). Поэтому промах он не пропускает, а явный выход — пропускает
    // без вопроса: ложный вопрос «несохранённые изменения будут потеряны» учил бы его не читать.
    touched: { outside: "hint", escape: "focusExit", exit: "close" },
    plain: { outside: "hint", escape: "close", exit: "close" },
    light: { outside: "close", escape: "close", exit: "close" }
  };
  var HINT_MS = 600;
  var rings = /* @__PURE__ */ new WeakMap();
  function pointAtExit(root, focus2) {
    const reachable = (query) => [...root?.querySelectorAll(query) ?? []].find((el) => !el.closest("[inert]"));
    const exit = reachable("[data-modal-exit]:not([disabled])") ?? reachable("[data-modal-cross]");
    if (!root || !exit) return;
    exit.scrollIntoView?.({ block: "nearest" });
    if (focus2) exit.focus();
    clearTimeout(rings.get(root));
    root.querySelectorAll("[data-modal-hint]").forEach((old) => old.removeAttribute("data-modal-hint"));
    exit.setAttribute("data-modal-hint", "");
    rings.set(root, setTimeout(() => exit.removeAttribute("data-modal-hint"), HINT_MS));
  }

  // src/client/src/shared/ui/Modal.tsx
  var NARROW_FULL = "max-sm:inset-0 max-sm:translate-x-0 max-sm:translate-y-0 max-sm:w-full max-sm:max-w-none max-sm:max-h-none max-sm:rounded-none max-sm:border-0";
  function Modal(props) {
    return /* @__PURE__ */ React.createElement(Dialog, { open: props.open, onOpenChange: props.onOpenChange }, props.open && /* @__PURE__ */ React.createElement(ModalBody, { ...props }));
  }
  function ModalExit({ children = "\u041E\u0442\u043C\u0435\u043D\u0430", variant = "text", disabled, ...rest }) {
    const { requestClose, busy } = useModalControl();
    return /* @__PURE__ */ React.createElement(
      Button,
      {
        ...rest,
        type: "button",
        variant,
        "data-modal-exit": "",
        disabled,
        "aria-disabled": busy || void 0,
        className: `${rest.className ?? ""} ${busy ? BUSY_EXIT : ""}`,
        onClick: requestClose
      },
      children
    );
  }
  var BUSY_EXIT = "opacity-40 pointer-events-none";
  function ModalBody({
    onOpenChange,
    title,
    children,
    wide,
    fullScreen,
    headerless,
    isDirty,
    flushBody,
    footer,
    busy = false,
    nothingToLose,
    acknowledge
  }) {
    const [confirmClose, setConfirmClose] = (0, import_react14.useState)(false);
    const [touched, setTouched] = (0, import_react14.useState)(false);
    const content = (0, import_react14.useRef)(null);
    const { host, top, touchTop, stepSlot } = useWindowSteps(content);
    const state = top ? modalState({ busy: busy || top.busy, isDirty: top.isDirty, touched: top.touched }) : modalState({ busy, acknowledge, isDirty, touched, nothingToLose });
    const leave = top ? top.back : () => onOpenChange(false);
    const rule = DISMISSAL[state];
    const asking = confirmClose && rule.exit !== "dead";
    const askedFrom = (0, import_react14.useRef)(null);
    (0, import_react14.useEffect)(() => {
      if (asking) return;
      if (askedFrom.current?.isConnected) askedFrom.current.focus();
      askedFrom.current = null;
    }, [asking]);
    function requestClose() {
      if (rule.exit === "dead") return;
      if (rule.exit === "ask") {
        askedFrom.current ?? (askedFrom.current = document.activeElement);
        setConfirmClose(true);
      } else leave();
    }
    const showExit = (focus2) => pointAtExit(content.current, focus2);
    function noteInput(e) {
      const field = e.target;
      if (!content.current?.contains(field) || field.closest?.("[data-search]")) return;
      if (top) touchTop();
      else setTouched(true);
    }
    function afterFields(act) {
      let reached = false;
      const seen = () => {
        reached = true;
      };
      document.addEventListener("keydown", seen, { once: true });
      setTimeout(() => {
        document.removeEventListener("keydown", seen);
        if (reached) act();
      }, 0);
    }
    return /* @__PURE__ */ React.createElement(DialogPortal, null, /* @__PURE__ */ React.createElement(
      DialogOverlay,
      {
        className: "fixed inset-0 z-40 bg-black/40",
        style: { backdropFilter: "blur(2px)" },
        onMouseDown: (e) => e.preventDefault()
      }
    ), /* @__PURE__ */ React.createElement(
      DialogContent,
      {
        ref: content,
        "data-modal-state": rule.escape === "close" ? "free" : state,
        className: fullScreen ? "fixed inset-0 z-50 flex flex-col overflow-hidden focus:outline-none bg-base" : `fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 rounded-[28px] max-h-[90vh] flex flex-col overflow-hidden focus:outline-none bg-surface border border-stroke ${// У широкого — зазор по краям: между телефоном и 896 px (планшет, 768) иначе окно
        // ложилось бы в край экрана, скруглёнными углами вплотную (ревью PR #1386).
        wide ? "w-[calc(100%-2rem)] max-w-4xl" : "w-full max-w-lg"} ${NARROW_FULL}`,
        style: fullScreen ? void 0 : { boxShadow: "var(--f-shadow28)" },
        onChangeCapture: noteInput,
        onInput: noteInput,
        onOpenAutoFocus: (e) => {
          e.preventDefault();
          content.current?.focus();
        },
        onEscapeKeyDown: (e) => {
          e.preventDefault();
          if (e.isComposing) return;
          if (asking) {
            setConfirmClose(false);
            return;
          }
          if (rule.escape === "close") afterFields(leave);
          else if (rule.escape === "focusExit") afterFields(() => showExit(true));
        },
        onPointerDownOutside: () => {
          if (!asking && rule.outside === "hint") showExit(false);
        },
        onInteractOutside: (e) => {
          if (rule.outside !== "close" || top) e.preventDefault();
        }
      },
      /* @__PURE__ */ React.createElement(ModalControlContext.Provider, { value: { requestClose, busy: busy || !!top?.busy } }, /* @__PURE__ */ React.createElement(WindowStepContext.Provider, { value: host }, /* @__PURE__ */ React.createElement(DialogTitle, { className: "sr-only" }, top?.title ?? title), (!headerless || top) && /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between shrink-0 px-6 pt-6 pb-5", inert: asking }, /* @__PURE__ */ React.createElement("span", { className: "text-base font-semibold text-fg1 truncate", title: top?.title ?? title }, top?.title ?? title), !acknowledge && /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: requestClose,
          "aria-disabled": busy || void 0,
          "data-modal-cross": "",
          "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
          className: `flex items-center justify-center w-9 h-9 rounded-full transition-colors text-fg3 hover:text-fg1 hover:bg-black/5 dark:hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand ${busy ? BUSY_EXIT : ""}`
        },
        /* @__PURE__ */ React.createElement(X, { size: 18 })
      )), flushBody ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "flex-1 min-h-0 flex flex-col", inert: asking, hidden: !!top }, typeof children === "function" ? children(requestClose) : children), top && /* @__PURE__ */ React.createElement("div", { className: "overflow-y-auto flex-1 px-6 pt-2 pb-4", inert: asking }, stepSlot("body"))) : /* @__PURE__ */ React.createElement("div", { className: `overflow-y-auto flex-1 px-6 pt-2 ${footer || acknowledge || top ? "pb-4" : "pb-6"}`, inert: asking }, /* @__PURE__ */ React.createElement("div", { className: "contents", hidden: !!top }, typeof children === "function" ? children(requestClose) : children), stepSlot("body")), (footer || acknowledge || top) && /* @__PURE__ */ React.createElement("div", { className: "shrink-0 px-6 py-3 border-t border-stroke bg-surface", inert: asking }, acknowledge ? /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-2" }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 min-w-0" }, typeof footer === "function" ? footer(requestClose) : footer), /* @__PURE__ */ React.createElement(ModalExit, { variant: "filled" }, acknowledge)) : /* @__PURE__ */ React.createElement("div", { className: "contents", hidden: !!top }, typeof footer === "function" ? footer(requestClose) : footer), stepSlot("footer")), asking && /* @__PURE__ */ React.createElement("div", { className: `absolute inset-0 z-10 flex items-center justify-center bg-black/40 ${fullScreen ? "" : "rounded-[28px]"}` }, /* @__PURE__ */ React.createElement("div", { className: "rounded-3xl p-5 w-80 bg-surface border border-stroke", style: { boxShadow: "var(--f-shadow28)" } }, /* @__PURE__ */ React.createElement("p", { className: "text-sm font-semibold mb-1 text-fg1" }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0431\u0435\u0437 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F?"), /* @__PURE__ */ React.createElement("p", { className: "text-xs mb-4 text-fg3" }, "\u041D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0431\u0443\u0434\u0443\u0442 \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u044B."), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2 justify-end" }, /* @__PURE__ */ React.createElement(Button, { variant: "text", size: "sm", autoFocus: true, onClick: () => setConfirmClose(false) }, "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435"), /* @__PURE__ */ React.createElement(
        Button,
        {
          variant: "filled",
          danger: true,
          size: "sm",
          onClick: () => {
            setConfirmClose(false);
            leave();
          }
        },
        "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"
      ))))))
    ));
  }
  function useWindowSteps(content) {
    const [steps, setSteps] = (0, import_react14.useState)([]);
    const [slots, setSlots] = (0, import_react14.useState)({});
    const openers = (0, import_react14.useRef)(/* @__PURE__ */ new Map());
    const restore = (0, import_react14.useRef)(null);
    const push = (0, import_react14.useCallback)((id, back) => {
      openers.current.set(id, document.activeElement);
      setSteps((s) => s.some((x) => x.id === id) ? s : [...s, { id, back, title: "", busy: false, touched: false }]);
    }, []);
    const update = (0, import_react14.useCallback)((id, next) => {
      setSteps((s) => s.map((x) => x.id === id ? { ...x, ...next } : x));
    }, []);
    const pop = (0, import_react14.useCallback)((id) => {
      restore.current = openers.current.get(id) ?? null;
      openers.current.delete(id);
      setSteps((s) => s.filter((x) => x.id !== id));
      setSlots((s) => {
        const rest = { ...s };
        delete rest[id];
        return rest;
      });
    }, []);
    const host = (0, import_react14.useMemo)(() => ({ push, update, pop, slots }), [push, update, pop, slots]);
    const refs = (0, import_react14.useRef)(/* @__PURE__ */ new Map());
    function slotRef(id, kind) {
      const key = `${id}:${kind}`;
      let ref = refs.current.get(key);
      if (!ref) {
        ref = (el) => setSlots((s) => s[id]?.[kind] === el || !el && !s[id] ? s : { ...s, [id]: { ...s[id], [kind]: el } });
        refs.current.set(key, ref);
      }
      return ref;
    }
    const top = steps.at(-1) ?? null;
    const topId = top?.id;
    const touchTop = () => {
      if (topId && !top?.touched) setSteps((s) => s.map((x) => x.id === topId ? { ...x, touched: true } : x));
    };
    (0, import_react14.useEffect)(() => {
      const back = restore.current;
      restore.current = null;
      if (back?.isConnected && !back.closest("[hidden]")) {
        back.focus();
        return;
      }
      if (!topId) return;
      const active = document.activeElement;
      if (!content.current?.contains(active) || active?.closest("[hidden]")) content.current?.focus();
    }, [topId, content]);
    const stepSlot = (kind) => steps.map((s) => /* @__PURE__ */ React.createElement("div", { key: s.id, ref: slotRef(s.id, kind), className: "contents", hidden: s.id !== topId }));
    return { host, top, touchTop, stepSlot };
  }

  // src/client/src/shared/ui/ConfirmDialog.tsx
  init_define_import_meta_env();
  var import_react16 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/ui/Checkbox.tsx
  init_define_import_meta_env();
  var import_react15 = __toESM(require_react_shim(), 1);
  var BOX = {
    md: "w-[18px] h-[18px]",
    sm: "w-4 h-4"
  };
  var Checkbox = (0, import_react15.forwardRef)(function Checkbox2({ checked, onChange, indeterminate = false, label, description, size: size4 = "md", disabled, className = "", ...rest }, ref) {
    const inner = (0, import_react15.useRef)(null);
    (0, import_react15.useEffect)(() => {
      if (inner.current) inner.current.indeterminate = indeterminate;
    }, [indeterminate]);
    const input = /* @__PURE__ */ React.createElement(
      "input",
      {
        ...rest,
        ref: (el) => {
          inner.current = el;
          if (typeof ref === "function") ref(el);
          else if (ref) ref.current = el;
        },
        type: "checkbox",
        checked,
        disabled,
        onChange: (e) => onChange(e.target.checked),
        className: `${BOX[size4]} shrink-0 accent-brand ${disabled ? "cursor-not-allowed" : "cursor-pointer"} focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand ${label ? size4 === "md" ? "mt-px" : "mt-0.5" : className}`
      }
    );
    if (!label) return input;
    return /* @__PURE__ */ React.createElement("label", { className: `inline-flex items-start gap-2 text-sm text-fg1 select-none ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"} ${className}` }, input, /* @__PURE__ */ React.createElement("span", { className: "min-w-0" }, label, description && /* @__PURE__ */ React.createElement("span", { className: "block text-xs text-fg3" }, description)));
  });

  // src/client/src/shared/utils/apiError.ts
  init_define_import_meta_env();
  function apiError(e, fallback = "\u041E\u0448\u0438\u0431\u043A\u0430") {
    const err = e;
    const data = err?.response?.data;
    if (typeof data === "string" && data.trim()) return data;
    if (data && typeof data === "object") {
      const d = data;
      if (d.error) return d.error;
      if (d.detail) return d.detail;
    }
    return err?.message || fallback;
  }

  // src/client/src/shared/ui/ConfirmDialog.tsx
  function ConfirmDialog(props) {
    return props.open ? /* @__PURE__ */ React.createElement(ConfirmDialogBody, { ...props }) : null;
  }
  function ConfirmDialogBody({
    onOpenChange,
    title,
    description,
    confirmLabel,
    confirmDanger = true,
    cancelLabel = "\u041E\u0442\u043C\u0435\u043D\u0430",
    requireCheckbox,
    errorTitle = "\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E",
    blocked,
    onConfirm,
    onRefused
  }) {
    const [checked, setChecked] = (0, import_react16.useState)(false);
    const [busy, setBusy] = (0, import_react16.useState)(false);
    const [error, setError] = (0, import_react16.useState)(null);
    const [exit, setExit] = (0, import_react16.useState)(null);
    const [exitFailed, setExitFailed] = (0, import_react16.useState)(null);
    const canConfirm = !requireCheckbox || checked;
    const blockedView = error != null || blocked != null;
    const rule = blockedView ? DISMISSAL.result : null;
    const content = (0, import_react16.useRef)(null);
    async function handleConfirm() {
      setBusy(true);
      setError(null);
      try {
        await onConfirm();
        onOpenChange(false);
      } catch (e) {
        setError(apiError(e, "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435."));
        setExit(onRefused?.(e) ?? null);
      } finally {
        setBusy(false);
      }
    }
    async function handleExit(action) {
      setBusy(true);
      try {
        await action.onConfirm();
        onOpenChange(false);
      } catch (e) {
        setError(apiError(e, "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435."));
        setExitFailed(action.errorTitle);
        setExit(null);
      } finally {
        setBusy(false);
      }
    }
    return /* @__PURE__ */ React.createElement(Dialog, { open: true, onOpenChange: (o) => {
      if (!busy) onOpenChange(o);
    } }, /* @__PURE__ */ React.createElement(DialogPortal, null, /* @__PURE__ */ React.createElement(
      DialogOverlay,
      {
        className: "fixed inset-0 z-40 bg-black/40",
        style: { backdropFilter: "blur(2px)" }
      }
    ), /* @__PURE__ */ React.createElement(
      DialogContent,
      {
        className: "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 rounded-[28px] p-6 w-full max-w-sm bg-surface border border-stroke focus:outline-none",
        style: { boxShadow: "var(--f-shadow28)" },
        ref: content,
        "data-modal-state": busy ? "busy" : rule ? "result" : "free",
        onEscapeKeyDown: (e) => {
          if (!rule || rule.escape === "close") return;
          e.preventDefault();
          if (rule.escape === "focusExit") pointAtExit(content.current, true);
        },
        onInteractOutside: (e) => {
          if (!rule || rule.outside === "close") return;
          e.preventDefault();
          if (rule.outside === "hint") pointAtExit(content.current, false);
        }
      },
      /* @__PURE__ */ React.createElement(DialogTitle, { className: "text-sm font-semibold mb-2 text-fg1" }, blockedView ? exitFailed ?? errorTitle : title),
      blockedView ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "mt-2 flex items-start gap-2.5 rounded-md bg-danger-subtle px-3 py-2.5 text-xs text-fg1" }, /* @__PURE__ */ React.createElement(TriangleAlert, { size: 16, className: "shrink-0 mt-0.5 text-danger" }), /* @__PURE__ */ React.createElement("div", { className: "max-h-40 overflow-y-auto whitespace-pre-line min-w-0" }, error ?? blocked)), exit?.note && /* @__PURE__ */ React.createElement("p", { className: "mt-3 text-xs text-fg2" }, exit.note), exit?.secondary && /* @__PURE__ */ React.createElement("div", { className: "mt-3 pt-3 border-t border-stroke text-xs text-fg2" }, /* @__PURE__ */ React.createElement("p", null, exit.secondary.note), exit.secondary.action && /* @__PURE__ */ React.createElement(
        Button,
        {
          variant: "text",
          danger: true,
          size: "sm",
          className: "mt-1 -ml-3",
          disabled: busy,
          onClick: exit.secondary.action.onClick
        },
        exit.secondary.action.label
      ))) : /* @__PURE__ */ React.createElement(React.Fragment, null, description && /* @__PURE__ */ React.createElement("div", { className: "text-xs mb-3 text-fg3 space-y-1" }, description), requireCheckbox && /* @__PURE__ */ React.createElement("label", { className: "flex items-start gap-2 mb-4 text-xs text-fg2 cursor-pointer select-none" }, /* @__PURE__ */ React.createElement(Checkbox, { size: "sm", checked, onChange: setChecked }), requireCheckbox)),
      /* @__PURE__ */ React.createElement("div", { className: `flex gap-2 justify-end items-start ${blockedView || !requireCheckbox ? "mt-4" : ""}` }, blockedView ? exit?.action ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Button, { variant: "text", size: "sm", className: "shrink-0", disabled: busy, autoFocus: true, "data-modal-exit": "", onClick: () => onOpenChange(false) }, "\u041F\u043E\u043D\u044F\u0442\u043D\u043E"), /* @__PURE__ */ React.createElement(
        Button,
        {
          variant: "filled",
          size: "sm",
          multiline: true,
          className: "min-w-0",
          loading: busy,
          onClick: () => handleExit(exit.action)
        },
        exit.action.label
      )) : (
        // Фокус — на выход: кнопка подтверждения, на которой он стоял, с отказом исчезла, а Esc
        // здесь больше не закрывает — без фокуса человеку с клавиатурой пришлось бы искать выход.
        /* @__PURE__ */ React.createElement(Button, { variant: "tonal", size: "sm", autoFocus: true, "data-modal-exit": "", onClick: () => onOpenChange(false) }, "\u041F\u043E\u043D\u044F\u0442\u043D\u043E")
      ) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(DialogClose, { asChild: true }, /* @__PURE__ */ React.createElement(Button, { variant: "text", size: "sm", className: "shrink-0", disabled: busy }, cancelLabel)), /* @__PURE__ */ React.createElement(
        Button,
        {
          variant: "filled",
          danger: confirmDanger,
          size: "sm",
          multiline: true,
          className: "min-w-0",
          disabled: !canConfirm,
          loading: busy,
          onClick: handleConfirm
        },
        confirmLabel
      )))
    )));
  }
  function CascadeList({ items }) {
    return /* @__PURE__ */ React.createElement("ul", { className: "list-disc pl-4 space-y-0.5" }, items.map((item, i) => /* @__PURE__ */ React.createElement("li", { key: i }, item)));
  }

  // src/client/src/shared/ui/RowActionsMenu.tsx
  init_define_import_meta_env();

  // src/client/node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs
  init_define_import_meta_env();
  var React38 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-menu/dist/index.mjs
  init_define_import_meta_env();
  var React37 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/@radix-ui/react-roving-focus/dist/index.mjs
  init_define_import_meta_env();
  var React36 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime15 = __toESM(require_react_shim(), 1);
  var ENTRY_FOCUS = "rovingFocusGroup.onEntryFocus";
  var EVENT_OPTIONS2 = { bubbles: false, cancelable: true };
  var GROUP_NAME2 = "RovingFocusGroup";
  var [Collection2, useCollection2, createCollectionScope2] = createCollection(GROUP_NAME2);
  var [createRovingFocusGroupContext, createRovingFocusGroupScope] = createContextScope(
    GROUP_NAME2,
    [createCollectionScope2]
  );
  var [RovingFocusProvider, useRovingFocusContext] = createRovingFocusGroupContext(GROUP_NAME2);
  var RovingFocusGroup = React36.forwardRef(
    (props, forwardedRef) => {
      return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(Collection2.Provider, { scope: props.__scopeRovingFocusGroup, children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(Collection2.Slot, { scope: props.__scopeRovingFocusGroup, children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(RovingFocusGroupImpl, { ...props, ref: forwardedRef }) }) });
    }
  );
  RovingFocusGroup.displayName = GROUP_NAME2;
  var RovingFocusGroupImpl = React36.forwardRef((props, forwardedRef) => {
    const {
      __scopeRovingFocusGroup,
      orientation,
      loop = false,
      dir,
      currentTabStopId: currentTabStopIdProp,
      defaultCurrentTabStopId,
      onCurrentTabStopIdChange,
      onEntryFocus,
      preventScrollOnEntryFocus = false,
      ...groupProps
    } = props;
    const ref = React36.useRef(null);
    const composedRefs = useComposedRefs(forwardedRef, ref);
    const direction = useDirection(dir);
    const [currentTabStopId, setCurrentTabStopId] = useControllableState({
      prop: currentTabStopIdProp,
      defaultProp: defaultCurrentTabStopId ?? null,
      onChange: onCurrentTabStopIdChange,
      caller: GROUP_NAME2
    });
    const [isTabbingBackOut, setIsTabbingBackOut] = React36.useState(false);
    const handleEntryFocus = useCallbackRef(onEntryFocus);
    const getItems = useCollection2(__scopeRovingFocusGroup);
    const isClickFocusRef = React36.useRef(false);
    const [focusableItemsCount, setFocusableItemsCount] = React36.useState(0);
    React36.useEffect(() => {
      const node = ref.current;
      if (node) {
        node.addEventListener(ENTRY_FOCUS, handleEntryFocus);
        return () => node.removeEventListener(ENTRY_FOCUS, handleEntryFocus);
      }
    }, [handleEntryFocus]);
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
      RovingFocusProvider,
      {
        scope: __scopeRovingFocusGroup,
        orientation,
        dir: direction,
        loop,
        currentTabStopId,
        onItemFocus: React36.useCallback(
          (tabStopId) => setCurrentTabStopId(tabStopId),
          [setCurrentTabStopId]
        ),
        onItemShiftTab: React36.useCallback(() => setIsTabbingBackOut(true), []),
        onFocusableItemAdd: React36.useCallback(
          () => setFocusableItemsCount((prevCount) => prevCount + 1),
          []
        ),
        onFocusableItemRemove: React36.useCallback(
          () => setFocusableItemsCount((prevCount) => prevCount - 1),
          []
        ),
        children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
          Primitive.div,
          {
            tabIndex: isTabbingBackOut || focusableItemsCount === 0 ? -1 : 0,
            "data-orientation": orientation,
            ...groupProps,
            ref: composedRefs,
            style: { outline: "none", ...props.style },
            onMouseDown: composeEventHandlers(props.onMouseDown, () => {
              isClickFocusRef.current = true;
            }),
            onFocus: composeEventHandlers(props.onFocus, (event) => {
              const isKeyboardFocus = !isClickFocusRef.current;
              if (event.target === event.currentTarget && isKeyboardFocus && !isTabbingBackOut) {
                const entryFocusEvent = new CustomEvent(ENTRY_FOCUS, EVENT_OPTIONS2);
                event.currentTarget.dispatchEvent(entryFocusEvent);
                if (!entryFocusEvent.defaultPrevented) {
                  const items = getItems().filter((item) => item.focusable);
                  const activeItem = items.find((item) => item.active);
                  const currentItem = items.find((item) => item.id === currentTabStopId);
                  const candidateItems = [activeItem, currentItem, ...items].filter(
                    Boolean
                  );
                  const candidateNodes = candidateItems.map((item) => item.ref.current);
                  focusFirst2(candidateNodes, preventScrollOnEntryFocus);
                }
              }
              isClickFocusRef.current = false;
            }),
            onBlur: composeEventHandlers(props.onBlur, () => setIsTabbingBackOut(false))
          }
        )
      }
    );
  });
  var ITEM_NAME2 = "RovingFocusGroupItem";
  var RovingFocusGroupItem = React36.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopeRovingFocusGroup,
        focusable = true,
        active = false,
        tabStopId,
        children,
        ...itemProps
      } = props;
      const autoId = useId2();
      const id = tabStopId || autoId;
      const context = useRovingFocusContext(ITEM_NAME2, __scopeRovingFocusGroup);
      const isCurrentTabStop = context.currentTabStopId === id;
      const getItems = useCollection2(__scopeRovingFocusGroup);
      const { onFocusableItemAdd, onFocusableItemRemove, currentTabStopId } = context;
      React36.useEffect(() => {
        if (focusable) {
          onFocusableItemAdd();
          return () => onFocusableItemRemove();
        }
      }, [focusable, onFocusableItemAdd, onFocusableItemRemove]);
      return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
        Collection2.ItemSlot,
        {
          scope: __scopeRovingFocusGroup,
          id,
          focusable,
          active,
          children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
            Primitive.span,
            {
              tabIndex: isCurrentTabStop ? 0 : -1,
              "data-orientation": context.orientation,
              ...itemProps,
              ref: forwardedRef,
              onMouseDown: composeEventHandlers(props.onMouseDown, (event) => {
                if (!focusable) event.preventDefault();
                else context.onItemFocus(id);
              }),
              onFocus: composeEventHandlers(props.onFocus, () => context.onItemFocus(id)),
              onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
                if (event.key === "Tab" && event.shiftKey) {
                  context.onItemShiftTab();
                  return;
                }
                if (event.target !== event.currentTarget) return;
                const focusIntent = getFocusIntent(event, context.orientation, context.dir);
                if (focusIntent !== void 0) {
                  if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
                  event.preventDefault();
                  const items = getItems().filter((item) => item.focusable);
                  let candidateNodes = items.map((item) => item.ref.current);
                  if (focusIntent === "last") candidateNodes.reverse();
                  else if (focusIntent === "prev" || focusIntent === "next") {
                    if (focusIntent === "prev") candidateNodes.reverse();
                    const currentIndex = candidateNodes.indexOf(event.currentTarget);
                    candidateNodes = context.loop ? wrapArray2(candidateNodes, currentIndex + 1) : candidateNodes.slice(currentIndex + 1);
                  }
                  setTimeout(() => focusFirst2(candidateNodes));
                }
              }),
              children: typeof children === "function" ? children({ isCurrentTabStop, hasTabStop: currentTabStopId != null }) : children
            }
          )
        }
      );
    }
  );
  RovingFocusGroupItem.displayName = ITEM_NAME2;
  var MAP_KEY_TO_FOCUS_INTENT = {
    ArrowLeft: "prev",
    ArrowUp: "prev",
    ArrowRight: "next",
    ArrowDown: "next",
    PageUp: "first",
    Home: "first",
    PageDown: "last",
    End: "last"
  };
  function getDirectionAwareKey(key, dir) {
    if (dir !== "rtl") return key;
    return key === "ArrowLeft" ? "ArrowRight" : key === "ArrowRight" ? "ArrowLeft" : key;
  }
  function getFocusIntent(event, orientation, dir) {
    const key = getDirectionAwareKey(event.key, dir);
    if (orientation === "vertical" && ["ArrowLeft", "ArrowRight"].includes(key)) return void 0;
    if (orientation === "horizontal" && ["ArrowUp", "ArrowDown"].includes(key)) return void 0;
    return MAP_KEY_TO_FOCUS_INTENT[key];
  }
  function focusFirst2(candidates, preventScroll = false) {
    const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
    for (const candidate of candidates) {
      if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
      candidate.focus({ preventScroll });
      if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
    }
  }
  function wrapArray2(array, startIndex) {
    return array.map((_, index2) => array[(startIndex + index2) % array.length]);
  }
  var Root4 = RovingFocusGroup;
  var Item = RovingFocusGroupItem;

  // src/client/node_modules/@radix-ui/react-menu/dist/index.mjs
  var import_jsx_runtime16 = __toESM(require_react_shim(), 1);
  var SELECTION_KEYS2 = ["Enter", " "];
  var FIRST_KEYS = ["ArrowDown", "PageUp", "Home"];
  var LAST_KEYS = ["ArrowUp", "PageDown", "End"];
  var FIRST_LAST_KEYS = [...FIRST_KEYS, ...LAST_KEYS];
  var SUB_OPEN_KEYS = {
    ltr: [...SELECTION_KEYS2, "ArrowRight"],
    rtl: [...SELECTION_KEYS2, "ArrowLeft"]
  };
  var SUB_CLOSE_KEYS = {
    ltr: ["ArrowLeft"],
    rtl: ["ArrowRight"]
  };
  var MENU_NAME = "Menu";
  var [Collection3, useCollection3, createCollectionScope3] = createCollection(MENU_NAME);
  var [createMenuContext, createMenuScope] = createContextScope(MENU_NAME, [
    createCollectionScope3,
    createPopperScope,
    createRovingFocusGroupScope
  ]);
  var usePopperScope3 = createPopperScope();
  var useRovingFocusGroupScope = createRovingFocusGroupScope();
  var [MenuProvider, useMenuContext] = createMenuContext(MENU_NAME);
  var [MenuRootProvider, useMenuRootContext] = createMenuContext(MENU_NAME);
  var Menu = (props) => {
    const { __scopeMenu, open = false, children, dir, onOpenChange, modal = true } = props;
    const popperScope = usePopperScope3(__scopeMenu);
    const [content, setContent] = React37.useState(null);
    const isUsingKeyboardRef = React37.useRef(false);
    const handleOpenChange = useCallbackRef(onOpenChange);
    const direction = useDirection(dir);
    React37.useEffect(() => {
      const handleKeyDown = () => {
        isUsingKeyboardRef.current = true;
        document.addEventListener("pointerdown", handlePointer, { capture: true, once: true });
        document.addEventListener("pointermove", handlePointer, { capture: true, once: true });
      };
      const handlePointer = () => isUsingKeyboardRef.current = false;
      document.addEventListener("keydown", handleKeyDown, { capture: true });
      return () => {
        document.removeEventListener("keydown", handleKeyDown, { capture: true });
        document.removeEventListener("pointerdown", handlePointer, { capture: true });
        document.removeEventListener("pointermove", handlePointer, { capture: true });
      };
    }, []);
    React37.useEffect(() => {
      if (!open) {
        return;
      }
      const handleBlur = () => handleOpenChange(false);
      window.addEventListener("blur", handleBlur);
      return () => window.removeEventListener("blur", handleBlur);
    }, [open, handleOpenChange]);
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Root2, { ...popperScope, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
      MenuProvider,
      {
        scope: __scopeMenu,
        open,
        onOpenChange: handleOpenChange,
        content,
        onContentChange: setContent,
        children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
          MenuRootProvider,
          {
            scope: __scopeMenu,
            onClose: React37.useCallback(() => handleOpenChange(false), [handleOpenChange]),
            isUsingKeyboardRef,
            dir: direction,
            modal,
            children
          }
        )
      }
    ) });
  };
  Menu.displayName = MENU_NAME;
  var ANCHOR_NAME3 = "MenuAnchor";
  var MenuAnchor = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, ...anchorProps } = props;
      const popperScope = usePopperScope3(__scopeMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Anchor, { ...popperScope, ...anchorProps, ref: forwardedRef });
    }
  );
  MenuAnchor.displayName = ANCHOR_NAME3;
  var PORTAL_NAME5 = "MenuPortal";
  var [PortalProvider4, usePortalContext4] = createMenuContext(PORTAL_NAME5, {
    forceMount: void 0
  });
  var MenuPortal = (props) => {
    const { __scopeMenu, forceMount, children, container } = props;
    const context = useMenuContext(PORTAL_NAME5, __scopeMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(PortalProvider4, { scope: __scopeMenu, forceMount, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Portal, { asChild: true, container, children }) }) });
  };
  MenuPortal.displayName = PORTAL_NAME5;
  var CONTENT_NAME5 = "MenuContent";
  var [MenuContentProvider, useMenuContentContext] = createMenuContext(CONTENT_NAME5);
  var MenuContent = React37.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext4(CONTENT_NAME5, props.__scopeMenu);
      const { forceMount = portalContext.forceMount, ...contentProps } = props;
      const context = useMenuContext(CONTENT_NAME5, props.__scopeMenu);
      const rootContext = useMenuRootContext(CONTENT_NAME5, props.__scopeMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Collection3.Provider, { scope: props.__scopeMenu, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Collection3.Slot, { scope: props.__scopeMenu, children: rootContext.modal ? /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(MenuRootContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(MenuRootContentNonModal, { ...contentProps, ref: forwardedRef }) }) }) });
    }
  );
  var MenuRootContentModal = React37.forwardRef(
    (props, forwardedRef) => {
      const context = useMenuContext(CONTENT_NAME5, props.__scopeMenu);
      const ref = React37.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      React37.useEffect(() => {
        const content = ref.current;
        if (content) return hideOthers(content);
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuContentImpl,
        {
          ...props,
          ref: composedRefs,
          trapFocus: context.open,
          disableOutsidePointerEvents: context.open,
          disableOutsideScroll: true,
          onFocusOutside: composeEventHandlers(
            props.onFocusOutside,
            (event) => event.preventDefault(),
            { checkForDefaultPrevented: false }
          ),
          onDismiss: () => context.onOpenChange(false)
        }
      );
    }
  );
  var MenuRootContentNonModal = React37.forwardRef((props, forwardedRef) => {
    const context = useMenuContext(CONTENT_NAME5, props.__scopeMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
      MenuContentImpl,
      {
        ...props,
        ref: forwardedRef,
        trapFocus: false,
        disableOutsidePointerEvents: false,
        disableOutsideScroll: false,
        onDismiss: () => context.onOpenChange(false)
      }
    );
  });
  var Slot4 = createSlot("MenuContent.ScrollLock");
  var MenuContentImpl = React37.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopeMenu,
        loop = false,
        trapFocus,
        onOpenAutoFocus,
        onCloseAutoFocus,
        disableOutsidePointerEvents,
        onEntryFocus,
        onEscapeKeyDown,
        onPointerDownOutside,
        onFocusOutside,
        onInteractOutside,
        onDismiss,
        disableOutsideScroll,
        ...contentProps
      } = props;
      const context = useMenuContext(CONTENT_NAME5, __scopeMenu);
      const rootContext = useMenuRootContext(CONTENT_NAME5, __scopeMenu);
      const popperScope = usePopperScope3(__scopeMenu);
      const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
      const getItems = useCollection3(__scopeMenu);
      const [currentItemId, setCurrentItemId] = React37.useState(null);
      const contentRef = React37.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, contentRef, context.onContentChange);
      const timerRef = React37.useRef(0);
      const searchRef = React37.useRef("");
      const pointerGraceTimerRef = React37.useRef(0);
      const pointerGraceIntentRef = React37.useRef(null);
      const pointerDirRef = React37.useRef("right");
      const lastPointerXRef = React37.useRef(0);
      const ScrollLockWrapper = disableOutsideScroll ? Combination_default : React37.Fragment;
      const scrollLockWrapperProps = disableOutsideScroll ? { as: Slot4, allowPinchZoom: true } : void 0;
      const handleTypeaheadSearch = (key) => {
        const search = searchRef.current + key;
        const items = getItems().filter((item) => !item.disabled);
        const currentItem = document.activeElement;
        const currentMatch = items.find((item) => item.ref.current === currentItem)?.textValue;
        const values = items.map((item) => item.textValue);
        const nextMatch = getNextMatch(values, search, currentMatch);
        const newItem = items.find((item) => item.textValue === nextMatch)?.ref.current;
        (function updateSearch(value) {
          searchRef.current = value;
          window.clearTimeout(timerRef.current);
          if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
        })(search);
        if (newItem) {
          setTimeout(() => newItem.focus());
        }
      };
      React37.useEffect(() => {
        return () => window.clearTimeout(timerRef.current);
      }, []);
      useFocusGuards();
      const isPointerMovingToSubmenu = React37.useCallback((event) => {
        const isMovingTowards = pointerDirRef.current === pointerGraceIntentRef.current?.side;
        return isMovingTowards && isPointerInGraceArea(event, pointerGraceIntentRef.current?.area);
      }, []);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuContentProvider,
        {
          scope: __scopeMenu,
          searchRef,
          onItemEnter: React37.useCallback(
            (event) => {
              if (isPointerMovingToSubmenu(event)) event.preventDefault();
            },
            [isPointerMovingToSubmenu]
          ),
          onItemLeave: React37.useCallback(
            (event) => {
              if (isPointerMovingToSubmenu(event)) return;
              contentRef.current?.focus();
              setCurrentItemId(null);
            },
            [isPointerMovingToSubmenu]
          ),
          onTriggerLeave: React37.useCallback(
            (event) => {
              if (isPointerMovingToSubmenu(event)) event.preventDefault();
            },
            [isPointerMovingToSubmenu]
          ),
          pointerGraceTimerRef,
          onPointerGraceIntentChange: React37.useCallback((intent) => {
            pointerGraceIntentRef.current = intent;
          }, []),
          children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(ScrollLockWrapper, { ...scrollLockWrapperProps, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
            FocusScope,
            {
              asChild: true,
              trapped: trapFocus,
              onMountAutoFocus: composeEventHandlers(onOpenAutoFocus, (event) => {
                event.preventDefault();
                contentRef.current?.focus({ preventScroll: true });
              }),
              onUnmountAutoFocus: onCloseAutoFocus,
              children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
                DismissableLayer,
                {
                  asChild: true,
                  disableOutsidePointerEvents,
                  onEscapeKeyDown,
                  onPointerDownOutside,
                  onFocusOutside,
                  onInteractOutside,
                  onDismiss,
                  children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
                    Root4,
                    {
                      asChild: true,
                      ...rovingFocusGroupScope,
                      dir: rootContext.dir,
                      orientation: "vertical",
                      loop,
                      currentTabStopId: currentItemId,
                      onCurrentTabStopIdChange: setCurrentItemId,
                      onEntryFocus: composeEventHandlers(onEntryFocus, (event) => {
                        if (!rootContext.isUsingKeyboardRef.current) event.preventDefault();
                      }),
                      preventScrollOnEntryFocus: true,
                      children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
                        Content,
                        {
                          role: "menu",
                          "aria-orientation": "vertical",
                          "data-state": getOpenState(context.open),
                          "data-radix-menu-content": "",
                          dir: rootContext.dir,
                          ...popperScope,
                          ...contentProps,
                          ref: composedRefs,
                          style: { outline: "none", ...contentProps.style },
                          onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
                            const target = event.target;
                            const isKeyDownInside = target.closest("[data-radix-menu-content]") === event.currentTarget;
                            const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
                            const isCharacterKey = event.key.length === 1;
                            if (isKeyDownInside) {
                              if (event.key === "Tab") event.preventDefault();
                              if (!isModifierKey && isCharacterKey) handleTypeaheadSearch(event.key);
                            }
                            const content = contentRef.current;
                            if (event.target !== content) return;
                            if (!FIRST_LAST_KEYS.includes(event.key)) return;
                            event.preventDefault();
                            const items = getItems().filter((item) => !item.disabled);
                            const candidateNodes = items.map((item) => item.ref.current);
                            if (LAST_KEYS.includes(event.key)) candidateNodes.reverse();
                            focusFirst3(candidateNodes);
                          }),
                          onBlur: composeEventHandlers(props.onBlur, (event) => {
                            if (!event.currentTarget.contains(event.target)) {
                              window.clearTimeout(timerRef.current);
                              searchRef.current = "";
                            }
                          }),
                          onPointerMove: composeEventHandlers(
                            props.onPointerMove,
                            whenMouse((event) => {
                              const target = event.target;
                              const pointerXHasChanged = lastPointerXRef.current !== event.clientX;
                              if (event.currentTarget.contains(target) && pointerXHasChanged) {
                                const newDir = event.clientX > lastPointerXRef.current ? "right" : "left";
                                pointerDirRef.current = newDir;
                                lastPointerXRef.current = event.clientX;
                              }
                            })
                          )
                        }
                      )
                    }
                  )
                }
              )
            }
          ) })
        }
      );
    }
  );
  MenuContent.displayName = CONTENT_NAME5;
  var GROUP_NAME3 = "MenuGroup";
  var MenuGroup = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, ...groupProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Primitive.div, { role: "group", ...groupProps, ref: forwardedRef });
    }
  );
  MenuGroup.displayName = GROUP_NAME3;
  var LABEL_NAME2 = "MenuLabel";
  var MenuLabel = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, ...labelProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Primitive.div, { ...labelProps, ref: forwardedRef });
    }
  );
  MenuLabel.displayName = LABEL_NAME2;
  var ITEM_NAME3 = "MenuItem";
  var ITEM_SELECT = "menu.itemSelect";
  var MenuItem = React37.forwardRef(
    (props, forwardedRef) => {
      const { disabled = false, onSelect, ...itemProps } = props;
      const ref = React37.useRef(null);
      const rootContext = useMenuRootContext(ITEM_NAME3, props.__scopeMenu);
      const contentContext = useMenuContentContext(ITEM_NAME3, props.__scopeMenu);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      const isPointerDownRef = React37.useRef(false);
      const handleSelect = () => {
        const menuItem = ref.current;
        if (!disabled && menuItem) {
          const itemSelectEvent = new CustomEvent(ITEM_SELECT, { bubbles: true, cancelable: true });
          menuItem.addEventListener(ITEM_SELECT, (event) => onSelect?.(event), { once: true });
          dispatchDiscreteCustomEvent(menuItem, itemSelectEvent);
          if (itemSelectEvent.defaultPrevented) {
            isPointerDownRef.current = false;
          } else {
            rootContext.onClose();
          }
        }
      };
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuItemImpl,
        {
          ...itemProps,
          ref: composedRefs,
          disabled,
          onClick: composeEventHandlers(props.onClick, handleSelect),
          onPointerDown: (event) => {
            props.onPointerDown?.(event);
            isPointerDownRef.current = true;
          },
          onPointerUp: composeEventHandlers(props.onPointerUp, (event) => {
            if (!isPointerDownRef.current) event.currentTarget?.click();
          }),
          onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
            const isTypingAhead = contentContext.searchRef.current !== "";
            if (disabled || isTypingAhead && event.key === " ") return;
            if (SELECTION_KEYS2.includes(event.key)) {
              event.currentTarget.click();
              event.preventDefault();
            }
          })
        }
      );
    }
  );
  MenuItem.displayName = ITEM_NAME3;
  var MenuItemImpl = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, disabled = false, textValue, ...itemProps } = props;
      const contentContext = useMenuContentContext(ITEM_NAME3, __scopeMenu);
      const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
      const ref = React37.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      const [isFocused, setIsFocused] = React37.useState(false);
      const [textContent, setTextContent] = React37.useState("");
      React37.useEffect(() => {
        const menuItem = ref.current;
        if (menuItem) {
          setTextContent((menuItem.textContent ?? "").trim());
        }
      }, [itemProps.children]);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        Collection3.ItemSlot,
        {
          scope: __scopeMenu,
          disabled,
          textValue: textValue ?? textContent,
          children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Item, { asChild: true, ...rovingFocusGroupScope, focusable: !disabled, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
            Primitive.div,
            {
              role: "menuitem",
              "data-highlighted": isFocused ? "" : void 0,
              "aria-disabled": disabled || void 0,
              "data-disabled": disabled ? "" : void 0,
              ...itemProps,
              ref: composedRefs,
              onPointerMove: composeEventHandlers(
                props.onPointerMove,
                whenMouse((event) => {
                  if (disabled) {
                    contentContext.onItemLeave(event);
                  } else {
                    contentContext.onItemEnter(event);
                    if (!event.defaultPrevented) {
                      const item = event.currentTarget;
                      item.focus({ preventScroll: true });
                    }
                  }
                })
              ),
              onPointerLeave: composeEventHandlers(
                props.onPointerLeave,
                whenMouse((event) => contentContext.onItemLeave(event))
              ),
              onFocus: composeEventHandlers(props.onFocus, () => setIsFocused(true)),
              onBlur: composeEventHandlers(props.onBlur, () => setIsFocused(false))
            }
          ) })
        }
      );
    }
  );
  var CHECKBOX_ITEM_NAME = "MenuCheckboxItem";
  var MenuCheckboxItem = React37.forwardRef(
    (props, forwardedRef) => {
      const { checked = false, onCheckedChange, ...checkboxItemProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(ItemIndicatorProvider, { scope: props.__scopeMenu, checked, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuItem,
        {
          role: "menuitemcheckbox",
          "aria-checked": isIndeterminate(checked) ? "mixed" : checked,
          ...checkboxItemProps,
          ref: forwardedRef,
          "data-state": getCheckedState(checked),
          onSelect: composeEventHandlers(
            checkboxItemProps.onSelect,
            () => onCheckedChange?.(isIndeterminate(checked) ? true : !checked),
            { checkForDefaultPrevented: false }
          )
        }
      ) });
    }
  );
  MenuCheckboxItem.displayName = CHECKBOX_ITEM_NAME;
  var RADIO_GROUP_NAME = "MenuRadioGroup";
  var [RadioGroupProvider, useRadioGroupContext] = createMenuContext(
    RADIO_GROUP_NAME,
    { value: void 0, onValueChange: () => {
    } }
  );
  var MenuRadioGroup = React37.forwardRef(
    (props, forwardedRef) => {
      const { value, onValueChange, ...groupProps } = props;
      const handleValueChange = useCallbackRef(onValueChange);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(RadioGroupProvider, { scope: props.__scopeMenu, value, onValueChange: handleValueChange, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(MenuGroup, { ...groupProps, ref: forwardedRef }) });
    }
  );
  MenuRadioGroup.displayName = RADIO_GROUP_NAME;
  var RADIO_ITEM_NAME = "MenuRadioItem";
  var MenuRadioItem = React37.forwardRef(
    (props, forwardedRef) => {
      const { value, ...radioItemProps } = props;
      const context = useRadioGroupContext(RADIO_ITEM_NAME, props.__scopeMenu);
      const checked = value === context.value;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(ItemIndicatorProvider, { scope: props.__scopeMenu, checked, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuItem,
        {
          role: "menuitemradio",
          "aria-checked": checked,
          ...radioItemProps,
          ref: forwardedRef,
          "data-state": getCheckedState(checked),
          onSelect: composeEventHandlers(
            radioItemProps.onSelect,
            () => context.onValueChange?.(value),
            { checkForDefaultPrevented: false }
          )
        }
      ) });
    }
  );
  MenuRadioItem.displayName = RADIO_ITEM_NAME;
  var ITEM_INDICATOR_NAME2 = "MenuItemIndicator";
  var [ItemIndicatorProvider, useItemIndicatorContext] = createMenuContext(
    ITEM_INDICATOR_NAME2,
    { checked: false }
  );
  var MenuItemIndicator = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, forceMount, ...itemIndicatorProps } = props;
      const indicatorContext = useItemIndicatorContext(ITEM_INDICATOR_NAME2, __scopeMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        Presence,
        {
          present: forceMount || isIndeterminate(indicatorContext.checked) || indicatorContext.checked === true,
          children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
            Primitive.span,
            {
              ...itemIndicatorProps,
              ref: forwardedRef,
              "data-state": getCheckedState(indicatorContext.checked)
            }
          )
        }
      );
    }
  );
  MenuItemIndicator.displayName = ITEM_INDICATOR_NAME2;
  var SEPARATOR_NAME2 = "MenuSeparator";
  var MenuSeparator = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, ...separatorProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        Primitive.div,
        {
          role: "separator",
          "aria-orientation": "horizontal",
          ...separatorProps,
          ref: forwardedRef
        }
      );
    }
  );
  MenuSeparator.displayName = SEPARATOR_NAME2;
  var ARROW_NAME4 = "MenuArrow";
  var MenuArrow = React37.forwardRef(
    (props, forwardedRef) => {
      const { __scopeMenu, ...arrowProps } = props;
      const popperScope = usePopperScope3(__scopeMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Arrow2, { ...popperScope, ...arrowProps, ref: forwardedRef });
    }
  );
  MenuArrow.displayName = ARROW_NAME4;
  var SUB_NAME = "MenuSub";
  var [MenuSubProvider, useMenuSubContext] = createMenuContext(SUB_NAME);
  var MenuSub = (props) => {
    const { __scopeMenu, children, open = false, onOpenChange } = props;
    const parentMenuContext = useMenuContext(SUB_NAME, __scopeMenu);
    const popperScope = usePopperScope3(__scopeMenu);
    const [trigger, setTrigger] = React37.useState(null);
    const [content, setContent] = React37.useState(null);
    const handleOpenChange = useCallbackRef(onOpenChange);
    React37.useEffect(() => {
      if (parentMenuContext.open === false) handleOpenChange(false);
      return () => handleOpenChange(false);
    }, [parentMenuContext.open, handleOpenChange]);
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Root2, { ...popperScope, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
      MenuProvider,
      {
        scope: __scopeMenu,
        open,
        onOpenChange: handleOpenChange,
        content,
        onContentChange: setContent,
        children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
          MenuSubProvider,
          {
            scope: __scopeMenu,
            contentId: useId2(),
            triggerId: useId2(),
            trigger,
            onTriggerChange: setTrigger,
            children
          }
        )
      }
    ) });
  };
  MenuSub.displayName = SUB_NAME;
  var SUB_TRIGGER_NAME = "MenuSubTrigger";
  var MenuSubTrigger = React37.forwardRef(
    (props, forwardedRef) => {
      const context = useMenuContext(SUB_TRIGGER_NAME, props.__scopeMenu);
      const rootContext = useMenuRootContext(SUB_TRIGGER_NAME, props.__scopeMenu);
      const subContext = useMenuSubContext(SUB_TRIGGER_NAME, props.__scopeMenu);
      const contentContext = useMenuContentContext(SUB_TRIGGER_NAME, props.__scopeMenu);
      const openTimerRef = React37.useRef(null);
      const { pointerGraceTimerRef, onPointerGraceIntentChange } = contentContext;
      const scope = { __scopeMenu: props.__scopeMenu };
      const clearOpenTimer = React37.useCallback(() => {
        if (openTimerRef.current) window.clearTimeout(openTimerRef.current);
        openTimerRef.current = null;
      }, []);
      React37.useEffect(() => clearOpenTimer, [clearOpenTimer]);
      React37.useEffect(() => {
        const pointerGraceTimer = pointerGraceTimerRef.current;
        return () => {
          window.clearTimeout(pointerGraceTimer);
          onPointerGraceIntentChange(null);
        };
      }, [pointerGraceTimerRef, onPointerGraceIntentChange]);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(MenuAnchor, { asChild: true, ...scope, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuItemImpl,
        {
          id: subContext.triggerId,
          "aria-haspopup": "menu",
          "aria-expanded": context.open,
          "aria-controls": context.open ? subContext.contentId : void 0,
          "data-state": getOpenState(context.open),
          ...props,
          ref: composeRefs(forwardedRef, subContext.onTriggerChange),
          onClick: (event) => {
            props.onClick?.(event);
            if (props.disabled || event.defaultPrevented) return;
            event.currentTarget.focus();
            if (!context.open) context.onOpenChange(true);
          },
          onPointerMove: composeEventHandlers(
            props.onPointerMove,
            whenMouse((event) => {
              contentContext.onItemEnter(event);
              if (event.defaultPrevented) return;
              if (!props.disabled && !context.open && !openTimerRef.current) {
                contentContext.onPointerGraceIntentChange(null);
                openTimerRef.current = window.setTimeout(() => {
                  context.onOpenChange(true);
                  clearOpenTimer();
                }, 100);
              }
            })
          ),
          onPointerLeave: composeEventHandlers(
            props.onPointerLeave,
            whenMouse((event) => {
              clearOpenTimer();
              const contentRect = context.content?.getBoundingClientRect();
              if (contentRect) {
                const side = context.content?.dataset.side;
                const rightSide = side === "right";
                const bleed = rightSide ? -5 : 5;
                const contentNearEdge = contentRect[rightSide ? "left" : "right"];
                const contentFarEdge = contentRect[rightSide ? "right" : "left"];
                contentContext.onPointerGraceIntentChange({
                  area: [
                    // Apply a bleed on clientX to ensure that our exit point is
                    // consistently within polygon bounds
                    { x: event.clientX + bleed, y: event.clientY },
                    { x: contentNearEdge, y: contentRect.top },
                    { x: contentFarEdge, y: contentRect.top },
                    { x: contentFarEdge, y: contentRect.bottom },
                    { x: contentNearEdge, y: contentRect.bottom }
                  ],
                  side
                });
                window.clearTimeout(pointerGraceTimerRef.current);
                pointerGraceTimerRef.current = window.setTimeout(
                  () => contentContext.onPointerGraceIntentChange(null),
                  300
                );
              } else {
                contentContext.onTriggerLeave(event);
                if (event.defaultPrevented) return;
                contentContext.onPointerGraceIntentChange(null);
              }
            })
          ),
          onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
            const isTypingAhead = contentContext.searchRef.current !== "";
            if (props.disabled || isTypingAhead && event.key === " ") return;
            if (SUB_OPEN_KEYS[rootContext.dir].includes(event.key)) {
              context.onOpenChange(true);
              context.content?.focus();
              event.preventDefault();
            }
          })
        }
      ) });
    }
  );
  MenuSubTrigger.displayName = SUB_TRIGGER_NAME;
  var SUB_CONTENT_NAME = "MenuSubContent";
  var MenuSubContent = React37.forwardRef(
    (props, forwardedRef) => {
      const portalContext = usePortalContext4(CONTENT_NAME5, props.__scopeMenu);
      const { forceMount = portalContext.forceMount, align = "start", ...subContentProps } = props;
      const context = useMenuContext(CONTENT_NAME5, props.__scopeMenu);
      const rootContext = useMenuRootContext(CONTENT_NAME5, props.__scopeMenu);
      const subContext = useMenuSubContext(SUB_CONTENT_NAME, props.__scopeMenu);
      const ref = React37.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Collection3.Provider, { scope: props.__scopeMenu, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Collection3.Slot, { scope: props.__scopeMenu, children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
        MenuContentImpl,
        {
          id: subContext.contentId,
          "aria-labelledby": subContext.triggerId,
          ...subContentProps,
          ref: composedRefs,
          align,
          side: rootContext.dir === "rtl" ? "left" : "right",
          disableOutsidePointerEvents: false,
          disableOutsideScroll: false,
          trapFocus: false,
          onOpenAutoFocus: (event) => {
            if (rootContext.isUsingKeyboardRef.current) ref.current?.focus();
            event.preventDefault();
          },
          onCloseAutoFocus: (event) => event.preventDefault(),
          onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => {
            if (event.target !== subContext.trigger) context.onOpenChange(false);
          }),
          onEscapeKeyDown: composeEventHandlers(props.onEscapeKeyDown, (event) => {
            rootContext.onClose();
            event.preventDefault();
          }),
          onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
            const isKeyDownInside = event.currentTarget.contains(event.target);
            const isCloseKey = SUB_CLOSE_KEYS[rootContext.dir].includes(event.key);
            if (isKeyDownInside && isCloseKey) {
              context.onOpenChange(false);
              subContext.trigger?.focus();
              event.preventDefault();
            }
          })
        }
      ) }) }) });
    }
  );
  MenuSubContent.displayName = SUB_CONTENT_NAME;
  function getOpenState(open) {
    return open ? "open" : "closed";
  }
  function isIndeterminate(checked) {
    return checked === "indeterminate";
  }
  function getCheckedState(checked) {
    return isIndeterminate(checked) ? "indeterminate" : checked ? "checked" : "unchecked";
  }
  function focusFirst3(candidates) {
    const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
    for (const candidate of candidates) {
      if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
      candidate.focus();
      if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
    }
  }
  function wrapArray3(array, startIndex) {
    return array.map((_, index2) => array[(startIndex + index2) % array.length]);
  }
  function getNextMatch(values, search, currentMatch) {
    const isRepeated = search.length > 1 && Array.from(search).every((char) => char === search[0]);
    const normalizedSearch = isRepeated ? search[0] : search;
    const currentMatchIndex = currentMatch ? values.indexOf(currentMatch) : -1;
    let wrappedValues = wrapArray3(values, Math.max(currentMatchIndex, 0));
    const excludeCurrentMatch = normalizedSearch.length === 1;
    if (excludeCurrentMatch) wrappedValues = wrappedValues.filter((v) => v !== currentMatch);
    const nextMatch = wrappedValues.find(
      (value) => value.toLowerCase().startsWith(normalizedSearch.toLowerCase())
    );
    return nextMatch !== currentMatch ? nextMatch : void 0;
  }
  function isPointInPolygon(point, polygon) {
    const { x, y } = point;
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const ii = polygon[i];
      const jj = polygon[j];
      const xi = ii.x;
      const yi = ii.y;
      const xj = jj.x;
      const yj = jj.y;
      const intersect = yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi) + xi;
      if (intersect) inside = !inside;
    }
    return inside;
  }
  function isPointerInGraceArea(event, area) {
    if (!area) return false;
    const cursorPos = { x: event.clientX, y: event.clientY };
    return isPointInPolygon(cursorPos, area);
  }
  function whenMouse(handler) {
    return (event) => event.pointerType === "mouse" ? handler(event) : void 0;
  }
  var Root32 = Menu;
  var Anchor22 = MenuAnchor;
  var Portal3 = MenuPortal;
  var Content22 = MenuContent;
  var Group = MenuGroup;
  var Label = MenuLabel;
  var Item2 = MenuItem;
  var CheckboxItem = MenuCheckboxItem;
  var RadioGroup = MenuRadioGroup;
  var RadioItem = MenuRadioItem;
  var ItemIndicator = MenuItemIndicator;
  var Separator = MenuSeparator;
  var Arrow22 = MenuArrow;
  var Sub = MenuSub;
  var SubTrigger = MenuSubTrigger;
  var SubContent = MenuSubContent;

  // src/client/node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs
  var import_jsx_runtime17 = __toESM(require_react_shim(), 1);
  var DROPDOWN_MENU_NAME = "DropdownMenu";
  var [createDropdownMenuContext, createDropdownMenuScope] = createContextScope(
    DROPDOWN_MENU_NAME,
    [createMenuScope]
  );
  var useMenuScope = createMenuScope();
  var [DropdownMenuProvider, useDropdownMenuContext] = createDropdownMenuContext(DROPDOWN_MENU_NAME);
  var DropdownMenu = (props) => {
    const {
      __scopeDropdownMenu,
      children,
      dir,
      open: openProp,
      defaultOpen,
      onOpenChange,
      modal = true
    } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    const triggerRef = React38.useRef(null);
    const [open, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen ?? false,
      onChange: onOpenChange,
      caller: DROPDOWN_MENU_NAME
    });
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
      DropdownMenuProvider,
      {
        scope: __scopeDropdownMenu,
        triggerId: useId2(),
        triggerRef,
        contentId: useId2(),
        open,
        onOpenChange: setOpen,
        onOpenToggle: React38.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
        modal,
        children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Root32, { ...menuScope, open, onOpenChange: setOpen, dir, modal, children })
      }
    );
  };
  DropdownMenu.displayName = DROPDOWN_MENU_NAME;
  var TRIGGER_NAME4 = "DropdownMenuTrigger";
  var DropdownMenuTrigger = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, disabled = false, ...triggerProps } = props;
      const context = useDropdownMenuContext(TRIGGER_NAME4, __scopeDropdownMenu);
      const menuScope = useMenuScope(__scopeDropdownMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Anchor22, { asChild: true, ...menuScope, children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
        Primitive.button,
        {
          type: "button",
          id: context.triggerId,
          "aria-haspopup": "menu",
          "aria-expanded": context.open,
          "aria-controls": context.open ? context.contentId : void 0,
          "data-state": context.open ? "open" : "closed",
          "data-disabled": disabled ? "" : void 0,
          disabled,
          ...triggerProps,
          ref: composeRefs(forwardedRef, context.triggerRef),
          onPointerDown: composeEventHandlers(props.onPointerDown, (event) => {
            if (!disabled && event.button === 0 && event.ctrlKey === false) {
              context.onOpenToggle();
              if (!context.open) event.preventDefault();
            }
          }),
          onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
            if (disabled) return;
            if (["Enter", " "].includes(event.key)) context.onOpenToggle();
            if (event.key === "ArrowDown") context.onOpenChange(true);
            if (["Enter", " ", "ArrowDown"].includes(event.key)) event.preventDefault();
          })
        }
      ) });
    }
  );
  DropdownMenuTrigger.displayName = TRIGGER_NAME4;
  var PORTAL_NAME6 = "DropdownMenuPortal";
  var DropdownMenuPortal = (props) => {
    const { __scopeDropdownMenu, ...portalProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Portal3, { ...menuScope, ...portalProps });
  };
  DropdownMenuPortal.displayName = PORTAL_NAME6;
  var CONTENT_NAME6 = "DropdownMenuContent";
  var DropdownMenuContent = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, ...contentProps } = props;
      const context = useDropdownMenuContext(CONTENT_NAME6, __scopeDropdownMenu);
      const menuScope = useMenuScope(__scopeDropdownMenu);
      const hasInteractedOutsideRef = React38.useRef(false);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
        Content22,
        {
          id: context.contentId,
          "aria-labelledby": context.triggerId,
          ...menuScope,
          ...contentProps,
          ref: forwardedRef,
          onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
            if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
            hasInteractedOutsideRef.current = false;
            event.preventDefault();
          }),
          onInteractOutside: composeEventHandlers(props.onInteractOutside, (event) => {
            const originalEvent = event.detail.originalEvent;
            const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
            const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
            if (!context.modal || isRightClick) hasInteractedOutsideRef.current = true;
          }),
          style: {
            ...props.style,
            // re-namespace exposed content custom properties
            ...{
              "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
              "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
              "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
              "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
              "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
            }
          }
        }
      );
    }
  );
  DropdownMenuContent.displayName = CONTENT_NAME6;
  var GROUP_NAME4 = "DropdownMenuGroup";
  var DropdownMenuGroup = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, ...groupProps } = props;
      const menuScope = useMenuScope(__scopeDropdownMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Group, { ...menuScope, ...groupProps, ref: forwardedRef });
    }
  );
  DropdownMenuGroup.displayName = GROUP_NAME4;
  var LABEL_NAME3 = "DropdownMenuLabel";
  var DropdownMenuLabel = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, ...labelProps } = props;
      const menuScope = useMenuScope(__scopeDropdownMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Label, { ...menuScope, ...labelProps, ref: forwardedRef });
    }
  );
  DropdownMenuLabel.displayName = LABEL_NAME3;
  var ITEM_NAME4 = "DropdownMenuItem";
  var DropdownMenuItem = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, ...itemProps } = props;
      const menuScope = useMenuScope(__scopeDropdownMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Item2, { ...menuScope, ...itemProps, ref: forwardedRef });
    }
  );
  DropdownMenuItem.displayName = ITEM_NAME4;
  var CHECKBOX_ITEM_NAME2 = "DropdownMenuCheckboxItem";
  var DropdownMenuCheckboxItem = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...checkboxItemProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(CheckboxItem, { ...menuScope, ...checkboxItemProps, ref: forwardedRef });
  });
  DropdownMenuCheckboxItem.displayName = CHECKBOX_ITEM_NAME2;
  var RADIO_GROUP_NAME2 = "DropdownMenuRadioGroup";
  var DropdownMenuRadioGroup = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...radioGroupProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(RadioGroup, { ...menuScope, ...radioGroupProps, ref: forwardedRef });
  });
  DropdownMenuRadioGroup.displayName = RADIO_GROUP_NAME2;
  var RADIO_ITEM_NAME2 = "DropdownMenuRadioItem";
  var DropdownMenuRadioItem = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...radioItemProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(RadioItem, { ...menuScope, ...radioItemProps, ref: forwardedRef });
  });
  DropdownMenuRadioItem.displayName = RADIO_ITEM_NAME2;
  var INDICATOR_NAME = "DropdownMenuItemIndicator";
  var DropdownMenuItemIndicator = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...itemIndicatorProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(ItemIndicator, { ...menuScope, ...itemIndicatorProps, ref: forwardedRef });
  });
  DropdownMenuItemIndicator.displayName = INDICATOR_NAME;
  var SEPARATOR_NAME3 = "DropdownMenuSeparator";
  var DropdownMenuSeparator = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...separatorProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Separator, { ...menuScope, ...separatorProps, ref: forwardedRef });
  });
  DropdownMenuSeparator.displayName = SEPARATOR_NAME3;
  var ARROW_NAME5 = "DropdownMenuArrow";
  var DropdownMenuArrow = React38.forwardRef(
    (props, forwardedRef) => {
      const { __scopeDropdownMenu, ...arrowProps } = props;
      const menuScope = useMenuScope(__scopeDropdownMenu);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Arrow22, { ...menuScope, ...arrowProps, ref: forwardedRef });
    }
  );
  DropdownMenuArrow.displayName = ARROW_NAME5;
  var DropdownMenuSub = (props) => {
    const { __scopeDropdownMenu, children, open: openProp, onOpenChange, defaultOpen } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    const [open, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen ?? false,
      onChange: onOpenChange,
      caller: "DropdownMenuSub"
    });
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Sub, { ...menuScope, open, onOpenChange: setOpen, children });
  };
  var SUB_TRIGGER_NAME2 = "DropdownMenuSubTrigger";
  var DropdownMenuSubTrigger = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...subTriggerProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(SubTrigger, { ...menuScope, ...subTriggerProps, ref: forwardedRef });
  });
  DropdownMenuSubTrigger.displayName = SUB_TRIGGER_NAME2;
  var SUB_CONTENT_NAME2 = "DropdownMenuSubContent";
  var DropdownMenuSubContent = React38.forwardRef((props, forwardedRef) => {
    const { __scopeDropdownMenu, ...subContentProps } = props;
    const menuScope = useMenuScope(__scopeDropdownMenu);
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
      SubContent,
      {
        ...menuScope,
        ...subContentProps,
        ref: forwardedRef,
        style: {
          ...props.style,
          // re-namespace exposed content custom properties
          ...{
            "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
            "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
            "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
            "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
            "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
          }
        }
      }
    );
  });
  DropdownMenuSubContent.displayName = SUB_CONTENT_NAME2;
  var Root23 = DropdownMenu;
  var Trigger2 = DropdownMenuTrigger;
  var Portal22 = DropdownMenuPortal;
  var Content23 = DropdownMenuContent;
  var Item22 = DropdownMenuItem;
  var Separator2 = DropdownMenuSeparator;
  var Sub2 = DropdownMenuSub;
  var SubTrigger2 = DropdownMenuSubTrigger;
  var SubContent2 = DropdownMenuSubContent;

  // src/client/src/shared/ui/RowActionsMenu.tsx
  var itemCls = "flex items-center gap-2 px-3 py-1.5 text-sm cursor-pointer select-none outline-none data-[highlighted]:bg-base data-[disabled]:opacity-40 data-[disabled]:pointer-events-none";
  function Row({ action }) {
    const color = action.danger ? "text-danger" : action.active ? "text-brand" : "text-fg2";
    return /* @__PURE__ */ React.createElement(React.Fragment, null, action.icon && /* @__PURE__ */ React.createElement("span", { className: action.active ? "text-brand" : action.danger ? "text-danger" : "text-fg4" }, action.icon), /* @__PURE__ */ React.createElement("span", { className: `truncate ${color}` }, action.label), action.badge && /* @__PURE__ */ React.createElement("span", { className: "ml-auto text-caption text-fg4 tabular-nums" }, action.badge));
  }
  function renderAction(action) {
    if (action.submenu) {
      return /* @__PURE__ */ React.createElement(Sub2, { key: action.key }, /* @__PURE__ */ React.createElement(SubTrigger2, { className: itemCls, disabled: action.disabled }, /* @__PURE__ */ React.createElement(Row, { action }), /* @__PURE__ */ React.createElement(ChevronRight, { size: 13, className: "ml-auto text-fg4" })), /* @__PURE__ */ React.createElement(Portal22, null, /* @__PURE__ */ React.createElement(
        SubContent2,
        {
          className: "z-50 min-w-[10rem] max-h-72 overflow-auto rounded-md border border-stroke bg-surface py-1",
          style: { boxShadow: "var(--f-shadow28)" }
        },
        action.submenu.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "px-3 py-1.5 text-xs text-fg4" }, "\u041D\u0435\u0442 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u043E\u0432") : action.submenu.map((sub) => /* @__PURE__ */ React.createElement(
          Item22,
          {
            key: sub.key,
            className: itemCls,
            disabled: sub.disabled,
            onSelect: () => sub.onSelect?.()
          },
          /* @__PURE__ */ React.createElement(Row, { action: sub })
        ))
      )));
    }
    return /* @__PURE__ */ React.createElement(
      Item22,
      {
        key: action.key,
        className: itemCls,
        disabled: action.disabled,
        onSelect: () => action.onSelect?.()
      },
      /* @__PURE__ */ React.createElement(Row, { action })
    );
  }
  function RowActionsMenu({ actions, ariaLabel = "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F", hasActive }) {
    const normal = actions.filter((a) => !a.danger);
    const danger = actions.filter((a) => a.danger);
    return /* @__PURE__ */ React.createElement(Root23, null, /* @__PURE__ */ React.createElement(Trigger2, { asChild: true }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        "aria-label": ariaLabel,
        onClick: (e) => e.stopPropagation(),
        className: "relative p-1 rounded text-fg4 hover:text-fg1 hover:bg-base outline-none focus-visible:ring-2 focus-visible:ring-brand/40"
      },
      /* @__PURE__ */ React.createElement(EllipsisVertical, { size: 14 }),
      hasActive && /* @__PURE__ */ React.createElement("span", { className: "absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-brand" })
    )), /* @__PURE__ */ React.createElement(Portal22, null, /* @__PURE__ */ React.createElement(
      Content23,
      {
        align: "end",
        sideOffset: 4,
        onClick: (e) => e.stopPropagation(),
        className: "z-50 min-w-[11rem] rounded-md border border-stroke bg-surface py-1",
        style: { boxShadow: "var(--f-shadow28)" }
      },
      normal.map(renderAction),
      danger.length > 0 && normal.length > 0 && /* @__PURE__ */ React.createElement(Separator2, { className: "my-1 h-px bg-stroke" }),
      danger.map(renderAction)
    )));
  }

  // src/client/src/shared/ui/TypePicker.tsx
  init_define_import_meta_env();

  // src/client/src/shared/ui/typeIcons.ts
  init_define_import_meta_env();
  function typeIcon(t) {
    const s = `${t.name} ${t.code}`.toLowerCase();
    if (/организ|сро|надзор|подрядчик|заказчик/.test(s)) return Building2;
    if (/персон|фио|подписант/.test(s)) return User;
    if (/адрес|координат|объект строит/.test(s)) return MapPin;
    if (/работ/.test(s)) return Wrench;
    if (/материал/.test(s)) return Package;
    if (/единиц|измерен|угол|лаборатори/.test(s)) return Ruler;
    if (/период|срок|дата/.test(s)) return CalendarDays;
    if (t.section.toLowerCase().includes("\u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442")) return FileText;
    return Boxes;
  }

  // src/client/src/shared/ui/TypePicker.tsx
  var import_react17 = __toESM(require_react_shim(), 1);
  var RECENTS_CAP = 6;
  function TypePicker(props) {
    return props.open ? /* @__PURE__ */ React.createElement(TypePickerBody, { ...props }) : null;
  }
  function TypePickerBody({ onOpenChange, types, onSelect, recentKey, title = "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043F", noneOption, onSelectNone, aside }) {
    const [query, setQuery] = (0, import_react17.useState)("");
    const [active, setActive] = (0, import_react17.useState)(0);
    const [revealed, setRevealed] = (0, import_react17.useState)(false);
    const input = (0, import_react17.useRef)(null);
    const storeKey = recentKey ? `typepicker-recents:${recentKey}` : null;
    function loadRecents() {
      if (!storeKey) return [];
      try {
        return JSON.parse(localStorage.getItem(storeKey) || "[]");
      } catch {
        return [];
      }
    }
    function pushRecent(id) {
      if (!storeKey) return;
      const next = [id, ...loadRecents().filter((x) => x !== id)].slice(0, RECENTS_CAP);
      localStorage.setItem(storeKey, JSON.stringify(next));
    }
    const q = query.trim().toLowerCase();
    const sideOf = (t) => !!aside && !!t.aside;
    const asideShown = revealed || !!q;
    const asideHidden = !asideShown && types.some(sideOf);
    const sections = (0, import_react17.useMemo)(() => {
      const byName = (a, b) => a.name.localeCompare(b.name, "ru");
      const matches = (t) => `${t.name} ${t.code}`.toLowerCase().includes(q);
      const groups = [];
      if (!q) {
        const recents = loadRecents().map((id) => types.find((t) => t.id === id)).filter((t) => !!t && (asideShown || !sideOf(t)));
        if (recents.length) groups.push({ key: "recent", label: "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435", items: recents });
      }
      for (const side of [false, true]) {
        if (side && !asideShown) break;
        const order = [];
        const bySection = /* @__PURE__ */ new Map();
        for (const t of types) {
          if (sideOf(t) !== side || q && !matches(t)) continue;
          if (!bySection.has(t.section)) {
            bySection.set(t.section, []);
            order.push(t.section);
          }
          bySection.get(t.section).push(t);
        }
        order.forEach((s, i) => groups.push({
          key: `${side ? "aside" : "main"}:${s}`,
          label: s,
          items: bySection.get(s).slice().sort(byName),
          heading: side && i === 0 ? aside?.label : void 0
        }));
      }
      return groups;
    }, [types, q, asideShown, aside]);
    const flat = (0, import_react17.useMemo)(() => sections.flatMap((g) => g.items), [sections]);
    const noneVisible = !!noneOption && !q;
    const base = noneVisible ? 1 : 0;
    const total = base + flat.length;
    function choose(t) {
      pushRecent(t.id);
      onSelect(t.id);
      onOpenChange(false);
    }
    function chooseNone() {
      onSelectNone?.();
      onOpenChange(false);
    }
    function reveal() {
      setRevealed(true);
      input.current?.focus();
    }
    function onKey(e) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive((a) => Math.min(a + 1, total - 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive((a) => Math.max(a - 1, 0));
      } else if (e.key === "Enter") {
        e.preventDefault();
        if (noneVisible && active === 0) {
          chooseNone();
          return;
        }
        const t = flat[active - base];
        if (t) choose(t);
        else if (asideHidden) reveal();
      }
    }
    let idx = base - 1;
    return /* @__PURE__ */ React.createElement(Dialog, { open: true, onOpenChange }, /* @__PURE__ */ React.createElement(DialogPortal, null, /* @__PURE__ */ React.createElement(DialogOverlay, { className: "fixed inset-0 z-40 bg-black/40", style: { backdropFilter: "blur(2px)" } }), /* @__PURE__ */ React.createElement(
      DialogContent,
      {
        "data-modal-state": "free",
        className: "fixed left-1/2 top-16 z-50 w-[calc(100vw-2rem)] max-w-lg -translate-x-1/2 flex flex-col max-h-[calc(100vh-8rem)] overflow-hidden rounded-2xl border border-stroke bg-surface focus:outline-none",
        style: { boxShadow: "var(--f-shadow28)" }
      },
      /* @__PURE__ */ React.createElement(DialogTitle, { className: "sr-only" }, title),
      /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-2 border-b border-stroke px-4 shrink-0" }, /* @__PURE__ */ React.createElement(Search, { size: 16, className: "shrink-0 text-fg4" }), /* @__PURE__ */ React.createElement(
        "input",
        {
          ref: input,
          autoFocus: true,
          value: query,
          onChange: (e) => {
            setQuery(e.target.value);
            setActive(0);
          },
          onKeyDown: onKey,
          placeholder: "\u041F\u043E\u0438\u0441\u043A \u0442\u0438\u043F\u0430 \u043F\u043E \u0438\u043C\u0435\u043D\u0438 \u0438\u043B\u0438 \u043A\u043E\u0434\u0443\u2026",
          "aria-label": "\u041F\u043E\u0438\u0441\u043A \u0442\u0438\u043F\u0430",
          className: "h-12 flex-1 bg-transparent text-sm text-fg1 outline-none placeholder:text-fg4"
        }
      ), /* @__PURE__ */ React.createElement("kbd", { className: "rounded border border-stroke px-1 text-caption text-fg4" }, "Esc")),
      /* @__PURE__ */ React.createElement("ul", { className: "overflow-y-auto p-2", role: "listbox", "aria-label": title }, noneVisible && /* @__PURE__ */ React.createElement("li", { role: "option", "aria-selected": active === 0 }, /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onMouseEnter: () => setActive(0),
          onClick: chooseNone,
          className: `flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors ${active === 0 ? "bg-tonal text-on-tonal" : "text-fg1 hover:bg-black/5 dark:hover:bg-white/10"}`
        },
        /* @__PURE__ */ React.createElement(Ban, { size: 16, className: active === 0 ? "text-on-tonal" : "text-fg4" }),
        /* @__PURE__ */ React.createElement("span", { className: "flex-1 truncate", title: noneOption.label }, noneOption.label)
      )), flat.length === 0 ? !noneVisible && !asideHidden && /* @__PURE__ */ React.createElement("li", { className: "px-3 py-6 text-center text-sm text-fg4" }, "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E") : sections.map((g) => /* @__PURE__ */ React.createElement("li", { key: g.key }, g.heading && /* @__PURE__ */ React.createElement("div", { className: "mt-2 border-t border-stroke px-3 pt-3 pb-1 text-xs font-medium text-fg2" }, g.heading), /* @__PURE__ */ React.createElement("div", { className: "px-3 pt-2 pb-1 text-caption font-semibold uppercase tracking-wide text-fg4" }, g.label), /* @__PURE__ */ React.createElement("ul", null, g.items.map((t) => {
        const i = ++idx;
        const Icon2 = typeIcon(t);
        const code = t.code.trim();
        const showCode = !!code && code.toLowerCase() !== t.name.trim().toLowerCase();
        return /* @__PURE__ */ React.createElement("li", { key: `${g.key}:${t.id}`, role: "option", "aria-selected": i === active }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            onMouseEnter: () => setActive(i),
            onClick: () => choose(t),
            className: `flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors ${i === active ? "bg-tonal text-on-tonal" : "text-fg1 hover:bg-black/5 dark:hover:bg-white/10"}`
          },
          /* @__PURE__ */ React.createElement(Icon2, { size: 16, className: i === active ? "text-on-tonal" : "text-fg3" }),
          /* @__PURE__ */ React.createElement(Tooltip, { content: showCode ? `${t.name} (${code})` : t.name }, /* @__PURE__ */ React.createElement("span", { className: "flex-1 truncate" }, t.name)),
          showCode && /* @__PURE__ */ React.createElement("span", { className: `text-caption font-mono shrink-0 ${i === active ? "text-on-tonal/80" : "text-fg4"}` }, code)
        ));
      }))))),
      asideHidden && aside && /* @__PURE__ */ React.createElement("div", { className: "shrink-0 border-t border-stroke p-2" }, /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: reveal,
          className: "w-full rounded-lg px-3 py-2 text-left text-sm text-brand hover:bg-black/5 dark:hover:bg-white/10"
        },
        aside.reveal
      ))
    )));
  }

  // src/client/src/shared/ui/ListDetailShell.tsx
  init_define_import_meta_env();
  var import_react19 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/ui/listDetailView.ts
  init_define_import_meta_env();
  var import_react18 = __toESM(require_react_shim(), 1);
  function useListDetailView(addressed) {
    const [view, setView] = (0, import_react18.useState)(addressed ? "detail" : "list");
    const [seen, setSeen] = (0, import_react18.useState)(addressed);
    if (addressed !== seen) {
      setSeen(addressed);
      if (addressed) setView("detail");
    }
    return (0, import_react18.useMemo)(() => ({ view, showDetail: () => setView("detail"), showList: () => setView("list") }), [view]);
  }
  var ListDetailViewContext = (0, import_react18.createContext)(null);

  // src/client/src/shared/ui/PageHeader.tsx
  init_define_import_meta_env();
  function PageHeader({ title, subtitle, icon, badge, breadcrumb, actions, bar = false, className = "" }) {
    const plain = typeof title === "string";
    return /* @__PURE__ */ React.createElement("header", { className: `@container ${bar ? "shrink-0 px-6 py-3 border-b border-stroke " : ""}${className}` }, /* @__PURE__ */ React.createElement("div", { className: "flex flex-col gap-2 @2xl:flex-row @2xl:items-center @2xl:justify-between @2xl:gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "min-w-0 @2xl:flex-1 @2xl:min-w-48" }, breadcrumb && /* @__PURE__ */ React.createElement("div", { className: "mb-0.5" }, breadcrumb), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-2 min-w-0" }, icon && /* @__PURE__ */ React.createElement("span", { className: "flex text-fg3 shrink-0" }, icon), /* @__PURE__ */ React.createElement(Tooltip, { content: plain ? title : void 0 }, /* @__PURE__ */ React.createElement("h1", { className: `text-xl font-semibold text-fg1 min-w-0 ${plain ? "truncate" : ""}` }, title)), badge && /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap items-center gap-x-2 gap-y-1 min-w-0" }, badge)), subtitle && /* @__PURE__ */ React.createElement("div", { className: "text-xs text-fg3 mt-0.5" }, subtitle)), actions && /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap items-center gap-2 min-w-0 @2xl:justify-end" }, actions)));
  }

  // src/client/src/shared/ui/SearchInput.tsx
  init_define_import_meta_env();
  function SearchInput({
    value,
    onChange,
    placeholder = "\u041F\u043E\u0438\u0441\u043A\u2026",
    ariaLabel,
    className = "",
    rounded = "md",
    autoFocus
  }) {
    return /* @__PURE__ */ React.createElement("div", { className: "relative" }, /* @__PURE__ */ React.createElement(Search, { size: 15, className: "absolute left-3 top-1/2 -translate-y-1/2 text-fg4 pointer-events-none" }), /* @__PURE__ */ React.createElement(
      "input",
      {
        value,
        onChange: (e) => onChange(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Escape" && value) {
            e.preventDefault();
            e.stopPropagation();
            onChange("");
          }
        },
        placeholder,
        "aria-label": ariaLabel ?? "\u041F\u043E\u0438\u0441\u043A",
        autoFocus,
        "data-search": "",
        className: `w-full h-10 pl-9 pr-9 text-sm bg-surface border border-stroke-strong text-fg1 outline-none focus-visible:ring-2 focus-visible:ring-brand placeholder:text-fg4 ${rounded === "full" ? "rounded-full" : "rounded-md"} ${className}`
      }
    ), value && /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => onChange(""),
        "aria-label": "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u043F\u043E\u0438\u0441\u043A",
        className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-fg4 hover:text-fg2 transition-colors"
      },
      /* @__PURE__ */ React.createElement(X, { size: 15 })
    ));
  }

  // src/client/src/shared/ui/ListDetailShell.tsx
  var OWN_START = "own";
  var NAV_WIDE = { "w-80": "@2xl/ld:w-80", "w-64": "@2xl/ld:w-64" };
  function ListDetailShell({ overlay, nav, navWidth = "w-80", detail, view, backLabel, ...header }) {
    const own2 = useListDetailView(OWN_START);
    const current = view ?? own2;
    const onDetail = current.view === "detail";
    return /* @__PURE__ */ React.createElement("div", { className: "h-full flex flex-col @container/ld" }, /* @__PURE__ */ React.createElement(PageHeader, { bar: true, ...header }), overlay ?? /* @__PURE__ */ React.createElement(ListDetailViewContext.Provider, { value: current }, /* @__PURE__ */ React.createElement("div", { className: "flex-1 min-h-0 flex" }, /* @__PURE__ */ React.createElement(
      "nav",
      {
        "aria-label": header.title,
        "data-testid": "ld-nav",
        className: `w-full ${NAV_WIDE[navWidth]} shrink-0 @2xl/ld:border-r border-stroke flex flex-col bg-base ${onDetail ? "@max-2xl/ld:hidden" : ""}`
      },
      nav
    ), /* @__PURE__ */ React.createElement("div", { "data-testid": "ld-detail", className: `flex-1 min-w-0 min-h-0 flex flex-col ${onDetail ? "" : "@max-2xl/ld:hidden"}` }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: current.showList,
        className: "@2xl/ld:hidden shrink-0 flex items-center gap-2 h-11 px-4 border-b border-stroke text-sm font-medium text-brand hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand"
      },
      /* @__PURE__ */ React.createElement(ArrowLeft, { size: 16, className: "shrink-0" }),
      backLabel ?? "\u041A \u0441\u043F\u0438\u0441\u043A\u0443"
    ), /* @__PURE__ */ React.createElement("div", { className: "flex-1 min-h-0 flex" }, detail)))));
  }
  function NavSearchInput({ value, onChange, placeholder = "\u041F\u043E\u0438\u0441\u043A\u2026" }) {
    return /* @__PURE__ */ React.createElement("div", { className: "p-3 shrink-0" }, /* @__PURE__ */ React.createElement(SearchInput, { value, onChange, placeholder, rounded: "full" }));
  }
  function NavSection({ label }) {
    return /* @__PURE__ */ React.createElement("div", { className: "px-3 pt-3 pb-1 text-caption font-semibold uppercase tracking-wide text-fg4" }, label);
  }
  function NavItem({ icon, label, count: count3, active, chevron, filter: filter2, onClick, alert, alertDanger, progress, progressTitle }) {
    const highlight = active && !chevron;
    const view = (0, import_react19.useContext)(ListDetailViewContext);
    return /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => {
          if (!chevron && !filter2) view?.showDetail();
          onClick();
        },
        "aria-current": active ? "true" : void 0,
        className: `w-full flex items-center gap-2.5 px-3 h-11 rounded-full text-left transition-colors ${highlight ? "bg-brand-subtle text-brand-hover font-medium" : "text-fg2 hover:bg-muted"}`
      },
      /* @__PURE__ */ React.createElement("span", { className: `shrink-0 ${highlight ? "text-brand-hover" : "text-fg4"}` }, icon),
      /* @__PURE__ */ React.createElement("span", { className: "flex-1 truncate text-sm" }, label),
      progress != null && /* @__PURE__ */ React.createElement(Tooltip, { content: progressTitle ?? `\u0413\u043E\u0442\u043E\u0432\u043D\u043E\u0441\u0442\u044C \u043F\u043E \u043F\u043B\u0430\u043D\u0443: ${progress}%` }, /* @__PURE__ */ React.createElement(
        "span",
        {
          className: `text-caption px-1.5 py-0.5 rounded-full shrink-0 tabular-nums ${progress === 100 ? "bg-brand-subtle text-brand" : "bg-muted text-fg3"}`
        },
        progress,
        "%"
      )),
      alert != null && alert > 0 && /* @__PURE__ */ React.createElement(Tooltip, { content: `\u0422\u0440\u0435\u0431\u0443\u0435\u0442 \u0440\u0430\u0437\u0431\u043E\u0440\u0430: ${alert}` }, /* @__PURE__ */ React.createElement(
        "span",
        {
          className: `text-caption px-1.5 py-0.5 rounded-full shrink-0 ${alertDanger ? "bg-danger-subtle text-danger" : "bg-warning-subtle text-warning"}`
        },
        alert > 99 ? "99+" : alert
      )),
      chevron ? /* @__PURE__ */ React.createElement(React.Fragment, null, count3 != null && /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4 shrink-0" }, count3), /* @__PURE__ */ React.createElement(ChevronRight, { size: 14, className: "shrink-0 text-fg4" })) : count3 != null && count3 > 0 && /* @__PURE__ */ React.createElement("span", { className: `text-caption px-1.5 py-0.5 rounded-full shrink-0 ${highlight ? "bg-white/50 text-brand-hover" : "bg-brand-subtle text-brand"}` }, count3)
    );
  }
  function DetailTitle({ children }) {
    return /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-normal text-fg1 truncate min-w-0", title: children }, children);
  }
  function DetailHeader({ heading, dirty, saving, onSaveAll, onRevert, actions }) {
    return /* @__PURE__ */ React.createElement("div", { className: "shrink-0 px-6 py-4 border-b border-stroke bg-surface" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-start gap-3" }, /* @__PURE__ */ React.createElement("div", { className: "min-w-0 flex-1" }, heading), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-1.5 shrink-0" }, dirty && /* @__PURE__ */ React.createElement("span", { className: "text-xs px-2 py-0.5 rounded-full font-medium bg-warning-subtle text-warning" }, "\u0435\u0441\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F"), onRevert && /* @__PURE__ */ React.createElement(Button, { variant: "text", size: "sm", disabled: !dirty || saving, onClick: onRevert }, "\u041E\u0442\u043C\u0435\u043D\u0430"), /* @__PURE__ */ React.createElement(
      Button,
      {
        variant: "filled",
        size: "sm",
        disabled: !dirty,
        loading: saving,
        onClick: () => {
          onSaveAll().catch(() => {
          });
        }
      },
      "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C"
    ), actions)));
  }

  // src/client/src/shared/ui/EmptyState.tsx
  init_define_import_meta_env();
  function EmptyState({
    icon,
    title,
    description,
    action,
    className = ""
  }) {
    return /* @__PURE__ */ React.createElement("div", { className: `flex flex-col items-center gap-4 rounded-2xl border border-dashed border-stroke px-6 py-12 text-center ${className}` }, /* @__PURE__ */ React.createElement("div", { className: "flex h-16 w-16 items-center justify-center rounded-full bg-tonal text-on-tonal" }, icon), /* @__PURE__ */ React.createElement("div", { className: "space-y-1" }, /* @__PURE__ */ React.createElement("h3", { className: "text-base font-medium text-fg1" }, title), description && /* @__PURE__ */ React.createElement("p", { className: "mx-auto max-w-sm text-sm text-fg3" }, description)), action && /* @__PURE__ */ React.createElement("div", { className: "pt-1" }, action));
  }

  // src/client/src/shared/ui/ShortcutsHelp.tsx
  init_define_import_meta_env();
  var SHORTCUTS = [
    ["Ctrl / \u2318 + K", "\u041A\u043E\u043C\u0430\u043D\u0434\u043D\u0430\u044F \u043F\u0430\u043B\u0438\u0442\u0440\u0430 \u2014 \u043F\u0435\u0440\u0435\u0445\u043E\u0434 \u043A \u0440\u0430\u0437\u0434\u0435\u043B\u0430\u043C \u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F"],
    ["?", "\u042D\u0442\u0430 \u0441\u043F\u0440\u0430\u0432\u043A\u0430 \u043F\u043E \u0433\u043E\u0440\u044F\u0447\u0438\u043C \u043A\u043B\u0430\u0432\u0438\u0448\u0430\u043C"],
    ["\u2191 \u2193 + Enter", "\u041D\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044F \u043F\u043E \u0441\u043F\u0438\u0441\u043A\u0430\u043C \u0438 \u043F\u0438\u043A\u0435\u0440\u0430\u043C (\u043F\u0430\u043B\u0438\u0442\u0440\u0430, \u0432\u044B\u0431\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430)"],
    ["\u2190 \u2192", "\u041F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0432\u043A\u043B\u0430\u0434\u043E\u043A \u0432 \u0440\u0435\u0434\u0430\u043A\u0442\u043E\u0440\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430"],
    ["Esc", "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0430\u043B\u0438\u0442\u0440\u0443, \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0438\u043B\u0438 \u043F\u0443\u0441\u0442\u043E\u0439 \u0434\u0438\u0430\u043B\u043E\u0433; \u0432 \u0444\u043E\u0440\u043C\u0435 \u0441 \u043D\u0430\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u2014 \u043F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u043A\u043D\u043E\u043F\u043A\u0435 \u0432\u044B\u0445\u043E\u0434\u0430"],
    ["Tab", "\u041F\u0435\u0440\u0435\u0445\u043E\u0434 \u043C\u0435\u0436\u0434\u0443 \u043F\u043E\u043B\u044F\u043C\u0438 \u0444\u043E\u0440\u043C\u044B"]
  ];
  function ShortcutsHelp({ open, onOpenChange }) {
    return /* @__PURE__ */ React.createElement(Modal, { open, onOpenChange, title: "\u0413\u043E\u0440\u044F\u0447\u0438\u0435 \u043A\u043B\u0430\u0432\u0438\u0448\u0438", nothingToLose: true }, /* @__PURE__ */ React.createElement("div", { className: "divide-y divide-muted" }, SHORTCUTS.map(([keys, desc]) => /* @__PURE__ */ React.createElement("div", { key: keys, className: "flex items-center gap-4 py-2" }, /* @__PURE__ */ React.createElement("kbd", { className: "min-w-[120px] shrink-0 rounded bg-muted px-2 py-1 text-center text-xs font-medium text-fg2" }, keys), /* @__PURE__ */ React.createElement("span", { className: "text-sm text-fg2" }, desc)))));
  }

  // src/client/src/shared/ui/Avatar.tsx
  init_define_import_meta_env();

  // src/client/src/shared/ui/avatarHelpers.ts
  init_define_import_meta_env();
  function initialsOf(name, email) {
    const src = (name || email || "").trim();
    const parts = src.split(/\s+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return src.slice(0, 2).toUpperCase();
  }
  function downscaleToDataUri(file, maxPx = 256, quality = 0.85) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => {
        try {
          const side = Math.min(image.width, image.height);
          const sx = (image.width - side) / 2;
          const sy = (image.height - side) / 2;
          const target = Math.min(maxPx, side);
          const canvas = document.createElement("canvas");
          canvas.width = target;
          canvas.height = target;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            reject(new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435"));
            return;
          }
          ctx.drawImage(image, sx, sy, side, side, 0, 0, target, target);
          resolve(canvas.toDataURL("image/jpeg", quality));
        } catch (e) {
          reject(e instanceof Error ? e : new Error("\u041E\u0448\u0438\u0431\u043A\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F"));
        } finally {
          URL.revokeObjectURL(url);
        }
      };
      image.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435"));
      };
      image.src = url;
    });
  }

  // src/client/src/shared/ui/Avatar.tsx
  function Avatar({ src, name, email, className = "w-10 h-10 text-base", alt = "" }) {
    const base = `inline-flex items-center justify-center rounded-full shrink-0 overflow-hidden ${className}`;
    if (src) {
      return /* @__PURE__ */ React.createElement("span", { className: base }, /* @__PURE__ */ React.createElement("img", { src, alt, className: "w-full h-full object-cover" }));
    }
    return /* @__PURE__ */ React.createElement("span", { className: `${base} bg-brand-subtle text-on-brand-subtle font-medium` }, initialsOf(name, email));
  }

  // src/client/src/shared/ui/TypePickerField.tsx
  init_define_import_meta_env();
  var import_react20 = __toESM(require_react_shim(), 1);
  function TypePickerField({
    types,
    value,
    onChange,
    recentKey,
    title = "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043F",
    placeholder = "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0442\u0438\u043F",
    size: size4 = "md",
    label,
    required,
    clearable,
    disabled,
    className = "",
    "aria-label": ariaLabel
  }) {
    const [open, setOpen] = (0, import_react20.useState)(false);
    const [focused, setFocused] = (0, import_react20.useState)(false);
    const triggerRef = (0, import_react20.useRef)(null);
    const labelId = (0, import_react20.useId)();
    const selected = value ? types.find((t) => t.id === value) : void 0;
    const icon = selected ? typeIcon(selected) : Boxes;
    const code = selected?.code.trim();
    const framed = label !== void 0;
    const showCode = framed && !!code && code.toLowerCase() !== selected.name.trim().toLowerCase();
    const showClear = !!clearable && !!selected && !disabled;
    const triggerClass = framed ? `w-full h-14 px-4 rounded-md bg-transparent text-sm text-left outline-none disabled:opacity-50 disabled:pointer-events-none` : `w-full ${size4 === "sm" ? "h-8" : "h-9"} px-3 rounded-md border border-stroke-strong bg-surface text-sm text-left transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-brand data-[state=open]:ring-2 disabled:opacity-50 disabled:pointer-events-none`;
    const trigger = /* @__PURE__ */ React.createElement(
      "button",
      {
        ref: triggerRef,
        type: "button",
        disabled,
        onClick: () => setOpen(true),
        "aria-haspopup": "dialog",
        "aria-expanded": open,
        "aria-label": framed ? void 0 : ariaLabel,
        "aria-labelledby": framed ? required ? `${labelId} ${labelId}-required` : labelId : void 0,
        className: `inline-flex items-center gap-2 overflow-hidden ${triggerClass}`,
        "data-state": open ? "open" : "closed"
      },
      (0, import_react20.createElement)(icon, { size: 16, className: `shrink-0 ${selected ? "text-fg3" : "text-fg4"}` }),
      /* @__PURE__ */ React.createElement(Tooltip, { content: selected ? showCode ? `${selected.name} (${code})` : selected.name : void 0 }, /* @__PURE__ */ React.createElement("span", { className: `flex-1 truncate ${selected ? "text-fg1" : "text-fg4"}` }, selected ? selected.name : placeholder)),
      showCode && /* @__PURE__ */ React.createElement("span", { className: "text-caption font-mono text-fg4 shrink-0" }, code),
      showClear && /* @__PURE__ */ React.createElement("span", { "aria-hidden": true, className: "w-[22px] shrink-0" }),
      /* @__PURE__ */ React.createElement(Search, { size: 15, className: "shrink-0 text-fg4" })
    );
    const clear = showClear && /* @__PURE__ */ React.createElement(Tooltip, { content: "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        "aria-label": "\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C",
        onClick: () => {
          onChange(null);
          triggerRef.current?.focus();
        },
        className: `absolute ${framed ? "right-10" : "right-9"} top-1/2 -translate-y-1/2 z-10 text-fg4 opacity-0 pointer-events-none transition-opacity hover:text-fg2 group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:opacity-100 group-focus-within:pointer-events-auto [@media(pointer:coarse)]:opacity-100 [@media(pointer:coarse)]:pointer-events-auto focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand rounded-sm`
      },
      /* @__PURE__ */ React.createElement(X, { size: 14 })
    ));
    const body = /* @__PURE__ */ React.createElement(
      "div",
      {
        className: "relative flex w-full",
        onFocus: () => setFocused(true),
        onBlur: (e) => {
          if (!e.currentTarget.contains(e.relatedTarget)) setFocused(false);
        }
      },
      trigger,
      clear,
      framed && required && /* @__PURE__ */ React.createElement("span", { id: `${labelId}-required`, className: "sr-only" }, "\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435")
    );
    return /* @__PURE__ */ React.createElement(React.Fragment, null, framed ? /* @__PURE__ */ React.createElement(
      OutlinedField,
      {
        label,
        required,
        raise: "always",
        focused,
        labelId,
        containerClassName: `group ${className}`
      },
      body
    ) : /* @__PURE__ */ React.createElement("div", { className: `group ${className}` }, body), /* @__PURE__ */ React.createElement(
      TypePicker,
      {
        open,
        onOpenChange: setOpen,
        title,
        recentKey,
        types,
        onSelect: (id) => onChange(id),
        noneOption: clearable,
        onSelectNone: clearable ? () => onChange(null) : void 0
      }
    ));
  }

  // src/client/src/shared/ui/TextAreaField.tsx
  init_define_import_meta_env();
  var import_react21 = __toESM(require_react_shim(), 1);
  var TextAreaField = (0, import_react21.forwardRef)(function TextAreaField2({
    label,
    error,
    invalid,
    hint,
    className = "",
    containerClassName = "",
    id,
    required,
    rows = 3,
    onFocus,
    onBlur,
    ...rest
  }, ref) {
    const [focused, setFocused] = (0, import_react21.useState)(false);
    const autoId = (0, import_react21.useId)();
    const areaId = id ?? autoId;
    return /* @__PURE__ */ React.createElement(
      OutlinedField,
      {
        label,
        required,
        invalid,
        error,
        hint,
        raise: "always",
        focused,
        readOnly: rest.readOnly,
        htmlFor: areaId,
        containerClassName
      },
      /* @__PURE__ */ React.createElement("div", { className: "pt-4" }, /* @__PURE__ */ React.createElement(
        "textarea",
        {
          ref,
          id: areaId,
          required,
          rows,
          className: `block w-full rounded-md bg-transparent px-4 pb-2 text-sm text-fg1 outline-none disabled:opacity-50 ${className}`,
          onFocus: (e) => {
            setFocused(true);
            onFocus?.(e);
          },
          onBlur: (e) => {
            setFocused(false);
            onBlur?.(e);
          },
          ...rest
        }
      ))
    );
  });

  // src/client/src/shared/ui/ValueIssue.tsx
  init_define_import_meta_env();
  function ValueIssueHint({ messages, compact }) {
    if (!messages?.length) return null;
    return /* @__PURE__ */ React.createElement("p", { className: `${compact ? "text-caption mt-0.5" : "text-xs mt-1"} text-warning flex items-start gap-1` }, /* @__PURE__ */ React.createElement(TriangleAlert, { size: compact ? 11 : 12, className: "shrink-0 mt-[3px]" }), /* @__PURE__ */ React.createElement("span", null, messages.join(" ")));
  }
  function ValueIssueBadge({ count: count3, className = "" }) {
    if (count3 <= 0) return null;
    return /* @__PURE__ */ React.createElement(Tooltip, { content: `\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043D\u0435 \u043F\u043E \u0442\u0438\u043F\u0443: ${count3}` }, /* @__PURE__ */ React.createElement(
      "span",
      {
        className: `inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-warning-subtle text-warning border border-warning-border text-caption font-semibold leading-none ${className}`
      },
      count3
    ));
  }

  // src/client/src/shared/ui/ScopeIcon.tsx
  init_define_import_meta_env();

  // src/client/src/shared/api/types.ts
  init_define_import_meta_env();
  var SCOPE_LABELS = {
    Set: "\u041A\u043E\u043C\u043F\u043B\u0435\u043A\u0442",
    Section: "\u0420\u0430\u0437\u0434\u0435\u043B",
    Construction: "\u0421\u0442\u0440\u043E\u0439\u043A\u0430",
    System: "\u0421\u0438\u0441\u0442\u0435\u043C\u0430"
  };

  // src/client/src/shared/ui/ScopeIcon.tsx
  var SCOPE_ICONS = {
    Set: FolderOpen,
    Section: Layers,
    Construction: Building2,
    System: Boxes
  };
  function ScopeIcon({ scope, size: size4 = 13, className = "", title }) {
    const Icon2 = SCOPE_ICONS[scope];
    const label = title ?? `\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u0441\u0432\u044F\u0437\u0438: ${SCOPE_LABELS[scope]}`;
    return /* @__PURE__ */ React.createElement(Tooltip, { content: label }, /* @__PURE__ */ React.createElement(
      "span",
      {
        "aria-label": label,
        role: "img",
        className: `inline-flex items-center shrink-0 text-fg4 ${className}`
      },
      /* @__PURE__ */ React.createElement(Icon2, { size: size4 })
    ));
  }

  // src/client/src/shared/ui/MoveButtons.tsx
  init_define_import_meta_env();
  function MoveButtons({
    onUp,
    onDown,
    isFirst,
    isLast,
    busy = false,
    size: size4 = 12,
    className = "",
    upTitle = "\u0412\u044B\u0448\u0435",
    downTitle = "\u041D\u0438\u0436\u0435"
  }) {
    const cls = `p-0.5 text-fg4 hover:text-fg2 aria-disabled:opacity-25 aria-disabled:hover:text-fg4 ${className}`;
    const upBlocked = isFirst || busy;
    const downBlocked = isLast || busy;
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Tooltip, { content: upTitle, name: true }, /* @__PURE__ */ React.createElement("button", { type: "button", onClick: () => {
      if (!upBlocked) onUp();
    }, "aria-disabled": upBlocked, className: cls }, /* @__PURE__ */ React.createElement(ArrowUp, { size: size4 }))), /* @__PURE__ */ React.createElement(Tooltip, { content: downTitle, name: true }, /* @__PURE__ */ React.createElement("button", { type: "button", onClick: () => {
      if (!downBlocked) onDown();
    }, "aria-disabled": downBlocked, className: cls }, /* @__PURE__ */ React.createElement(ArrowDown, { size: size4 }))));
  }

  // src/client/src/shared/ui/Toast.ts
  init_define_import_meta_env();
  var import_react22 = __toESM(require_react_shim(), 1);
  var ToastCtx = (0, import_react22.createContext)(null);
  function useToast() {
    const ctx = (0, import_react22.useContext)(ToastCtx);
    if (!ctx) throw new Error("useToast \u0434\u043E\u043B\u0436\u0435\u043D \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u0432\u043D\u0443\u0442\u0440\u0438 ToastProvider");
    return ctx;
  }

  // src/client/src/shared/ui/Markdown.tsx
  init_define_import_meta_env();
  var INLINE = /(\*\*[^*]+\*\*|__[^_]+__|\*[^*\n]+\*|_[^_\n]+_|`[^`]+`|\[[^\]]+\]\([^)]+\))/g;
  function safeHref(url) {
    return /^(https?:|mailto:)/i.test(url.trim()) ? url.trim() : void 0;
  }
  function inline3(text, kp) {
    const out = [];
    let last = 0;
    let m;
    let i = 0;
    INLINE.lastIndex = 0;
    while ((m = INLINE.exec(text)) !== null) {
      if (m.index > last) out.push(text.slice(last, m.index));
      const tok = m[0];
      const k = `${kp}-${i++}`;
      if (tok.startsWith("**") || tok.startsWith("__")) out.push(/* @__PURE__ */ React.createElement("strong", { key: k }, tok.slice(2, -2)));
      else if (tok.startsWith("`")) out.push(
        /* @__PURE__ */ React.createElement("code", { key: k, className: "font-mono bg-muted text-fg1 px-1 rounded text-[0.9em]" }, tok.slice(1, -1))
      );
      else if (tok.startsWith("[")) {
        const mm = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(tok);
        const href = safeHref(mm[2]);
        out.push(href ? /* @__PURE__ */ React.createElement("a", { key: k, href, target: "_blank", rel: "noreferrer", className: "text-brand hover:text-brand-hover underline" }, mm[1]) : mm[1]);
      } else out.push(/* @__PURE__ */ React.createElement("em", { key: k }, tok.slice(1, -1)));
      last = m.index + tok.length;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
  }
  function Markdown({ children, className = "" }) {
    const lines = children.replace(/\r\n/g, "\n").split("\n");
    const out = [];
    let para = [];
    let list = null;
    let k = 0;
    const flushPara = () => {
      if (!para.length) return;
      const p = para;
      const key = `p${k++}`;
      out.push(/* @__PURE__ */ React.createElement("p", { key }, p.flatMap((l, i) => i === 0 ? inline3(l, `${key}-${i}`) : [/* @__PURE__ */ React.createElement("br", { key: `br${i}` }), ...inline3(l, `${key}-${i}`)])));
      para = [];
    };
    const flushList = () => {
      if (!list) return;
      const { ordered, items } = list;
      const key = `l${k++}`;
      out.push(ordered ? /* @__PURE__ */ React.createElement("ol", { key, className: "list-decimal pl-5 space-y-0.5" }, items.map((t, i) => /* @__PURE__ */ React.createElement("li", { key: i }, inline3(t, `${key}-${i}`)))) : /* @__PURE__ */ React.createElement("ul", { key, className: "list-disc pl-5 space-y-0.5" }, items.map((t, i) => /* @__PURE__ */ React.createElement("li", { key: i }, inline3(t, `${key}-${i}`)))));
      list = null;
    };
    for (const line of lines) {
      if (line.trim() === "") {
        flushPara();
        flushList();
        continue;
      }
      const h = /^(#{1,3})\s+(.*)$/.exec(line);
      const ul = /^[-*]\s+(.*)$/.exec(line);
      const ol = /^\d+\.\s+(.*)$/.exec(line);
      if (h) {
        flushPara();
        flushList();
        const lvl = h[1].length;
        const cls = lvl === 1 ? "text-base font-semibold text-fg1" : lvl === 2 ? "text-sm font-semibold text-fg1" : "text-sm font-medium text-fg1";
        out.push(/* @__PURE__ */ React.createElement("p", { key: `h${k++}`, className: cls }, inline3(h[2], `h${k}`)));
      } else if (ul) {
        flushPara();
        if (list && !list.ordered) list.items.push(ul[1]);
        else {
          flushList();
          list = { ordered: false, items: [ul[1]] };
        }
      } else if (ol) {
        flushPara();
        if (list && list.ordered) list.items.push(ol[1]);
        else {
          flushList();
          list = { ordered: true, items: [ol[1]] };
        }
      } else {
        flushList();
        para.push(line);
      }
    }
    flushPara();
    flushList();
    return /* @__PURE__ */ React.createElement("div", { className: `text-sm text-fg2 space-y-2 leading-relaxed ${className}` }, out);
  }

  // src/client/src/features/settings/FieldBuilder.tsx
  init_define_import_meta_env();
  var import_react24 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/api/schema.ts
  init_define_import_meta_env();

  // src/client/src/shared/api/tags.ts
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/react-query/build/modern/index.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/index.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/focusManager.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/subscribable.js
  init_define_import_meta_env();
  var Subscribable = class {
    constructor() {
      this.listeners = /* @__PURE__ */ new Set();
      this.subscribe = this.subscribe.bind(this);
    }
    subscribe(listener) {
      this.listeners.add(listener);
      this.onSubscribe();
      return () => {
        this.listeners.delete(listener);
        this.onUnsubscribe();
      };
    }
    hasListeners() {
      return this.listeners.size > 0;
    }
    onSubscribe() {
    }
    onUnsubscribe() {
    }
  };

  // src/client/node_modules/@tanstack/query-core/build/modern/focusManager.js
  var _focused, _cleanup, _setup, _a;
  var FocusManager = (_a = class extends Subscribable {
    constructor() {
      super();
      __privateAdd(this, _focused);
      __privateAdd(this, _cleanup);
      __privateAdd(this, _setup);
      __privateSet(this, _setup, (onFocus) => {
        if (typeof window !== "undefined" && window.addEventListener) {
          const listener = () => onFocus();
          window.addEventListener("visibilitychange", listener, false);
          return () => {
            window.removeEventListener("visibilitychange", listener);
          };
        }
        return;
      });
    }
    onSubscribe() {
      if (!__privateGet(this, _cleanup)) {
        this.setEventListener(__privateGet(this, _setup));
      }
    }
    onUnsubscribe() {
      var _a6;
      if (!this.hasListeners()) {
        (_a6 = __privateGet(this, _cleanup)) == null ? void 0 : _a6.call(this);
        __privateSet(this, _cleanup, void 0);
      }
    }
    setEventListener(setup) {
      var _a6;
      __privateSet(this, _setup, setup);
      (_a6 = __privateGet(this, _cleanup)) == null ? void 0 : _a6.call(this);
      __privateSet(this, _cleanup, setup((focused) => {
        if (typeof focused === "boolean") {
          this.setFocused(focused);
        } else {
          this.onFocus();
        }
      }));
    }
    setFocused(focused) {
      const changed = __privateGet(this, _focused) !== focused;
      if (changed) {
        __privateSet(this, _focused, focused);
        this.onFocus();
      }
    }
    onFocus() {
      const isFocused = this.isFocused();
      this.listeners.forEach((listener) => {
        listener(isFocused);
      });
    }
    isFocused() {
      if (typeof __privateGet(this, _focused) === "boolean") {
        return __privateGet(this, _focused);
      }
      return globalThis.document?.visibilityState !== "hidden";
    }
  }, _focused = new WeakMap(), _cleanup = new WeakMap(), _setup = new WeakMap(), _a);
  var focusManager = new FocusManager();

  // src/client/node_modules/@tanstack/query-core/build/modern/environmentManager.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/utils.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/timeoutManager.js
  init_define_import_meta_env();
  var defaultTimeoutProvider = {
    // We need the wrapper function syntax below instead of direct references to
    // global setTimeout etc.
    //
    // BAD: `setTimeout: setTimeout`
    // GOOD: `setTimeout: (cb, delay) => setTimeout(cb, delay)`
    //
    // If we use direct references here, then anything that wants to spy on or
    // replace the global setTimeout (like tests) won't work since we'll already
    // have a hard reference to the original implementation at the time when this
    // file was imported.
    setTimeout: (callback, delay) => setTimeout(callback, delay),
    clearTimeout: (timeoutId) => clearTimeout(timeoutId),
    setInterval: (callback, delay) => setInterval(callback, delay),
    clearInterval: (intervalId) => clearInterval(intervalId)
  };
  var _provider, _providerCalled, _a2;
  var TimeoutManager = (_a2 = class {
    constructor() {
      // We cannot have TimeoutManager<T> as we must instantiate it with a concrete
      // type at app boot; and if we leave that type, then any new timer provider
      // would need to support the default provider's concrete timer ID, which is
      // infeasible across environments.
      //
      // We settle for type safety for the TimeoutProvider type, and accept that
      // this class is unsafe internally to allow for extension.
      __privateAdd(this, _provider, defaultTimeoutProvider);
      __privateAdd(this, _providerCalled, false);
    }
    setTimeoutProvider(provider) {
      if (true) {
        if (__privateGet(this, _providerCalled) && provider !== __privateGet(this, _provider)) {
          console.error(
            `[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`,
            { previous: __privateGet(this, _provider), provider }
          );
        }
      }
      __privateSet(this, _provider, provider);
      if (true) {
        __privateSet(this, _providerCalled, false);
      }
    }
    setTimeout(callback, delay) {
      if (true) {
        __privateSet(this, _providerCalled, true);
      }
      return __privateGet(this, _provider).setTimeout(callback, delay);
    }
    clearTimeout(timeoutId) {
      __privateGet(this, _provider).clearTimeout(timeoutId);
    }
    setInterval(callback, delay) {
      if (true) {
        __privateSet(this, _providerCalled, true);
      }
      return __privateGet(this, _provider).setInterval(callback, delay);
    }
    clearInterval(intervalId) {
      __privateGet(this, _provider).clearInterval(intervalId);
    }
  }, _provider = new WeakMap(), _providerCalled = new WeakMap(), _a2);
  var timeoutManager = new TimeoutManager();
  function systemSetTimeoutZero(callback) {
    setTimeout(callback, 0);
  }

  // src/client/node_modules/@tanstack/query-core/build/modern/utils.js
  var isServer = typeof window === "undefined" || "Deno" in globalThis;
  function noop3() {
  }
  function isValidTimeout(value) {
    return typeof value === "number" && value >= 0 && value !== Infinity;
  }
  function timeUntilStale(updatedAt, staleTime) {
    return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
  }
  function resolveStaleTime(staleTime, query) {
    return typeof staleTime === "function" ? staleTime(query) : staleTime;
  }
  function resolveQueryBoolean(option, query) {
    return typeof option === "function" ? option(query) : option;
  }
  var hasOwn = Object.prototype.hasOwnProperty;
  function replaceEqualDeep(a, b, depth = 0) {
    if (a === b) {
      return a;
    }
    if (depth > 500) return b;
    const array = isPlainArray(a) && isPlainArray(b);
    if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
    const aItems = array ? a : Object.keys(a);
    const aSize = aItems.length;
    const bItems = array ? b : Object.keys(b);
    const bSize = bItems.length;
    const copy = array ? new Array(bSize) : {};
    let equalItems = 0;
    for (let i = 0; i < bSize; i++) {
      const key = array ? i : bItems[i];
      const aItem = a[key];
      const bItem = b[key];
      if (aItem === bItem) {
        copy[key] = aItem;
        if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
        continue;
      }
      if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
        copy[key] = bItem;
        continue;
      }
      const v = replaceEqualDeep(aItem, bItem, depth + 1);
      copy[key] = v;
      if (v === aItem) equalItems++;
    }
    return aSize === bSize && equalItems === aSize ? a : copy;
  }
  function shallowEqualObjects(a, b) {
    if (!b || Object.keys(a).length !== Object.keys(b).length) {
      return false;
    }
    for (const key in a) {
      if (a[key] !== b[key]) {
        return false;
      }
    }
    return true;
  }
  function isPlainArray(value) {
    return Array.isArray(value) && value.length === Object.keys(value).length;
  }
  function isPlainObject(o) {
    if (!hasObjectPrototype(o)) {
      return false;
    }
    const ctor = o.constructor;
    if (ctor === void 0) {
      return true;
    }
    const prot = ctor.prototype;
    if (!hasObjectPrototype(prot)) {
      return false;
    }
    if (!prot.hasOwnProperty("isPrototypeOf")) {
      return false;
    }
    if (Object.getPrototypeOf(o) !== Object.prototype) {
      return false;
    }
    return true;
  }
  function hasObjectPrototype(o) {
    return Object.prototype.toString.call(o) === "[object Object]";
  }
  function replaceData(prevData, data, options2) {
    if (typeof options2.structuralSharing === "function") {
      return options2.structuralSharing(prevData, data);
    } else if (options2.structuralSharing !== false) {
      if (true) {
        try {
          return replaceEqualDeep(prevData, data);
        } catch (error) {
          console.error(
            `Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options2.queryHash}]: ${error}`
          );
          throw error;
        }
      }
      return replaceEqualDeep(prevData, data);
    }
    return data;
  }
  function shouldThrowError(throwOnError, params) {
    if (typeof throwOnError === "function") {
      return throwOnError(...params);
    }
    return !!throwOnError;
  }

  // src/client/node_modules/@tanstack/query-core/build/modern/environmentManager.js
  var environmentManager = /* @__PURE__ */ (() => {
    let isServerFn = () => isServer;
    return {
      /**
       * Returns whether the current runtime should be treated as a server environment.
       */
      isServer() {
        return isServerFn();
      },
      /**
       * Overrides the server check globally.
       */
      setIsServer(isServerValue) {
        isServerFn = isServerValue;
      }
    };
  })();

  // src/client/node_modules/@tanstack/query-core/build/modern/thenable.js
  init_define_import_meta_env();
  function pendingThenable() {
    let resolve;
    let reject;
    const thenable = new Promise((_resolve, _reject) => {
      resolve = _resolve;
      reject = _reject;
    });
    thenable.status = "pending";
    thenable.catch(() => {
    });
    function finalize(data) {
      Object.assign(thenable, data);
      delete thenable.resolve;
      delete thenable.reject;
    }
    thenable.resolve = (value) => {
      finalize({
        status: "fulfilled",
        value
      });
      resolve(value);
    };
    thenable.reject = (reason) => {
      finalize({
        status: "rejected",
        reason
      });
      reject(reason);
    };
    return thenable;
  }

  // src/client/node_modules/@tanstack/query-core/build/modern/queryObserver.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/notifyManager.js
  init_define_import_meta_env();
  var defaultScheduler = systemSetTimeoutZero;
  function createNotifyManager() {
    let queue = [];
    let transactions = 0;
    let notifyFn = (callback) => {
      callback();
    };
    let batchNotifyFn = (callback) => {
      callback();
    };
    let scheduleFn = defaultScheduler;
    const schedule = (callback) => {
      if (transactions) {
        queue.push(callback);
      } else {
        scheduleFn(() => {
          notifyFn(callback);
        });
      }
    };
    const flush = () => {
      const originalQueue = queue;
      queue = [];
      if (originalQueue.length) {
        scheduleFn(() => {
          batchNotifyFn(() => {
            originalQueue.forEach((callback) => {
              notifyFn(callback);
            });
          });
        });
      }
    };
    return {
      batch: (callback) => {
        let result;
        transactions++;
        try {
          result = callback();
        } finally {
          transactions--;
          if (!transactions) {
            flush();
          }
        }
        return result;
      },
      /**
       * All calls to the wrapped function will be batched.
       */
      batchCalls: (callback) => {
        return (...args) => {
          schedule(() => {
            callback(...args);
          });
        };
      },
      schedule,
      /**
       * Use this method to set a custom notify function.
       * This can be used to for example wrap notifications with `React.act` while running tests.
       */
      setNotifyFunction: (fn) => {
        notifyFn = fn;
      },
      /**
       * Use this method to set a custom function to batch notifications together into a single tick.
       * By default React Query will use the batch function provided by ReactDOM or React Native.
       */
      setBatchNotifyFunction: (fn) => {
        batchNotifyFn = fn;
      },
      setScheduler: (fn) => {
        scheduleFn = fn;
      }
    };
  }
  var notifyManager = createNotifyManager();

  // src/client/node_modules/@tanstack/query-core/build/modern/query.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/retryer.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/query-core/build/modern/onlineManager.js
  init_define_import_meta_env();
  var _online, _cleanup2, _setup2, _a3;
  var OnlineManager = (_a3 = class extends Subscribable {
    constructor() {
      super();
      __privateAdd(this, _online, true);
      __privateAdd(this, _cleanup2);
      __privateAdd(this, _setup2);
      __privateSet(this, _setup2, (onOnline) => {
        if (typeof window !== "undefined" && window.addEventListener) {
          const onlineListener = () => onOnline(true);
          const offlineListener = () => onOnline(false);
          window.addEventListener("online", onlineListener, false);
          window.addEventListener("offline", offlineListener, false);
          return () => {
            window.removeEventListener("online", onlineListener);
            window.removeEventListener("offline", offlineListener);
          };
        }
        return;
      });
    }
    onSubscribe() {
      if (!__privateGet(this, _cleanup2)) {
        this.setEventListener(__privateGet(this, _setup2));
      }
    }
    onUnsubscribe() {
      var _a6;
      if (!this.hasListeners()) {
        (_a6 = __privateGet(this, _cleanup2)) == null ? void 0 : _a6.call(this);
        __privateSet(this, _cleanup2, void 0);
      }
    }
    setEventListener(setup) {
      var _a6;
      __privateSet(this, _setup2, setup);
      (_a6 = __privateGet(this, _cleanup2)) == null ? void 0 : _a6.call(this);
      __privateSet(this, _cleanup2, setup(this.setOnline.bind(this)));
    }
    setOnline(online) {
      const changed = __privateGet(this, _online) !== online;
      if (changed) {
        __privateSet(this, _online, online);
        this.listeners.forEach((listener) => {
          listener(online);
        });
      }
    }
    isOnline() {
      return __privateGet(this, _online);
    }
  }, _online = new WeakMap(), _cleanup2 = new WeakMap(), _setup2 = new WeakMap(), _a3);
  var onlineManager = new OnlineManager();

  // src/client/node_modules/@tanstack/query-core/build/modern/retryer.js
  function canFetch(networkMode) {
    return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
  }

  // src/client/node_modules/@tanstack/query-core/build/modern/query.js
  function fetchState(data, options2) {
    return {
      fetchFailureCount: 0,
      fetchFailureReason: null,
      fetchStatus: canFetch(options2.networkMode) ? "fetching" : "paused",
      ...data === void 0 && {
        error: null,
        status: "pending"
      }
    };
  }

  // src/client/node_modules/@tanstack/query-core/build/modern/queryObserver.js
  var _client, _currentQuery, _currentQueryInitialState, _currentResult, _currentResultState, _currentResultOptions, _currentThenable, _selectError, _selectFn, _selectResult, _lastQueryWithDefinedData, _staleTimeoutId, _refetchIntervalId, _currentRefetchInterval, _trackedProps, _QueryObserver_instances, executeFetch_fn, updateStaleTimeout_fn, computeRefetchInterval_fn, updateRefetchInterval_fn, updateTimers_fn, clearStaleTimeout_fn, clearRefetchInterval_fn, updateQuery_fn, notify_fn, _a4;
  var QueryObserver = (_a4 = class extends Subscribable {
    constructor(client, options2) {
      super();
      __privateAdd(this, _QueryObserver_instances);
      __privateAdd(this, _client);
      __privateAdd(this, _currentQuery);
      __privateAdd(this, _currentQueryInitialState);
      __privateAdd(this, _currentResult);
      __privateAdd(this, _currentResultState);
      __privateAdd(this, _currentResultOptions);
      __privateAdd(this, _currentThenable);
      __privateAdd(this, _selectError);
      __privateAdd(this, _selectFn);
      __privateAdd(this, _selectResult);
      // This property keeps track of the last query with defined data.
      // It will be used to pass the previous data and query to the placeholder function between renders.
      __privateAdd(this, _lastQueryWithDefinedData);
      __privateAdd(this, _staleTimeoutId);
      __privateAdd(this, _refetchIntervalId);
      __privateAdd(this, _currentRefetchInterval);
      __privateAdd(this, _trackedProps, /* @__PURE__ */ new Set());
      this.options = options2;
      __privateSet(this, _client, client);
      __privateSet(this, _selectError, null);
      __privateSet(this, _currentThenable, pendingThenable());
      this.bindMethods();
      this.setOptions(options2);
    }
    bindMethods() {
      this.refetch = this.refetch.bind(this);
    }
    onSubscribe() {
      if (this.listeners.size === 1) {
        __privateGet(this, _currentQuery).addObserver(this);
        if (shouldFetchOnMount(__privateGet(this, _currentQuery), this.options)) {
          __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
        } else {
          this.updateResult();
        }
        __privateMethod(this, _QueryObserver_instances, updateTimers_fn).call(this);
      }
    }
    onUnsubscribe() {
      if (!this.hasListeners()) {
        this.destroy();
      }
    }
    shouldFetchOnReconnect() {
      return shouldFetchOn(
        __privateGet(this, _currentQuery),
        this.options,
        this.options.refetchOnReconnect
      );
    }
    shouldFetchOnWindowFocus() {
      return shouldFetchOn(
        __privateGet(this, _currentQuery),
        this.options,
        this.options.refetchOnWindowFocus
      );
    }
    destroy() {
      this.listeners = /* @__PURE__ */ new Set();
      __privateMethod(this, _QueryObserver_instances, clearStaleTimeout_fn).call(this);
      __privateMethod(this, _QueryObserver_instances, clearRefetchInterval_fn).call(this);
      __privateGet(this, _currentQuery).removeObserver(this);
    }
    setOptions(options2) {
      const prevOptions = this.options;
      const prevQuery = __privateGet(this, _currentQuery);
      this.options = __privateGet(this, _client).defaultQueryOptions(options2);
      if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryBoolean(this.options.enabled, __privateGet(this, _currentQuery)) !== "boolean") {
        throw new Error(
          "Expected enabled to be a boolean or a callback that returns a boolean"
        );
      }
      __privateMethod(this, _QueryObserver_instances, updateQuery_fn).call(this);
      __privateGet(this, _currentQuery).setOptions(this.options);
      if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) {
        __privateGet(this, _client).getQueryCache().notify({
          type: "observerOptionsUpdated",
          query: __privateGet(this, _currentQuery),
          observer: this
        });
      }
      const mounted = this.hasListeners();
      if (mounted && shouldFetchOptionally(
        __privateGet(this, _currentQuery),
        prevQuery,
        this.options,
        prevOptions
      )) {
        __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
      }
      this.updateResult();
      if (mounted && (__privateGet(this, _currentQuery) !== prevQuery || resolveQueryBoolean(this.options.enabled, __privateGet(this, _currentQuery)) !== resolveQueryBoolean(prevOptions.enabled, __privateGet(this, _currentQuery)) || resolveStaleTime(this.options.staleTime, __privateGet(this, _currentQuery)) !== resolveStaleTime(prevOptions.staleTime, __privateGet(this, _currentQuery)))) {
        __privateMethod(this, _QueryObserver_instances, updateStaleTimeout_fn).call(this);
      }
      const nextRefetchInterval = __privateMethod(this, _QueryObserver_instances, computeRefetchInterval_fn).call(this);
      if (mounted && (__privateGet(this, _currentQuery) !== prevQuery || resolveQueryBoolean(this.options.enabled, __privateGet(this, _currentQuery)) !== resolveQueryBoolean(prevOptions.enabled, __privateGet(this, _currentQuery)) || nextRefetchInterval !== __privateGet(this, _currentRefetchInterval))) {
        __privateMethod(this, _QueryObserver_instances, updateRefetchInterval_fn).call(this, nextRefetchInterval);
      }
    }
    getOptimisticResult(options2) {
      const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), options2);
      const result = this.createResult(query, options2);
      if (shouldAssignObserverCurrentProperties(this, result)) {
        __privateSet(this, _currentResult, result);
        __privateSet(this, _currentResultOptions, this.options);
        __privateSet(this, _currentResultState, __privateGet(this, _currentQuery).state);
      }
      return result;
    }
    getCurrentResult() {
      return __privateGet(this, _currentResult);
    }
    trackResult(result, onPropTracked) {
      return new Proxy(result, {
        get: (target, key) => {
          this.trackProp(key);
          onPropTracked?.(key);
          if (key === "promise") {
            this.trackProp("data");
            if (!this.options.experimental_prefetchInRender && __privateGet(this, _currentThenable).status === "pending") {
              __privateGet(this, _currentThenable).reject(
                new Error(
                  "experimental_prefetchInRender feature flag is not enabled"
                )
              );
            }
          }
          return Reflect.get(target, key);
        }
      });
    }
    trackProp(key) {
      __privateGet(this, _trackedProps).add(key);
    }
    getCurrentQuery() {
      return __privateGet(this, _currentQuery);
    }
    refetch({ ...options2 } = {}) {
      return this.fetch({
        ...options2
      });
    }
    fetchOptimistic(options2) {
      const defaultedOptions = __privateGet(this, _client).defaultQueryOptions(options2);
      const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), defaultedOptions);
      return query.fetch().then(() => this.createResult(query, defaultedOptions));
    }
    fetch(fetchOptions) {
      return __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this, {
        ...fetchOptions,
        cancelRefetch: fetchOptions.cancelRefetch ?? true
      }).then(() => {
        this.updateResult();
        return __privateGet(this, _currentResult);
      });
    }
    createResult(query, options2) {
      const prevQuery = __privateGet(this, _currentQuery);
      const prevOptions = this.options;
      const prevResult = __privateGet(this, _currentResult);
      const prevResultState = __privateGet(this, _currentResultState);
      const prevResultOptions = __privateGet(this, _currentResultOptions);
      const queryChange = query !== prevQuery;
      const queryInitialState = queryChange ? query.state : __privateGet(this, _currentQueryInitialState);
      const { state } = query;
      let newState = { ...state };
      let isPlaceholderData = false;
      let data;
      if (options2._optimisticResults) {
        const mounted = this.hasListeners();
        const fetchOnMount = !mounted && shouldFetchOnMount(query, options2);
        const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options2, prevOptions);
        if (fetchOnMount || fetchOptionally) {
          newState = {
            ...newState,
            ...fetchState(state.data, query.options)
          };
        }
        if (options2._optimisticResults === "isRestoring") {
          newState.fetchStatus = "idle";
        }
      }
      let { error, errorUpdatedAt, status } = newState;
      data = newState.data;
      let skipSelect = false;
      if (options2.placeholderData !== void 0 && data === void 0 && status === "pending") {
        let placeholderData;
        if (prevResult?.isPlaceholderData && options2.placeholderData === prevResultOptions?.placeholderData) {
          placeholderData = prevResult.data;
          skipSelect = true;
        } else {
          placeholderData = typeof options2.placeholderData === "function" ? options2.placeholderData(
            __privateGet(this, _lastQueryWithDefinedData)?.state.data,
            __privateGet(this, _lastQueryWithDefinedData)
          ) : options2.placeholderData;
        }
        if (placeholderData !== void 0) {
          status = "success";
          data = replaceData(
            prevResult?.data,
            placeholderData,
            options2
          );
          isPlaceholderData = true;
        }
      }
      if (options2.select && data !== void 0 && !skipSelect) {
        if (prevResult && data === prevResultState?.data && options2.select === __privateGet(this, _selectFn)) {
          data = __privateGet(this, _selectResult);
        } else {
          try {
            __privateSet(this, _selectFn, options2.select);
            data = options2.select(data);
            data = replaceData(prevResult?.data, data, options2);
            __privateSet(this, _selectResult, data);
            __privateSet(this, _selectError, null);
          } catch (selectError) {
            __privateSet(this, _selectError, selectError);
          }
        }
      }
      if (__privateGet(this, _selectError)) {
        error = __privateGet(this, _selectError);
        data = __privateGet(this, _selectResult);
        errorUpdatedAt = Date.now();
        status = "error";
      }
      const isFetching = newState.fetchStatus === "fetching";
      const isPending = status === "pending";
      const isError = status === "error";
      const isLoading = isPending && isFetching;
      const hasData = data !== void 0;
      const result = {
        status,
        fetchStatus: newState.fetchStatus,
        isPending,
        isSuccess: status === "success",
        isError,
        isInitialLoading: isLoading,
        isLoading,
        data,
        dataUpdatedAt: newState.dataUpdatedAt,
        error,
        errorUpdatedAt,
        failureCount: newState.fetchFailureCount,
        failureReason: newState.fetchFailureReason,
        errorUpdateCount: newState.errorUpdateCount,
        isFetched: query.isFetched(),
        isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
        isFetching,
        isRefetching: isFetching && !isPending,
        isLoadingError: isError && !hasData,
        isPaused: newState.fetchStatus === "paused",
        isPlaceholderData,
        isRefetchError: isError && hasData,
        isStale: isStale(query, options2),
        refetch: this.refetch,
        promise: __privateGet(this, _currentThenable),
        isEnabled: resolveQueryBoolean(options2.enabled, query) !== false
      };
      const nextResult = result;
      if (this.options.experimental_prefetchInRender) {
        const hasResultData = nextResult.data !== void 0;
        const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
        const finalizeThenableIfPossible = (thenable) => {
          if (isErrorWithoutData) {
            thenable.reject(nextResult.error);
          } else if (hasResultData) {
            thenable.resolve(nextResult.data);
          }
        };
        const recreateThenable = () => {
          const pending = __privateSet(this, _currentThenable, nextResult.promise = pendingThenable());
          finalizeThenableIfPossible(pending);
        };
        const prevThenable = __privateGet(this, _currentThenable);
        switch (prevThenable.status) {
          case "pending":
            if (query.queryHash === prevQuery.queryHash) {
              finalizeThenableIfPossible(prevThenable);
            }
            break;
          case "fulfilled":
            if (isErrorWithoutData || nextResult.data !== prevThenable.value) {
              recreateThenable();
            }
            break;
          case "rejected":
            if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) {
              recreateThenable();
            }
            break;
        }
      }
      return nextResult;
    }
    updateResult() {
      const prevResult = __privateGet(this, _currentResult);
      const nextResult = this.createResult(__privateGet(this, _currentQuery), this.options);
      __privateSet(this, _currentResultState, __privateGet(this, _currentQuery).state);
      __privateSet(this, _currentResultOptions, this.options);
      if (__privateGet(this, _currentResultState).data !== void 0) {
        __privateSet(this, _lastQueryWithDefinedData, __privateGet(this, _currentQuery));
      }
      if (shallowEqualObjects(nextResult, prevResult)) {
        return;
      }
      __privateSet(this, _currentResult, nextResult);
      const shouldNotifyListeners = () => {
        if (!prevResult) {
          return true;
        }
        const { notifyOnChangeProps } = this.options;
        const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
        if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !__privateGet(this, _trackedProps).size) {
          return true;
        }
        const includedProps = new Set(
          notifyOnChangePropsValue ?? __privateGet(this, _trackedProps)
        );
        if (this.options.throwOnError) {
          includedProps.add("error");
        }
        return Object.keys(__privateGet(this, _currentResult)).some((key) => {
          const typedKey = key;
          const changed = __privateGet(this, _currentResult)[typedKey] !== prevResult[typedKey];
          return changed && includedProps.has(typedKey);
        });
      };
      __privateMethod(this, _QueryObserver_instances, notify_fn).call(this, { listeners: shouldNotifyListeners() });
    }
    onQueryUpdate() {
      this.updateResult();
      if (this.hasListeners()) {
        __privateMethod(this, _QueryObserver_instances, updateTimers_fn).call(this);
      }
    }
  }, _client = new WeakMap(), _currentQuery = new WeakMap(), _currentQueryInitialState = new WeakMap(), _currentResult = new WeakMap(), _currentResultState = new WeakMap(), _currentResultOptions = new WeakMap(), _currentThenable = new WeakMap(), _selectError = new WeakMap(), _selectFn = new WeakMap(), _selectResult = new WeakMap(), _lastQueryWithDefinedData = new WeakMap(), _staleTimeoutId = new WeakMap(), _refetchIntervalId = new WeakMap(), _currentRefetchInterval = new WeakMap(), _trackedProps = new WeakMap(), _QueryObserver_instances = new WeakSet(), executeFetch_fn = function(fetchOptions) {
    __privateMethod(this, _QueryObserver_instances, updateQuery_fn).call(this);
    let promise = __privateGet(this, _currentQuery).fetch(
      this.options,
      fetchOptions
    );
    if (!fetchOptions?.throwOnError) {
      promise = promise.catch(noop3);
    }
    return promise;
  }, updateStaleTimeout_fn = function() {
    __privateMethod(this, _QueryObserver_instances, clearStaleTimeout_fn).call(this);
    const staleTime = resolveStaleTime(
      this.options.staleTime,
      __privateGet(this, _currentQuery)
    );
    if (environmentManager.isServer() || __privateGet(this, _currentResult).isStale || !isValidTimeout(staleTime)) {
      return;
    }
    const time = timeUntilStale(__privateGet(this, _currentResult).dataUpdatedAt, staleTime);
    const timeout = time + 1;
    __privateSet(this, _staleTimeoutId, timeoutManager.setTimeout(() => {
      if (!__privateGet(this, _currentResult).isStale) {
        this.updateResult();
      }
    }, timeout));
  }, computeRefetchInterval_fn = function() {
    return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(__privateGet(this, _currentQuery)) : this.options.refetchInterval) ?? false;
  }, updateRefetchInterval_fn = function(nextInterval) {
    __privateMethod(this, _QueryObserver_instances, clearRefetchInterval_fn).call(this);
    __privateSet(this, _currentRefetchInterval, nextInterval);
    if (environmentManager.isServer() || resolveQueryBoolean(this.options.enabled, __privateGet(this, _currentQuery)) === false || !isValidTimeout(__privateGet(this, _currentRefetchInterval)) || __privateGet(this, _currentRefetchInterval) === 0) {
      return;
    }
    __privateSet(this, _refetchIntervalId, timeoutManager.setInterval(() => {
      if (this.options.refetchIntervalInBackground || focusManager.isFocused()) {
        __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
      }
    }, __privateGet(this, _currentRefetchInterval)));
  }, updateTimers_fn = function() {
    __privateMethod(this, _QueryObserver_instances, updateStaleTimeout_fn).call(this);
    __privateMethod(this, _QueryObserver_instances, updateRefetchInterval_fn).call(this, __privateMethod(this, _QueryObserver_instances, computeRefetchInterval_fn).call(this));
  }, clearStaleTimeout_fn = function() {
    if (__privateGet(this, _staleTimeoutId) !== void 0) {
      timeoutManager.clearTimeout(__privateGet(this, _staleTimeoutId));
      __privateSet(this, _staleTimeoutId, void 0);
    }
  }, clearRefetchInterval_fn = function() {
    if (__privateGet(this, _refetchIntervalId) !== void 0) {
      timeoutManager.clearInterval(__privateGet(this, _refetchIntervalId));
      __privateSet(this, _refetchIntervalId, void 0);
    }
  }, updateQuery_fn = function() {
    const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), this.options);
    if (query === __privateGet(this, _currentQuery)) {
      return;
    }
    const prevQuery = __privateGet(this, _currentQuery);
    __privateSet(this, _currentQuery, query);
    __privateSet(this, _currentQueryInitialState, query.state);
    if (this.hasListeners()) {
      prevQuery?.removeObserver(this);
      query.addObserver(this);
    }
  }, notify_fn = function(notifyOptions) {
    notifyManager.batch(() => {
      if (notifyOptions.listeners) {
        this.listeners.forEach((listener) => {
          listener(__privateGet(this, _currentResult));
        });
      }
      __privateGet(this, _client).getQueryCache().notify({
        query: __privateGet(this, _currentQuery),
        type: "observerResultsUpdated"
      });
    });
  }, _a4);
  function shouldLoadOnMount(query, options2) {
    return resolveQueryBoolean(options2.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryBoolean(options2.retryOnMount, query) === false);
  }
  function shouldFetchOnMount(query, options2) {
    return shouldLoadOnMount(query, options2) || query.state.data !== void 0 && shouldFetchOn(query, options2, options2.refetchOnMount);
  }
  function shouldFetchOn(query, options2, field) {
    if (resolveQueryBoolean(options2.enabled, query) !== false && resolveStaleTime(options2.staleTime, query) !== "static") {
      const value = typeof field === "function" ? field(query) : field;
      return value === "always" || value !== false && isStale(query, options2);
    }
    return false;
  }
  function shouldFetchOptionally(query, prevQuery, options2, prevOptions) {
    return (query !== prevQuery || resolveQueryBoolean(prevOptions.enabled, query) === false) && (!options2.suspense || query.state.status !== "error") && isStale(query, options2);
  }
  function isStale(query, options2) {
    return resolveQueryBoolean(options2.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options2.staleTime, query));
  }
  function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
    if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) {
      return true;
    }
    return false;
  }

  // src/client/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
  init_define_import_meta_env();
  var React39 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime18 = __toESM(require_react_shim(), 1);
  var QueryClientContext = React39.createContext(
    void 0
  );
  var useQueryClient = (queryClient) => {
    const client = React39.useContext(QueryClientContext);
    if (queryClient) {
      return queryClient;
    }
    if (!client) {
      throw new Error("No QueryClient set, use QueryClientProvider to set one");
    }
    return client;
  };

  // src/client/node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
  init_define_import_meta_env();
  var React40 = __toESM(require_react_shim(), 1);
  var IsRestoringContext = React40.createContext(false);
  var useIsRestoring = () => React40.useContext(IsRestoringContext);
  var IsRestoringProvider = IsRestoringContext.Provider;

  // src/client/node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
  init_define_import_meta_env();
  var React41 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime19 = __toESM(require_react_shim(), 1);
  function createValue() {
    let isReset = false;
    return {
      clearReset: () => {
        isReset = false;
      },
      reset: () => {
        isReset = true;
      },
      isReset: () => {
        return isReset;
      }
    };
  }
  var QueryErrorResetBoundaryContext = React41.createContext(createValue());
  var useQueryErrorResetBoundary = () => React41.useContext(QueryErrorResetBoundaryContext);

  // src/client/node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
  init_define_import_meta_env();
  var React42 = __toESM(require_react_shim(), 1);
  var ensurePreventErrorBoundaryRetry = (options2, errorResetBoundary, query) => {
    const throwOnError = query?.state.error && typeof options2.throwOnError === "function" ? shouldThrowError(options2.throwOnError, [query.state.error, query]) : options2.throwOnError;
    if (options2.suspense || options2.experimental_prefetchInRender || throwOnError) {
      if (!errorResetBoundary.isReset()) {
        options2.retryOnMount = false;
      }
    }
  };
  var useClearResetErrorBoundary = (errorResetBoundary) => {
    React42.useEffect(() => {
      errorResetBoundary.clearReset();
    }, [errorResetBoundary]);
  };
  var getHasError = ({
    result,
    errorResetBoundary,
    throwOnError,
    query,
    suspense
  }) => {
    return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
  };

  // src/client/node_modules/@tanstack/react-query/build/modern/suspense.js
  init_define_import_meta_env();
  var ensureSuspenseTimers = (defaultedOptions) => {
    if (defaultedOptions.suspense) {
      const MIN_SUSPENSE_TIME_MS = 1e3;
      const clamp3 = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
      const originalStaleTime = defaultedOptions.staleTime;
      defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp3(originalStaleTime(...args)) : clamp3(originalStaleTime);
      if (typeof defaultedOptions.gcTime === "number") {
        defaultedOptions.gcTime = Math.max(
          defaultedOptions.gcTime,
          MIN_SUSPENSE_TIME_MS
        );
      }
    }
  };
  var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
  var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
  var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
    errorResetBoundary.clearReset();
  });

  // src/client/node_modules/@tanstack/react-query/build/modern/useQuery.js
  init_define_import_meta_env();

  // src/client/node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
  init_define_import_meta_env();
  var React43 = __toESM(require_react_shim(), 1);
  function useBaseQuery(options2, Observer, queryClient) {
    if (true) {
      if (typeof options2 !== "object" || Array.isArray(options2)) {
        throw new Error(
          'Bad argument type. Starting with v5, only the "Object" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object'
        );
      }
    }
    const isRestoring = useIsRestoring();
    const errorResetBoundary = useQueryErrorResetBoundary();
    const client = useQueryClient(queryClient);
    const defaultedOptions = client.defaultQueryOptions(options2);
    client.getDefaultOptions().queries?._experimental_beforeQuery?.(
      defaultedOptions
    );
    const query = client.getQueryCache().get(defaultedOptions.queryHash);
    if (true) {
      if (!defaultedOptions.queryFn) {
        console.error(
          `[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`
        );
      }
    }
    const subscribed = options2.subscribed !== false;
    defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
    ensureSuspenseTimers(defaultedOptions);
    ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
    useClearResetErrorBoundary(errorResetBoundary);
    const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
    const [observer] = React43.useState(
      () => new Observer(
        client,
        defaultedOptions
      )
    );
    const result = observer.getOptimisticResult(defaultedOptions);
    const shouldSubscribe = !isRestoring && subscribed;
    React43.useSyncExternalStore(
      React43.useCallback(
        (onStoreChange) => {
          const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop3;
          observer.updateResult();
          return unsubscribe;
        },
        [observer, shouldSubscribe]
      ),
      () => observer.getCurrentResult(),
      () => observer.getCurrentResult()
    );
    React43.useEffect(() => {
      observer.setOptions(defaultedOptions);
    }, [defaultedOptions, observer]);
    if (shouldSuspend(defaultedOptions, result)) {
      throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
    }
    if (getHasError({
      result,
      errorResetBoundary,
      throwOnError: defaultedOptions.throwOnError,
      query,
      suspense: defaultedOptions.suspense
    })) {
      throw result.error;
    }
    ;
    client.getDefaultOptions().queries?._experimental_afterQuery?.(
      defaultedOptions,
      result
    );
    if (defaultedOptions.experimental_prefetchInRender && !environmentManager.isServer() && willFetch(result, isRestoring)) {
      const promise = isNewCacheEntry ? (
        // Fetch immediately on render in order to ensure `.promise` is resolved even if the component is unmounted
        fetchOptimistic(defaultedOptions, observer, errorResetBoundary)
      ) : (
        // subscribe to the "cache promise" so that we can finalize the currentThenable once data comes in
        query?.promise
      );
      promise?.catch(noop3).finally(() => {
        observer.updateResult();
      });
    }
    return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
  }

  // src/client/node_modules/@tanstack/react-query/build/modern/useQuery.js
  function useQuery(options2, queryClient) {
    return useBaseQuery(options2, QueryObserver, queryClient);
  }

  // src/client/src/shared/api/client.ts
  init_define_import_meta_env();

  // src/client/node_modules/axios/index.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/axios.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/utils.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/bind.js
  init_define_import_meta_env();
  function bind(fn, thisArg) {
    return function wrap() {
      return fn.apply(thisArg, arguments);
    };
  }

  // src/client/node_modules/axios/lib/utils.js
  var { toString } = Object.prototype;
  var { getPrototypeOf } = Object;
  var { iterator, toStringTag } = Symbol;
  var hasOwnProperty = (({ hasOwnProperty: hasOwnProperty2 }) => (obj, prop) => hasOwnProperty2.call(obj, prop))(Object.prototype);
  var hasOwnInPrototypeChain = (thing, prop) => {
    let obj = thing;
    const seen = [];
    while (obj != null && obj !== Object.prototype) {
      if (seen.indexOf(obj) !== -1) {
        return false;
      }
      seen.push(obj);
      if (hasOwnProperty(obj, prop)) {
        return true;
      }
      obj = getPrototypeOf(obj);
    }
    return false;
  };
  var getSafeProp = (obj, prop) => obj != null && hasOwnInPrototypeChain(obj, prop) ? obj[prop] : void 0;
  var kindOf = /* @__PURE__ */ ((cache) => (thing) => {
    const str = toString.call(thing);
    return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null));
  var kindOfTest = (type) => {
    type = type.toLowerCase();
    return (thing) => kindOf(thing) === type;
  };
  var typeOfTest = (type) => (thing) => typeof thing === type;
  var { isArray } = Array;
  var isUndefined = typeOfTest("undefined");
  function isBuffer(val) {
    return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction3(val.constructor.isBuffer) && val.constructor.isBuffer(val);
  }
  var isArrayBuffer = kindOfTest("ArrayBuffer");
  function isArrayBufferView(val) {
    let result;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      result = ArrayBuffer.isView(val);
    } else {
      result = val && val.buffer && isArrayBuffer(val.buffer);
    }
    return result;
  }
  var isString = typeOfTest("string");
  var isFunction3 = typeOfTest("function");
  var isNumber = typeOfTest("number");
  var isObject = (thing) => thing !== null && typeof thing === "object";
  var isBoolean = (thing) => thing === true || thing === false;
  var isPlainObject2 = (val) => {
    if (!isObject(val)) {
      return false;
    }
    const prototype2 = getPrototypeOf(val);
    return (prototype2 === null || prototype2 === Object.prototype || getPrototypeOf(prototype2) === null) && // Treat any genuine (non-Object.prototype-polluted) Symbol.toStringTag or
    // Symbol.iterator as evidence the value is a tagged/iterable type rather
    // than a plain object, while ignoring keys injected onto Object.prototype.
    !hasOwnInPrototypeChain(val, toStringTag) && !hasOwnInPrototypeChain(val, iterator);
  };
  var isEmptyObject = (val) => {
    if (!isObject(val) || isBuffer(val)) {
      return false;
    }
    try {
      return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
    } catch (e) {
      return false;
    }
  };
  var isDate = kindOfTest("Date");
  var isFile = kindOfTest("File");
  var isReactNativeBlob = (value) => {
    return !!(value && typeof value.uri !== "undefined");
  };
  var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
  var isBlob = kindOfTest("Blob");
  var isFileList = kindOfTest("FileList");
  var isStream = (val) => isObject(val) && isFunction3(val.pipe);
  function getGlobal() {
    if (typeof globalThis !== "undefined") return globalThis;
    if (typeof self !== "undefined") return self;
    if (typeof window !== "undefined") return window;
    if (typeof global !== "undefined") return global;
    return {};
  }
  var G = getGlobal();
  var FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
  var isFormData = (thing) => {
    if (!thing) return false;
    if (FormDataCtor && thing instanceof FormDataCtor) return true;
    const proto = getPrototypeOf(thing);
    if (!proto || proto === Object.prototype) return false;
    if (!isFunction3(thing.append)) return false;
    const kind = kindOf(thing);
    return kind === "formdata" || // detect form-data instance
    kind === "object" && isFunction3(thing.toString) && thing.toString() === "[object FormData]";
  };
  var isURLSearchParams = kindOfTest("URLSearchParams");
  var [isReadableStream, isRequest, isResponse, isHeaders] = [
    "ReadableStream",
    "Request",
    "Response",
    "Headers"
  ].map(kindOfTest);
  var trim = (str) => {
    return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  };
  function forEach(obj, fn, { allOwnKeys = false } = {}) {
    if (obj === null || typeof obj === "undefined") {
      return;
    }
    let i;
    let l;
    if (typeof obj !== "object") {
      obj = [obj];
    }
    if (isArray(obj)) {
      for (i = 0, l = obj.length; i < l; i++) {
        fn.call(null, obj[i], i, obj);
      }
    } else {
      if (isBuffer(obj)) {
        return;
      }
      const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
      const len = keys.length;
      let key;
      for (i = 0; i < len; i++) {
        key = keys[i];
        fn.call(null, obj[key], key, obj);
      }
    }
  }
  function findKey(obj, key) {
    if (isBuffer(obj)) {
      return null;
    }
    key = key.toLowerCase();
    const keys = Object.keys(obj);
    let i = keys.length;
    let _key;
    while (i-- > 0) {
      _key = keys[i];
      if (key === _key.toLowerCase()) {
        return _key;
      }
    }
    return null;
  }
  var _global = (() => {
    if (typeof globalThis !== "undefined") return globalThis;
    return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
  })();
  var isContextDefined = (context) => !isUndefined(context) && context !== _global;
  function merge(...objs) {
    const { caseless, skipUndefined } = isContextDefined(this) && this || {};
    const result = {};
    const assignValue = (val, key) => {
      if (key === "__proto__" || key === "constructor" || key === "prototype") {
        return;
      }
      const targetKey = caseless && typeof key === "string" && findKey(result, key) || key;
      const existing = hasOwnProperty(result, targetKey) ? result[targetKey] : void 0;
      if (isPlainObject2(existing) && isPlainObject2(val)) {
        result[targetKey] = merge(existing, val);
      } else if (isPlainObject2(val)) {
        result[targetKey] = merge({}, val);
      } else if (isArray(val)) {
        result[targetKey] = val.slice();
      } else if (!skipUndefined || !isUndefined(val)) {
        result[targetKey] = val;
      }
    };
    for (let i = 0, l = objs.length; i < l; i++) {
      const source = objs[i];
      if (!source || isBuffer(source)) {
        continue;
      }
      forEach(source, assignValue);
      if (typeof source !== "object" || isArray(source)) {
        continue;
      }
      const symbols = Object.getOwnPropertySymbols(source);
      for (let j = 0; j < symbols.length; j++) {
        const symbol = symbols[j];
        if (propertyIsEnumerable.call(source, symbol)) {
          assignValue(source[symbol], symbol);
        }
      }
    }
    return result;
  }
  var extend = (a, b, thisArg, { allOwnKeys } = {}) => {
    forEach(
      b,
      (val, key) => {
        if (thisArg && isFunction3(val)) {
          Object.defineProperty(a, key, {
            // Null-proto descriptor so a polluted Object.prototype.get cannot
            // hijack defineProperty's accessor-vs-data resolution.
            __proto__: null,
            value: bind(val, thisArg),
            writable: true,
            enumerable: true,
            configurable: true
          });
        } else {
          Object.defineProperty(a, key, {
            __proto__: null,
            value: val,
            writable: true,
            enumerable: true,
            configurable: true
          });
        }
      },
      { allOwnKeys }
    );
    return a;
  };
  var stripBOM = (content) => {
    if (content.charCodeAt(0) === 65279) {
      content = content.slice(1);
    }
    return content;
  };
  var inherits = (constructor, superConstructor, props, descriptors) => {
    constructor.prototype = Object.create(superConstructor.prototype, descriptors);
    Object.defineProperty(constructor.prototype, "constructor", {
      __proto__: null,
      value: constructor,
      writable: true,
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(constructor, "super", {
      __proto__: null,
      value: superConstructor.prototype
    });
    props && Object.assign(constructor.prototype, props);
  };
  var toFlatObject = (sourceObj, destObj, filter2, propFilter) => {
    let props;
    let i;
    let prop;
    const merged = {};
    destObj = destObj || {};
    if (sourceObj == null) return destObj;
    do {
      props = Object.getOwnPropertyNames(sourceObj);
      i = props.length;
      while (i-- > 0) {
        prop = props[i];
        if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
          destObj[prop] = sourceObj[prop];
          merged[prop] = true;
        }
      }
      sourceObj = filter2 !== false && getPrototypeOf(sourceObj);
    } while (sourceObj && (!filter2 || filter2(sourceObj, destObj)) && sourceObj !== Object.prototype);
    return destObj;
  };
  var endsWith = (str, searchString, position) => {
    str = String(str);
    if (position === void 0 || position > str.length) {
      position = str.length;
    }
    position -= searchString.length;
    const lastIndex = str.indexOf(searchString, position);
    return lastIndex !== -1 && lastIndex === position;
  };
  var toArray = (thing) => {
    if (!thing) return null;
    if (isArray(thing)) return thing;
    let i = thing.length;
    if (!isNumber(i)) return null;
    const arr = new Array(i);
    while (i-- > 0) {
      arr[i] = thing[i];
    }
    return arr;
  };
  var isTypedArray = /* @__PURE__ */ ((TypedArray) => {
    return (thing) => {
      return TypedArray && thing instanceof TypedArray;
    };
  })(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
  var forEachEntry = (obj, fn) => {
    const generator = obj && obj[iterator];
    const _iterator = generator.call(obj);
    let result;
    while ((result = _iterator.next()) && !result.done) {
      const pair = result.value;
      fn.call(obj, pair[0], pair[1]);
    }
  };
  var matchAll = (regExp, str) => {
    let matches;
    const arr = [];
    while ((matches = regExp.exec(str)) !== null) {
      arr.push(matches);
    }
    return arr;
  };
  var isHTMLForm = kindOfTest("HTMLFormElement");
  var toCamelCase2 = (str) => {
    return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
      return p1.toUpperCase() + p2;
    });
  };
  var { propertyIsEnumerable } = Object.prototype;
  var isRegExp = kindOfTest("RegExp");
  var reduceDescriptors = (obj, reducer) => {
    const descriptors = Object.getOwnPropertyDescriptors(obj);
    const reducedDescriptors = {};
    forEach(descriptors, (descriptor, name) => {
      let ret;
      if ((ret = reducer(descriptor, name, obj)) !== false) {
        reducedDescriptors[name] = ret || descriptor;
      }
    });
    Object.defineProperties(obj, reducedDescriptors);
  };
  var freezeMethods = (obj) => {
    reduceDescriptors(obj, (descriptor, name) => {
      if (isFunction3(obj) && ["arguments", "caller", "callee"].includes(name)) {
        return false;
      }
      const value = obj[name];
      if (!isFunction3(value)) return;
      descriptor.enumerable = false;
      if ("writable" in descriptor) {
        descriptor.writable = false;
        return;
      }
      if (!descriptor.set) {
        descriptor.set = () => {
          throw Error("Can not rewrite read-only method '" + name + "'");
        };
      }
    });
  };
  var toObjectSet = (arrayOrString, delimiter) => {
    const obj = {};
    const define = (arr) => {
      arr.forEach((value) => {
        obj[value] = true;
      });
    };
    isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
    return obj;
  };
  var noop4 = () => {
  };
  var toFiniteNumber = (value, defaultValue) => {
    return value != null && Number.isFinite(value = +value) ? value : defaultValue;
  };
  function isSpecCompliantForm(thing) {
    return !!(thing && isFunction3(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
  }
  var toJSONObject = (obj) => {
    const visited = /* @__PURE__ */ new WeakSet();
    const visit = (source) => {
      if (isObject(source)) {
        if (visited.has(source)) {
          return;
        }
        if (isBuffer(source)) {
          return source;
        }
        if (!("toJSON" in source)) {
          visited.add(source);
          const target = isArray(source) ? [] : {};
          forEach(source, (value, key) => {
            const reducedValue = visit(value);
            !isUndefined(reducedValue) && (target[key] = reducedValue);
          });
          visited.delete(source);
          return target;
        }
      }
      return source;
    };
    return visit(obj);
  };
  var isAsyncFn = kindOfTest("AsyncFunction");
  var isThenable = (thing) => thing && (isObject(thing) || isFunction3(thing)) && isFunction3(thing.then) && isFunction3(thing.catch);
  var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
    if (setImmediateSupported) {
      return setImmediate;
    }
    return postMessageSupported ? ((token, callbacks) => {
      _global.addEventListener(
        "message",
        ({ source, data }) => {
          if (source === _global && data === token) {
            callbacks.length && callbacks.shift()();
          }
        },
        false
      );
      return (cb) => {
        callbacks.push(cb);
        _global.postMessage(token, "*");
      };
    })(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
  })(typeof setImmediate === "function", isFunction3(_global.postMessage));
  var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
  var isIterable = (thing) => thing != null && isFunction3(thing[iterator]);
  var isSafeIterable = (thing) => thing != null && hasOwnInPrototypeChain(thing, iterator) && isIterable(thing);
  var utils_default = {
    isArray,
    isArrayBuffer,
    isBuffer,
    isFormData,
    isArrayBufferView,
    isString,
    isNumber,
    isBoolean,
    isObject,
    isPlainObject: isPlainObject2,
    isEmptyObject,
    isReadableStream,
    isRequest,
    isResponse,
    isHeaders,
    isUndefined,
    isDate,
    isFile,
    isReactNativeBlob,
    isReactNative,
    isBlob,
    isRegExp,
    isFunction: isFunction3,
    isStream,
    isURLSearchParams,
    isTypedArray,
    isFileList,
    forEach,
    merge,
    extend,
    trim,
    stripBOM,
    inherits,
    toFlatObject,
    kindOf,
    kindOfTest,
    endsWith,
    toArray,
    forEachEntry,
    matchAll,
    isHTMLForm,
    hasOwnProperty,
    hasOwnProp: hasOwnProperty,
    // an alias to avoid ESLint no-prototype-builtins detection
    hasOwnInPrototypeChain,
    getSafeProp,
    reduceDescriptors,
    freezeMethods,
    toObjectSet,
    toCamelCase: toCamelCase2,
    noop: noop4,
    toFiniteNumber,
    findKey,
    global: _global,
    isContextDefined,
    isSpecCompliantForm,
    toJSONObject,
    isAsyncFn,
    isThenable,
    setImmediate: _setImmediate,
    asap,
    isIterable,
    isSafeIterable
  };

  // src/client/node_modules/axios/lib/core/Axios.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/buildURL.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/AxiosURLSearchParams.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/toFormData.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/core/AxiosError.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/core/AxiosHeaders.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/parseHeaders.js
  init_define_import_meta_env();
  var ignoreDuplicateOf = utils_default.toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ]);
  var parseHeaders_default = (rawHeaders) => {
    const parsed = {};
    let key;
    let val;
    let i;
    rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
      i = line.indexOf(":");
      key = line.substring(0, i).trim().toLowerCase();
      val = line.substring(i + 1).trim();
      if (!key || parsed[key] && ignoreDuplicateOf[key]) {
        return;
      }
      if (key === "set-cookie") {
        if (parsed[key]) {
          parsed[key].push(val);
        } else {
          parsed[key] = [val];
        }
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
      }
    });
    return parsed;
  };

  // src/client/node_modules/axios/lib/helpers/sanitizeHeaderValue.js
  init_define_import_meta_env();
  function trimSPorHTAB(str) {
    let start = 0;
    let end = str.length;
    while (start < end) {
      const code = str.charCodeAt(start);
      if (code !== 9 && code !== 32) {
        break;
      }
      start += 1;
    }
    while (end > start) {
      const code = str.charCodeAt(end - 1);
      if (code !== 9 && code !== 32) {
        break;
      }
      end -= 1;
    }
    return start === 0 && end === str.length ? str : str.slice(start, end);
  }
  var INVALID_UNICODE_HEADER_VALUE_CHARS = new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
  var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
  function sanitizeValue(value, invalidChars) {
    if (utils_default.isArray(value)) {
      return value.map((item) => sanitizeValue(item, invalidChars));
    }
    return trimSPorHTAB(String(value).replace(invalidChars, ""));
  }
  var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
  var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
  function toByteStringHeaderObject(headers) {
    const byteStringHeaders = /* @__PURE__ */ Object.create(null);
    utils_default.forEach(headers.toJSON(), (value, header) => {
      byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
    });
    return byteStringHeaders;
  }

  // src/client/node_modules/axios/lib/core/AxiosHeaders.js
  var $internals = /* @__PURE__ */ Symbol("internals");
  function normalizeHeader(header) {
    return header && String(header).trim().toLowerCase();
  }
  function normalizeValue(value) {
    if (value === false || value == null) {
      return value;
    }
    return utils_default.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
  }
  function parseTokens(str) {
    const tokens = /* @__PURE__ */ Object.create(null);
    const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let match;
    while (match = tokensRE.exec(str)) {
      tokens[match[1]] = match[2];
    }
    return tokens;
  }
  var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
  function matchHeaderValue(context, value, header, filter2, isHeaderNameFilter) {
    if (utils_default.isFunction(filter2)) {
      return filter2.call(this, value, header);
    }
    if (isHeaderNameFilter) {
      value = header;
    }
    if (!utils_default.isString(value)) return;
    if (utils_default.isString(filter2)) {
      return value.indexOf(filter2) !== -1;
    }
    if (utils_default.isRegExp(filter2)) {
      return filter2.test(value);
    }
  }
  function formatHeader(header) {
    return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
      return char.toUpperCase() + str;
    });
  }
  function buildAccessors(obj, header) {
    const accessorName = utils_default.toCamelCase(" " + header);
    ["get", "set", "has"].forEach((methodName) => {
      Object.defineProperty(obj, methodName + accessorName, {
        // Null-proto descriptor so a polluted Object.prototype.get cannot turn
        // this data descriptor into an accessor descriptor on the way in.
        __proto__: null,
        value: function(arg1, arg2, arg3) {
          return this[methodName].call(this, header, arg1, arg2, arg3);
        },
        configurable: true
      });
    });
  }
  var AxiosHeaders = class {
    constructor(headers) {
      headers && this.set(headers);
    }
    set(header, valueOrRewrite, rewrite) {
      const self2 = this;
      function setHeader(_value, _header, _rewrite) {
        const lHeader = normalizeHeader(_header);
        if (!lHeader) {
          return;
        }
        const key = utils_default.findKey(self2, lHeader);
        if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
          self2[key || _header] = normalizeValue(_value);
        }
      }
      const setHeaders = (headers, _rewrite) => utils_default.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
      if (utils_default.isPlainObject(header) || header instanceof this.constructor) {
        setHeaders(header, valueOrRewrite);
      } else if (utils_default.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
        setHeaders(parseHeaders_default(header), valueOrRewrite);
      } else if (utils_default.isObject(header) && utils_default.isSafeIterable(header)) {
        let obj = /* @__PURE__ */ Object.create(null), dest, key;
        for (const entry of header) {
          if (!utils_default.isArray(entry)) {
            throw new TypeError("Object iterator must return a key-value pair");
          }
          key = entry[0];
          if (utils_default.hasOwnProp(obj, key)) {
            dest = obj[key];
            obj[key] = utils_default.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]];
          } else {
            obj[key] = entry[1];
          }
        }
        setHeaders(obj, valueOrRewrite);
      } else {
        header != null && setHeader(valueOrRewrite, header, rewrite);
      }
      return this;
    }
    get(header, parser) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils_default.findKey(this, header);
        if (key) {
          const value = this[key];
          if (!parser) {
            return value;
          }
          if (parser === true) {
            return parseTokens(value);
          }
          if (utils_default.isFunction(parser)) {
            return parser.call(this, value, key);
          }
          if (utils_default.isRegExp(parser)) {
            return parser.exec(value);
          }
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(header, matcher) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils_default.findKey(this, header);
        return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
      }
      return false;
    }
    delete(header, matcher) {
      const self2 = this;
      let deleted = false;
      function deleteHeader(_header) {
        _header = normalizeHeader(_header);
        if (_header) {
          const key = utils_default.findKey(self2, _header);
          if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
            delete self2[key];
            deleted = true;
          }
        }
      }
      if (utils_default.isArray(header)) {
        header.forEach(deleteHeader);
      } else {
        deleteHeader(header);
      }
      return deleted;
    }
    clear(matcher) {
      const keys = Object.keys(this);
      let i = keys.length;
      let deleted = false;
      while (i--) {
        const key = keys[i];
        if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
          delete this[key];
          deleted = true;
        }
      }
      return deleted;
    }
    normalize(format) {
      const self2 = this;
      const headers = {};
      utils_default.forEach(this, (value, header) => {
        const key = utils_default.findKey(headers, header);
        if (key) {
          self2[key] = normalizeValue(value);
          delete self2[header];
          return;
        }
        const normalized = format ? formatHeader(header) : String(header).trim();
        if (normalized !== header) {
          delete self2[header];
        }
        self2[normalized] = normalizeValue(value);
        headers[normalized] = true;
      });
      return this;
    }
    concat(...targets) {
      return this.constructor.concat(this, ...targets);
    }
    toJSON(asStrings) {
      const obj = /* @__PURE__ */ Object.create(null);
      utils_default.forEach(this, (value, header) => {
        value != null && value !== false && (obj[header] = asStrings && utils_default.isArray(value) ? value.join(", ") : value);
      });
      return obj;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
    }
    getSetCookie() {
      return this.get("set-cookie") || [];
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(thing) {
      return thing instanceof this ? thing : new this(thing);
    }
    static concat(first, ...targets) {
      const computed = new this(first);
      targets.forEach((target) => computed.set(target));
      return computed;
    }
    static accessor(header) {
      const internals = this[$internals] = this[$internals] = {
        accessors: {}
      };
      const accessors = internals.accessors;
      const prototype2 = this.prototype;
      function defineAccessor(_header) {
        const lHeader = normalizeHeader(_header);
        if (!accessors[lHeader]) {
          buildAccessors(prototype2, _header);
          accessors[lHeader] = true;
        }
      }
      utils_default.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
      return this;
    }
  };
  AxiosHeaders.accessor([
    "Content-Type",
    "Content-Length",
    "Accept",
    "Accept-Encoding",
    "User-Agent",
    "Authorization"
  ]);
  utils_default.reduceDescriptors(AxiosHeaders.prototype, ({ value }, key) => {
    let mapped = key[0].toUpperCase() + key.slice(1);
    return {
      get: () => value,
      set(headerValue) {
        this[mapped] = headerValue;
      }
    };
  });
  utils_default.freezeMethods(AxiosHeaders);
  var AxiosHeaders_default = AxiosHeaders;

  // src/client/node_modules/axios/lib/core/AxiosError.js
  var REDACTED = "[REDACTED ****]";
  function hasOwnOrPrototypeToJSON(source) {
    if (utils_default.hasOwnProp(source, "toJSON")) {
      return true;
    }
    let prototype2 = Object.getPrototypeOf(source);
    while (prototype2 && prototype2 !== Object.prototype) {
      if (utils_default.hasOwnProp(prototype2, "toJSON")) {
        return true;
      }
      prototype2 = Object.getPrototypeOf(prototype2);
    }
    return false;
  }
  function redactConfig(config, redactKeys) {
    const lowerKeys = new Set(redactKeys.map((k) => String(k).toLowerCase()));
    const seen = [];
    const visit = (source) => {
      if (source === null || typeof source !== "object") return source;
      if (utils_default.isBuffer(source)) return source;
      if (seen.indexOf(source) !== -1) return void 0;
      if (source instanceof AxiosHeaders_default) {
        source = source.toJSON();
      }
      seen.push(source);
      let result;
      if (utils_default.isArray(source)) {
        result = [];
        source.forEach((v, i) => {
          const reducedValue = visit(v);
          if (!utils_default.isUndefined(reducedValue)) {
            result[i] = reducedValue;
          }
        });
      } else {
        if (!utils_default.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
          seen.pop();
          return source;
        }
        result = /* @__PURE__ */ Object.create(null);
        for (const [key, value] of Object.entries(source)) {
          const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
          if (!utils_default.isUndefined(reducedValue)) {
            result[key] = reducedValue;
          }
        }
      }
      seen.pop();
      return result;
    };
    return visit(config);
  }
  var AxiosError = class _AxiosError extends Error {
    static from(error, code, config, request, response, customProps) {
      const axiosError = new _AxiosError(error.message, code || error.code, config, request, response);
      axiosError.cause = error;
      axiosError.name = error.name;
      if (error.status != null && axiosError.status == null) {
        axiosError.status = error.status;
      }
      customProps && Object.assign(axiosError, customProps);
      return axiosError;
    }
    /**
     * Create an Error with the specified message, config, error code, request and response.
     *
     * @param {string} message The error message.
     * @param {string} [code] The error code (for example, 'ECONNABORTED').
     * @param {Object} [config] The config.
     * @param {Object} [request] The request.
     * @param {Object} [response] The response.
     *
     * @returns {Error} The created error.
     */
    constructor(message, code, config, request, response) {
      super(message);
      Object.defineProperty(this, "message", {
        // Null-proto descriptor so a polluted Object.prototype.get cannot turn
        // this data descriptor into an accessor descriptor on the way in.
        __proto__: null,
        value: message,
        enumerable: true,
        writable: true,
        configurable: true
      });
      this.name = "AxiosError";
      this.isAxiosError = true;
      code && (this.code = code);
      config && (this.config = config);
      request && (this.request = request);
      if (response) {
        this.response = response;
        this.status = response.status;
      }
    }
    toJSON() {
      const config = this.config;
      const redactKeys = config && utils_default.hasOwnProp(config, "redact") ? config.redact : void 0;
      const serializedConfig = utils_default.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config, redactKeys) : utils_default.toJSONObject(config);
      return {
        // Standard
        message: this.message,
        name: this.name,
        // Microsoft
        description: this.description,
        number: this.number,
        // Mozilla
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        // Axios
        config: serializedConfig,
        code: this.code,
        status: this.status
      };
    }
  };
  AxiosError.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
  AxiosError.ERR_BAD_OPTION = "ERR_BAD_OPTION";
  AxiosError.ECONNABORTED = "ECONNABORTED";
  AxiosError.ETIMEDOUT = "ETIMEDOUT";
  AxiosError.ECONNREFUSED = "ECONNREFUSED";
  AxiosError.ERR_NETWORK = "ERR_NETWORK";
  AxiosError.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
  AxiosError.ERR_DEPRECATED = "ERR_DEPRECATED";
  AxiosError.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
  AxiosError.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
  AxiosError.ERR_CANCELED = "ERR_CANCELED";
  AxiosError.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
  AxiosError.ERR_INVALID_URL = "ERR_INVALID_URL";
  AxiosError.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
  var AxiosError_default = AxiosError;

  // src/client/node_modules/axios/lib/helpers/null.js
  init_define_import_meta_env();
  var null_default = null;

  // src/client/node_modules/axios/lib/helpers/toFormData.js
  var DEFAULT_FORM_DATA_MAX_DEPTH = 100;
  function isVisitable(thing) {
    return utils_default.isPlainObject(thing) || utils_default.isArray(thing);
  }
  function removeBrackets(key) {
    return utils_default.endsWith(key, "[]") ? key.slice(0, -2) : key;
  }
  function renderKey(path, key, dots) {
    if (!path) return key;
    return path.concat(key).map(function each(token, i) {
      token = removeBrackets(token);
      return !dots && i ? "[" + token + "]" : token;
    }).join(dots ? "." : "");
  }
  function isFlatArray(arr) {
    return utils_default.isArray(arr) && !arr.some(isVisitable);
  }
  var predicates = utils_default.toFlatObject(utils_default, {}, null, function filter(prop) {
    return /^is[A-Z]/.test(prop);
  });
  function toFormData(obj, formData, options2) {
    if (!utils_default.isObject(obj)) {
      throw new TypeError("target must be an object");
    }
    formData = formData || new (null_default || FormData)();
    options2 = utils_default.toFlatObject(
      options2,
      {
        metaTokens: true,
        dots: false,
        indexes: false
      },
      false,
      function defined(option, source) {
        return !utils_default.isUndefined(source[option]);
      }
    );
    const metaTokens = options2.metaTokens;
    const visitor = options2.visitor || defaultVisitor;
    const dots = options2.dots;
    const indexes = options2.indexes;
    const _Blob = options2.Blob || typeof Blob !== "undefined" && Blob;
    const maxDepth = options2.maxDepth === void 0 ? DEFAULT_FORM_DATA_MAX_DEPTH : options2.maxDepth;
    const useBlob = _Blob && utils_default.isSpecCompliantForm(formData);
    const stack = [];
    if (!utils_default.isFunction(visitor)) {
      throw new TypeError("visitor must be a function");
    }
    function convertValue(value) {
      if (value === null) return "";
      if (utils_default.isDate(value)) {
        return value.toISOString();
      }
      if (utils_default.isBoolean(value)) {
        return value.toString();
      }
      if (!useBlob && utils_default.isBlob(value)) {
        throw new AxiosError_default("Blob is not supported. Use a Buffer instead.");
      }
      if (utils_default.isArrayBuffer(value) || utils_default.isTypedArray(value)) {
        return useBlob && typeof Blob === "function" ? new Blob([value]) : Buffer.from(value);
      }
      return value;
    }
    function throwIfMaxDepthExceeded(depth) {
      if (depth > maxDepth) {
        throw new AxiosError_default(
          "Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth,
          AxiosError_default.ERR_FORM_DATA_DEPTH_EXCEEDED
        );
      }
    }
    function stringifyWithDepthLimit(value, depth) {
      if (maxDepth === Infinity) {
        return JSON.stringify(value);
      }
      const ancestors = [];
      return JSON.stringify(value, function limitDepth(_key, currentValue) {
        if (!utils_default.isObject(currentValue)) {
          return currentValue;
        }
        while (ancestors.length && ancestors[ancestors.length - 1] !== this) {
          ancestors.pop();
        }
        ancestors.push(currentValue);
        throwIfMaxDepthExceeded(depth + ancestors.length - 1);
        return currentValue;
      });
    }
    function defaultVisitor(value, key, path) {
      let arr = value;
      if (utils_default.isReactNative(formData) && utils_default.isReactNativeBlob(value)) {
        formData.append(renderKey(path, key, dots), convertValue(value));
        return false;
      }
      if (value && !path && typeof value === "object") {
        if (utils_default.endsWith(key, "{}")) {
          key = metaTokens ? key : key.slice(0, -2);
          value = stringifyWithDepthLimit(value, 1);
        } else if (utils_default.isArray(value) && isFlatArray(value) || (utils_default.isFileList(value) || utils_default.endsWith(key, "[]")) && (arr = utils_default.toArray(value))) {
          key = removeBrackets(key);
          arr.forEach(function each(el, index2) {
            !(utils_default.isUndefined(el) || el === null) && formData.append(
              // eslint-disable-next-line no-nested-ternary
              indexes === true ? renderKey([key], index2, dots) : indexes === null ? key : key + "[]",
              convertValue(el)
            );
          });
          return false;
        }
      }
      if (isVisitable(value)) {
        return true;
      }
      formData.append(renderKey(path, key, dots), convertValue(value));
      return false;
    }
    const exposedHelpers = Object.assign(predicates, {
      defaultVisitor,
      convertValue,
      isVisitable
    });
    function build(value, path, depth = 0) {
      if (utils_default.isUndefined(value)) return;
      throwIfMaxDepthExceeded(depth);
      if (stack.indexOf(value) !== -1) {
        throw new Error("Circular reference detected in " + path.join("."));
      }
      stack.push(value);
      utils_default.forEach(value, function each(el, key) {
        const result = !(utils_default.isUndefined(el) || el === null) && visitor.call(formData, el, utils_default.isString(key) ? key.trim() : key, path, exposedHelpers);
        if (result === true) {
          build(el, path ? path.concat(key) : [key], depth + 1);
        }
      });
      stack.pop();
    }
    if (!utils_default.isObject(obj)) {
      throw new TypeError("data must be an object");
    }
    build(obj);
    return formData;
  }
  var toFormData_default = toFormData;

  // src/client/node_modules/axios/lib/helpers/AxiosURLSearchParams.js
  function encode(str) {
    const charMap = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+"
    };
    return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
      return charMap[match];
    });
  }
  function AxiosURLSearchParams(params, options2) {
    this._pairs = [];
    params && toFormData_default(params, this, options2);
  }
  var prototype = AxiosURLSearchParams.prototype;
  prototype.append = function append(name, value) {
    this._pairs.push([name, value]);
  };
  prototype.toString = function toString2(encoder) {
    const _encode = encoder ? function(value) {
      return encoder.call(this, value, encode);
    } : encode;
    return this._pairs.map(function each(pair) {
      return _encode(pair[0]) + "=" + _encode(pair[1]);
    }, "").join("&");
  };
  var AxiosURLSearchParams_default = AxiosURLSearchParams;

  // src/client/node_modules/axios/lib/helpers/buildURL.js
  function encode2(val) {
    return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
  }
  function buildURL(url, params, options2) {
    if (!params) {
      return url;
    }
    const _options = utils_default.isFunction(options2) ? {
      serialize: options2
    } : options2;
    const _encode = utils_default.getSafeProp(_options, "encode") || encode2;
    const serializeFn = utils_default.getSafeProp(_options, "serialize");
    let serializedParams;
    if (serializeFn) {
      serializedParams = serializeFn(params, _options);
    } else {
      serializedParams = utils_default.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams_default(params, _options).toString(_encode);
    }
    if (serializedParams) {
      const hashmarkIndex = url.indexOf("#");
      if (hashmarkIndex !== -1) {
        url = url.slice(0, hashmarkIndex);
      }
      url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
    }
    return url;
  }

  // src/client/node_modules/axios/lib/core/InterceptorManager.js
  init_define_import_meta_env();
  var InterceptorManager = class {
    constructor() {
      this.handlers = [];
    }
    /**
     * Add a new interceptor to the stack
     *
     * @param {Function} fulfilled The function to handle `then` for a `Promise`
     * @param {Function} rejected The function to handle `reject` for a `Promise`
     * @param {Object} options The options for the interceptor, synchronous and runWhen
     *
     * @return {Number} An ID used to remove interceptor later
     */
    use(fulfilled, rejected, options2) {
      this.handlers.push({
        fulfilled,
        rejected,
        synchronous: options2 ? options2.synchronous : false,
        runWhen: options2 ? options2.runWhen : null
      });
      return this.handlers.length - 1;
    }
    /**
     * Remove an interceptor from the stack
     *
     * @param {Number} id The ID that was returned by `use`
     *
     * @returns {void}
     */
    eject(id) {
      if (this.handlers[id]) {
        this.handlers[id] = null;
      }
    }
    /**
     * Clear all interceptors from the stack
     *
     * @returns {void}
     */
    clear() {
      if (this.handlers) {
        this.handlers = [];
      }
    }
    /**
     * Iterate over all the registered interceptors
     *
     * This method is particularly useful for skipping over any
     * interceptors that may have become `null` calling `eject`.
     *
     * @param {Function} fn The function to call for each interceptor
     *
     * @returns {void}
     */
    forEach(fn) {
      utils_default.forEach(this.handlers, function forEachHandler(h) {
        if (h !== null) {
          fn(h);
        }
      });
    }
  };
  var InterceptorManager_default = InterceptorManager;

  // src/client/node_modules/axios/lib/core/dispatchRequest.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/core/transformData.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/defaults/index.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/defaults/transitional.js
  init_define_import_meta_env();
  var transitional_default = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false,
    legacyInterceptorReqResOrdering: true,
    advertiseZstdAcceptEncoding: false,
    validateStatusUndefinedResolves: true
  };

  // src/client/node_modules/axios/lib/helpers/toURLEncodedForm.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/platform/index.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/platform/browser/index.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/platform/browser/classes/URLSearchParams.js
  init_define_import_meta_env();
  var URLSearchParams_default = typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams_default;

  // src/client/node_modules/axios/lib/platform/browser/classes/FormData.js
  init_define_import_meta_env();
  var FormData_default = typeof FormData !== "undefined" ? FormData : null;

  // src/client/node_modules/axios/lib/platform/browser/classes/Blob.js
  init_define_import_meta_env();
  var Blob_default = typeof Blob !== "undefined" ? Blob : null;

  // src/client/node_modules/axios/lib/platform/browser/index.js
  var browser_default = {
    isBrowser: true,
    classes: {
      URLSearchParams: URLSearchParams_default,
      FormData: FormData_default,
      Blob: Blob_default
    },
    protocols: ["http", "https", "file", "blob", "url", "data"]
  };

  // src/client/node_modules/axios/lib/platform/common/utils.js
  var utils_exports = {};
  __export(utils_exports, {
    hasBrowserEnv: () => hasBrowserEnv,
    hasStandardBrowserEnv: () => hasStandardBrowserEnv,
    hasStandardBrowserWebWorkerEnv: () => hasStandardBrowserWebWorkerEnv,
    navigator: () => _navigator,
    origin: () => origin
  });
  init_define_import_meta_env();
  var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
  var _navigator = typeof navigator === "object" && navigator || void 0;
  var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || ["ReactNative", "NativeScript", "NS"].indexOf(_navigator.product) < 0);
  var hasStandardBrowserWebWorkerEnv = (() => {
    return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
    self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
  })();
  var origin = hasBrowserEnv && window.location.href || "http://localhost";

  // src/client/node_modules/axios/lib/platform/index.js
  var platform_default = {
    ...utils_exports,
    ...browser_default
  };

  // src/client/node_modules/axios/lib/helpers/toURLEncodedForm.js
  function toURLEncodedForm(data, options2) {
    return toFormData_default(data, new platform_default.classes.URLSearchParams(), {
      visitor: function(value, key, path, helpers) {
        if (platform_default.isNode && utils_default.isBuffer(value)) {
          this.append(key, value.toString("base64"));
          return false;
        }
        return helpers.defaultVisitor.apply(this, arguments);
      },
      ...options2
    });
  }

  // src/client/node_modules/axios/lib/helpers/formDataToJSON.js
  init_define_import_meta_env();
  var MAX_DEPTH = DEFAULT_FORM_DATA_MAX_DEPTH;
  function throwIfDepthExceeded(index2) {
    if (index2 > MAX_DEPTH) {
      throw new AxiosError_default(
        "FormData field is too deeply nested (" + index2 + " levels). Max depth: " + MAX_DEPTH,
        AxiosError_default.ERR_FORM_DATA_DEPTH_EXCEEDED
      );
    }
  }
  function parsePropPath(name) {
    const path = [];
    const pattern = /\w+|\[(\w*)]/g;
    let match;
    while ((match = pattern.exec(name)) !== null) {
      throwIfDepthExceeded(path.length);
      path.push(match[0] === "[]" ? "" : match[1] || match[0]);
    }
    return path;
  }
  function arrayToObject(arr) {
    const obj = {};
    const keys = Object.keys(arr);
    let i;
    const len = keys.length;
    let key;
    for (i = 0; i < len; i++) {
      key = keys[i];
      obj[key] = arr[key];
    }
    return obj;
  }
  function formDataToJSON(formData) {
    function buildPath(path, value, target, index2) {
      throwIfDepthExceeded(index2);
      let name = path[index2++];
      if (name === "__proto__") return true;
      const isNumericKey = Number.isFinite(+name);
      const isLast = index2 >= path.length;
      name = !name && utils_default.isArray(target) ? target.length : name;
      if (isLast) {
        if (utils_default.hasOwnProp(target, name)) {
          target[name] = utils_default.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
        } else {
          target[name] = value;
        }
        return !isNumericKey;
      }
      if (!utils_default.hasOwnProp(target, name) || !utils_default.isObject(target[name])) {
        target[name] = [];
      }
      const result = buildPath(path, value, target[name], index2);
      if (result && utils_default.isArray(target[name])) {
        target[name] = arrayToObject(target[name]);
      }
      return !isNumericKey;
    }
    if (utils_default.isFormData(formData) && utils_default.isFunction(formData.entries)) {
      const obj = {};
      utils_default.forEachEntry(formData, (name, value) => {
        buildPath(parsePropPath(name), value, obj, 0);
      });
      return obj;
    }
    return null;
  }
  var formDataToJSON_default = formDataToJSON;

  // src/client/node_modules/axios/lib/defaults/index.js
  var own = (obj, key) => obj != null && utils_default.hasOwnProp(obj, key) ? obj[key] : void 0;
  function stringifySafely(rawValue, parser, encoder) {
    if (utils_default.isString(rawValue)) {
      try {
        (parser || JSON.parse)(rawValue);
        return utils_default.trim(rawValue);
      } catch (e) {
        if (e.name !== "SyntaxError") {
          throw e;
        }
      }
    }
    return (encoder || JSON.stringify)(rawValue);
  }
  var defaults = {
    transitional: transitional_default,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [
      function transformRequest(data, headers) {
        const contentType = headers.getContentType() || "";
        const hasJSONContentType = contentType.indexOf("application/json") > -1;
        const isObjectPayload = utils_default.isObject(data);
        if (isObjectPayload && utils_default.isHTMLForm(data)) {
          data = new FormData(data);
        }
        const isFormData2 = utils_default.isFormData(data);
        if (isFormData2) {
          return hasJSONContentType ? JSON.stringify(formDataToJSON_default(data)) : data;
        }
        if (utils_default.isArrayBuffer(data) || utils_default.isBuffer(data) || utils_default.isStream(data) || utils_default.isFile(data) || utils_default.isBlob(data) || utils_default.isReadableStream(data)) {
          return data;
        }
        if (utils_default.isArrayBufferView(data)) {
          return data.buffer;
        }
        if (utils_default.isURLSearchParams(data)) {
          headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
          return data.toString();
        }
        let isFileList2;
        if (isObjectPayload) {
          const formSerializer = own(this, "formSerializer");
          if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
            return toURLEncodedForm(data, formSerializer).toString();
          }
          if ((isFileList2 = utils_default.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
            const env = own(this, "env");
            const _FormData = env && env.FormData;
            return toFormData_default(
              isFileList2 ? { "files[]": data } : data,
              _FormData && new _FormData(),
              formSerializer
            );
          }
        }
        if (isObjectPayload || hasJSONContentType) {
          headers.setContentType("application/json", false);
          return stringifySafely(data);
        }
        return data;
      }
    ],
    transformResponse: [
      function transformResponse(data) {
        const transitional2 = own(this, "transitional") || defaults.transitional;
        const forcedJSONParsing = transitional2 && transitional2.forcedJSONParsing;
        const responseType = own(this, "responseType");
        const JSONRequested = responseType === "json";
        if (utils_default.isResponse(data) || utils_default.isReadableStream(data)) {
          return data;
        }
        if (data && utils_default.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
          const silentJSONParsing = transitional2 && transitional2.silentJSONParsing;
          const strictJSONParsing = !silentJSONParsing && JSONRequested;
          try {
            return JSON.parse(data, own(this, "parseReviver"));
          } catch (e) {
            if (strictJSONParsing) {
              if (e.name === "SyntaxError") {
                throw AxiosError_default.from(e, AxiosError_default.ERR_BAD_RESPONSE, this, null, own(this, "response"));
              }
              throw e;
            }
          }
        }
        return data;
      }
    ],
    /**
     * A timeout in milliseconds to abort a request. If set to 0 (default) a
     * timeout is not created.
     */
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
      FormData: platform_default.classes.FormData,
      Blob: platform_default.classes.Blob
    },
    validateStatus: function validateStatus(status) {
      return status >= 200 && status < 300;
    },
    headers: {
      common: {
        Accept: "application/json, text/plain, */*",
        "Content-Type": void 0
      }
    }
  };
  utils_default.forEach(["delete", "get", "head", "post", "put", "patch", "query"], (method) => {
    defaults.headers[method] = {};
  });
  var defaults_default = defaults;

  // src/client/node_modules/axios/lib/core/transformData.js
  function transformData(fns, response) {
    const config = this || defaults_default;
    const context = response || config;
    const headers = AxiosHeaders_default.from(context.headers);
    let data = context.data;
    utils_default.forEach(fns, function transform(fn) {
      data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
    });
    headers.normalize();
    return data;
  }

  // src/client/node_modules/axios/lib/cancel/isCancel.js
  init_define_import_meta_env();
  function isCancel(value) {
    return !!(value && value.__CANCEL__);
  }

  // src/client/node_modules/axios/lib/cancel/CanceledError.js
  init_define_import_meta_env();
  var CanceledError = class extends AxiosError_default {
    /**
     * A `CanceledError` is an object that is thrown when an operation is canceled.
     *
     * @param {string=} message The message.
     * @param {Object=} config The config.
     * @param {Object=} request The request.
     *
     * @returns {CanceledError} The created error.
     */
    constructor(message, config, request) {
      super(message == null ? "canceled" : message, AxiosError_default.ERR_CANCELED, config, request);
      this.name = "CanceledError";
      this.__CANCEL__ = true;
    }
  };
  var CanceledError_default = CanceledError;

  // src/client/node_modules/axios/lib/adapters/adapters.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/adapters/xhr.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/core/settle.js
  init_define_import_meta_env();
  function settle(resolve, reject, response) {
    const validateStatus2 = response.config.validateStatus;
    if (!response.status || !validateStatus2 || validateStatus2(response.status)) {
      resolve(response);
    } else {
      reject(new AxiosError_default(
        "Request failed with status code " + response.status,
        response.status >= 400 && response.status < 500 ? AxiosError_default.ERR_BAD_REQUEST : AxiosError_default.ERR_BAD_RESPONSE,
        response.config,
        response.request,
        response
      ));
    }
  }

  // src/client/node_modules/axios/lib/helpers/parseProtocol.js
  init_define_import_meta_env();
  function parseProtocol(url) {
    const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url);
    return match && match[1] || "";
  }

  // src/client/node_modules/axios/lib/helpers/progressEventReducer.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/speedometer.js
  init_define_import_meta_env();
  function speedometer(samplesCount, min2) {
    samplesCount = samplesCount || 10;
    const bytes = new Array(samplesCount);
    const timestamps = new Array(samplesCount);
    let head = 0;
    let tail = 0;
    let firstSampleTS;
    min2 = min2 !== void 0 ? min2 : 1e3;
    return function push(chunkLength) {
      const now = Date.now();
      const startedAt = timestamps[tail];
      if (!firstSampleTS) {
        firstSampleTS = now;
      }
      bytes[head] = chunkLength;
      timestamps[head] = now;
      let i = tail;
      let bytesCount = 0;
      while (i !== head) {
        bytesCount += bytes[i++];
        i = i % samplesCount;
      }
      head = (head + 1) % samplesCount;
      if (head === tail) {
        tail = (tail + 1) % samplesCount;
      }
      if (now - firstSampleTS < min2) {
        return;
      }
      const passed = startedAt && now - startedAt;
      return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
    };
  }
  var speedometer_default = speedometer;

  // src/client/node_modules/axios/lib/helpers/throttle.js
  init_define_import_meta_env();
  function throttle(fn, freq) {
    let timestamp = 0;
    let threshold = 1e3 / freq;
    let lastArgs;
    let timer;
    const invoke = (args, now = Date.now()) => {
      timestamp = now;
      lastArgs = null;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      fn(...args);
    };
    const throttled = (...args) => {
      const now = Date.now();
      const passed = now - timestamp;
      if (passed >= threshold) {
        invoke(args, now);
      } else {
        lastArgs = args;
        if (!timer) {
          timer = setTimeout(() => {
            timer = null;
            invoke(lastArgs);
          }, threshold - passed);
        }
      }
    };
    const flush = () => lastArgs && invoke(lastArgs);
    return [throttled, flush];
  }
  var throttle_default = throttle;

  // src/client/node_modules/axios/lib/helpers/progressEventReducer.js
  var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
    let bytesNotified = 0;
    const _speedometer = speedometer_default(50, 250);
    return throttle_default((e) => {
      if (!e || typeof e.loaded !== "number") {
        return;
      }
      const rawLoaded = e.loaded;
      const total = e.lengthComputable ? e.total : void 0;
      const loaded = total != null ? Math.min(rawLoaded, total) : rawLoaded;
      const progressBytes = Math.max(0, loaded - bytesNotified);
      const rate = _speedometer(progressBytes);
      bytesNotified = Math.max(bytesNotified, loaded);
      const data = {
        loaded,
        total,
        progress: total ? loaded / total : void 0,
        bytes: progressBytes,
        rate: rate ? rate : void 0,
        estimated: rate && total ? (total - loaded) / rate : void 0,
        event: e,
        lengthComputable: total != null,
        [isDownloadStream ? "download" : "upload"]: true
      };
      listener(data);
    }, freq);
  };
  var progressEventDecorator = (total, throttled) => {
    const lengthComputable = total != null;
    return [
      (loaded) => throttled[0]({
        lengthComputable,
        total,
        loaded
      }),
      throttled[1]
    ];
  };
  var asyncDecorator = (fn) => (...args) => utils_default.asap(() => fn(...args));

  // src/client/node_modules/axios/lib/helpers/resolveConfig.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/isURLSameOrigin.js
  init_define_import_meta_env();
  var isURLSameOrigin_default = platform_default.hasStandardBrowserEnv ? /* @__PURE__ */ ((origin2, isMSIE) => (url) => {
    url = new URL(url, platform_default.origin);
    return origin2.protocol === url.protocol && origin2.host === url.host && (isMSIE || origin2.port === url.port);
  })(
    new URL(platform_default.origin),
    platform_default.navigator && /(msie|trident)/i.test(platform_default.navigator.userAgent)
  ) : () => true;

  // src/client/node_modules/axios/lib/helpers/cookies.js
  init_define_import_meta_env();
  var cookies_default = platform_default.hasStandardBrowserEnv ? (
    // Standard browser envs support document.cookie
    {
      write(name, value, expires, path, domain, secure, sameSite) {
        if (typeof document === "undefined") return;
        const cookie = [`${name}=${encodeURIComponent(value)}`];
        if (utils_default.isNumber(expires)) {
          cookie.push(`expires=${new Date(expires).toUTCString()}`);
        }
        if (utils_default.isString(path)) {
          cookie.push(`path=${path}`);
        }
        if (utils_default.isString(domain)) {
          cookie.push(`domain=${domain}`);
        }
        if (secure === true) {
          cookie.push("secure");
        }
        if (utils_default.isString(sameSite)) {
          cookie.push(`SameSite=${sameSite}`);
        }
        document.cookie = cookie.join("; ");
      },
      read(name) {
        if (typeof document === "undefined") return null;
        const cookies = document.cookie.split(";");
        for (let i = 0; i < cookies.length; i++) {
          const cookie = cookies[i].replace(/^\s+/, "");
          const eq = cookie.indexOf("=");
          if (eq !== -1 && cookie.slice(0, eq) === name) {
            return decodeURIComponent(cookie.slice(eq + 1));
          }
        }
        return null;
      },
      remove(name) {
        this.write(name, "", Date.now() - 864e5, "/");
      }
    }
  ) : (
    // Non-standard browser env (web workers, react-native) lack needed support.
    {
      write() {
      },
      read() {
        return null;
      },
      remove() {
      }
    }
  );

  // src/client/node_modules/axios/lib/core/buildFullPath.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/isAbsoluteURL.js
  init_define_import_meta_env();
  function isAbsoluteURL(url) {
    if (typeof url !== "string") {
      return false;
    }
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
  }

  // src/client/node_modules/axios/lib/helpers/combineURLs.js
  init_define_import_meta_env();
  function combineURLs(baseURL2, relativeURL) {
    return relativeURL ? baseURL2.replace(/\/?\/$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL2;
  }

  // src/client/node_modules/axios/lib/core/buildFullPath.js
  var malformedHttpProtocol = /^https?:(?!\/\/)/i;
  var httpProtocolControlCharacters = /[\t\n\r]/g;
  function stripLeadingC0ControlOrSpace(url) {
    let i = 0;
    while (i < url.length && url.charCodeAt(i) <= 32) {
      i++;
    }
    return url.slice(i);
  }
  function normalizeURLForProtocolCheck(url) {
    return stripLeadingC0ControlOrSpace(url).replace(httpProtocolControlCharacters, "");
  }
  function assertValidHttpProtocolURL(url, config) {
    if (typeof url === "string" && malformedHttpProtocol.test(normalizeURLForProtocolCheck(url))) {
      throw new AxiosError_default(
        'Invalid URL: missing "//" after protocol',
        AxiosError_default.ERR_INVALID_URL,
        config
      );
    }
  }
  function buildFullPath(baseURL2, requestedURL, allowAbsoluteUrls, config) {
    assertValidHttpProtocolURL(requestedURL, config);
    let isRelativeUrl = !isAbsoluteURL(requestedURL);
    if (baseURL2 && (isRelativeUrl || allowAbsoluteUrls === false)) {
      assertValidHttpProtocolURL(baseURL2, config);
      return combineURLs(baseURL2, requestedURL);
    }
    return requestedURL;
  }

  // src/client/node_modules/axios/lib/core/mergeConfig.js
  init_define_import_meta_env();
  var headersToObject = (thing) => thing instanceof AxiosHeaders_default ? { ...thing } : thing;
  function mergeConfig(config1, config2) {
    config2 = config2 || {};
    const config = /* @__PURE__ */ Object.create(null);
    Object.defineProperty(config, "hasOwnProperty", {
      // Null-proto descriptor so a polluted Object.prototype.get cannot turn
      // this data descriptor into an accessor descriptor on the way in.
      __proto__: null,
      value: Object.prototype.hasOwnProperty,
      enumerable: false,
      writable: true,
      configurable: true
    });
    function getMergedValue(target, source, prop, caseless) {
      if (utils_default.isPlainObject(target) && utils_default.isPlainObject(source)) {
        return utils_default.merge.call({ caseless }, target, source);
      } else if (utils_default.isPlainObject(source)) {
        return utils_default.merge({}, source);
      } else if (utils_default.isArray(source)) {
        return source.slice();
      }
      return source;
    }
    function mergeDeepProperties(a, b, prop, caseless) {
      if (!utils_default.isUndefined(b)) {
        return getMergedValue(a, b, prop, caseless);
      } else if (!utils_default.isUndefined(a)) {
        return getMergedValue(void 0, a, prop, caseless);
      }
    }
    function valueFromConfig2(a, b) {
      if (!utils_default.isUndefined(b)) {
        return getMergedValue(void 0, b);
      }
    }
    function defaultToConfig2(a, b) {
      if (!utils_default.isUndefined(b)) {
        return getMergedValue(void 0, b);
      } else if (!utils_default.isUndefined(a)) {
        return getMergedValue(void 0, a);
      }
    }
    function getMergedTransitionalOption(prop) {
      const transitional2 = utils_default.hasOwnProp(config2, "transitional") ? config2.transitional : void 0;
      if (!utils_default.isUndefined(transitional2)) {
        if (utils_default.isPlainObject(transitional2)) {
          if (utils_default.hasOwnProp(transitional2, prop)) {
            return transitional2[prop];
          }
        } else {
          return void 0;
        }
      }
      const transitional1 = utils_default.hasOwnProp(config1, "transitional") ? config1.transitional : void 0;
      if (utils_default.isPlainObject(transitional1) && utils_default.hasOwnProp(transitional1, prop)) {
        return transitional1[prop];
      }
      return void 0;
    }
    function mergeDirectKeys(a, b, prop) {
      if (utils_default.hasOwnProp(config2, prop)) {
        return getMergedValue(a, b);
      } else if (utils_default.hasOwnProp(config1, prop)) {
        return getMergedValue(void 0, a);
      }
    }
    const mergeMap = {
      url: valueFromConfig2,
      method: valueFromConfig2,
      data: valueFromConfig2,
      baseURL: defaultToConfig2,
      transformRequest: defaultToConfig2,
      transformResponse: defaultToConfig2,
      paramsSerializer: defaultToConfig2,
      timeout: defaultToConfig2,
      timeoutMessage: defaultToConfig2,
      withCredentials: defaultToConfig2,
      withXSRFToken: defaultToConfig2,
      adapter: defaultToConfig2,
      responseType: defaultToConfig2,
      xsrfCookieName: defaultToConfig2,
      xsrfHeaderName: defaultToConfig2,
      onUploadProgress: defaultToConfig2,
      onDownloadProgress: defaultToConfig2,
      decompress: defaultToConfig2,
      maxContentLength: defaultToConfig2,
      maxBodyLength: defaultToConfig2,
      beforeRedirect: defaultToConfig2,
      transport: defaultToConfig2,
      httpAgent: defaultToConfig2,
      httpsAgent: defaultToConfig2,
      cancelToken: defaultToConfig2,
      socketPath: defaultToConfig2,
      allowedSocketPaths: defaultToConfig2,
      responseEncoding: defaultToConfig2,
      validateStatus: mergeDirectKeys,
      headers: (a, b, prop) => mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true)
    };
    utils_default.forEach(Object.keys({ ...config1, ...config2 }), function computeConfigValue(prop) {
      if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
      const merge2 = utils_default.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
      const a = utils_default.hasOwnProp(config1, prop) ? config1[prop] : void 0;
      const b = utils_default.hasOwnProp(config2, prop) ? config2[prop] : void 0;
      const configValue = merge2(a, b, prop);
      utils_default.isUndefined(configValue) && merge2 !== mergeDirectKeys || (config[prop] = configValue);
    });
    if (utils_default.hasOwnProp(config2, "validateStatus") && utils_default.isUndefined(config2.validateStatus) && getMergedTransitionalOption("validateStatusUndefinedResolves") === false) {
      if (utils_default.hasOwnProp(config1, "validateStatus")) {
        config.validateStatus = getMergedValue(void 0, config1.validateStatus);
      } else {
        delete config.validateStatus;
      }
    }
    return config;
  }

  // src/client/node_modules/axios/lib/helpers/resolveConfig.js
  var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
  function setFormDataHeaders(headers, formHeaders, policy) {
    if (policy !== "content-only") {
      headers.set(formHeaders);
      return;
    }
    Object.entries(formHeaders).forEach(([key, val]) => {
      if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) {
        headers.set(key, val);
      }
    });
  }
  var encodeUTF8 = (str) => encodeURIComponent(str).replace(
    /%([0-9A-F]{2})/gi,
    (_, hex) => String.fromCharCode(parseInt(hex, 16))
  );
  function resolveConfig(config) {
    const newConfig = mergeConfig({}, config);
    const own2 = (key) => utils_default.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
    const data = own2("data");
    let withXSRFToken = own2("withXSRFToken");
    const xsrfHeaderName = own2("xsrfHeaderName");
    const xsrfCookieName = own2("xsrfCookieName");
    let headers = own2("headers");
    const auth = own2("auth");
    const baseURL2 = own2("baseURL");
    const allowAbsoluteUrls = own2("allowAbsoluteUrls");
    const url = own2("url");
    newConfig.headers = headers = AxiosHeaders_default.from(headers);
    newConfig.url = buildURL(
      buildFullPath(baseURL2, url, allowAbsoluteUrls, newConfig),
      own2("params"),
      own2("paramsSerializer")
    );
    if (auth) {
      const username = utils_default.getSafeProp(auth, "username") || "";
      const password = utils_default.getSafeProp(auth, "password") || "";
      headers.set(
        "Authorization",
        "Basic " + btoa(username + ":" + (password ? encodeUTF8(password) : ""))
      );
    }
    if (utils_default.isFormData(data)) {
      if (platform_default.hasStandardBrowserEnv || platform_default.hasStandardBrowserWebWorkerEnv || utils_default.isReactNative(data)) {
        headers.setContentType(void 0);
      } else if (utils_default.isFunction(data.getHeaders)) {
        setFormDataHeaders(headers, data.getHeaders(), own2("formDataHeaderPolicy"));
      }
    }
    if (platform_default.hasStandardBrowserEnv) {
      if (utils_default.isFunction(withXSRFToken)) {
        withXSRFToken = withXSRFToken(newConfig);
      }
      const shouldSendXSRF = withXSRFToken === true || withXSRFToken == null && isURLSameOrigin_default(newConfig.url);
      if (shouldSendXSRF) {
        const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies_default.read(xsrfCookieName);
        if (xsrfValue) {
          headers.set(xsrfHeaderName, xsrfValue);
        }
      }
    }
    return newConfig;
  }
  var resolveConfig_default = resolveConfig;

  // src/client/node_modules/axios/lib/adapters/xhr.js
  var isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
  var xhr_default = isXHRAdapterSupported && function(config) {
    return new Promise(function dispatchXhrRequest(resolve, reject) {
      const _config = resolveConfig_default(config);
      let requestData = _config.data;
      const requestHeaders = AxiosHeaders_default.from(_config.headers).normalize();
      let { responseType, onUploadProgress, onDownloadProgress } = _config;
      let onCanceled;
      let uploadThrottled, downloadThrottled;
      let flushUpload, flushDownload;
      function done() {
        flushUpload && flushUpload();
        flushDownload && flushDownload();
        _config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
        _config.signal && _config.signal.removeEventListener("abort", onCanceled);
      }
      let request = new XMLHttpRequest();
      request.open(_config.method.toUpperCase(), _config.url, true);
      request.timeout = _config.timeout;
      function onloadend() {
        if (!request) {
          return;
        }
        const responseHeaders = AxiosHeaders_default.from(
          "getAllResponseHeaders" in request && request.getAllResponseHeaders()
        );
        const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
        const response = {
          data: responseData,
          status: request.status,
          statusText: request.statusText,
          headers: responseHeaders,
          config,
          request
        };
        settle(
          function _resolve(value) {
            resolve(value);
            done();
          },
          function _reject(err) {
            reject(err);
            done();
          },
          response
        );
        request = null;
      }
      if ("onloadend" in request) {
        request.onloadend = onloadend;
      } else {
        request.onreadystatechange = function handleLoad() {
          if (!request || request.readyState !== 4) {
            return;
          }
          if (request.status === 0 && !(request.responseURL && request.responseURL.startsWith("file:"))) {
            return;
          }
          setTimeout(onloadend);
        };
      }
      request.onabort = function handleAbort() {
        if (!request) {
          return;
        }
        reject(new AxiosError_default("Request aborted", AxiosError_default.ECONNABORTED, config, request));
        done();
        request = null;
      };
      request.onerror = function handleError(event) {
        const msg = event && event.message ? event.message : "Network Error";
        const err = new AxiosError_default(msg, AxiosError_default.ERR_NETWORK, config, request);
        err.event = event || null;
        reject(err);
        done();
        request = null;
      };
      request.ontimeout = function handleTimeout() {
        let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
        const transitional2 = _config.transitional || transitional_default;
        if (_config.timeoutErrorMessage) {
          timeoutErrorMessage = _config.timeoutErrorMessage;
        }
        reject(
          new AxiosError_default(
            timeoutErrorMessage,
            transitional2.clarifyTimeoutError ? AxiosError_default.ETIMEDOUT : AxiosError_default.ECONNABORTED,
            config,
            request
          )
        );
        done();
        request = null;
      };
      requestData === void 0 && requestHeaders.setContentType(null);
      if ("setRequestHeader" in request) {
        utils_default.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
          request.setRequestHeader(key, val);
        });
      }
      if (!utils_default.isUndefined(_config.withCredentials)) {
        request.withCredentials = !!_config.withCredentials;
      }
      if (responseType && responseType !== "json") {
        request.responseType = _config.responseType;
      }
      if (onDownloadProgress) {
        [downloadThrottled, flushDownload] = progressEventReducer(onDownloadProgress, true);
        request.addEventListener("progress", downloadThrottled);
      }
      if (onUploadProgress && request.upload) {
        [uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
        request.upload.addEventListener("progress", uploadThrottled);
        request.upload.addEventListener("loadend", flushUpload);
      }
      if (_config.cancelToken || _config.signal) {
        onCanceled = (cancel) => {
          if (!request) {
            return;
          }
          reject(!cancel || cancel.type ? new CanceledError_default(null, config, request) : cancel);
          request.abort();
          done();
          request = null;
        };
        _config.cancelToken && _config.cancelToken.subscribe(onCanceled);
        if (_config.signal) {
          _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
        }
      }
      const protocol = parseProtocol(_config.url);
      if (protocol && !platform_default.protocols.includes(protocol)) {
        reject(
          new AxiosError_default(
            "Unsupported protocol " + protocol + ":",
            AxiosError_default.ERR_BAD_REQUEST,
            config
          )
        );
        return;
      }
      request.send(requestData || null);
    });
  };

  // src/client/node_modules/axios/lib/adapters/fetch.js
  init_define_import_meta_env();

  // src/client/node_modules/axios/lib/helpers/composeSignals.js
  init_define_import_meta_env();
  var composeSignals = (signals, timeout) => {
    signals = signals ? signals.filter(Boolean) : [];
    if (!timeout && !signals.length) {
      return;
    }
    const controller = new AbortController();
    let aborted = false;
    const onabort = function(reason) {
      if (!aborted) {
        aborted = true;
        unsubscribe();
        const err = reason instanceof Error ? reason : this.reason;
        controller.abort(
          err instanceof AxiosError_default ? err : new CanceledError_default(err instanceof Error ? err.message : err)
        );
      }
    };
    let timer = timeout && setTimeout(() => {
      timer = null;
      onabort(new AxiosError_default(`timeout of ${timeout}ms exceeded`, AxiosError_default.ETIMEDOUT));
    }, timeout);
    const unsubscribe = () => {
      if (!signals) {
        return;
      }
      timer && clearTimeout(timer);
      timer = null;
      signals.forEach((signal2) => {
        signal2.unsubscribe ? signal2.unsubscribe(onabort) : signal2.removeEventListener("abort", onabort);
      });
      signals = null;
    };
    signals.forEach((signal2) => signal2.addEventListener("abort", onabort));
    const { signal } = controller;
    signal.unsubscribe = () => utils_default.asap(unsubscribe);
    return signal;
  };
  var composeSignals_default = composeSignals;

  // src/client/node_modules/axios/lib/helpers/trackStream.js
  init_define_import_meta_env();
  var streamChunk = function* (chunk, chunkSize) {
    let len = chunk.byteLength;
    if (!chunkSize || len < chunkSize) {
      yield chunk;
      return;
    }
    let pos = 0;
    let end;
    while (pos < len) {
      end = pos + chunkSize;
      yield chunk.slice(pos, end);
      pos = end;
    }
  };
  var readBytes = async function* (iterable, chunkSize) {
    for await (const chunk of readStream(iterable)) {
      yield* streamChunk(chunk, chunkSize);
    }
  };
  var readStream = async function* (stream) {
    if (stream[Symbol.asyncIterator]) {
      yield* stream;
      return;
    }
    const reader = stream.getReader();
    try {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) {
          break;
        }
        yield value;
      }
    } finally {
      await reader.cancel();
    }
  };
  var trackStream = (stream, chunkSize, onProgress, onFinish) => {
    const iterator2 = readBytes(stream, chunkSize);
    let bytes = 0;
    let done;
    let _onFinish = (e) => {
      if (!done) {
        done = true;
        onFinish && onFinish(e);
      }
    };
    return new ReadableStream(
      {
        async pull(controller) {
          try {
            const { done: done2, value } = await iterator2.next();
            if (done2) {
              _onFinish();
              controller.close();
              return;
            }
            let len = value.byteLength;
            if (onProgress) {
              let loadedBytes = bytes += len;
              onProgress(loadedBytes);
            }
            controller.enqueue(new Uint8Array(value));
          } catch (err) {
            _onFinish(err);
            throw err;
          }
        },
        cancel(reason) {
          _onFinish(reason);
          return iterator2.return();
        }
      },
      {
        highWaterMark: 2
      }
    );
  };

  // src/client/node_modules/axios/lib/helpers/estimateDataURLDecodedBytes.js
  init_define_import_meta_env();
  var isHexDigit = (charCode) => charCode >= 48 && charCode <= 57 || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
  var isPercentEncodedByte = (str, i, len) => i + 2 < len && isHexDigit(str.charCodeAt(i + 1)) && isHexDigit(str.charCodeAt(i + 2));
  function estimateDataURLDecodedBytes(url) {
    if (!url || typeof url !== "string") return 0;
    if (!url.startsWith("data:")) return 0;
    const comma = url.indexOf(",");
    if (comma < 0) return 0;
    const meta = url.slice(5, comma);
    const body = url.slice(comma + 1);
    const isBase64 = /;base64/i.test(meta);
    if (isBase64) {
      let effectiveLen = body.length;
      const len = body.length;
      for (let i = 0; i < len; i++) {
        if (body.charCodeAt(i) === 37 && i + 2 < len) {
          const a = body.charCodeAt(i + 1);
          const b = body.charCodeAt(i + 2);
          const isHex = isHexDigit(a) && isHexDigit(b);
          if (isHex) {
            effectiveLen -= 2;
            i += 2;
          }
        }
      }
      let pad = 0;
      let idx = len - 1;
      const tailIsPct3D = (j) => j >= 2 && body.charCodeAt(j - 2) === 37 && // '%'
      body.charCodeAt(j - 1) === 51 && // '3'
      (body.charCodeAt(j) === 68 || body.charCodeAt(j) === 100);
      if (idx >= 0) {
        if (body.charCodeAt(idx) === 61) {
          pad++;
          idx--;
        } else if (tailIsPct3D(idx)) {
          pad++;
          idx -= 3;
        }
      }
      if (pad === 1 && idx >= 0) {
        if (body.charCodeAt(idx) === 61) {
          pad++;
        } else if (tailIsPct3D(idx)) {
          pad++;
        }
      }
      const groups = Math.floor(effectiveLen / 4);
      const bytes2 = groups * 3 - (pad || 0);
      return bytes2 > 0 ? bytes2 : 0;
    }
    let bytes = 0;
    for (let i = 0, len = body.length; i < len; i++) {
      const c = body.charCodeAt(i);
      if (c === 37 && isPercentEncodedByte(body, i, len)) {
        bytes += 1;
        i += 2;
      } else if (c < 128) {
        bytes += 1;
      } else if (c < 2048) {
        bytes += 2;
      } else if (c >= 55296 && c <= 56319 && i + 1 < len) {
        const next = body.charCodeAt(i + 1);
        if (next >= 56320 && next <= 57343) {
          bytes += 4;
          i++;
        } else {
          bytes += 3;
        }
      } else {
        bytes += 3;
      }
    }
    return bytes;
  }

  // src/client/node_modules/axios/lib/env/data.js
  init_define_import_meta_env();
  var VERSION = "1.18.0";

  // src/client/node_modules/axios/lib/adapters/fetch.js
  var DEFAULT_CHUNK_SIZE = 64 * 1024;
  var { isFunction: isFunction4 } = utils_default;
  var encodeUTF82 = (str) => encodeURIComponent(str).replace(
    /%([0-9A-F]{2})/gi,
    (_, hex) => String.fromCharCode(parseInt(hex, 16))
  );
  var decodeURIComponentSafe = (value) => {
    if (!utils_default.isString(value)) {
      return value;
    }
    try {
      return decodeURIComponent(value);
    } catch (error) {
      return value;
    }
  };
  var test = (fn, ...args) => {
    try {
      return !!fn(...args);
    } catch (e) {
      return false;
    }
  };
  var maybeWithAuthCredentials = (url) => {
    const protocolIndex = url.indexOf("://");
    let urlToCheck = url;
    if (protocolIndex !== -1) {
      urlToCheck = urlToCheck.slice(protocolIndex + 3);
    }
    return urlToCheck.includes("@") || urlToCheck.includes(":");
  };
  var factory = (env) => {
    const globalObject = utils_default.global !== void 0 && utils_default.global !== null ? utils_default.global : globalThis;
    const { ReadableStream: ReadableStream2, TextEncoder } = globalObject;
    env = utils_default.merge.call(
      {
        skipUndefined: true
      },
      {
        Request: globalObject.Request,
        Response: globalObject.Response
      },
      env
    );
    const { fetch: envFetch, Request: Request2, Response: Response2 } = env;
    const isFetchSupported = envFetch ? isFunction4(envFetch) : typeof fetch === "function";
    const isRequestSupported = isFunction4(Request2);
    const isResponseSupported = isFunction4(Response2);
    if (!isFetchSupported) {
      return false;
    }
    const isReadableStreamSupported = isFetchSupported && isFunction4(ReadableStream2);
    const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? /* @__PURE__ */ ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Request2(str).arrayBuffer()));
    const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
      let duplexAccessed = false;
      const request = new Request2(platform_default.origin, {
        body: new ReadableStream2(),
        method: "POST",
        get duplex() {
          duplexAccessed = true;
          return "half";
        }
      });
      const hasContentType = request.headers.has("Content-Type");
      if (request.body != null) {
        request.body.cancel();
      }
      return duplexAccessed && !hasContentType;
    });
    const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils_default.isReadableStream(new Response2("").body));
    const resolvers = {
      stream: supportsResponseStream && ((res) => res.body)
    };
    isFetchSupported && (() => {
      ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((type) => {
        !resolvers[type] && (resolvers[type] = (res, config) => {
          let method = res && res[type];
          if (method) {
            return method.call(res);
          }
          throw new AxiosError_default(
            `Response type '${type}' is not supported`,
            AxiosError_default.ERR_NOT_SUPPORT,
            config
          );
        });
      });
    })();
    const getBodyLength = async (body) => {
      if (body == null) {
        return 0;
      }
      if (utils_default.isBlob(body)) {
        return body.size;
      }
      if (utils_default.isSpecCompliantForm(body)) {
        const _request = new Request2(platform_default.origin, {
          method: "POST",
          body
        });
        return (await _request.arrayBuffer()).byteLength;
      }
      if (utils_default.isArrayBufferView(body) || utils_default.isArrayBuffer(body)) {
        return body.byteLength;
      }
      if (utils_default.isURLSearchParams(body)) {
        body = body + "";
      }
      if (utils_default.isString(body)) {
        return (await encodeText(body)).byteLength;
      }
    };
    const resolveBodyLength = async (headers, body) => {
      const length = utils_default.toFiniteNumber(headers.getContentLength());
      return length == null ? getBodyLength(body) : length;
    };
    return async (config) => {
      let {
        url,
        method,
        data,
        signal,
        cancelToken,
        timeout,
        onDownloadProgress,
        onUploadProgress,
        responseType,
        headers,
        withCredentials = "same-origin",
        fetchOptions,
        maxContentLength,
        maxBodyLength
      } = resolveConfig_default(config);
      const hasMaxContentLength = utils_default.isNumber(maxContentLength) && maxContentLength > -1;
      const hasMaxBodyLength = utils_default.isNumber(maxBodyLength) && maxBodyLength > -1;
      const own2 = (key) => utils_default.hasOwnProp(config, key) ? config[key] : void 0;
      let _fetch = envFetch || fetch;
      responseType = responseType ? (responseType + "").toLowerCase() : "text";
      let composedSignal = composeSignals_default(
        [signal, cancelToken && cancelToken.toAbortSignal()],
        timeout
      );
      let request = null;
      const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
        composedSignal.unsubscribe();
      });
      let requestContentLength;
      let pendingBodyError = null;
      const maxBodyLengthError = () => new AxiosError_default(
        "Request body larger than maxBodyLength limit",
        AxiosError_default.ERR_BAD_REQUEST,
        config,
        request
      );
      try {
        let auth = void 0;
        const configAuth = own2("auth");
        if (configAuth) {
          const username = utils_default.getSafeProp(configAuth, "username") || "";
          const password = utils_default.getSafeProp(configAuth, "password") || "";
          auth = {
            username,
            password
          };
        }
        if (maybeWithAuthCredentials(url)) {
          const parsedURL = new URL(url, platform_default.origin);
          if (!auth && (parsedURL.username || parsedURL.password)) {
            const urlUsername = decodeURIComponentSafe(parsedURL.username);
            const urlPassword = decodeURIComponentSafe(parsedURL.password);
            auth = {
              username: urlUsername,
              password: urlPassword
            };
          }
          if (parsedURL.username || parsedURL.password) {
            parsedURL.username = "";
            parsedURL.password = "";
            url = parsedURL.href;
          }
        }
        if (auth) {
          headers.delete("authorization");
          headers.set(
            "Authorization",
            "Basic " + btoa(encodeUTF82((auth.username || "") + ":" + (auth.password || "")))
          );
        }
        if (hasMaxContentLength && typeof url === "string" && url.startsWith("data:")) {
          const estimated = estimateDataURLDecodedBytes(url);
          if (estimated > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config,
              request
            );
          }
        }
        if (hasMaxBodyLength && method !== "get" && method !== "head") {
          const outboundLength = await getBodyLength(data);
          if (typeof outboundLength === "number" && isFinite(outboundLength)) {
            requestContentLength = outboundLength;
            if (outboundLength > maxBodyLength) {
              throw maxBodyLengthError();
            }
          }
        }
        const mustEnforceStreamBody = hasMaxBodyLength && (utils_default.isReadableStream(data) || utils_default.isStream(data));
        const trackRequestStream = (stream, onProgress, flush) => trackStream(
          stream,
          DEFAULT_CHUNK_SIZE,
          (loadedBytes) => {
            if (hasMaxBodyLength && loadedBytes > maxBodyLength) {
              throw pendingBodyError = maxBodyLengthError();
            }
            onProgress && onProgress(loadedBytes);
          },
          flush
        );
        if (supportsRequestStream && method !== "get" && method !== "head" && (onUploadProgress || mustEnforceStreamBody)) {
          requestContentLength = requestContentLength == null ? await resolveBodyLength(headers, data) : requestContentLength;
          if (requestContentLength !== 0 || mustEnforceStreamBody) {
            let _request = new Request2(url, {
              method: "POST",
              body: data,
              duplex: "half"
            });
            let contentTypeHeader;
            if (utils_default.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) {
              headers.setContentType(contentTypeHeader);
            }
            if (_request.body) {
              const [onProgress, flush] = onUploadProgress && progressEventDecorator(
                requestContentLength,
                progressEventReducer(asyncDecorator(onUploadProgress))
              ) || [];
              data = trackRequestStream(_request.body, onProgress, flush);
            }
          }
        } else if (mustEnforceStreamBody && !isRequestSupported && isReadableStreamSupported && method !== "get" && method !== "head") {
          data = trackRequestStream(data);
        } else if (mustEnforceStreamBody && isRequestSupported && !supportsRequestStream && method !== "get" && method !== "head") {
          throw new AxiosError_default(
            "Stream request bodies are not supported by the current fetch implementation",
            AxiosError_default.ERR_NOT_SUPPORT,
            config,
            request
          );
        }
        if (!utils_default.isString(withCredentials)) {
          withCredentials = withCredentials ? "include" : "omit";
        }
        const isCredentialsSupported = isRequestSupported && "credentials" in Request2.prototype;
        if (utils_default.isFormData(data)) {
          const contentType = headers.getContentType();
          if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) {
            headers.delete("content-type");
          }
        }
        headers.set("User-Agent", "axios/" + VERSION, false);
        const resolvedOptions = {
          ...fetchOptions,
          signal: composedSignal,
          method: method.toUpperCase(),
          headers: toByteStringHeaderObject(headers.normalize()),
          body: data,
          duplex: "half",
          credentials: isCredentialsSupported ? withCredentials : void 0
        };
        request = isRequestSupported && new Request2(url, resolvedOptions);
        let response = await (isRequestSupported ? _fetch(request, fetchOptions) : _fetch(url, resolvedOptions));
        const responseHeaders = AxiosHeaders_default.from(response.headers);
        if (hasMaxContentLength) {
          const declaredLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
          if (declaredLength != null && declaredLength > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config,
              request
            );
          }
        }
        const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
        if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
          const options2 = {};
          ["status", "statusText", "headers"].forEach((prop) => {
            options2[prop] = response[prop];
          });
          const responseContentLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
          const [onProgress, flush] = onDownloadProgress && progressEventDecorator(
            responseContentLength,
            progressEventReducer(asyncDecorator(onDownloadProgress), true)
          ) || [];
          let bytesRead = 0;
          const onChunkProgress = (loadedBytes) => {
            if (hasMaxContentLength) {
              bytesRead = loadedBytes;
              if (bytesRead > maxContentLength) {
                throw new AxiosError_default(
                  "maxContentLength size of " + maxContentLength + " exceeded",
                  AxiosError_default.ERR_BAD_RESPONSE,
                  config,
                  request
                );
              }
            }
            onProgress && onProgress(loadedBytes);
          };
          response = new Response2(
            trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
              flush && flush();
              unsubscribe && unsubscribe();
            }),
            options2
          );
        }
        responseType = responseType || "text";
        let responseData = await resolvers[utils_default.findKey(resolvers, responseType) || "text"](
          response,
          config
        );
        if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
          let materializedSize;
          if (responseData != null) {
            if (typeof responseData.byteLength === "number") {
              materializedSize = responseData.byteLength;
            } else if (typeof responseData.size === "number") {
              materializedSize = responseData.size;
            } else if (typeof responseData === "string") {
              materializedSize = typeof TextEncoder === "function" ? new TextEncoder().encode(responseData).byteLength : responseData.length;
            }
          }
          if (typeof materializedSize === "number" && materializedSize > maxContentLength) {
            throw new AxiosError_default(
              "maxContentLength size of " + maxContentLength + " exceeded",
              AxiosError_default.ERR_BAD_RESPONSE,
              config,
              request
            );
          }
        }
        !isStreamResponse && unsubscribe && unsubscribe();
        return await new Promise((resolve, reject) => {
          settle(resolve, reject, {
            data: responseData,
            headers: AxiosHeaders_default.from(response.headers),
            status: response.status,
            statusText: response.statusText,
            config,
            request
          });
        });
      } catch (err) {
        unsubscribe && unsubscribe();
        if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError_default) {
          const canceledError = composedSignal.reason;
          canceledError.config = config;
          request && (canceledError.request = request);
          err !== canceledError && (canceledError.cause = err);
          throw canceledError;
        }
        if (pendingBodyError) {
          request && !pendingBodyError.request && (pendingBodyError.request = request);
          throw pendingBodyError;
        }
        if (err instanceof AxiosError_default) {
          request && !err.request && (err.request = request);
          throw err;
        }
        if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
          throw Object.assign(
            new AxiosError_default(
              "Network Error",
              AxiosError_default.ERR_NETWORK,
              config,
              request,
              err && err.response
            ),
            {
              cause: err.cause || err
            }
          );
        }
        throw AxiosError_default.from(err, err && err.code, config, request, err && err.response);
      }
    };
  };
  var seedCache = /* @__PURE__ */ new Map();
  var getFetch = (config) => {
    let env = config && config.env || {};
    const { fetch: fetch2, Request: Request2, Response: Response2 } = env;
    const seeds = [Request2, Response2, fetch2];
    let len = seeds.length, i = len, seed, target, map = seedCache;
    while (i--) {
      seed = seeds[i];
      target = map.get(seed);
      target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
      map = target;
    }
    return target;
  };
  var adapter = getFetch();

  // src/client/node_modules/axios/lib/adapters/adapters.js
  var knownAdapters = {
    http: null_default,
    xhr: xhr_default,
    fetch: {
      get: getFetch
    }
  };
  utils_default.forEach(knownAdapters, (fn, value) => {
    if (fn) {
      try {
        Object.defineProperty(fn, "name", { __proto__: null, value });
      } catch (e) {
      }
      Object.defineProperty(fn, "adapterName", { __proto__: null, value });
    }
  });
  var renderReason = (reason) => `- ${reason}`;
  var isResolvedHandle = (adapter2) => utils_default.isFunction(adapter2) || adapter2 === null || adapter2 === false;
  function getAdapter(adapters, config) {
    adapters = utils_default.isArray(adapters) ? adapters : [adapters];
    const { length } = adapters;
    let nameOrAdapter;
    let adapter2;
    const rejectedReasons = {};
    for (let i = 0; i < length; i++) {
      nameOrAdapter = adapters[i];
      let id;
      adapter2 = nameOrAdapter;
      if (!isResolvedHandle(nameOrAdapter)) {
        adapter2 = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
        if (adapter2 === void 0) {
          throw new AxiosError_default(`Unknown adapter '${id}'`);
        }
      }
      if (adapter2 && (utils_default.isFunction(adapter2) || (adapter2 = adapter2.get(config)))) {
        break;
      }
      rejectedReasons[id || "#" + i] = adapter2;
    }
    if (!adapter2) {
      const reasons = Object.entries(rejectedReasons).map(
        ([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build")
      );
      let s = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
      throw new AxiosError_default(
        `There is no suitable adapter to dispatch the request ` + s,
        "ERR_NOT_SUPPORT"
      );
    }
    return adapter2;
  }
  var adapters_default = {
    /**
     * Resolve an adapter from a list of adapter names or functions.
     * @type {Function}
     */
    getAdapter,
    /**
     * Exposes all known adapters
     * @type {Object<string, Function|Object>}
     */
    adapters: knownAdapters
  };

  // src/client/node_modules/axios/lib/core/dispatchRequest.js
  function throwIfCancellationRequested(config) {
    if (config.cancelToken) {
      config.cancelToken.throwIfRequested();
    }
    if (config.signal && config.signal.aborted) {
      throw new CanceledError_default(null, config);
    }
  }
  function dispatchRequest(config) {
    throwIfCancellationRequested(config);
    config.headers = AxiosHeaders_default.from(config.headers);
    config.data = transformData.call(config, config.transformRequest);
    if (["post", "put", "patch"].indexOf(config.method) !== -1) {
      config.headers.setContentType("application/x-www-form-urlencoded", false);
    }
    const adapter2 = adapters_default.getAdapter(config.adapter || defaults_default.adapter, config);
    return adapter2(config).then(
      function onAdapterResolution(response) {
        throwIfCancellationRequested(config);
        config.response = response;
        try {
          response.data = transformData.call(config, config.transformResponse, response);
        } finally {
          delete config.response;
        }
        response.headers = AxiosHeaders_default.from(response.headers);
        return response;
      },
      function onAdapterRejection(reason) {
        if (!isCancel(reason)) {
          throwIfCancellationRequested(config);
          if (reason && reason.response) {
            config.response = reason.response;
            try {
              reason.response.data = transformData.call(
                config,
                config.transformResponse,
                reason.response
              );
            } finally {
              delete config.response;
            }
            reason.response.headers = AxiosHeaders_default.from(reason.response.headers);
          }
        }
        return Promise.reject(reason);
      }
    );
  }

  // src/client/node_modules/axios/lib/helpers/validator.js
  init_define_import_meta_env();
  var validators = {};
  ["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i) => {
    validators[type] = function validator(thing) {
      return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
    };
  });
  var deprecatedWarnings = {};
  validators.transitional = function transitional(validator, version, message) {
    function formatMessage(opt, desc) {
      return "[Axios v" + VERSION + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
    }
    return (value, opt, opts) => {
      if (validator === false) {
        throw new AxiosError_default(
          formatMessage(opt, " has been removed" + (version ? " in " + version : "")),
          AxiosError_default.ERR_DEPRECATED
        );
      }
      if (version && !deprecatedWarnings[opt]) {
        deprecatedWarnings[opt] = true;
        console.warn(
          formatMessage(
            opt,
            " has been deprecated since v" + version + " and will be removed in the near future"
          )
        );
      }
      return validator ? validator(value, opt, opts) : true;
    };
  };
  validators.spelling = function spelling(correctSpelling) {
    return (value, opt) => {
      console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
      return true;
    };
  };
  function assertOptions(options2, schema, allowUnknown) {
    if (typeof options2 !== "object") {
      throw new AxiosError_default("options must be an object", AxiosError_default.ERR_BAD_OPTION_VALUE);
    }
    const keys = Object.keys(options2);
    let i = keys.length;
    while (i-- > 0) {
      const opt = keys[i];
      const validator = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
      if (validator) {
        const value = options2[opt];
        const result = value === void 0 || validator(value, opt, options2);
        if (result !== true) {
          throw new AxiosError_default(
            "option " + opt + " must be " + result,
            AxiosError_default.ERR_BAD_OPTION_VALUE
          );
        }
        continue;
      }
      if (allowUnknown !== true) {
        throw new AxiosError_default("Unknown option " + opt, AxiosError_default.ERR_BAD_OPTION);
      }
    }
  }
  var validator_default = {
    assertOptions,
    validators
  };

  // src/client/node_modules/axios/lib/core/Axios.js
  var validators2 = validator_default.validators;
  var Axios = class {
    constructor(instanceConfig) {
      this.defaults = instanceConfig || {};
      this.interceptors = {
        request: new InterceptorManager_default(),
        response: new InterceptorManager_default()
      };
    }
    /**
     * Dispatch a request
     *
     * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
     * @param {?Object} config
     *
     * @returns {Promise} The Promise to be fulfilled
     */
    async request(configOrUrl, config) {
      try {
        return await this._request(configOrUrl, config);
      } catch (err) {
        if (err instanceof Error) {
          let dummy = {};
          Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = new Error();
          const stack = (() => {
            if (!dummy.stack) {
              return "";
            }
            const firstNewlineIndex = dummy.stack.indexOf("\n");
            return firstNewlineIndex === -1 ? "" : dummy.stack.slice(firstNewlineIndex + 1);
          })();
          try {
            if (!err.stack) {
              err.stack = stack;
            } else if (stack) {
              const firstNewlineIndex = stack.indexOf("\n");
              const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
              const stackWithoutTwoTopLines = secondNewlineIndex === -1 ? "" : stack.slice(secondNewlineIndex + 1);
              if (!String(err.stack).endsWith(stackWithoutTwoTopLines)) {
                err.stack += "\n" + stack;
              }
            }
          } catch (e) {
          }
        }
        throw err;
      }
    }
    _request(configOrUrl, config) {
      if (typeof configOrUrl === "string") {
        config = config || {};
        config.url = configOrUrl;
      } else {
        config = configOrUrl || {};
      }
      config = mergeConfig(this.defaults, config);
      const { transitional: transitional2, paramsSerializer, headers } = config;
      if (transitional2 !== void 0) {
        validator_default.assertOptions(
          transitional2,
          {
            silentJSONParsing: validators2.transitional(validators2.boolean),
            forcedJSONParsing: validators2.transitional(validators2.boolean),
            clarifyTimeoutError: validators2.transitional(validators2.boolean),
            legacyInterceptorReqResOrdering: validators2.transitional(validators2.boolean),
            advertiseZstdAcceptEncoding: validators2.transitional(validators2.boolean),
            validateStatusUndefinedResolves: validators2.transitional(validators2.boolean)
          },
          false
        );
      }
      if (paramsSerializer != null) {
        if (utils_default.isFunction(paramsSerializer)) {
          config.paramsSerializer = {
            serialize: paramsSerializer
          };
        } else {
          validator_default.assertOptions(
            paramsSerializer,
            {
              encode: validators2.function,
              serialize: validators2.function
            },
            true
          );
        }
      }
      if (config.allowAbsoluteUrls !== void 0) {
      } else if (this.defaults.allowAbsoluteUrls !== void 0) {
        config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
      } else {
        config.allowAbsoluteUrls = true;
      }
      validator_default.assertOptions(
        config,
        {
          baseUrl: validators2.spelling("baseURL"),
          withXsrfToken: validators2.spelling("withXSRFToken")
        },
        true
      );
      config.method = (config.method || this.defaults.method || "get").toLowerCase();
      let contextHeaders = headers && utils_default.merge(headers.common, headers[config.method]);
      headers && utils_default.forEach(["delete", "get", "head", "post", "put", "patch", "query", "common"], (method) => {
        delete headers[method];
      });
      config.headers = AxiosHeaders_default.concat(contextHeaders, headers);
      const requestInterceptorChain = [];
      let synchronousRequestInterceptors = true;
      this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
        if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) {
          return;
        }
        synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
        const transitional3 = config.transitional || transitional_default;
        const legacyInterceptorReqResOrdering = transitional3 && transitional3.legacyInterceptorReqResOrdering;
        if (legacyInterceptorReqResOrdering) {
          requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
        } else {
          requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
        }
      });
      const responseInterceptorChain = [];
      this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
        responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
      });
      let promise;
      let i = 0;
      let len;
      if (!synchronousRequestInterceptors) {
        const chain = [dispatchRequest.bind(this), void 0];
        chain.unshift(...requestInterceptorChain);
        chain.push(...responseInterceptorChain);
        len = chain.length;
        promise = Promise.resolve(config);
        while (i < len) {
          promise = promise.then(chain[i++], chain[i++]);
        }
        return promise;
      }
      len = requestInterceptorChain.length;
      let newConfig = config;
      while (i < len) {
        const onFulfilled = requestInterceptorChain[i++];
        const onRejected = requestInterceptorChain[i++];
        try {
          newConfig = onFulfilled(newConfig);
        } catch (error) {
          onRejected.call(this, error);
          break;
        }
      }
      try {
        promise = dispatchRequest.call(this, newConfig);
      } catch (error) {
        return Promise.reject(error);
      }
      i = 0;
      len = responseInterceptorChain.length;
      while (i < len) {
        promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
      }
      return promise;
    }
    getUri(config) {
      config = mergeConfig(this.defaults, config);
      const fullPath = buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls, config);
      return buildURL(fullPath, config.params, config.paramsSerializer);
    }
  };
  utils_default.forEach(["delete", "get", "head", "options"], function forEachMethodNoData(method) {
    Axios.prototype[method] = function(url, config) {
      return this.request(
        mergeConfig(config || {}, {
          method,
          url,
          data: config && utils_default.hasOwnProp(config, "data") ? config.data : void 0
        })
      );
    };
  });
  utils_default.forEach(["post", "put", "patch", "query"], function forEachMethodWithData(method) {
    function generateHTTPMethod(isForm) {
      return function httpMethod(url, data, config) {
        return this.request(
          mergeConfig(config || {}, {
            method,
            headers: isForm ? {
              "Content-Type": "multipart/form-data"
            } : {},
            url,
            data
          })
        );
      };
    }
    Axios.prototype[method] = generateHTTPMethod();
    if (method !== "query") {
      Axios.prototype[method + "Form"] = generateHTTPMethod(true);
    }
  });
  var Axios_default = Axios;

  // src/client/node_modules/axios/lib/cancel/CancelToken.js
  init_define_import_meta_env();
  var CancelToken = class _CancelToken {
    constructor(executor) {
      if (typeof executor !== "function") {
        throw new TypeError("executor must be a function.");
      }
      let resolvePromise;
      this.promise = new Promise(function promiseExecutor(resolve) {
        resolvePromise = resolve;
      });
      const token = this;
      this.promise.then((cancel) => {
        if (!token._listeners) return;
        let i = token._listeners.length;
        while (i-- > 0) {
          token._listeners[i](cancel);
        }
        token._listeners = null;
      });
      this.promise.then = (onfulfilled) => {
        let _resolve;
        const promise = new Promise((resolve) => {
          token.subscribe(resolve);
          _resolve = resolve;
        }).then(onfulfilled);
        promise.cancel = function reject() {
          token.unsubscribe(_resolve);
        };
        return promise;
      };
      executor(function cancel(message, config, request) {
        if (token.reason) {
          return;
        }
        token.reason = new CanceledError_default(message, config, request);
        resolvePromise(token.reason);
      });
    }
    /**
     * Throws a `CanceledError` if cancellation has been requested.
     */
    throwIfRequested() {
      if (this.reason) {
        throw this.reason;
      }
    }
    /**
     * Subscribe to the cancel signal
     */
    subscribe(listener) {
      if (this.reason) {
        listener(this.reason);
        return;
      }
      if (this._listeners) {
        this._listeners.push(listener);
      } else {
        this._listeners = [listener];
      }
    }
    /**
     * Unsubscribe from the cancel signal
     */
    unsubscribe(listener) {
      if (!this._listeners) {
        return;
      }
      const index2 = this._listeners.indexOf(listener);
      if (index2 !== -1) {
        this._listeners.splice(index2, 1);
      }
    }
    toAbortSignal() {
      const controller = new AbortController();
      const abort = (err) => {
        controller.abort(err);
      };
      this.subscribe(abort);
      controller.signal.unsubscribe = () => this.unsubscribe(abort);
      return controller.signal;
    }
    /**
     * Returns an object that contains a new `CancelToken` and a function that, when called,
     * cancels the `CancelToken`.
     */
    static source() {
      let cancel;
      const token = new _CancelToken(function executor(c) {
        cancel = c;
      });
      return {
        token,
        cancel
      };
    }
  };
  var CancelToken_default = CancelToken;

  // src/client/node_modules/axios/lib/helpers/spread.js
  init_define_import_meta_env();
  function spread(callback) {
    return function wrap(arr) {
      return callback.apply(null, arr);
    };
  }

  // src/client/node_modules/axios/lib/helpers/isAxiosError.js
  init_define_import_meta_env();
  function isAxiosError(payload) {
    return utils_default.isObject(payload) && payload.isAxiosError === true;
  }

  // src/client/node_modules/axios/lib/helpers/HttpStatusCode.js
  init_define_import_meta_env();
  var HttpStatusCode = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511,
    WebServerIsDown: 521,
    ConnectionTimedOut: 522,
    OriginIsUnreachable: 523,
    TimeoutOccurred: 524,
    SslHandshakeFailed: 525,
    InvalidSslCertificate: 526
  };
  Object.entries(HttpStatusCode).forEach(([key, value]) => {
    HttpStatusCode[value] = key;
  });
  var HttpStatusCode_default = HttpStatusCode;

  // src/client/node_modules/axios/lib/axios.js
  function createInstance(defaultConfig) {
    const context = new Axios_default(defaultConfig);
    const instance = bind(Axios_default.prototype.request, context);
    utils_default.extend(instance, Axios_default.prototype, context, { allOwnKeys: true });
    utils_default.extend(instance, context, null, { allOwnKeys: true });
    instance.create = function create2(instanceConfig) {
      return createInstance(mergeConfig(defaultConfig, instanceConfig));
    };
    return instance;
  }
  var axios = createInstance(defaults_default);
  axios.Axios = Axios_default;
  axios.CanceledError = CanceledError_default;
  axios.CancelToken = CancelToken_default;
  axios.isCancel = isCancel;
  axios.VERSION = VERSION;
  axios.toFormData = toFormData_default;
  axios.AxiosError = AxiosError_default;
  axios.Cancel = axios.CanceledError;
  axios.all = function all(promises) {
    return Promise.all(promises);
  };
  axios.spread = spread;
  axios.isAxiosError = isAxiosError;
  axios.mergeConfig = mergeConfig;
  axios.AxiosHeaders = AxiosHeaders_default;
  axios.formToJSON = (thing) => formDataToJSON_default(utils_default.isHTMLForm(thing) ? new FormData(thing) : thing);
  axios.getAdapter = adapters_default.getAdapter;
  axios.HttpStatusCode = HttpStatusCode_default;
  axios.default = axios;
  var axios_default = axios;

  // src/client/node_modules/axios/index.js
  var {
    Axios: Axios2,
    AxiosError: AxiosError2,
    CanceledError: CanceledError2,
    isCancel: isCancel2,
    CancelToken: CancelToken2,
    VERSION: VERSION2,
    all: all2,
    Cancel,
    isAxiosError: isAxiosError2,
    spread: spread2,
    toFormData: toFormData2,
    AxiosHeaders: AxiosHeaders2,
    HttpStatusCode: HttpStatusCode2,
    formToJSON,
    getAdapter: getAdapter2,
    mergeConfig: mergeConfig2,
    create
  } = axios_default;

  // src/client/src/shared/api/token.ts
  init_define_import_meta_env();
  var ACCESS = "access_token";
  var REFRESH = "refresh_token";
  var listeners = /* @__PURE__ */ new Set();
  function announce(access) {
    for (const listener of listeners) listener(access);
  }
  function getToken() {
    return localStorage.getItem(ACCESS) ?? sessionStorage.getItem(ACCESS);
  }
  function getRefreshToken() {
    return localStorage.getItem(REFRESH) ?? sessionStorage.getItem(REFRESH);
  }
  function replaceTokens(access, refresh) {
    const inSession = sessionStorage.getItem(ACCESS) !== null;
    const store = inSession ? sessionStorage : localStorage;
    store.setItem(ACCESS, access);
    store.setItem(REFRESH, refresh);
    announce(access);
  }
  function clearToken() {
    localStorage.removeItem(ACCESS);
    sessionStorage.removeItem(ACCESS);
    localStorage.removeItem(REFRESH);
    sessionStorage.removeItem(REFRESH);
    announce(null);
  }

  // src/client/src/shared/api/apiErrorLog.ts
  init_define_import_meta_env();
  var CAPACITY = 15;
  var buffer = [];
  function recordApiError(record) {
    const same = buffer.findIndex((e) => e.method === record.method && e.url === record.url && e.status === record.status);
    if (same >= 0) {
      const [prev] = buffer.splice(same, 1);
      buffer.push({ ...record, count: (prev.count ?? 1) + 1 });
      return;
    }
    buffer.push({ ...record, count: 1 });
    if (buffer.length > CAPACITY) buffer.splice(0, buffer.length - CAPACITY);
  }

  // src/client/src/shared/format/format.ts
  init_define_import_meta_env();

  // src/client/src/shared/hooks/useLocale.ts
  init_define_import_meta_env();
  var import_react23 = __toESM(require_react_shim());
  var LOCALE_KEY = "crg.locale";
  var SYSTEM_LOCALE = "system";
  var LocaleContext = (0, import_react23.createContext)(
    [SYSTEM_LOCALE, () => {
    }, "idle"]
  );
  function resolveLocale(stored2) {
    return stored2 === SYSTEM_LOCALE ? navigator.language : stored2;
  }

  // src/client/src/shared/format/format.ts
  var DEFAULT_CURRENCY = "RUB";
  var CURRENCY_KEY = "crg.currency";
  var stored = readMirror();
  var known = false;
  var currency = readCurrencyMirror();
  function readMirror() {
    try {
      return localStorage.getItem(LOCALE_KEY) ?? SYSTEM_LOCALE;
    } catch {
      return SYSTEM_LOCALE;
    }
  }
  function readCurrencyMirror() {
    try {
      const mirrored = localStorage.getItem(CURRENCY_KEY);
      if (!mirrored || !isCurrency(mirrored)) return DEFAULT_CURRENCY;
      known = true;
      return mirrored;
    } catch {
      return DEFAULT_CURRENCY;
    }
  }
  function isCurrency(code) {
    try {
      new Intl.NumberFormat("ru-RU", { style: "currency", currency: code });
      return true;
    } catch {
      return false;
    }
  }
  function formatLocale() {
    return resolveLocale(stored);
  }
  var dates = /* @__PURE__ */ new Map();
  function dateFormat(key, options2) {
    let format = dates.get(key);
    if (!format) dates.set(key, format = new Intl.DateTimeFormat(formatLocale(), options2));
    return format;
  }
  var DAY = { day: "2-digit", month: "2-digit", year: "numeric" };
  var DAY_UTC = { ...DAY, timeZone: "UTC" };
  var MINUTE = { ...DAY, hour: "2-digit", minute: "2-digit" };
  var TIME = { hour: "2-digit", minute: "2-digit" };
  var TIME_SECONDS = { ...TIME, second: "2-digit" };
  function formatTimeSeconds(value) {
    return render(value, "time:second", TIME_SECONDS);
  }
  function render(value, key, options2) {
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : dateFormat(key, options2).format(date);
  }

  // src/client/src/shared/api/client.ts
  function traceIdOf(e) {
    return e?.traceId;
  }
  var baseURL = define_import_meta_env_default.VITE_API_URL ?? "/api";
  var apiClient = axios_default.create({ baseURL });
  apiClient.interceptors.request.use((config) => {
    const token = getToken();
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  });
  var refreshPromise = null;
  async function refreshAccess() {
    const refresh = getRefreshToken();
    if (!refresh) return null;
    try {
      const { data } = await axios_default.post(
        `${baseURL}/auth/refresh`,
        { refreshToken: refresh }
      );
      replaceTokens(data.accessToken, data.refreshToken);
      return data.accessToken;
    } catch {
      return null;
    }
  }
  function toLogin() {
    clearToken();
    if (window.location.pathname !== "/login") window.location.href = "/login";
  }
  apiClient.interceptors.response.use(
    (r) => r,
    async (err) => {
      const original = err.config;
      const url = original?.url ?? "";
      const isAuthCall = url.includes("/auth/refresh") || url.includes("/auth/login");
      if (err.response?.status === 401 && original && !isAuthCall) {
        if (!original._retried && getRefreshToken()) {
          original._retried = true;
          refreshPromise ?? (refreshPromise = refreshAccess().finally(() => {
            refreshPromise = null;
          }));
          const newAccess = await refreshPromise;
          if (newAccess) {
            original.headers.Authorization = `Bearer ${newAccess}`;
            return apiClient(original);
          }
        }
        toLogin();
      }
      const body = err.response?.data;
      const serverMessage = body?.error ?? body?.detail;
      if (serverMessage) err.message = serverMessage;
      const traceId = typeof body?.traceId === "string" && body.traceId ? body.traceId : void 0;
      if (traceId) err.traceId = traceId;
      recordApiError({
        at: formatTimeSeconds(/* @__PURE__ */ new Date()),
        method: (original?.method ?? "GET").toUpperCase(),
        url,
        status: err.response?.status ?? 0,
        traceId
      });
      return Promise.reject(err);
    }
  );

  // src/client/src/shared/api/tags.ts
  function tagCode(raw) {
    const value = raw.trim();
    const sep = value.indexOf(":");
    return sep < 0 ? value : value.slice(0, sep).trim();
  }
  function tagOrder(raw) {
    const sep = raw.indexOf(":");
    if (sep < 0) return null;
    const param = raw.slice(sep + 1).trim();
    return /^\d+$/.test(param) ? Number(param) : null;
  }
  function tagLabelOf(registry, entry) {
    const code = tagCode(entry);
    return (registry ?? []).find((t) => t.code === code)?.label ?? code;
  }
  function hasTag(tags, code) {
    return !!tags?.some((t) => tagCode(t) === code);
  }
  function findTagEntry(tags, code) {
    return tags?.find((t) => tagCode(t) === code);
  }
  function withTagOrder(tags, code, order) {
    return tags.map((t) => tagCode(t) === code ? order === null ? code : `${code}:${order}` : t);
  }
  function useTagRegistry() {
    return useQuery({
      queryKey: ["tag-registry"],
      queryFn: () => apiClient.get("/tags").then((r) => r.data),
      staleTime: 5 * 6e4
    });
  }
  function fieldTags(all3, fieldType, roles, placed) {
    return offeredInRoles(
      (all3 ?? []).filter((t) => t.scope === "Field" && (t.appliesTo.length === 0 || t.appliesTo.includes(fieldType))),
      roles,
      placed
    );
  }
  function offeredInRoles(tags, roles, placed) {
    if (!roles) return tags;
    return tags.filter((t) => !t.role || roles.includes(t.role) || hasTag(placed, t.code));
  }
  function unknownTagCodes(fieldTags2, all3) {
    if (!all3 || !fieldTags2?.length) return [];
    const known2 = new Set(all3.map((t) => t.code));
    return [...new Set(fieldTags2.map(tagCode).filter((c) => !known2.has(c)))];
  }

  // src/client/src/shared/utils/rowIdentity.ts
  init_define_import_meta_env();
  var ROW_UID = /* @__PURE__ */ Symbol("rowUid");
  var counter = 0;
  function withRowUid(row) {
    return row[ROW_UID] ? row : { ...row, [ROW_UID]: `r${++counter}` };
  }

  // src/client/src/shared/api/schema.ts
  var FIELD_UID = ROW_UID;
  function withFieldUid(field) {
    return withRowUid(field);
  }

  // src/client/src/features/settings/schemaConstants.ts
  init_define_import_meta_env();
  function toCamelKey(title) {
    return title.split(/[^A-Za-zА-Яа-яЁё0-9]+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join("");
  }
  function nextAutoKey(currentKey, currentTitle, newTitle, isNew) {
    const isAuto = isNew && (!currentKey.trim() || currentKey === toCamelKey(currentTitle));
    return isAuto ? toCamelKey(newTitle) : currentKey;
  }
  function nextSavedKey(savedKey, currentKey, persistedKeys, prevPersistedKeys) {
    const key = currentKey.trim();
    if (!persistedKeys?.has(key)) return savedKey;
    if (prevPersistedKeys?.has(key)) return savedKey;
    return key;
  }
  var PRIMITIVE_TYPES = [
    { value: "string", label: "\u0421\u0442\u0440\u043E\u043A\u0430" },
    { value: "text", label: "\u0422\u0435\u043A\u0441\u0442" },
    { value: "number", label: "\u0427\u0438\u0441\u043B\u043E" },
    { value: "date", label: "\u0414\u0430\u0442\u0430" },
    { value: "boolean", label: "\u0424\u043B\u0430\u0433" },
    { value: "enum", label: "\u041F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435" },
    { value: "primitive", label: "\u0422\u0438\u043F \u043F\u043E\u043B\u044F (\u0441\u0432\u043E\u0439)" },
    { value: "complex", label: "\u0421\u043E\u0441\u0442\u0430\u0432\u043D\u043E\u0439 \u0442\u0438\u043F" },
    { value: "array", label: "\u041C\u0430\u0441\u0441\u0438\u0432 (\u043F\u043E\u0432\u0442. \u0441\u0442\u0440\u043E\u043A\u0438)" },
    { value: "doc-ref", label: "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 (\u0441\u0441\u044B\u043B\u043A\u0430)" },
    { value: "doc-array", label: "\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B (\u0441\u043F\u0438\u0441\u043E\u043A)" },
    { value: "image", label: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435" },
    { value: "file", label: "\u0424\u0430\u0439\u043B (\u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0435)" }
  ];
  var TYPE_LABELS = Object.fromEntries(
    PRIMITIVE_TYPES.map((t) => [t.value, t.label])
  );

  // src/client/src/features/settings/fieldTypeOptions.ts
  init_define_import_meta_env();

  // src/client/src/shared/api/typeOwners.ts
  init_define_import_meta_env();
  var CORE_OWNER = "core";
  function isOfferedType(type, access) {
    if (!access) return true;
    return type.module === CORE_OWNER || access.modules.some((m) => m.code === type.module);
  }
  function offeredTypes(types, access) {
    return access ? types.filter((t) => isOfferedType(t, access)) : types;
  }

  // src/client/src/features/settings/fieldTypeOptions.ts
  function fieldTypeSummary(f, reg) {
    if (f.type === "complex" || f.type === "array") {
      const ct = reg.compositeTypes.find((c) => c.id === f.typeId);
      return ct ? ct.name : f.type === "array" ? "\u041C\u0430\u0441\u0441\u0438\u0432" : "\u0421\u043E\u0441\u0442\u0430\u0432\u043D\u043E\u0439";
    }
    if (f.type === "enum") {
      const et = reg.enumTypes.find((e) => e.id === f.typeId);
      return et ? et.name : "\u041F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0435";
    }
    if (f.type === "primitive") {
      const pt = reg.primitiveTypes.find((p) => p.id === f.typeId);
      return pt ? pt.name : "\u0422\u0438\u043F \u043F\u043E\u043B\u044F";
    }
    return TYPE_LABELS[f.type] ?? f.type;
  }
  var BUILTIN_TYPES = [
    { type: "string", label: "\u0421\u0442\u0440\u043E\u043A\u0430" },
    { type: "text", label: "\u0422\u0435\u043A\u0441\u0442" },
    { type: "number", label: "\u0427\u0438\u0441\u043B\u043E" },
    { type: "date", label: "\u0414\u0430\u0442\u0430" },
    { type: "boolean", label: "\u0424\u043B\u0430\u0433" },
    { type: "image", label: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435" },
    { type: "file", label: "\u0424\u0430\u0439\u043B (\u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0435)" }
  ];
  function buildFieldTypeOptions(reg, access) {
    const opts = [];
    const composites = offeredTypes(reg.compositeTypes, access);
    for (const b of BUILTIN_TYPES) opts.push({ id: `builtin::${b.type}`, name: b.label, code: b.type, section: "\u0411\u0430\u0437\u043E\u0432\u044B\u0435" });
    for (const pt of reg.primitiveTypes) opts.push({ id: `primitive::${pt.id}`, name: pt.name, code: pt.code, section: "\u0422\u0438\u043F\u044B \u043F\u043E\u043B\u0435\u0439 (\u0440\u0435\u0435\u0441\u0442\u0440)" });
    for (const et of reg.enumTypes) opts.push({ id: `enum::${et.id}`, name: `${et.name} \xB7 ${et.values.length}`, code: et.code, section: "\u041F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F" });
    for (const ct of composites) opts.push({ id: `complex::${ct.id}`, name: ct.name, code: ct.code, section: "\u0421\u043E\u0441\u0442\u0430\u0432\u043D\u044B\u0435 \u0442\u0438\u043F\u044B" });
    for (const ct of composites) opts.push({ id: `array::${ct.id}`, name: `${ct.name} \u2014 \u0441\u043F\u0438\u0441\u043E\u043A`, code: ct.code, section: "\u0421\u043F\u0438\u0441\u043A\u0438 (\u043C\u0430\u0441\u0441\u0438\u0432\u044B)" });
    const docs = offeredTypes(reg.allDocTypes, access).filter((dt) => dt.kind === "Document");
    for (const dt of docs) opts.push({ id: `doc-ref::${dt.id}`, name: dt.name, code: dt.code, section: "\u0421\u0441\u044B\u043B\u043A\u0438 \u043D\u0430 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B" });
    for (const dt of docs) opts.push({ id: `doc-array::${dt.id}`, name: `${dt.name} \u2014 \u0441\u043F\u0438\u0441\u043E\u043A`, code: dt.code, section: "\u0421\u043F\u0438\u0441\u043A\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432" });
    return opts;
  }
  function decodeFieldType(id) {
    const sep = id.indexOf("::");
    const kind = id.slice(0, sep);
    const target = id.slice(sep + 2);
    if (kind === "builtin") return { type: target, typeId: void 0 };
    return { type: kind, typeId: target };
  }

  // src/client/src/shared/api/access.ts
  init_define_import_meta_env();
  var ACCESS_KEY = ["account", "access"];
  function useAccess(enabled = true) {
    return useQuery({
      queryKey: ACCESS_KEY,
      queryFn: () => apiClient.get("/account/access").then((r) => r.data),
      staleTime: 3e4,
      // Выключают там, где вошедшего может не быть (корень маршрутов): запрос без входа — отказ.
      enabled
    });
  }

  // src/client/src/features/settings/ModuleFieldBadge.tsx
  init_define_import_meta_env();
  function ModuleFieldBadge({ field }) {
    if (field.origin !== "module") return null;
    return /* @__PURE__ */ React.createElement(Tooltip, { content: field.locked ? "\u041F\u043E\u043B\u0435 \u043C\u043E\u0434\u0443\u043B\u044F: \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043A\u043B\u0430\u0434\u0451\u0442 \u043A\u043E\u0434 \u043C\u043E\u0434\u0443\u043B\u044F, \u0432\u0440\u0443\u0447\u043D\u0443\u044E \u043E\u043D\u043E \u043D\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F" : "\u041F\u043E\u043B\u0435 \u043C\u043E\u0434\u0443\u043B\u044F: \u043E\u0431\u044A\u044F\u0432\u043B\u0435\u043D\u043E \u043C\u043E\u0434\u0443\u043B\u0435\u043C, \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u043A\u0430\u043A \u043E\u0431\u044B\u0447\u043D\u043E" }, /* @__PURE__ */ React.createElement(
      "span",
      {
        className: "text-caption px-1.5 py-0.5 rounded bg-tonal text-on-tonal shrink-0"
      },
      field.locked ? "\u043C\u043E\u0434\u0443\u043B\u044C \xB7 \u0437\u0430\u043F\u0435\u0440\u0442\u043E" : "\u043C\u043E\u0434\u0443\u043B\u044C"
    ));
  }

  // src/client/src/features/settings/schemaKeyChecks.ts
  init_define_import_meta_env();
  function boundedEditDistance(a, b, limit) {
    if (a === b) return 0;
    if (Math.abs(a.length - b.length) > limit) return -1;
    const width = b.length + 1;
    let twoAgo = new Array(width).fill(0);
    let prev = Array.from({ length: width }, (_, j) => j);
    let cur = new Array(width).fill(0);
    for (let i = 1; i <= a.length; i++) {
      cur[0] = i;
      let rowMin = cur[0];
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        let v = Math.min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, twoAgo[j - 2] + 1);
        cur[j] = v;
        if (v < rowMin) rowMin = v;
      }
      if (rowMin > limit) return -1;
      const spare = twoAgo;
      twoAgo = prev;
      prev = cur;
      cur = spare;
    }
    return prev[b.length] <= limit ? prev[b.length] : -1;
  }
  var MIN_LENGTH_FOR_TYPO = 6;
  function differsOnlyByTrailingDigits(a, b) {
    const strippedA = a.replace(/\d+$/, "");
    const strippedB = b.replace(/\d+$/, "");
    return strippedA === strippedB && (strippedA !== a || strippedB !== b);
  }
  function similarKeyOf(key, others) {
    const k = key.trim();
    if (!k) return null;
    const lower = k.toLocaleLowerCase();
    for (const other of others) {
      const o = other.trim();
      if (!o || o === k) continue;
      if (o.toLocaleLowerCase() === lower) return o;
    }
    if (k.length < MIN_LENGTH_FOR_TYPO) return null;
    for (const other of others) {
      const o = other.trim();
      if (!o || o === k || o.length < MIN_LENGTH_FOR_TYPO) continue;
      if (differsOnlyByTrailingDigits(k, o)) continue;
      if (boundedEditDistance(lower, o.toLocaleLowerCase(), 1) >= 0) return o;
    }
    return null;
  }

  // src/client/src/features/settings/FunctionalTagChip.tsx
  init_define_import_meta_env();
  function FunctionalTagChip({ tag, entry, onToggle, onOrderChange }) {
    const on = entry !== void 0;
    const order = entry !== void 0 ? tagOrder(entry) : null;
    const showParameter = on && !!tag.parameter;
    const step = (delta) => onOrderChange(String(Math.min(99, Math.max(1, (order ?? 0) + delta))));
    const arrowClass = "invisible group-hover:visible group-focus-within:visible text-tertiary hover:text-on-tertiary-subtle disabled:opacity-40 shrink-0";
    return /* @__PURE__ */ React.createElement(
      "span",
      {
        className: `group inline-flex items-stretch overflow-hidden rounded-full border text-xs transition-colors ${on ? "bg-tertiary-subtle border-tertiary/50 text-on-tertiary-subtle focus-within:ring-1 focus-within:ring-tertiary/50" : "border-stroke text-fg4 hover:border-stroke-strong hover:text-fg2"}`
      },
      /* @__PURE__ */ React.createElement(Tooltip, { content: tag.description }, /* @__PURE__ */ React.createElement("button", { type: "button", onClick: onToggle, className: "px-2 py-0.5" }, tag.label)),
      showParameter && /* @__PURE__ */ React.createElement(Tooltip, { content: tag.parameter.description }, /* @__PURE__ */ React.createElement(
        "span",
        {
          className: "flex items-center gap-0.5 border-l border-tertiary/50 pl-1 pr-1"
        },
        /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            className: arrowClass,
            onClick: () => step(-1),
            disabled: (order ?? 0) <= 1,
            "aria-label": `\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u043F\u043E\u0440\u044F\u0434\u043E\u043A: ${tag.label}`
          },
          /* @__PURE__ */ React.createElement(Minus, { size: 11 })
        ),
        /* @__PURE__ */ React.createElement(
          "input",
          {
            type: "text",
            inputMode: "numeric",
            maxLength: 2,
            value: order ?? "",
            placeholder: tag.parameter.label,
            "aria-label": `\u041F\u043E\u0440\u044F\u0434\u043E\u043A \u043A\u043E\u043C\u043F\u043E\u043D\u0435\u043D\u0442\u0430: ${tag.label}`,
            onChange: (e) => onOrderChange(e.target.value),
            className: "w-5 bg-transparent text-center tabular-nums text-on-tertiary-subtle outline-none\n                         placeholder:text-tertiary/60"
          }
        ),
        /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            className: arrowClass,
            onClick: () => step(1),
            disabled: (order ?? 0) >= 99,
            "aria-label": `\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u043F\u043E\u0440\u044F\u0434\u043E\u043A: ${tag.label}`
          },
          /* @__PURE__ */ React.createElement(Plus, { size: 11 })
        )
      ))
    );
  }
  function FunctionalTagBadge({ registry, entry }) {
    const order = tagOrder(entry);
    return /* @__PURE__ */ React.createElement("span", { className: "hidden md:inline-flex items-center shrink-0 overflow-hidden rounded\n                     bg-brand-subtle text-caption text-brand" }, /* @__PURE__ */ React.createElement("span", { className: "px-1.5 py-0.5" }, tagLabelOf(registry, entry)), order !== null && /* @__PURE__ */ React.createElement("span", { className: "border-l border-brand/40 px-1.5 py-0.5 tabular-nums" }, order));
  }

  // src/client/src/shared/utils/computedExpression.ts
  init_define_import_meta_env();
  var GET_RE = /get\(\s*["']([^"']+)["']\s*\)/g;
  function referencedKeys(expression) {
    const keys = /* @__PURE__ */ new Set();
    let m;
    GET_RE.lastIndex = 0;
    while (m = GET_RE.exec(expression)) keys.add(m[1]);
    return [...keys];
  }
  function evalComputed(expression, values) {
    if (!expression.trim()) return { value: void 0 };
    try {
      const get = (key) => values[key];
      const fn = new Function("get", `"use strict"; return (${expression});`);
      const value = fn(get);
      return { value };
    } catch (e) {
      return { error: e instanceof Error ? e.message : String(e) };
    }
  }
  function validateComputed(expression, knownKeys) {
    const unknownRefs = referencedKeys(expression).filter((k) => !knownKeys.has(k));
    let syntaxError;
    if (expression.trim()) {
      try {
        new Function("get", `"use strict"; return (${expression});`);
      } catch (e) {
        syntaxError = e instanceof Error ? e.message : String(e);
      }
    }
    return { syntaxError, unknownRefs };
  }
  function findComputedCycles(computed) {
    const keys = Object.keys(computed);
    const keySet = new Set(keys);
    const deps = {};
    const indeg = {};
    for (const k of keys) {
      deps[k] = referencedKeys(computed[k]).filter((r) => keySet.has(r) && r !== k);
      indeg[k] = 0;
    }
    const selfCyclic = new Set(keys.filter((k) => referencedKeys(computed[k]).includes(k)));
    const dependents = Object.fromEntries(keys.map((k) => [k, []]));
    for (const k of keys) for (const d of deps[k]) {
      dependents[d].push(k);
      indeg[k]++;
    }
    const ready = keys.filter((k) => indeg[k] === 0);
    const ordered = [];
    while (ready.length) {
      const n = ready.shift();
      ordered.push(n);
      for (const m of dependents[n]) if (--indeg[m] === 0) ready.push(m);
    }
    const cyclic = new Set(keys.filter((k) => !ordered.includes(k)));
    for (const k of selfCyclic) cyclic.add(k);
    return cyclic;
  }

  // src/client/src/shared/utils/moveItem.ts
  init_define_import_meta_env();
  function moveItem(items, from, to) {
    if (from === to || from < 0 || from >= items.length || to < 0 || to >= items.length) return items;
    const next = [...items];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    return next;
  }

  // src/client/src/features/settings/FieldBuilder.tsx
  var COMPUTABLE_TYPES = /* @__PURE__ */ new Set(["string", "text", "number", "date", "boolean"]);
  function SchemaFieldKinds_isComputable(type) {
    return COMPUTABLE_TYPES.has(type);
  }
  function ComputedFieldEditor({ field, siblingFields, onChange }) {
    const taRef = (0, import_react24.useRef)(null);
    const [pickOpen, setPickOpen] = (0, import_react24.useState)(false);
    const [pickFilter, setPickFilter] = (0, import_react24.useState)("");
    const [testOpen, setTestOpen] = (0, import_react24.useState)(false);
    const [sample, setSample] = (0, import_react24.useState)({});
    const expr = field.expression ?? "";
    const refs = siblingFields.filter((f) => f.key.trim());
    const knownKeys = (0, import_react24.useMemo)(() => /* @__PURE__ */ new Set([field.key, ...refs.map((f) => f.key)]), [field.key, refs]);
    const { syntaxError, unknownRefs } = validateComputed(expr, knownKeys);
    const inCycle = (0, import_react24.useMemo)(() => {
      const map = { [field.key]: expr };
      for (const f of refs) if (f.computed && f.expression) map[f.key] = f.expression;
      return findComputedCycles(map).has(field.key);
    }, [field.key, expr, refs]);
    const filtered = refs.filter((f) => !pickFilter || `${f.key} ${f.title}`.toLowerCase().includes(pickFilter.toLowerCase()));
    function insertRef(key) {
      const snippet = `get("${key}")`;
      const cur = field.expression ?? "";
      const ta = taRef.current;
      if (!ta) {
        onChange({ expression: cur + snippet });
        setPickOpen(false);
        return;
      }
      const start = ta.selectionStart ?? cur.length;
      const end = ta.selectionEnd ?? cur.length;
      onChange({ expression: cur.slice(0, start) + snippet + cur.slice(end) });
      setPickOpen(false);
      setPickFilter("");
      requestAnimationFrame(() => {
        ta.focus();
        const p = start + snippet.length;
        ta.setSelectionRange(p, p);
      });
    }
    const testRefs = referencedKeys(expr);
    const testResult = (0, import_react24.useMemo)(() => {
      if (!testOpen) return null;
      const values = {};
      for (const k of testRefs) {
        const raw = sample[k] ?? "";
        values[k] = raw !== "" && !Number.isNaN(Number(raw)) ? Number(raw) : raw;
      }
      return evalComputed(expr, values);
    }, [testOpen, sample, expr, testRefs]);
    return /* @__PURE__ */ React.createElement("div", { className: "rounded-md border border-brand/30 bg-brand-subtle/40 p-2 space-y-1.5" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-between gap-2" }, /* @__PURE__ */ React.createElement("span", { className: "text-caption text-fg3 font-medium" }, "\u0424\u043E\u0440\u043C\u0443\u043B\u0430 (JavaScript)"), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-1.5" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => setTestOpen((o) => !o),
        className: "text-caption px-2 py-0.5 rounded border border-stroke-strong text-fg3 hover:bg-muted"
      },
      "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043D\u0430 \u043E\u0431\u0440\u0430\u0437\u0446\u0435"
    ), /* @__PURE__ */ React.createElement("div", { className: "relative" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => {
          setPickOpen((o) => !o);
          setPickFilter("");
        },
        className: "text-caption px-2 py-0.5 rounded border border-stroke-strong text-brand hover:bg-brand/10"
      },
      "+ \u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u043B\u0435"
    ), pickOpen && /* @__PURE__ */ React.createElement("div", { className: "absolute right-0 top-full mt-1 z-50 w-64 bg-surface border border-stroke rounded-lg shadow-lg py-1" }, /* @__PURE__ */ React.createElement(
      "input",
      {
        autoFocus: true,
        value: pickFilter,
        onChange: (e) => setPickFilter(e.target.value),
        placeholder: "\u0424\u0438\u043B\u044C\u0442\u0440\u2026",
        spellCheck: false,
        className: "mx-2 mb-1 w-[calc(100%-1rem)] border border-stroke rounded px-2 py-1 text-xs bg-surface focus:outline-none focus-visible:ring-1 focus-visible:ring-brand"
      }
    ), /* @__PURE__ */ React.createElement("div", { className: "max-h-52 overflow-auto" }, filtered.length === 0 ? /* @__PURE__ */ React.createElement("p", { className: "px-3 py-2 text-xs text-fg4" }, "\u041D\u0435\u0442 \u043F\u043E\u043B\u0435\u0439") : filtered.map((f) => /* @__PURE__ */ React.createElement(
      "button",
      {
        key: f.key,
        type: "button",
        onClick: () => insertRef(f.key),
        className: "w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-base"
      },
      /* @__PURE__ */ React.createElement("code", { className: "text-caption font-mono text-brand shrink-0 max-w-[45%] truncate" }, f.key),
      /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg3 truncate flex-1" }, f.title || "\u2014"),
      /* @__PURE__ */ React.createElement("span", { className: "text-caption text-fg4 shrink-0" }, f.type)
    ))))))), /* @__PURE__ */ React.createElement(
      "textarea",
      {
        ref: taRef,
        value: expr,
        spellCheck: false,
        rows: 2,
        onChange: (e) => onChange({ expression: e.target.value }),
        placeholder: 'get("\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E") * get("\u0426\u0435\u043D\u0430")',
        className: "w-full font-mono text-xs border border-stroke-strong rounded px-2 py-1.5 bg-surface focus:outline-none focus-visible:ring-2 focus-visible:ring-brand resize-y"
      }
    ), inCycle ? /* @__PURE__ */ React.createElement("p", { className: "text-caption text-danger" }, "\u26A0 \u0426\u0438\u043A\u043B\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u044C \u2014 \u043F\u043E\u043B\u0435 \u0441\u0441\u044B\u043B\u0430\u0435\u0442\u0441\u044F \u0441\u0430\u043C\u043E \u043D\u0430 \u0441\u0435\u0431\u044F (\u043F\u0440\u044F\u043C\u043E \u0438\u043B\u0438 \u0447\u0435\u0440\u0435\u0437 \u0434\u0440\u0443\u0433\u0438\u0435 \u0440\u0430\u0441\u0447\u0451\u0442\u043D\u044B\u0435).") : syntaxError ? /* @__PURE__ */ React.createElement(Tooltip, { content: syntaxError }, /* @__PURE__ */ React.createElement("p", { className: "text-caption text-danger" }, "\u2717 \u0421\u0438\u043D\u0442\u0430\u043A\u0441\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430: ", syntaxError)) : unknownRefs.length > 0 ? /* @__PURE__ */ React.createElement("p", { className: "text-caption text-warning" }, "\u26A0 \u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0435 \u043F\u043E\u043B\u044F: ", unknownRefs.map((k) => `\xAB${k}\xBB`).join(", ")) : expr.trim() ? /* @__PURE__ */ React.createElement("p", { className: "text-caption text-success" }, "\u2713 \u0421\u0438\u043D\u0442\u0430\u043A\u0441\u0438\u0441 \u0432 \u043F\u043E\u0440\u044F\u0434\u043A\u0435") : null, testOpen && /* @__PURE__ */ React.createElement("div", { className: "rounded border border-stroke bg-surface p-2 space-y-1.5" }, testRefs.length === 0 ? /* @__PURE__ */ React.createElement("p", { className: "text-caption text-fg4" }, "\u0424\u043E\u0440\u043C\u0443\u043B\u0430 \u043D\u0435 \u0441\u0441\u044B\u043B\u0430\u0435\u0442\u0441\u044F \u043D\u0430 \u043F\u043E\u043B\u044F.") : testRefs.map((k) => /* @__PURE__ */ React.createElement("label", { key: k, className: "flex items-center gap-2 text-caption" }, /* @__PURE__ */ React.createElement("code", { className: "font-mono text-fg3 w-28 truncate shrink-0" }, k), /* @__PURE__ */ React.createElement(
      "input",
      {
        value: sample[k] ?? "",
        onChange: (e) => setSample((s) => ({ ...s, [k]: e.target.value })),
        placeholder: "\u043E\u0431\u0440\u0430\u0437\u0446\u043E\u0432\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435",
        className: "flex-1 border border-stroke rounded px-2 py-1 text-xs bg-surface focus:outline-none focus-visible:ring-1 focus-visible:ring-brand"
      }
    ))), /* @__PURE__ */ React.createElement("div", { className: "text-caption pt-0.5" }, testResult?.error ? /* @__PURE__ */ React.createElement("span", { className: "text-danger" }, "\u041E\u0448\u0438\u0431\u043A\u0430: ", testResult.error) : /* @__PURE__ */ React.createElement("span", { className: "text-fg2" }, "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442: ", /* @__PURE__ */ React.createElement("strong", { className: "font-mono" }, String(testResult?.value ?? "\u2014"))))), /* @__PURE__ */ React.createElement("p", { className: "text-caption text-fg4" }, "\u0427\u0438\u0442\u0430\u0439\u0442\u0435 \u043F\u043E\u043B\u044F \u0447\u0435\u0440\u0435\u0437 ", /* @__PURE__ */ React.createElement("code", { className: "font-mono" }, 'get("\u041A\u043B\u044E\u0447")'), ". \u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0439 \u0432\u0438\u0434\u043D\u044B \u043A\u0430\u043A \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0430\u0435\u043C\u043E\u0435 \u0438\u043C\u044F."));
  }
  function FieldCard({
    field,
    reg,
    keyConflict,
    persistedKeys,
    siblingFields,
    otherKeys,
    onKeyRename,
    autoFocus,
    onAutoFocused,
    open,
    onToggleOpen,
    onChange,
    onRemove,
    onMoveUp,
    onMoveDown,
    isFirst,
    isLast,
    dragging,
    onDragStart,
    onDragEnd,
    onDragOver,
    onDrop
  }) {
    const { primitiveTypes, enumTypes, tagRegistry } = reg;
    const tags = field.tags ?? [];
    const unknownTags = unknownTagCodes(field.tags, tagRegistry);
    const [pickerOpen, setPickerOpen] = (0, import_react24.useState)(false);
    const titleRef = (0, import_react24.useRef)(null);
    (0, import_react24.useEffect)(() => {
      if (!autoFocus) return;
      titleRef.current?.focus();
      onAutoFocused?.();
    }, [autoFocus]);
    const [keyUnlocked, setKeyUnlocked] = (0, import_react24.useState)(false);
    const [confirmUnlock, setConfirmUnlock] = (0, import_react24.useState)(false);
    const [savedKey, setSavedKey] = (0, import_react24.useState)(() => nextSavedKey(null, field.key, persistedKeys));
    const prevPersisted = (0, import_react24.useRef)(persistedKeys);
    (0, import_react24.useEffect)(() => {
      setSavedKey((k) => nextSavedKey(k, field.key, persistedKeys, prevPersisted.current));
      prevPersisted.current = persistedKeys;
    }, [persistedKeys]);
    const isNew = savedKey === null;
    const keyLocked = !isNew && !keyUnlocked;
    const keyChanged = savedKey !== null && field.key !== savedKey;
    const similarKey = similarKeyOf(field.key, otherKeys ?? []);
    const keyAutoNew = isNew && !!field.title.trim() && field.key === toCamelKey(field.title);
    const { data: access } = useAccess();
    const pickTypes = (0, import_react24.useMemo)(
      () => buildFieldTypeOptions(reg, access),
      [reg.compositeTypes, reg.primitiveTypes, reg.enumTypes, reg.allDocTypes, access]
    );
    const toggleTag = (code) => {
      const next = hasTag(tags, code) ? tags.filter((c) => tagCode(c) !== code) : [...tags, code];
      onChange({ tags: next.length ? next : void 0 });
    };
    const setTagOrder = (code, raw) => {
      const digits = raw.replace(/\D/g, "");
      onChange({ tags: withTagOrder(tags, code, digits.length ? Number(digits) : null) });
    };
    const applicableTags = (() => {
      if (field.type === "primitive") {
        const pt = primitiveTypes.find((p) => p.id === field.typeId);
        const codes = new Set(pt?.allowedTags ?? []);
        return offeredInRoles((tagRegistry ?? []).filter((t) => t.scope === "Field" && codes.has(t.code)), reg.roles, tags);
      }
      return fieldTags(tagRegistry, field.type, reg.roles, tags);
    })();
    const isLegacyEnum = field.type === "enum" && !field.typeId && (field.options?.length ?? 0) > 0;
    const enumTypeDef = field.type === "enum" ? enumTypes.find((et) => et.id === field.typeId) : void 0;
    const updateTitle = (title) => {
      const key = nextAutoKey(field.key, field.title, title, isNew);
      onChange({ title, ...key !== field.key ? { key } : {} });
    };
    return /* @__PURE__ */ React.createElement(
      "div",
      {
        className: `border rounded-lg overflow-hidden bg-surface transition-colors ${dragging ? "border-brand" : "border-stroke"}`,
        onDragOver,
        onDrop
      },
      /* @__PURE__ */ React.createElement(
        "div",
        {
          className: "flex items-center gap-2 pl-2 pr-3 py-2 hover:bg-muted/40 transition-colors",
          draggable: true,
          onDragStart,
          onDragEnd
        },
        /* @__PURE__ */ React.createElement(GripVertical, { size: 15, className: "text-fg4 shrink-0 cursor-grab" }),
        /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            onClick: onToggleOpen,
            className: "flex-1 min-w-0 flex items-center gap-2 text-left"
          },
          /* @__PURE__ */ React.createElement("span", { className: "min-w-0 flex-1" }, /* @__PURE__ */ React.createElement("span", { className: "flex items-center gap-1.5" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium text-fg1 truncate" }, field.title || "(\u0431\u0435\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F)"), field.required && /* @__PURE__ */ React.createElement("span", { className: "text-caption text-danger shrink-0" }, "\u043E\u0431\u044F\u0437."), keyConflict && /* @__PURE__ */ React.createElement("span", { className: "text-caption text-danger shrink-0" }, "! \u043A\u043B\u044E\u0447 \u0437\u0430\u043D\u044F\u0442")), /* @__PURE__ */ React.createElement("span", { className: "block text-xs text-fg4 font-mono truncate" }, field.key || "\u2014")),
          /* @__PURE__ */ React.createElement(ModuleFieldBadge, { field }),
          tags.slice(0, 2).map((tc) => /* @__PURE__ */ React.createElement(FunctionalTagBadge, { key: tc, registry: tagRegistry, entry: tc })),
          tags.length > 2 && /* @__PURE__ */ React.createElement("span", { className: "text-caption text-fg4 shrink-0" }, "+", tags.length - 2),
          /* @__PURE__ */ React.createElement("span", { className: "text-xs px-2 py-0.5 rounded-full bg-muted text-fg3 shrink-0" }, fieldTypeSummary(field, reg)),
          open ? /* @__PURE__ */ React.createElement(ChevronUp, { size: 16, className: "text-fg4 shrink-0" }) : /* @__PURE__ */ React.createElement(ChevronDown, { size: 16, className: "text-fg4 shrink-0" })
        )
      ),
      open && /* @__PURE__ */ React.createElement("div", { className: "px-3 pb-3 pt-2 border-t border-stroke space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-[1fr_1fr_160px_72px_76px] gap-2 items-center" }, /* @__PURE__ */ React.createElement(
        "input",
        {
          ref: titleRef,
          value: field.title,
          onChange: (e) => updateTitle(e.target.value),
          placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435",
          className: "border border-stroke-strong rounded-md px-3 py-1.5 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-brand bg-surface"
        }
      ), /* @__PURE__ */ React.createElement("div", { className: "relative" }, /* @__PURE__ */ React.createElement(Tooltip, { content: keyLocked ? "\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u2014 \u0437\u0430\u043C\u043E\u0440\u043E\u0436\u0435\u043D. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0437\u0430\u043C\u043E\u043A, \u0447\u0442\u043E\u0431\u044B \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C." : void 0 }, /* @__PURE__ */ React.createElement(
        "input",
        {
          value: field.key,
          onChange: (e) => {
            onChange({ key: e.target.value });
            if (savedKey !== null) onKeyRename?.(savedKey, e.target.value);
          },
          readOnly: keyLocked,
          placeholder: "\u041A\u043B\u044E\u0447\u041F\u043E\u043B\u044F",
          spellCheck: false,
          className: `w-full border rounded-md pl-3 pr-7 py-1.5 text-sm font-mono focus:outline-none focus-visible:ring-2 ${keyConflict ? "border-danger focus-visible:ring-danger" : "border-stroke-strong focus-visible:ring-brand"} ${keyLocked ? "bg-muted/60 text-fg3 cursor-default" : "bg-surface"}`
        }
      )), keyConflict ? /* @__PURE__ */ React.createElement("span", { className: "absolute right-2 top-1/2 -translate-y-1/2 text-xs text-danger" }, "!") : keyLocked ? /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043B\u044E\u0447 (\u043E\u0441\u0442\u043E\u0440\u043E\u0436\u043D\u043E: \u043E\u0441\u0438\u0440\u043E\u0442\u0438\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432)", name: true }, /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: () => setConfirmUnlock(true),
          className: "absolute right-1.5 top-1/2 -translate-y-1/2 p-0.5 text-fg4 hover:text-fg2"
        },
        /* @__PURE__ */ React.createElement(Lock, { size: 13 })
      )) : keyAutoNew ? /* @__PURE__ */ React.createElement(Tooltip, { content: "\u041A\u043B\u044E\u0447 \u0430\u0432\u0442\u043E-\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u0438\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F" }, /* @__PURE__ */ React.createElement("span", { className: "absolute right-2 top-1/2 -translate-y-1/2 text-fg4 pointer-events-none" }, /* @__PURE__ */ React.createElement(Link2, { size: 13 }))) : null), /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u0442\u0438\u043F \u043F\u043E\u043B\u044F" }, /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: () => setPickerOpen(true),
          className: "flex items-center justify-between gap-1 border border-stroke-strong rounded-md px-2 py-1.5 text-sm bg-surface hover:bg-muted/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand"
        },
        /* @__PURE__ */ React.createElement("span", { className: "truncate text-left" }, fieldTypeSummary(field, reg)),
        /* @__PURE__ */ React.createElement(ChevronDown, { size: 14, className: "text-fg4 shrink-0" })
      )), field.computed ? /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0420\u0430\u0441\u0447\u0451\u0442\u043D\u043E\u0435 \u043F\u043E\u043B\u0435 \u2014 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432\u044B\u0447\u0438\u0441\u043B\u044F\u0435\u0442\u0441\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u043E\u0439" }, /* @__PURE__ */ React.createElement("span", { className: "flex items-center justify-center gap-1 text-caption text-brand" }, /* @__PURE__ */ React.createElement(SquareFunction, { size: 12 }), " \u0432\u044B\u0447\u0438\u0441\u043B.")) : /* @__PURE__ */ React.createElement("label", { className: "flex items-center justify-center gap-1.5 cursor-pointer" }, /* @__PURE__ */ React.createElement(
        "input",
        {
          type: "checkbox",
          checked: field.required,
          onChange: (e) => onChange({ required: e.target.checked }),
          className: "w-4 h-4 rounded border-stroke-strong text-brand"
        }
      ), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg3" }, "\u0434\u0430")), /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-end gap-0.5" }, /* @__PURE__ */ React.createElement(
        MoveButtons,
        {
          onUp: () => onMoveUp?.(),
          onDown: () => onMoveDown?.(),
          isFirst: !!isFirst,
          isLast: !!isLast
        }
      ), /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: onRemove,
          className: "p-1 text-fg4 hover:text-danger"
        },
        /* @__PURE__ */ React.createElement(Trash2, { size: 12 })
      ))), keyChanged && /* @__PURE__ */ React.createElement("p", { className: "text-xs text-danger flex items-start gap-1.5" }, /* @__PURE__ */ React.createElement(Lock, { size: 12, className: "shrink-0 mt-0.5" }), /* @__PURE__ */ React.createElement("span", null, "\u041A\u043B\u044E\u0447 \u0438\u0437\u043C\u0435\u043D\u0451\u043D \u0441 \xAB", /* @__PURE__ */ React.createElement("span", { className: "font-mono" }, savedKey), "\xBB \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043E\u0441\u0442\u0430\u043D\u0443\u0442\u0441\u044F \u043F\u043E\u0434 \u0441\u0442\u0430\u0440\u044B\u043C \u043A\u043B\u044E\u0447\u043E\u043C (\u043E\u0441\u0438\u0440\u043E\u0442\u0435\u044E\u0442). \u041F\u0435\u0440\u0435\u043D\u043E\u0441 \u0441\u0442\u0430\u0440\u044B\u0439\u2192\u043D\u043E\u0432\u044B\u0439 \u2014 \u0447\u0435\u0440\u0435\u0437 \xAB\u0410\u0443\u0434\u0438\u0442\xBB (\u043F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0441\u0438\u0440\u043E\u0442\u0435\u0432\u0448\u0435\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u043F\u043E\u043B\u0435 \u0441\u0445\u0435\u043C\u044B).")), similarKey && !keyConflict && /* @__PURE__ */ React.createElement("p", { className: "text-xs text-warning flex items-start gap-1.5" }, /* @__PURE__ */ React.createElement(TriangleAlert, { size: 12, className: "shrink-0 mt-0.5" }), /* @__PURE__ */ React.createElement("span", null, "\u041A\u043B\u044E\u0447 \u043F\u043E\u0445\u043E\u0436 \u043D\u0430 \xAB", /* @__PURE__ */ React.createElement("span", { className: "font-mono" }, similarKey), "\xBB \u2014 \u043E\u043F\u0435\u0447\u0430\u0442\u043A\u0430? \u0414\u0432\u0430 \u043F\u043E\u0447\u0442\u0438 \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0445 \u043A\u043B\u044E\u0447\u0430 \u0434\u0430\u044E\u0442 \u0432 \u0444\u043E\u0440\u043C\u0435 \u0434\u0432\u0430 \u043F\u043E\u043B\u044F, \u0430 \u0432 \u0434\u0430\u043D\u043D\u044B\u0445 \u2014 \u0434\u0432\u0435 \u043D\u0435\u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u044F\u0447\u0435\u0439\u043A\u0438.")), /* @__PURE__ */ React.createElement(
        ConfirmDialog,
        {
          open: confirmUnlock,
          onOpenChange: setConfirmUnlock,
          title: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043B\u044E\u0447 \u043F\u043E\u043B\u044F?",
          description: /* @__PURE__ */ React.createElement("p", null, "\u041A\u043B\u044E\u0447 \u2014 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F. \u041F\u043E\u0441\u043B\u0435 \u0441\u043C\u0435\u043D\u044B \u0434\u0430\u043D\u043D\u044B\u0435 \u0432\u0441\u0435\u0445 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u044D\u0442\u043E\u0433\u043E \u0442\u0438\u043F\u0430 \u043E\u0441\u0438\u0440\u043E\u0442\u0435\u044E\u0442 \u043F\u043E \u0441\u0442\u0430\u0440\u043E\u043C\u0443 \u043A\u043B\u044E\u0447\u0443 \xAB", /* @__PURE__ */ React.createElement("span", { className: "font-mono" }, savedKey), "\xBB. \u041F\u0435\u0440\u0435\u043D\u0435\u0441\u0442\u0438 \u0438\u0445 \u043D\u0430 \u043D\u043E\u0432\u044B\u0439 \u043A\u043B\u044E\u0447 \u043C\u043E\u0436\u043D\u043E \u0447\u0435\u0440\u0435\u0437 \xAB\u0410\u0443\u0434\u0438\u0442\xBB (\u043F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u043E\u0441\u0438\u0440\u043E\u0442\u0435\u0432\u0448\u0435\u0433\u043E \u043A\u043B\u044E\u0447\u0430). \u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C?"),
          confirmLabel: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043A\u043B\u044E\u0447",
          onConfirm: () => {
            setConfirmUnlock(false);
            setKeyUnlocked(true);
          }
        }
      ), SchemaFieldKinds_isComputable(field.type) && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("label", { className: "flex items-center gap-2 cursor-pointer w-fit" }, /* @__PURE__ */ React.createElement(
        "input",
        {
          type: "checkbox",
          checked: !!field.computed,
          onChange: (e) => onChange(e.target.checked ? { computed: true, required: false, defaultValue: void 0 } : { computed: void 0, expression: void 0 }),
          className: "w-4 h-4 rounded border-stroke-strong text-brand"
        }
      ), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg2 flex items-center gap-1" }, /* @__PURE__ */ React.createElement(SquareFunction, { size: 13, className: "text-brand" }), " \u0412\u044B\u0447\u0438\u0441\u043B\u044F\u0435\u043C\u043E\u0435 (\u0444\u043E\u0440\u043C\u0443\u043B\u0430)")), field.computed && /* @__PURE__ */ React.createElement(ComputedFieldEditor, { field, siblingFields: siblingFields ?? [], onChange })), !field.computed && field.type !== "complex" && field.type !== "array" && field.type !== "primitive" && field.type !== "doc-ref" && field.type !== "doc-array" && /* @__PURE__ */ React.createElement("div", { className: "ml-[calc(33%+0.5rem)] mr-[calc(5rem)] flex items-center gap-2" }, /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4 shrink-0 w-28" }, "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u0443\u043C\u043E\u043B\u0447.:"), field.type === "boolean" ? /* @__PURE__ */ React.createElement("label", { className: "flex items-center gap-1.5 cursor-pointer" }, /* @__PURE__ */ React.createElement(
        "input",
        {
          type: "checkbox",
          checked: !!field.defaultValue,
          onChange: (e) => onChange({ defaultValue: e.target.checked ? true : void 0 }),
          className: "w-3.5 h-3.5 rounded border-stroke-strong text-brand"
        }
      ), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg3" }, field.defaultValue ? "true" : "\u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E")) : field.type === "enum" ? /* @__PURE__ */ React.createElement(
        Select2,
        {
          size: "sm",
          className: "flex-1",
          "aria-label": "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E",
          value: String(field.defaultValue ?? ""),
          onValueChange: (v) => onChange({ defaultValue: v || void 0 }),
          emptyItem: "\u2014 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u2014"
        },
        enumTypeDef ? enumTypeDef.values.map((v) => /* @__PURE__ */ React.createElement(SelectItem2, { key: v.code, value: v.code }, v.label)) : (field.options ?? []).filter((o) => o).map((opt) => /* @__PURE__ */ React.createElement(SelectItem2, { key: opt, value: opt }, opt))
      ) : field.type === "date" ? /* @__PURE__ */ React.createElement(
        DateInput,
        {
          value: field.defaultValue != null ? String(field.defaultValue) : "",
          onChange: (v) => onChange({ defaultValue: v || void 0 }),
          className: "flex-1 border border-stroke rounded px-2 py-1 text-xs bg-surface focus:outline-none focus-visible:ring-1 focus-visible:ring-brand"
        }
      ) : /* @__PURE__ */ React.createElement(
        "input",
        {
          type: field.type === "number" ? "number" : "text",
          placeholder: "\u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E",
          value: field.defaultValue != null ? String(field.defaultValue) : "",
          onChange: (e) => {
            const v = e.target.value;
            onChange({
              defaultValue: v === "" ? void 0 : field.type === "number" ? Number(v) : v
            });
          },
          className: "flex-1 border border-stroke rounded px-2 py-1 text-xs bg-surface focus:outline-none focus-visible:ring-1 focus-visible:ring-brand"
        }
      )), isLegacyEnum && /* @__PURE__ */ React.createElement("div", { className: "ml-[calc(33%+0.5rem)] mr-[calc(5rem)] space-y-1.5" }, (field.options ?? []).map((opt, oi) => /* @__PURE__ */ React.createElement("div", { key: oi, className: "flex items-center gap-1.5" }, /* @__PURE__ */ React.createElement(
        "input",
        {
          value: opt,
          onChange: (e) => {
            const opts = [...field.options ?? []];
            opts[oi] = e.target.value;
            onChange({ options: opts });
          },
          placeholder: `\u0412\u0430\u0440\u0438\u0430\u043D\u0442 ${oi + 1}`,
          className: "flex-1 border border-stroke-strong rounded px-2 py-1 text-xs focus:outline-none focus-visible:ring-1 focus-visible:ring-brand bg-surface"
        }
      ), /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: () => {
            const opts = (field.options ?? []).filter((_, j) => j !== oi);
            onChange({ options: opts });
          },
          className: "p-0.5 text-fg4 hover:text-danger"
        },
        /* @__PURE__ */ React.createElement(Trash2, { size: 11 })
      ))), /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          onClick: () => onChange({ options: [...field.options ?? [], ""] }),
          className: "flex items-center gap-1 text-xs text-brand hover:text-brand-hover"
        },
        /* @__PURE__ */ React.createElement(Plus, { size: 11 }),
        " \u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0432\u0430\u0440\u0438\u0430\u043D\u0442"
      )), unknownTags.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "ml-[calc(33%+0.5rem)] mr-[calc(5rem)] flex items-start gap-2" }, /* @__PURE__ */ React.createElement(Cpu, { size: 12, className: "mt-1 text-stroke-strong" }), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4 shrink-0 w-28 mt-1" }, "\u0422\u044D\u0433\u0438 \u043C\u043E\u0434\u0443\u043B\u044F:"), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-1.5" }, unknownTags.map((code) => /* @__PURE__ */ React.createElement(Tooltip, { key: code, content: "\u0422\u044D\u0433 \u043C\u043E\u0434\u0443\u043B\u044F, \u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u043E\u0433\u043E \u043D\u0430 \u044D\u0442\u043E\u043C \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440\u0435. \u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u0441\u0442\u0430\u0451\u0442\u0441\u044F \u0432 \u0441\u0445\u0435\u043C\u0435 \u0438 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442, \u043A\u043E\u0433\u0434\u0430 \u043C\u043E\u0434\u0443\u043B\u044C \u0432\u043A\u043B\u044E\u0447\u0430\u0442." }, /* @__PURE__ */ React.createElement(
        "span",
        {
          className: "inline-flex items-center gap-1 rounded-full border border-dashed border-stroke px-2 py-0.5 text-caption text-fg4"
        },
        /* @__PURE__ */ React.createElement(Lock, { size: 9 }),
        code
      ))))), applicableTags.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "ml-[calc(33%+0.5rem)] mr-[calc(5rem)] flex items-start gap-2" }, /* @__PURE__ */ React.createElement(Cpu, { size: 12, className: `mt-1 ${tags.length ? "text-tertiary" : "text-stroke-strong"}` }), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4 shrink-0 w-28 mt-1" }, "\u0424\u0443\u043D\u043A\u0446. \u0442\u044D\u0433\u0438:"), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-1.5" }, applicableTags.map((t) => {
        return /* @__PURE__ */ React.createElement(
          FunctionalTagChip,
          {
            key: t.code,
            tag: t,
            entry: findTagEntry(tags, t.code),
            onToggle: () => toggleTag(t.code),
            onOrderChange: (raw) => setTagOrder(t.code, raw)
          }
        );
      })))),
      /* @__PURE__ */ React.createElement(
        TypePicker,
        {
          open: pickerOpen,
          onOpenChange: setPickerOpen,
          types: pickTypes,
          recentKey: "field-type",
          title: "\u0422\u0438\u043F \u043F\u043E\u043B\u044F",
          onSelect: (id) => {
            const dec = decodeFieldType(id);
            const changed = dec.type !== field.type || dec.typeId !== field.typeId;
            onChange(changed ? { ...dec, defaultValue: void 0, options: void 0 } : dec);
          }
        }
      )
    );
  }
  function FieldBuilder({ fields, onChange, disabledKeys, persistedKeys, compositeTypes, primitiveTypes, enumTypes, allDocTypes }) {
    const uid = (0, import_react24.useId)();
    const { data: tagRegistry } = useTagRegistry();
    const reg = { compositeTypes, primitiveTypes, enumTypes, allDocTypes, tagRegistry };
    const [justAdded, setJustAdded] = (0, import_react24.useState)(null);
    const add = () => {
      const field = withFieldUid({ key: "", title: "", type: "string", required: false });
      onChange([...fields, field]);
      setOpenIndex(fields.length);
      setJustAdded(field[FIELD_UID]);
    };
    const [openIndex, setOpenIndex] = (0, import_react24.useState)(null);
    const [dragIndex, setDragIndex] = (0, import_react24.useState)(null);
    const move = (from, to) => {
      const next = moveItem(fields, from, to);
      if (next === fields) return;
      onChange(next);
      setOpenIndex((o) => {
        if (o === null) return o;
        if (o === from) return to;
        if (from < o && o <= to) return o - 1;
        if (to <= o && o < from) return o + 1;
        return o;
      });
    };
    return /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, fields.map((field, i) => /* @__PURE__ */ React.createElement(
      FieldCard,
      {
        key: field[FIELD_UID] ?? `${uid}-${i}`,
        field,
        reg,
        keyConflict: !!field.key && !!disabledKeys?.has(field.key.trim()),
        persistedKeys,
        autoFocus: !!justAdded && field[FIELD_UID] === justAdded,
        onAutoFocused: () => setJustAdded(null),
        siblingFields: fields.filter((_, idx) => idx !== i).map((f) => ({ key: f.key, title: f.title, type: f.type, computed: f.computed, expression: f.expression })),
        otherKeys: [...disabledKeys ?? [], ...fields.filter((_, idx) => idx !== i).map((f) => f.key)],
        open: openIndex === i,
        onToggleOpen: () => setOpenIndex((o) => o === i ? null : i),
        onChange: (patch) => onChange(fields.map((f, idx) => idx === i ? { ...f, ...patch } : f)),
        onRemove: () => onChange(fields.filter((_, idx) => idx !== i)),
        onMoveUp: () => move(i, i - 1),
        onMoveDown: () => move(i, i + 1),
        isFirst: i === 0,
        isLast: i === fields.length - 1,
        dragging: dragIndex === i,
        onDragStart: () => setDragIndex(i),
        onDragEnd: () => setDragIndex(null),
        onDragOver: dragIndex !== null ? (e) => e.preventDefault() : void 0,
        onDrop: dragIndex !== null ? () => {
          move(dragIndex, i);
          setDragIndex(null);
        } : void 0
      }
    )), /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "tonal", onClick: add, icon: /* @__PURE__ */ React.createElement(Plus, { size: 14 }), className: "w-full justify-center" }, "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u043B\u0435"));
  }

  // src/client/src/features/settings/GroupedFieldsEditor.tsx
  init_define_import_meta_env();
  var import_react25 = __toESM(require_react_shim(), 1);
  function GroupedFieldsEditor({
    fields,
    onFieldsChange,
    groups,
    onGroupsChange,
    ungroupedOrder = [],
    onUngroupedOrderChange,
    parentEffectiveFields,
    disabledKeys,
    persistedKeys,
    onKeyRename,
    reg
  }) {
    const [openIndex, setOpenIndex] = (0, import_react25.useState)(null);
    const [justAdded, setJustAdded] = (0, import_react25.useState)(null);
    const [dragKey, setDragKey] = (0, import_react25.useState)(null);
    const [dropTarget, setDropTarget] = (0, import_react25.useState)(null);
    const [dropBeforeKey, setDropBeforeKey] = (0, import_react25.useState)(null);
    const [newGroupTitle, setNewGroupTitle] = (0, import_react25.useState)("");
    const [dragGroupKey, setDragGroupKey] = (0, import_react25.useState)(null);
    const [groupDropBefore, setGroupDropBefore] = (0, import_react25.useState)(null);
    const lineBefore = (key) => !!dragKey && dropBeforeKey === key && dragKey !== key;
    const ownByKey = new Map(fields.map((f) => [f.key, f]));
    const inhByKey = new Map(parentEffectiveFields.map((f) => [f.key, f]));
    const groupedKeys = new Set(groups.flatMap((g) => g.fieldKeys));
    const ownUngrouped = fields.filter((f) => !f.key || !groupedKeys.has(f.key));
    const inhUngrouped = parentEffectiveFields.filter((f) => !groupedKeys.has(f.key));
    const ungroupedMembers = (() => {
      const pool = [
        ...ownUngrouped.map((f) => ({ key: f.key, own: f })),
        ...inhUngrouped.map((f) => ({ key: f.key, inh: f }))
      ];
      const posMap = new Map(ungroupedOrder.map((k, i) => [k, i]));
      const rank = (k) => k && posMap.has(k) ? posMap.get(k) : Number.POSITIVE_INFINITY;
      return [...pool].sort((a, b) => rank(a.key) - rank(b.key));
    })();
    const ungroupedMemberKeys = ungroupedMembers.map((m) => m.key);
    const removeKeyFromGroups = (gs, key) => gs.map((g) => ({ ...g, fieldKeys: g.fieldKeys.filter((k) => k !== key) }));
    function moveKey(key, gKey, beforeKey) {
      if (!key || key === beforeKey) return;
      if (gKey) {
        const gs = removeKeyFromGroups(groups, key).map((g) => {
          if (g.key !== gKey) return g;
          const arr = g.fieldKeys.filter((k) => k !== key);
          const idx = beforeKey ? arr.indexOf(beforeKey) : -1;
          if (idx >= 0) arr.splice(idx, 0, key);
          else arr.push(key);
          return { ...g, fieldKeys: arr };
        });
        onGroupsChange(gs);
      } else {
        if (groupedKeys.has(key)) onGroupsChange(removeKeyFromGroups(groups, key));
        const base = ungroupedMemberKeys.filter((k) => !!k);
        const arr = (base.includes(key) ? base : [...base, key]).filter((k) => k !== key);
        const to = beforeKey ? arr.indexOf(beforeKey) : -1;
        arr.splice(to < 0 ? arr.length : to, 0, key);
        onUngroupedOrderChange?.(arr);
      }
    }
    function patchOwn(f, patch) {
      const idx = fields.indexOf(f);
      if (idx < 0) return;
      const oldKey = f.key;
      onFieldsChange(fields.map((x, i) => i === idx ? { ...x, ...patch } : x));
      if (patch.key !== void 0 && patch.key !== oldKey && oldKey) {
        if (groupedKeys.has(oldKey)) {
          onGroupsChange(groups.map((g) => ({ ...g, fieldKeys: g.fieldKeys.map((k) => k === oldKey ? patch.key : k) })));
        }
        if (ungroupedOrder.includes(oldKey)) {
          onUngroupedOrderChange?.(ungroupedOrder.map((k) => k === oldKey ? patch.key : k));
        }
      }
    }
    function removeOwn(f) {
      const idx = fields.indexOf(f);
      onFieldsChange(fields.filter((_, i) => i !== idx));
      if (f.key && groupedKeys.has(f.key)) onGroupsChange(removeKeyFromGroups(groups, f.key));
      if (f.key && ungroupedOrder.includes(f.key)) onUngroupedOrderChange?.(ungroupedOrder.filter((k) => k !== f.key));
      setOpenIndex(null);
    }
    function addField() {
      const field = withFieldUid({ key: "", title: "", type: "string", required: false });
      onFieldsChange([...fields, field]);
      setOpenIndex(fields.length);
      setJustAdded(field[FIELD_UID]);
    }
    function addGroup() {
      if (!newGroupTitle.trim()) return;
      onGroupsChange([...groups, { key: `group_${Date.now()}`, title: newGroupTitle.trim(), fieldKeys: [] }]);
      setNewGroupTitle("");
    }
    function renameGroup(gKey, title) {
      onGroupsChange(groups.map((g) => g.key === gKey ? { ...g, title } : g));
    }
    function deleteGroup(gKey) {
      onGroupsChange(groups.filter((g) => g.key !== gKey));
    }
    function moveGroup(gKey, dir) {
      const idx = groups.findIndex((g) => g.key === gKey);
      const swap = idx + dir;
      if (idx < 0 || swap < 0 || swap >= groups.length) return;
      const next = [...groups];
      [next[idx], next[swap]] = [next[swap], next[idx]];
      onGroupsChange(next);
    }
    function moveGroupTo(gKey, beforeKey) {
      const from = groups.findIndex((g) => g.key === gKey);
      if (from < 0 || gKey === beforeKey) return;
      const next = [...groups];
      const [moved] = next.splice(from, 1);
      const to = beforeKey === "__end__" ? next.length : next.findIndex((g) => g.key === beforeKey);
      next.splice(to < 0 ? next.length : to, 0, moved);
      onGroupsChange(next);
    }
    const endGroupDrag = () => {
      setDragGroupKey(null);
      setGroupDropBefore(null);
    };
    const memberDropProps = (targetKey, containerKey) => ({
      dragging: !!dragKey && dragKey === targetKey,
      onDragStart: () => {
        if (targetKey) setDragKey(targetKey);
      },
      onDragEnd: () => {
        setDragKey(null);
        setDropTarget(null);
        setDropBeforeKey(null);
      },
      // Над конкретным полем: линия ПЕРЕД ним. stopPropagation — чтобы обработчик тела контейнера
      // (append) не перебивал точную позицию.
      onDragOver: (e) => {
        if (dragKey && targetKey && dragKey !== targetKey) {
          e.preventDefault();
          e.stopPropagation();
          setDropTarget(containerKey ?? "__ungrouped__");
          setDropBeforeKey(targetKey);
        }
      },
      onDrop: (e) => {
        e.stopPropagation();
        if (dragKey && targetKey && dragKey !== targetKey) moveKey(dragKey, containerKey, targetKey);
        setDragKey(null);
        setDropTarget(null);
        setDropBeforeKey(null);
      }
    });
    function renderOwn(own2, containerKey, siblingKeys, pos) {
      const idx = fields.indexOf(own2);
      const dp = memberDropProps(own2.key, containerKey);
      return /* @__PURE__ */ React.createElement("div", { key: own2[FIELD_UID] ?? `own-${idx}` }, lineBefore(own2.key) && /* @__PURE__ */ React.createElement(DropLine, null), /* @__PURE__ */ React.createElement(
        FieldCard,
        {
          field: own2,
          reg,
          keyConflict: !!own2.key && !!disabledKeys?.has(own2.key.trim()),
          otherKeys: [...disabledKeys ?? [], ...fields.filter((f) => f !== own2).map((f) => f.key)],
          persistedKeys,
          autoFocus: !!justAdded && own2[FIELD_UID] === justAdded,
          onAutoFocused: () => setJustAdded(null),
          onKeyRename,
          open: openIndex === idx,
          onToggleOpen: () => setOpenIndex((o) => o === idx ? null : idx),
          onChange: (patch) => patchOwn(own2, patch),
          onRemove: () => removeOwn(own2),
          onMoveUp: pos > 0 ? () => moveKey(own2.key, containerKey, siblingKeys[pos - 1]) : void 0,
          onMoveDown: pos < siblingKeys.length - 1 ? () => moveKey(own2.key, containerKey, siblingKeys[pos + 2]) : void 0,
          isFirst: pos === 0,
          isLast: pos === siblingKeys.length - 1,
          ...dp
        }
      ));
    }
    function renderInherited(inh, containerKey) {
      const dp = memberDropProps(inh.key, containerKey);
      return /* @__PURE__ */ React.createElement("div", { key: `inh-${inh.key}` }, lineBefore(inh.key) && /* @__PURE__ */ React.createElement(DropLine, null), /* @__PURE__ */ React.createElement(InheritedRow, { field: inh, typeLabel: fieldTypeSummary(inh, reg), ...dp }));
    }
    function renderMemberByKey(key, containerKey, siblings) {
      const own2 = ownByKey.get(key);
      if (own2) return renderOwn(own2, containerKey, siblings, siblings.indexOf(key));
      const inh = inhByKey.get(key);
      if (inh) return renderInherited(inh, containerKey);
      return null;
    }
    const dropZoneProps = (containerKey) => {
      const id = containerKey ?? "__ungrouped__";
      return {
        // Тело контейнера (не над полем — обработчик поля делает stopPropagation): бросок в конец.
        onDragOver: (e) => {
          if (dragKey) {
            e.preventDefault();
            setDropTarget(id);
            setDropBeforeKey(null);
          }
        },
        onDrop: () => {
          if (dragKey) moveKey(dragKey, containerKey);
          setDragKey(null);
          setDropTarget(null);
          setDropBeforeKey(null);
        },
        highlighted: dropTarget === id,
        // Линия «в конец» — когда курсор над телом этого контейнера, но не над конкретным полем.
        appendLine: !!dragKey && dropTarget === id && dropBeforeKey === null
      };
    };
    return /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, (() => {
      const zone = dropZoneProps(null);
      return /* @__PURE__ */ React.createElement("div", { className: `border rounded-lg overflow-hidden transition-colors ${zone.highlighted ? "border-brand bg-brand-subtle/30" : "border-stroke border-dashed bg-base"}` }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-2 px-3 py-2 bg-surface border-b border-stroke" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm font-medium text-fg3" }, "\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B"), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4" }, ownUngrouped.length + inhUngrouped.length)), /* @__PURE__ */ React.createElement("div", { className: "p-2 space-y-2 min-h-[3rem]", onDragOver: zone.onDragOver, onDrop: zone.onDrop }, ungroupedMembers.map((m, i) => m.own ? renderOwn(m.own, null, ungroupedMemberKeys, i) : renderInherited(m.inh, null)), zone.appendLine && ungroupedMembers.length > 0 && /* @__PURE__ */ React.createElement(DropLine, null), /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "tonal", onClick: addField, icon: /* @__PURE__ */ React.createElement(Plus, { size: 14 }), className: "w-full justify-center" }, "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u043B\u0435")));
    })(), groups.map((group, gi) => {
      const zone = dropZoneProps(group.key);
      const members = group.fieldKeys.filter((k) => ownByKey.has(k) || inhByKey.has(k));
      const draggingThis = dragGroupKey === group.key;
      return /* @__PURE__ */ React.createElement("div", { key: group.key }, !!dragGroupKey && !draggingThis && groupDropBefore === group.key && /* @__PURE__ */ React.createElement(DropLine, null), /* @__PURE__ */ React.createElement(
        "div",
        {
          className: `border rounded-lg overflow-hidden transition-colors ${draggingThis ? "opacity-40" : ""} ${zone.highlighted ? "border-brand bg-brand-subtle/30" : "border-stroke bg-base"}`,
          onDragOver: (e) => {
            if (dragGroupKey && !draggingThis) {
              e.preventDefault();
              setGroupDropBefore(group.key);
            }
          },
          onDrop: () => {
            if (dragGroupKey && !draggingThis) {
              moveGroupTo(dragGroupKey, group.key);
              endGroupDrag();
            }
          }
        },
        /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-2 px-3 py-2 bg-surface border-b border-stroke" }, /* @__PURE__ */ React.createElement(Tooltip, { content: "\u041F\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u044C \u0434\u043B\u044F \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u0440\u044F\u0434\u043A\u0430 \u0433\u0440\u0443\u043F\u043F" }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            draggable: true,
            onDragStart: () => setDragGroupKey(group.key),
            onDragEnd: endGroupDrag,
            className: "cursor-grab active:cursor-grabbing text-fg4 hover:text-fg2 shrink-0 focus-visible:outline-none focus-visible:text-brand",
            "aria-label": `\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0433\u0440\u0443\u043F\u043F\u0443 \xAB${group.title || group.key}\xBB \u043F\u0435\u0440\u0435\u0442\u0430\u0441\u043A\u0438\u0432\u0430\u043D\u0438\u0435\u043C`
          },
          /* @__PURE__ */ React.createElement(GripVertical, { size: 14 })
        )), /* @__PURE__ */ React.createElement(Layers, { size: 14, className: "text-fg4 shrink-0" }), /* @__PURE__ */ React.createElement(
          "input",
          {
            value: group.title,
            onChange: (e) => renameGroup(group.key, e.target.value),
            placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0433\u0440\u0443\u043F\u043F\u044B",
            className: "flex-1 min-w-0 text-sm font-medium border-b border-transparent hover:border-stroke-strong focus:border-brand bg-transparent outline-none"
          }
        ), /* @__PURE__ */ React.createElement("span", { className: "text-xs text-fg4 shrink-0" }, members.length), /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-0.5 shrink-0" }, /* @__PURE__ */ React.createElement(
          MoveButtons,
          {
            onUp: () => moveGroup(group.key, -1),
            onDown: () => moveGroup(group.key, 1),
            isFirst: gi === 0,
            isLast: gi === groups.length - 1,
            size: 13
          }
        ), /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0433\u0440\u0443\u043F\u043F\u0443 (\u043F\u043E\u043B\u044F \u2192 \xAB\u0411\u0435\u0437 \u0433\u0440\u0443\u043F\u043F\u044B\xBB)", name: true }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            onClick: () => deleteGroup(group.key),
            className: "p-1 text-fg4 hover:text-danger"
          },
          /* @__PURE__ */ React.createElement(Trash2, { size: 13 })
        )))),
        /* @__PURE__ */ React.createElement("div", { className: "p-2 space-y-2 min-h-[3rem]", onDragOver: zone.onDragOver, onDrop: zone.onDrop }, members.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "text-xs text-fg4 text-center py-3 select-none" }, dragKey ? "\u041E\u0442\u043F\u0443\u0441\u0442\u0438\u0442\u0435 \u043F\u043E\u043B\u0435 \u0437\u0434\u0435\u0441\u044C" : "\u041F\u0443\u0441\u0442\u043E \u2014 \u043F\u0435\u0440\u0435\u0442\u0430\u0449\u0438\u0442\u0435 \u043F\u043E\u043B\u0435 \u0441\u044E\u0434\u0430"), members.map((k) => renderMemberByKey(k, group.key, members)), zone.appendLine && members.length > 0 && /* @__PURE__ */ React.createElement(DropLine, null))
      ));
    }), !!dragGroupKey && groupDropBefore === "__end__" && /* @__PURE__ */ React.createElement(DropLine, null), /* @__PURE__ */ React.createElement(
      "div",
      {
        className: "flex items-center gap-2",
        onDragOver: (e) => {
          if (dragGroupKey) {
            e.preventDefault();
            setGroupDropBefore("__end__");
          }
        },
        onDrop: () => {
          if (dragGroupKey) {
            moveGroupTo(dragGroupKey, "__end__");
            endGroupDrag();
          }
        }
      },
      /* @__PURE__ */ React.createElement(
        "input",
        {
          value: newGroupTitle,
          onChange: (e) => setNewGroupTitle(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              addGroup();
            }
          },
          placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043D\u043E\u0432\u043E\u0439 \u0433\u0440\u0443\u043F\u043F\u044B",
          className: "flex-1 border border-dashed border-stroke-strong rounded-md px-3 py-2 text-sm bg-surface focus:outline-none focus-visible:ring-2 focus-visible:ring-brand focus:border-brand"
        }
      ),
      /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "outlined", size: "sm", onClick: addGroup, disabled: !newGroupTitle.trim(), icon: /* @__PURE__ */ React.createElement(Plus, { size: 14 }) }, "\u0413\u0440\u0443\u043F\u043F\u0430")
    ));
  }
  function DropLine() {
    return /* @__PURE__ */ React.createElement("div", { "aria-hidden": true, className: "h-0.5 rounded-full bg-brand mb-2 shadow-[0_0_0_1px_var(--color-brand)]" });
  }
  function InheritedRow({ field, typeLabel, dragging, onDragStart, onDragEnd, onDragOver, onDrop }) {
    return /* @__PURE__ */ React.createElement(
      "div",
      {
        className: `flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-lg border transition-colors ${dragging ? "border-brand" : "border-stroke bg-muted/40"}`,
        draggable: true,
        onDragStart,
        onDragEnd,
        onDragOver,
        onDrop
      },
      /* @__PURE__ */ React.createElement(GripVertical, { size: 15, className: "text-fg4 shrink-0 cursor-grab" }),
      /* @__PURE__ */ React.createElement(Lock, { size: 12, className: "text-fg4 shrink-0" }),
      /* @__PURE__ */ React.createElement("span", { className: "min-w-0 flex-1" }, /* @__PURE__ */ React.createElement("span", { className: "flex items-center gap-1.5" }, /* @__PURE__ */ React.createElement("span", { className: "text-sm text-fg2 truncate" }, field.title || field.key), field.required && /* @__PURE__ */ React.createElement("span", { className: "text-caption text-danger shrink-0" }, "\u043E\u0431\u044F\u0437.")), /* @__PURE__ */ React.createElement("span", { className: "block text-xs text-fg4 font-mono truncate" }, field.key)),
      /* @__PURE__ */ React.createElement(ModuleFieldBadge, { field }),
      /* @__PURE__ */ React.createElement("span", { className: "text-caption px-1.5 py-0.5 rounded bg-warning-subtle text-warning shrink-0" }, "\u0443\u043D\u0430\u0441\u043B\u0435\u0434."),
      /* @__PURE__ */ React.createElement("span", { className: "text-xs px-2 py-0.5 rounded-full bg-muted text-fg3 shrink-0" }, typeLabel)
    );
  }

  // src/client/src/shared/ui/ToastProvider.tsx
  init_define_import_meta_env();

  // src/client/node_modules/@radix-ui/react-toast/dist/index.mjs
  init_define_import_meta_env();
  var React44 = __toESM(require_react_shim(), 1);
  var ReactDOM5 = __toESM(require_react_dom_shim(), 1);
  var import_jsx_runtime20 = __toESM(require_react_shim(), 1);
  var PROVIDER_NAME2 = "ToastProvider";
  var [Collection4, useCollection4, createCollectionScope4] = createCollection("Toast");
  var [createToastContext, createToastScope] = createContextScope("Toast", [createCollectionScope4]);
  var [ToastProviderProvider, useToastProviderContext] = createToastContext(PROVIDER_NAME2);
  var ToastProvider = (props) => {
    const {
      __scopeToast,
      label = "Notification",
      duration = 5e3,
      swipeDirection = "right",
      swipeThreshold = 50,
      announcerContainer,
      children
    } = props;
    const [viewport, setViewport] = React44.useState(null);
    const [toastCount, setToastCount] = React44.useState(0);
    const isFocusedToastEscapeKeyDownRef = React44.useRef(false);
    const isClosePausedRef = React44.useRef(false);
    if (!label.trim()) {
      console.error(
        `Invalid prop \`label\` supplied to \`${PROVIDER_NAME2}\`. Expected non-empty \`string\`.`
      );
    }
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Collection4.Provider, { scope: __scopeToast, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
      ToastProviderProvider,
      {
        scope: __scopeToast,
        label,
        duration,
        swipeDirection,
        swipeThreshold,
        toastCount,
        viewport,
        onViewportChange: setViewport,
        onToastAdd: React44.useCallback(() => setToastCount((prevCount) => prevCount + 1), []),
        onToastRemove: React44.useCallback(() => setToastCount((prevCount) => prevCount - 1), []),
        isFocusedToastEscapeKeyDownRef,
        isClosePausedRef,
        announcerContainer,
        children
      }
    ) });
  };
  ToastProvider.displayName = PROVIDER_NAME2;
  var VIEWPORT_NAME2 = "ToastViewport";
  var VIEWPORT_DEFAULT_HOTKEY = ["F8"];
  var VIEWPORT_PAUSE = "toast.viewportPause";
  var VIEWPORT_RESUME = "toast.viewportResume";
  var ToastViewport = React44.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopeToast,
        hotkey = VIEWPORT_DEFAULT_HOTKEY,
        label = "Notifications ({hotkey})",
        ...viewportProps
      } = props;
      const context = useToastProviderContext(VIEWPORT_NAME2, __scopeToast);
      const getItems = useCollection4(__scopeToast);
      const wrapperRef = React44.useRef(null);
      const headFocusProxyRef = React44.useRef(null);
      const tailFocusProxyRef = React44.useRef(null);
      const ref = React44.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref, context.onViewportChange);
      const hotkeyLabel = hotkey.join("+").replace(/Key/g, "").replace(/Digit/g, "");
      const hasToasts = context.toastCount > 0;
      React44.useEffect(() => {
        const handleKeyDown = (event) => {
          const isHotkeyPressed = hotkey.length !== 0 && hotkey.every((key) => event[key] || event.code === key);
          if (isHotkeyPressed) ref.current?.focus();
        };
        document.addEventListener("keydown", handleKeyDown);
        return () => document.removeEventListener("keydown", handleKeyDown);
      }, [hotkey]);
      React44.useEffect(() => {
        const wrapper = wrapperRef.current;
        const viewport = ref.current;
        if (hasToasts && wrapper && viewport) {
          const handlePause = () => {
            if (!context.isClosePausedRef.current) {
              const pauseEvent = new CustomEvent(VIEWPORT_PAUSE);
              viewport.dispatchEvent(pauseEvent);
              context.isClosePausedRef.current = true;
            }
          };
          const handleResume = () => {
            if (context.isClosePausedRef.current) {
              const resumeEvent = new CustomEvent(VIEWPORT_RESUME);
              viewport.dispatchEvent(resumeEvent);
              context.isClosePausedRef.current = false;
            }
          };
          const handleFocusOutResume = (event) => {
            const isFocusMovingOutside = !wrapper.contains(event.relatedTarget);
            if (isFocusMovingOutside) handleResume();
          };
          const handlePointerLeaveResume = () => {
            const isFocusInside = wrapper.contains(document.activeElement);
            if (!isFocusInside) handleResume();
          };
          wrapper.addEventListener("focusin", handlePause);
          wrapper.addEventListener("focusout", handleFocusOutResume);
          wrapper.addEventListener("pointermove", handlePause);
          wrapper.addEventListener("pointerleave", handlePointerLeaveResume);
          window.addEventListener("blur", handlePause);
          window.addEventListener("focus", handleResume);
          return () => {
            wrapper.removeEventListener("focusin", handlePause);
            wrapper.removeEventListener("focusout", handleFocusOutResume);
            wrapper.removeEventListener("pointermove", handlePause);
            wrapper.removeEventListener("pointerleave", handlePointerLeaveResume);
            window.removeEventListener("blur", handlePause);
            window.removeEventListener("focus", handleResume);
          };
        }
      }, [hasToasts, context.isClosePausedRef]);
      const getSortedTabbableCandidates = React44.useCallback(
        ({ tabbingDirection }) => {
          const toastItems = getItems();
          const tabbableCandidates = toastItems.map((toastItem) => {
            const toastNode = toastItem.ref.current;
            const toastTabbableCandidates = [toastNode, ...getTabbableCandidates2(toastNode)];
            return tabbingDirection === "forwards" ? toastTabbableCandidates : toastTabbableCandidates.reverse();
          });
          return (tabbingDirection === "forwards" ? tabbableCandidates.reverse() : tabbableCandidates).flat();
        },
        [getItems]
      );
      React44.useEffect(() => {
        const viewport = ref.current;
        if (viewport) {
          const handleKeyDown = (event) => {
            const isMetaKey = event.altKey || event.ctrlKey || event.metaKey;
            const isTabKey = event.key === "Tab" && !isMetaKey;
            if (isTabKey) {
              const focusedElement = document.activeElement;
              const isTabbingBackwards = event.shiftKey;
              const targetIsViewport = event.target === viewport;
              if (targetIsViewport && isTabbingBackwards) {
                headFocusProxyRef.current?.focus();
                return;
              }
              const tabbingDirection = isTabbingBackwards ? "backwards" : "forwards";
              const sortedCandidates = getSortedTabbableCandidates({ tabbingDirection });
              const index2 = sortedCandidates.findIndex((candidate) => candidate === focusedElement);
              if (focusFirst4(sortedCandidates.slice(index2 + 1))) {
                event.preventDefault();
              } else {
                isTabbingBackwards ? headFocusProxyRef.current?.focus() : tailFocusProxyRef.current?.focus();
              }
            }
          };
          viewport.addEventListener("keydown", handleKeyDown);
          return () => viewport.removeEventListener("keydown", handleKeyDown);
        }
      }, [getItems, getSortedTabbableCandidates]);
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(
        Branch,
        {
          ref: wrapperRef,
          role: "region",
          "aria-label": label.replace("{hotkey}", hotkeyLabel),
          tabIndex: -1,
          style: { pointerEvents: hasToasts ? void 0 : "none" },
          children: [
            hasToasts && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
              FocusProxy,
              {
                ref: headFocusProxyRef,
                onFocusFromOutsideViewport: () => {
                  const tabbableCandidates = getSortedTabbableCandidates({
                    tabbingDirection: "forwards"
                  });
                  focusFirst4(tabbableCandidates);
                }
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Collection4.Slot, { scope: __scopeToast, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Primitive.ol, { tabIndex: -1, ...viewportProps, ref: composedRefs }) }),
            hasToasts && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
              FocusProxy,
              {
                ref: tailFocusProxyRef,
                onFocusFromOutsideViewport: () => {
                  const tabbableCandidates = getSortedTabbableCandidates({
                    tabbingDirection: "backwards"
                  });
                  focusFirst4(tabbableCandidates);
                }
              }
            )
          ]
        }
      );
    }
  );
  ToastViewport.displayName = VIEWPORT_NAME2;
  var FOCUS_PROXY_NAME = "ToastFocusProxy";
  var FocusProxy = React44.forwardRef(
    (props, forwardedRef) => {
      const { __scopeToast, onFocusFromOutsideViewport, ...proxyProps } = props;
      const context = useToastProviderContext(FOCUS_PROXY_NAME, __scopeToast);
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
        VisuallyHidden,
        {
          tabIndex: 0,
          ...proxyProps,
          ref: forwardedRef,
          style: { position: "fixed" },
          onFocus: (event) => {
            const prevFocusedElement = event.relatedTarget;
            const isFocusFromOutsideViewport = !context.viewport?.contains(prevFocusedElement);
            if (isFocusFromOutsideViewport) onFocusFromOutsideViewport();
          }
        }
      );
    }
  );
  FocusProxy.displayName = FOCUS_PROXY_NAME;
  var TOAST_NAME = "Toast";
  var TOAST_SWIPE_START = "toast.swipeStart";
  var TOAST_SWIPE_MOVE = "toast.swipeMove";
  var TOAST_SWIPE_CANCEL = "toast.swipeCancel";
  var TOAST_SWIPE_END = "toast.swipeEnd";
  var Toast = React44.forwardRef(
    (props, forwardedRef) => {
      const { forceMount, open: openProp, defaultOpen, onOpenChange, ...toastProps } = props;
      const [open, setOpen] = useControllableState({
        prop: openProp,
        defaultProp: defaultOpen ?? true,
        onChange: onOpenChange,
        caller: TOAST_NAME
      });
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Presence, { present: forceMount || open, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
        ToastImpl,
        {
          open,
          ...toastProps,
          ref: forwardedRef,
          onClose: () => setOpen(false),
          onPause: useCallbackRef(props.onPause),
          onResume: useCallbackRef(props.onResume),
          onSwipeStart: composeEventHandlers(props.onSwipeStart, (event) => {
            event.currentTarget.setAttribute("data-swipe", "start");
          }),
          onSwipeMove: composeEventHandlers(props.onSwipeMove, (event) => {
            const { x, y } = event.detail.delta;
            event.currentTarget.setAttribute("data-swipe", "move");
            event.currentTarget.style.setProperty("--radix-toast-swipe-move-x", `${x}px`);
            event.currentTarget.style.setProperty("--radix-toast-swipe-move-y", `${y}px`);
          }),
          onSwipeCancel: composeEventHandlers(props.onSwipeCancel, (event) => {
            event.currentTarget.setAttribute("data-swipe", "cancel");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-move-x");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-move-y");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-end-x");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-end-y");
          }),
          onSwipeEnd: composeEventHandlers(props.onSwipeEnd, (event) => {
            const { x, y } = event.detail.delta;
            event.currentTarget.setAttribute("data-swipe", "end");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-move-x");
            event.currentTarget.style.removeProperty("--radix-toast-swipe-move-y");
            event.currentTarget.style.setProperty("--radix-toast-swipe-end-x", `${x}px`);
            event.currentTarget.style.setProperty("--radix-toast-swipe-end-y", `${y}px`);
            setOpen(false);
          })
        }
      ) });
    }
  );
  Toast.displayName = TOAST_NAME;
  var [ToastInteractiveProvider, useToastInteractiveContext] = createToastContext(TOAST_NAME, {
    onClose() {
    }
  });
  var ToastImpl = React44.forwardRef(
    (props, forwardedRef) => {
      const {
        __scopeToast,
        type = "foreground",
        duration: durationProp,
        open,
        onClose,
        onEscapeKeyDown,
        onPause,
        onResume,
        onSwipeStart,
        onSwipeMove,
        onSwipeCancel,
        onSwipeEnd,
        ...toastProps
      } = props;
      const context = useToastProviderContext(TOAST_NAME, __scopeToast);
      const [node, setNode] = React44.useState(null);
      const composedRefs = useComposedRefs(forwardedRef, (node2) => setNode(node2));
      const pointerStartRef = React44.useRef(null);
      const swipeDeltaRef = React44.useRef(null);
      const duration = durationProp || context.duration;
      const closeTimerStartTimeRef = React44.useRef(0);
      const closeTimerRemainingTimeRef = React44.useRef(duration);
      const closeTimerRef = React44.useRef(0);
      const { onToastAdd, onToastRemove } = context;
      const handleClose = useCallbackRef(() => {
        const isFocusInToast = node?.contains(document.activeElement);
        if (isFocusInToast) context.viewport?.focus();
        onClose();
      });
      const startTimer = React44.useCallback(
        (duration2) => {
          if (!duration2 || duration2 === Infinity) return;
          window.clearTimeout(closeTimerRef.current);
          closeTimerStartTimeRef.current = (/* @__PURE__ */ new Date()).getTime();
          closeTimerRef.current = window.setTimeout(handleClose, duration2);
        },
        [handleClose]
      );
      React44.useEffect(() => {
        const viewport = context.viewport;
        if (viewport) {
          const handleResume = () => {
            startTimer(closeTimerRemainingTimeRef.current);
            onResume?.();
          };
          const handlePause = () => {
            const elapsedTime = (/* @__PURE__ */ new Date()).getTime() - closeTimerStartTimeRef.current;
            closeTimerRemainingTimeRef.current = closeTimerRemainingTimeRef.current - elapsedTime;
            window.clearTimeout(closeTimerRef.current);
            onPause?.();
          };
          viewport.addEventListener(VIEWPORT_PAUSE, handlePause);
          viewport.addEventListener(VIEWPORT_RESUME, handleResume);
          return () => {
            viewport.removeEventListener(VIEWPORT_PAUSE, handlePause);
            viewport.removeEventListener(VIEWPORT_RESUME, handleResume);
          };
        }
      }, [context.viewport, duration, onPause, onResume, startTimer]);
      React44.useEffect(() => {
        if (open && !context.isClosePausedRef.current) startTimer(duration);
      }, [open, duration, context.isClosePausedRef, startTimer]);
      React44.useEffect(() => {
        onToastAdd();
        return () => onToastRemove();
      }, [onToastAdd, onToastRemove]);
      const announceTextContent = React44.useMemo(() => {
        return node ? getAnnounceTextContent(node) : null;
      }, [node]);
      if (!context.viewport) return null;
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(import_jsx_runtime20.Fragment, { children: [
        announceTextContent && /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
          ToastAnnounce,
          {
            __scopeToast,
            role: "status",
            "aria-live": type === "foreground" ? "assertive" : "polite",
            children: announceTextContent
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(ToastInteractiveProvider, { scope: __scopeToast, onClose: handleClose, children: ReactDOM5.createPortal(
          /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Collection4.ItemSlot, { scope: __scopeToast, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
            Root3,
            {
              asChild: true,
              onEscapeKeyDown: composeEventHandlers(onEscapeKeyDown, () => {
                if (!context.isFocusedToastEscapeKeyDownRef.current) handleClose();
                context.isFocusedToastEscapeKeyDownRef.current = false;
              }),
              children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
                Primitive.li,
                {
                  tabIndex: 0,
                  "data-state": open ? "open" : "closed",
                  "data-swipe-direction": context.swipeDirection,
                  ...toastProps,
                  ref: composedRefs,
                  style: { userSelect: "none", touchAction: "none", ...props.style },
                  onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
                    if (event.key !== "Escape") return;
                    onEscapeKeyDown?.(event.nativeEvent);
                    if (!event.nativeEvent.defaultPrevented) {
                      context.isFocusedToastEscapeKeyDownRef.current = true;
                      handleClose();
                    }
                  }),
                  onPointerDown: composeEventHandlers(props.onPointerDown, (event) => {
                    if (event.button !== 0) return;
                    pointerStartRef.current = { x: event.clientX, y: event.clientY };
                  }),
                  onPointerMove: composeEventHandlers(props.onPointerMove, (event) => {
                    if (!pointerStartRef.current) return;
                    const x = event.clientX - pointerStartRef.current.x;
                    const y = event.clientY - pointerStartRef.current.y;
                    const hasSwipeMoveStarted = Boolean(swipeDeltaRef.current);
                    const isHorizontalSwipe = ["left", "right"].includes(context.swipeDirection);
                    const clamp3 = ["left", "up"].includes(context.swipeDirection) ? Math.min : Math.max;
                    const clampedX = isHorizontalSwipe ? clamp3(0, x) : 0;
                    const clampedY = !isHorizontalSwipe ? clamp3(0, y) : 0;
                    const moveStartBuffer = event.pointerType === "touch" ? 10 : 2;
                    const delta = { x: clampedX, y: clampedY };
                    const eventDetail = { originalEvent: event, delta };
                    if (hasSwipeMoveStarted) {
                      swipeDeltaRef.current = delta;
                      handleAndDispatchCustomEvent2(TOAST_SWIPE_MOVE, onSwipeMove, eventDetail, {
                        discrete: false
                      });
                    } else if (isDeltaInDirection(delta, context.swipeDirection, moveStartBuffer)) {
                      swipeDeltaRef.current = delta;
                      handleAndDispatchCustomEvent2(TOAST_SWIPE_START, onSwipeStart, eventDetail, {
                        discrete: false
                      });
                      event.target.setPointerCapture(event.pointerId);
                    } else if (Math.abs(x) > moveStartBuffer || Math.abs(y) > moveStartBuffer) {
                      pointerStartRef.current = null;
                    }
                  }),
                  onPointerUp: composeEventHandlers(props.onPointerUp, (event) => {
                    const delta = swipeDeltaRef.current;
                    const target = event.target;
                    if (target.hasPointerCapture(event.pointerId)) {
                      target.releasePointerCapture(event.pointerId);
                    }
                    swipeDeltaRef.current = null;
                    pointerStartRef.current = null;
                    if (delta) {
                      const toast = event.currentTarget;
                      const eventDetail = { originalEvent: event, delta };
                      if (isDeltaInDirection(delta, context.swipeDirection, context.swipeThreshold)) {
                        handleAndDispatchCustomEvent2(TOAST_SWIPE_END, onSwipeEnd, eventDetail, {
                          discrete: true
                        });
                      } else {
                        handleAndDispatchCustomEvent2(
                          TOAST_SWIPE_CANCEL,
                          onSwipeCancel,
                          eventDetail,
                          {
                            discrete: true
                          }
                        );
                      }
                      toast.addEventListener("click", (event2) => event2.preventDefault(), {
                        once: true
                      });
                    }
                  })
                }
              )
            }
          ) }),
          context.viewport
        ) })
      ] });
    }
  );
  var ToastAnnounce = (props) => {
    const { __scopeToast, children, ...announceProps } = props;
    const context = useToastProviderContext(TOAST_NAME, __scopeToast);
    const [renderAnnounceText, setRenderAnnounceText] = React44.useState(false);
    const [isAnnounced, setIsAnnounced] = React44.useState(false);
    useNextFrame(() => setRenderAnnounceText(true));
    React44.useEffect(() => {
      const timer = window.setTimeout(() => setIsAnnounced(true), 1e3);
      return () => window.clearTimeout(timer);
    }, []);
    return isAnnounced ? null : /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Portal, { asChild: true, container: context.announcerContainer || void 0, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(VisuallyHidden, { ...announceProps, children: renderAnnounceText && /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(import_jsx_runtime20.Fragment, { children: [
      context.label,
      " ",
      children
    ] }) }) });
  };
  var TITLE_NAME2 = "ToastTitle";
  var ToastTitle = React44.forwardRef(
    (props, forwardedRef) => {
      const { __scopeToast, ...titleProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Primitive.div, { ...titleProps, ref: forwardedRef });
    }
  );
  ToastTitle.displayName = TITLE_NAME2;
  var DESCRIPTION_NAME2 = "ToastDescription";
  var ToastDescription = React44.forwardRef(
    (props, forwardedRef) => {
      const { __scopeToast, ...descriptionProps } = props;
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Primitive.div, { ...descriptionProps, ref: forwardedRef });
    }
  );
  ToastDescription.displayName = DESCRIPTION_NAME2;
  var ACTION_NAME = "ToastAction";
  var ToastAction = React44.forwardRef(
    (props, forwardedRef) => {
      const { altText, ...actionProps } = props;
      if (!altText.trim()) {
        console.error(
          `Invalid prop \`altText\` supplied to \`${ACTION_NAME}\`. Expected non-empty \`string\`.`
        );
        return null;
      }
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(ToastAnnounceExclude, { altText, asChild: true, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(ToastClose, { ...actionProps, ref: forwardedRef }) });
    }
  );
  ToastAction.displayName = ACTION_NAME;
  var CLOSE_NAME3 = "ToastClose";
  var ToastClose = React44.forwardRef(
    (props, forwardedRef) => {
      const { __scopeToast, ...closeProps } = props;
      const interactiveContext = useToastInteractiveContext(CLOSE_NAME3, __scopeToast);
      return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(ToastAnnounceExclude, { asChild: true, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
        Primitive.button,
        {
          type: "button",
          ...closeProps,
          ref: forwardedRef,
          onClick: composeEventHandlers(props.onClick, interactiveContext.onClose)
        }
      ) });
    }
  );
  ToastClose.displayName = CLOSE_NAME3;
  var ToastAnnounceExclude = React44.forwardRef((props, forwardedRef) => {
    const { __scopeToast, altText, ...announceExcludeProps } = props;
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
      Primitive.div,
      {
        "data-radix-toast-announce-exclude": "",
        "data-radix-toast-announce-alt": altText || void 0,
        ...announceExcludeProps,
        ref: forwardedRef
      }
    );
  });
  function getAnnounceTextContent(container) {
    const textContent = [];
    const childNodes = Array.from(container.childNodes);
    childNodes.forEach((node) => {
      if (node.nodeType === node.TEXT_NODE && node.textContent) textContent.push(node.textContent);
      if (isHTMLElement2(node)) {
        const isHidden2 = node.ariaHidden || node.hidden || node.style.display === "none";
        const isExcluded = node.dataset.radixToastAnnounceExclude === "";
        if (!isHidden2) {
          if (isExcluded) {
            const altText = node.dataset.radixToastAnnounceAlt;
            if (altText) textContent.push(altText);
          } else {
            textContent.push(...getAnnounceTextContent(node));
          }
        }
      }
    });
    return textContent;
  }
  function handleAndDispatchCustomEvent2(name, handler, detail, { discrete }) {
    const currentTarget = detail.originalEvent.currentTarget;
    const event = new CustomEvent(name, { bubbles: true, cancelable: true, detail });
    if (handler) currentTarget.addEventListener(name, handler, { once: true });
    if (discrete) {
      dispatchDiscreteCustomEvent(currentTarget, event);
    } else {
      currentTarget.dispatchEvent(event);
    }
  }
  var isDeltaInDirection = (delta, direction, threshold = 0) => {
    const deltaX = Math.abs(delta.x);
    const deltaY = Math.abs(delta.y);
    const isDeltaX = deltaX > deltaY;
    if (direction === "left" || direction === "right") {
      return isDeltaX && deltaX > threshold;
    } else {
      return !isDeltaX && deltaY > threshold;
    }
  };
  function useNextFrame(callback = () => {
  }) {
    const fn = useCallbackRef(callback);
    useLayoutEffect22(() => {
      let raf1 = 0;
      let raf2 = 0;
      raf1 = window.requestAnimationFrame(() => raf2 = window.requestAnimationFrame(fn));
      return () => {
        window.cancelAnimationFrame(raf1);
        window.cancelAnimationFrame(raf2);
      };
    }, [fn]);
  }
  function isHTMLElement2(node) {
    return node.nodeType === node.ELEMENT_NODE;
  }
  function getTabbableCandidates2(container) {
    const nodes = [];
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (node) => {
        const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
        if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
        return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
  }
  function focusFirst4(candidates) {
    const previouslyFocusedElement = document.activeElement;
    return candidates.some((candidate) => {
      if (candidate === previouslyFocusedElement) return true;
      candidate.focus();
      return document.activeElement !== previouslyFocusedElement;
    });
  }
  var Provider = ToastProvider;
  var Viewport = ToastViewport;
  var Root24 = Toast;
  var Description = ToastDescription;
  var Action = ToastAction;
  var Close = ToastClose;

  // src/client/src/shared/ui/ToastProvider.tsx
  var import_react27 = __toESM(require_react_shim(), 1);

  // src/client/src/shared/ui/bugReportBus.ts
  init_define_import_meta_env();
  var import_react26 = __toESM(require_react_shim(), 1);
  var BugReportCtx = (0, import_react26.createContext)(null);
  var openFromAnywhere = null;
  function openBugReport(prefill = {}) {
    openFromAnywhere?.(prefill);
  }

  // src/client/src/shared/ui/ToastProvider.tsx
  var MAX_VISIBLE = 3;
  var DEFAULT_DURATION = { success: 4e3, info: 4e3, error: 8e3 };
  var VARIANT_ICON = { success: CircleCheck, error: TriangleAlert, info: Info };
  var VARIANT_ICON_COLOR = {
    success: "text-success",
    error: "text-danger",
    info: "text-fg3"
  };
  function ToastProvider2({ children }) {
    const [items, setItems] = (0, import_react27.useState)([]);
    const idRef = (0, import_react27.useRef)(0);
    const push = (0, import_react27.useCallback)((o) => {
      setItems((prev) => [...prev, { ...o, id: ++idRef.current }].slice(-MAX_VISIBLE));
    }, []);
    const remove = (0, import_react27.useCallback)((id) => setItems((prev) => prev.filter((t) => t.id !== id)), []);
    const api = (0, import_react27.useMemo)(() => ({
      toast: push,
      success: (message, o) => push({ ...o, message, variant: "success" }),
      error: (message, o) => push({ ...o, message, variant: "error" }),
      info: (message, o) => push({ ...o, message, variant: "info" }),
      apiError: (e, fallback, o) => push({
        ...o,
        message: apiError(e, fallback ?? "\u041E\u0448\u0438\u0431\u043A\u0430"),
        variant: "error",
        traceId: traceIdOf(e)
      })
    }), [push]);
    return /* @__PURE__ */ React.createElement(ToastCtx.Provider, { value: api }, /* @__PURE__ */ React.createElement(Provider, { swipeDirection: "right" }, children, items.map((t) => /* @__PURE__ */ React.createElement(ToastCard, { key: t.id, item: t, onRemove: () => remove(t.id) })), /* @__PURE__ */ React.createElement(Viewport, { className: "fixed bottom-4 right-4 z-[100] flex w-[380px] max-w-[calc(100vw-2rem)] flex-col gap-2 outline-none" })));
  }
  function ToastCard({ item, onRemove }) {
    const variant = item.variant ?? "info";
    const Icon2 = VARIANT_ICON[variant];
    const bg = variant === "error" ? "bg-danger-subtle" : "bg-surface";
    return /* @__PURE__ */ React.createElement(
      Root24,
      {
        duration: item.duration ?? DEFAULT_DURATION[variant],
        type: variant === "error" ? "foreground" : "background",
        onOpenChange: (open) => {
          if (!open) onRemove();
        },
        className: `flex items-start gap-2.5 rounded-lg border border-stroke ${bg} px-3.5 py-3 shadow-[var(--f-shadow16)]
        data-[state=open]:[animation:toast-in_150ms_ease-out]
        data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)]
        data-[swipe=cancel]:translate-x-0 data-[swipe=cancel]:transition-transform
        data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)]`
      },
      /* @__PURE__ */ React.createElement(Icon2, { size: 18, className: `mt-0.5 shrink-0 ${VARIANT_ICON_COLOR[variant]}` }),
      /* @__PURE__ */ React.createElement(Description, { className: "flex-1 min-w-0 text-sm text-fg1" }, item.message),
      !item.action && item.traceId && /* @__PURE__ */ React.createElement(
        Action,
        {
          altText: "\u0421\u043E\u043E\u0431\u0449\u0438\u0442\u044C \u043E\u0431 \u043E\u0448\u0438\u0431\u043A\u0435",
          asChild: true,
          onClick: () => openBugReport({ origin: "toast", received: item.message })
        },
        /* @__PURE__ */ React.createElement("button", { type: "button", className: "shrink-0 text-sm font-medium text-brand hover:text-brand-hover transition-colors" }, "\u0421\u043E\u043E\u0431\u0449\u0438\u0442\u044C")
      ),
      item.action && /* @__PURE__ */ React.createElement(Action, { altText: item.action.label, asChild: true, onClick: () => item.action.onClick() }, /* @__PURE__ */ React.createElement("button", { type: "button", className: "shrink-0 text-sm font-medium text-brand hover:text-brand-hover transition-colors" }, item.action.label)),
      /* @__PURE__ */ React.createElement(Close, { "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C", className: "shrink-0 text-fg4 hover:text-fg2 transition-colors" }, /* @__PURE__ */ React.createElement(X, { size: 15 }))
    );
  }

  // src/client/src/shared/ui/useDirtyGuard.ts
  init_define_import_meta_env();
  var import_react28 = __toESM(require_react_shim(), 1);
  function useDirtyGuard({ isDirty, saving, saveAll, onCommit }) {
    const [pending, setPending] = (0, import_react28.useState)(null);
    const request = (next) => {
      if (isDirty) setPending({ next });
      else onCommit(next);
    };
    const dialogProps = {
      open: pending !== null,
      saving,
      onCancel: () => setPending(null),
      onDiscard: () => {
        if (pending) onCommit(pending.next);
        setPending(null);
      },
      onSave: async () => {
        try {
          await saveAll();
          if (pending) onCommit(pending.next);
        } catch {
        } finally {
          setPending(null);
        }
      }
    };
    return { request, dialogProps };
  }

  // src/client/src/shared/ui/DataGrid.tsx
  init_define_import_meta_env();
  var import_react30 = __toESM(require_react_shim(), 1);

  // src/client/node_modules/react-router/dist/production/index.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/router/history.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/router/url.js
  init_define_import_meta_env();
  var ABSOLUTE_URL_REGEX = /^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i;
  var PROTOCOL_RELATIVE_URL_REGEX = /^[\\/]{2}/;
  function normalizeProtocolRelativeUrl(url, protocol) {
    return protocol + url.replace(/\\/g, "/");
  }

  // src/client/node_modules/react-router/dist/production/lib/router/history.js
  function invariant(value, message) {
    if (value === false || value === null || typeof value === "undefined") throw new Error(message);
  }
  function warning(cond, message) {
    if (!cond) {
      if (typeof console !== "undefined") console.warn(message);
      try {
        throw new Error(message);
      } catch (e) {
      }
    }
  }
  function createPath({ pathname = "/", search = "", hash = "" }) {
    if (search && search !== "?") pathname += search.charAt(0) === "?" ? search : "?" + search;
    if (hash && hash !== "#") pathname += hash.charAt(0) === "#" ? hash : "#" + hash;
    return pathname;
  }
  function parsePath(path) {
    let parsedPath = {};
    if (path) {
      let hashIndex = path.indexOf("#");
      if (hashIndex >= 0) {
        parsedPath.hash = path.substring(hashIndex);
        path = path.substring(0, hashIndex);
      }
      let searchIndex = path.indexOf("?");
      if (searchIndex >= 0) {
        parsedPath.search = path.substring(searchIndex);
        path = path.substring(0, searchIndex);
      }
      if (path) parsedPath.pathname = path;
    }
    return parsedPath;
  }

  // src/client/node_modules/react-router/dist/production/lib/router/utils.js
  init_define_import_meta_env();
  var React$1 = __toESM(require_react_shim(), 1);
  function matchRoutes(routes, locationArg, basename = "/") {
    return matchRoutesImpl(routes, locationArg, basename, false);
  }
  function matchRoutesImpl(routes, locationArg, basename, allowPartial, precomputedBranches) {
    let pathname = stripBasename((typeof locationArg === "string" ? parsePath(locationArg) : locationArg).pathname || "/", basename);
    if (pathname == null) return null;
    let branches = precomputedBranches ?? flattenAndRankRoutes(routes);
    let matches = null;
    let decoded = decodePath(pathname);
    for (let i = 0; matches == null && i < branches.length; ++i) matches = matchRouteBranch(branches[i], decoded, allowPartial);
    return matches;
  }
  function convertRouteMatchToUiMatch(match, loaderData) {
    let { route, pathname, params } = match;
    return {
      id: route.id,
      pathname,
      params,
      loaderData: loaderData[route.id],
      handle: route.handle
    };
  }
  function flattenAndRankRoutes(routes) {
    let branches = flattenRoutes(routes);
    rankRouteBranches(branches);
    return branches;
  }
  function flattenRoutes(routes, branches = [], parentsMeta = [], parentPath = "", _hasParentOptionalSegments = false) {
    let flattenRoute = (route, index2, hasParentOptionalSegments = _hasParentOptionalSegments, relativePath) => {
      let meta = {
        relativePath: relativePath === void 0 ? route.path || "" : relativePath,
        caseSensitive: route.caseSensitive === true,
        childrenIndex: index2,
        route
      };
      if (meta.relativePath.startsWith("/")) {
        if (!meta.relativePath.startsWith(parentPath) && hasParentOptionalSegments) return;
        invariant(meta.relativePath.startsWith(parentPath), `Absolute route path "${meta.relativePath}" nested under path "${parentPath}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`);
        meta.relativePath = meta.relativePath.slice(parentPath.length);
      }
      let path = joinPaths([parentPath, meta.relativePath]);
      let routesMeta = parentsMeta.concat(meta);
      if (route.children && route.children.length > 0) {
        invariant(route.index !== true, `Index routes must not have child routes. Please remove all child routes from route path "${path}".`);
        flattenRoutes(route.children, branches, routesMeta, path, hasParentOptionalSegments);
      }
      if (route.path == null && !route.index) return;
      branches.push({
        path,
        score: computeScore(path, route.index),
        routesMeta: routesMeta.map((meta2, i) => {
          let [matcher, params] = compilePath(meta2.relativePath, meta2.caseSensitive, i === routesMeta.length - 1);
          return {
            ...meta2,
            matcher,
            compiledParams: params
          };
        })
      });
    };
    routes.forEach((route, index2) => {
      if (route.path === "" || !route.path?.includes("?")) flattenRoute(route, index2);
      else for (let exploded of explodeOptionalSegments(route.path)) flattenRoute(route, index2, true, exploded);
    });
    return branches;
  }
  function explodeOptionalSegments(path) {
    let segments = path.split("/");
    if (segments.length === 0) return [];
    let [first, ...rest] = segments;
    let isOptional = first.endsWith("?");
    let required = first.replace(/\?$/, "");
    if (rest.length === 0) return isOptional ? [required, ""] : [required];
    let restExploded = explodeOptionalSegments(rest.join("/"));
    let result = [];
    result.push(...restExploded.map((subpath) => subpath === "" ? required : [required, subpath].join("/")));
    if (isOptional) result.push(...restExploded);
    return result.map((exploded) => path.startsWith("/") && exploded === "" ? "/" : exploded);
  }
  function rankRouteBranches(branches) {
    branches.sort((a, b) => a.score !== b.score ? b.score - a.score : compareIndexes(a.routesMeta.map((meta) => meta.childrenIndex), b.routesMeta.map((meta) => meta.childrenIndex)));
  }
  var paramRe = /^:[\w-]+$/;
  var partialParamRe = /^:[\w-]+/;
  var partialDynamicSegmentValue = 3.5;
  var dynamicSegmentValue = 3;
  var indexRouteValue = 2;
  var emptySegmentValue = 1;
  var staticSegmentValue = 10;
  var splatPenalty = -2;
  var isSplat = (s) => s === "*";
  function computeScore(path, index2) {
    let segments = path.split("/");
    let initialScore = segments.length;
    if (segments.some(isSplat)) initialScore += splatPenalty;
    if (index2) initialScore += indexRouteValue;
    return segments.filter((s) => !isSplat(s)).reduce((score, segment) => score + (paramRe.test(segment) ? dynamicSegmentValue : partialParamRe.test(segment) ? partialDynamicSegmentValue : segment === "" ? emptySegmentValue : staticSegmentValue), initialScore);
  }
  function compareIndexes(a, b) {
    return a.length === b.length && a.slice(0, -1).every((n, i) => n === b[i]) ? a[a.length - 1] - b[b.length - 1] : 0;
  }
  function matchRouteBranch(branch, pathname, allowPartial = false) {
    let { routesMeta } = branch;
    let matchedParams = {};
    let matchedPathname = "/";
    let matches = [];
    for (let i = 0; i < routesMeta.length; ++i) {
      let meta = routesMeta[i];
      let end = i === routesMeta.length - 1;
      let remainingPathname = matchedPathname === "/" ? pathname : pathname.slice(matchedPathname.length) || "/";
      let pattern = {
        path: meta.relativePath,
        caseSensitive: meta.caseSensitive,
        end
      };
      let match = meta.matcher && meta.compiledParams ? matchPathImpl(pattern, remainingPathname, meta.matcher, meta.compiledParams) : matchPath(pattern, remainingPathname);
      let route = meta.route;
      if (!match && end && allowPartial && !routesMeta[routesMeta.length - 1].route.index) match = matchPath({
        path: meta.relativePath,
        caseSensitive: meta.caseSensitive,
        end: false
      }, remainingPathname);
      if (!match) return null;
      Object.assign(matchedParams, match.params);
      matches.push({
        params: matchedParams,
        pathname: joinPaths([matchedPathname, match.pathname]),
        pathnameBase: normalizePathname(joinPaths([matchedPathname, match.pathnameBase])),
        route
      });
      if (match.pathnameBase !== "/") matchedPathname = joinPaths([matchedPathname, match.pathnameBase]);
    }
    return matches;
  }
  function matchPath(pattern, pathname) {
    if (typeof pattern === "string") pattern = {
      path: pattern,
      caseSensitive: false,
      end: true
    };
    let [matcher, compiledParams] = compilePath(pattern.path, pattern.caseSensitive, pattern.end);
    return matchPathImpl(pattern, pathname, matcher, compiledParams);
  }
  function matchPathImpl(pattern, pathname, matcher, compiledParams) {
    let match = pathname.match(matcher);
    if (!match) return null;
    let matchedPathname = match[0];
    let pathnameBase = matchedPathname.replace(/(.)\/+$/, "$1");
    let captureGroups = match.slice(1);
    return {
      params: compiledParams.reduce((memo2, { paramName, isOptional }, index2) => {
        if (paramName === "*") {
          let splatValue = captureGroups[index2] || "";
          pathnameBase = matchedPathname.slice(0, matchedPathname.length - splatValue.length).replace(/(.)\/+$/, "$1");
        }
        const value = captureGroups[index2];
        if (isOptional && !value) memo2[paramName] = void 0;
        else memo2[paramName] = (value || "").replace(/%2F/g, "/");
        return memo2;
      }, {}),
      pathname: matchedPathname,
      pathnameBase,
      pattern
    };
  }
  function compilePath(path, caseSensitive = false, end = true) {
    warning(path === "*" || !path.endsWith("*") || path.endsWith("/*"), `Route path "${path}" will be treated as if it were "${path.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${path.replace(/\*$/, "/*")}".`);
    let params = [];
    let regexpSource = "^" + path.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (match, paramName, isOptional, index2, str) => {
      params.push({
        paramName,
        isOptional: isOptional != null
      });
      if (isOptional) {
        let nextChar = str.charAt(index2 + match.length);
        if (nextChar && nextChar !== "/") return "/([^\\/]*)";
        return "(?:/([^\\/]*))?";
      }
      return "/([^\\/]+)";
    }).replace(/\/([\w-]+)\?(?=\/|$|\()/g, "(?:/$1)?");
    if (path.endsWith("*")) {
      params.push({ paramName: "*" });
      regexpSource += path === "*" || path === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$";
    } else if (end) regexpSource += "\\/*$";
    else if (path !== "" && path !== "/") regexpSource += "(?:(?=\\/|$))";
    return [new RegExp(regexpSource, caseSensitive ? void 0 : "i"), params];
  }
  function decodePath(value) {
    try {
      return value.split("/").map((v) => decodeURIComponent(v).replace(/\//g, "%2F")).join("/");
    } catch (error) {
      warning(false, `The URL path "${value}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${error}).`);
      return value;
    }
  }
  function stripBasename(pathname, basename) {
    if (basename === "/") return pathname;
    if (!pathname.toLowerCase().startsWith(basename.toLowerCase())) return null;
    let startIndex = basename.endsWith("/") ? basename.length - 1 : basename.length;
    let nextChar = pathname.charAt(startIndex);
    if (nextChar && nextChar !== "/") return null;
    return pathname.slice(startIndex) || "/";
  }
  function resolvePath(to, fromPathname = "/") {
    let { pathname: toPathname, search = "", hash = "" } = typeof to === "string" ? parsePath(to) : to;
    let pathname;
    if (toPathname) {
      toPathname = removeDoubleSlashes(toPathname);
      if (toPathname.startsWith("/")) pathname = resolvePathname(toPathname.substring(1), "/");
      else pathname = resolvePathname(toPathname, fromPathname);
    } else pathname = fromPathname;
    return {
      pathname,
      search: normalizeSearch(search),
      hash: normalizeHash(hash)
    };
  }
  function resolvePathname(relativePath, fromPathname) {
    let segments = removeTrailingSlash(fromPathname).split("/");
    relativePath.split("/").forEach((segment) => {
      if (segment === "..") {
        if (segments.length > 1) segments.pop();
      } else if (segment !== ".") segments.push(segment);
    });
    return segments.length > 1 ? segments.join("/") : "/";
  }
  function getInvalidPathError(char, field, dest, path) {
    return `Cannot include a '${char}' character in a manually specified \`to.${field}\` field [${JSON.stringify(path)}].  Please separate it out to the \`to.${dest}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
  }
  function getPathContributingMatches(matches) {
    return matches.filter((match, index2) => index2 === 0 || match.route.path && match.route.path.length > 0);
  }
  function getResolveToMatches(matches) {
    let pathMatches = getPathContributingMatches(matches);
    return pathMatches.map((match, idx) => idx === pathMatches.length - 1 ? match.pathname : match.pathnameBase);
  }
  function resolveTo(toArg, routePathnames, locationPathname, isPathRelative = false) {
    let to;
    if (typeof toArg === "string") to = parsePath(toArg);
    else {
      to = { ...toArg };
      invariant(!to.pathname || !to.pathname.includes("?"), getInvalidPathError("?", "pathname", "search", to));
      invariant(!to.pathname || !to.pathname.includes("#"), getInvalidPathError("#", "pathname", "hash", to));
      invariant(!to.search || !to.search.includes("#"), getInvalidPathError("#", "search", "hash", to));
    }
    let isEmptyPath = toArg === "" || to.pathname === "";
    let toPathname = isEmptyPath ? "/" : to.pathname;
    let from;
    if (toPathname == null) from = locationPathname;
    else {
      let routePathnameIndex = routePathnames.length - 1;
      if (!isPathRelative && toPathname.startsWith("..")) {
        let toSegments = toPathname.split("/");
        while (toSegments[0] === "..") {
          toSegments.shift();
          routePathnameIndex -= 1;
        }
        to.pathname = toSegments.join("/");
      }
      from = routePathnameIndex >= 0 ? routePathnames[routePathnameIndex] : "/";
    }
    let path = resolvePath(to, from);
    let hasExplicitTrailingSlash = toPathname && toPathname !== "/" && toPathname.endsWith("/");
    let hasCurrentTrailingSlash = (isEmptyPath || toPathname === ".") && locationPathname.endsWith("/");
    if (!path.pathname.endsWith("/") && (hasExplicitTrailingSlash || hasCurrentTrailingSlash)) path.pathname += "/";
    return path;
  }
  var removeDoubleSlashes = (path) => path.replace(/[\\/]{2,}/g, "/");
  var joinPaths = (paths) => removeDoubleSlashes(paths.join("/"));
  var removeTrailingSlash = (path) => path.replace(/\/+$/, "");
  var normalizePathname = (pathname) => removeTrailingSlash(pathname).replace(/^\/*/, "/");
  var normalizeSearch = (search) => !search || search === "?" ? "" : search.startsWith("?") ? search : "?" + search;
  var normalizeHash = (hash) => !hash || hash === "#" ? "" : hash.startsWith("#") ? hash : "#" + hash;
  var ErrorResponseImpl = class {
    constructor(status, statusText, data, internal = false) {
      __publicField(this, "status");
      __publicField(this, "statusText");
      __publicField(this, "data");
      __publicField(this, "error");
      __publicField(this, "internal");
      this.status = status;
      this.statusText = statusText || "";
      this.internal = internal;
      if (data instanceof Error) {
        this.data = data.toString();
        this.error = data;
      } else this.data = data;
    }
  };
  function isRouteErrorResponse(error) {
    return error != null && typeof error.status === "number" && typeof error.statusText === "string" && typeof error.internal === "boolean" && "data" in error;
  }
  function getRoutePattern(matches) {
    return joinPaths(matches.map((m) => m.route.path).filter(Boolean)) || "/";
  }
  var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
  function parseToInfo(_to, basename) {
    let to = _to;
    if (typeof to !== "string" || !ABSOLUTE_URL_REGEX.test(to)) return {
      absoluteURL: void 0,
      isExternal: false,
      to
    };
    let absoluteURL = to;
    let isExternal = false;
    if (isBrowser) try {
      let currentUrl = new URL(window.location.href);
      let targetUrl = PROTOCOL_RELATIVE_URL_REGEX.test(to) ? new URL(normalizeProtocolRelativeUrl(to, currentUrl.protocol)) : new URL(to);
      let path = stripBasename(targetUrl.pathname, basename);
      if (targetUrl.origin === currentUrl.origin && path != null) to = path + targetUrl.search + targetUrl.hash;
      else isExternal = true;
    } catch (e) {
      warning(false, `<Link to="${to}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`);
    }
    return {
      absoluteURL,
      isExternal,
      to
    };
  }

  // src/client/node_modules/react-router/dist/production/lib/router/router.js
  init_define_import_meta_env();
  var validMutationMethodsArr = [
    "POST",
    "PUT",
    "PATCH",
    "DELETE"
  ];
  var validMutationMethods = new Set(validMutationMethodsArr);
  var validRequestMethodsArr = ["GET", ...validMutationMethodsArr];
  var validRequestMethods = new Set(validRequestMethodsArr);
  var invalidProtocols = [
    "about:",
    "blob:",
    "chrome:",
    "chrome-untrusted:",
    "content:",
    "data:",
    "devtools:",
    "file:",
    "filesystem:",
    "javascript:"
  ];
  function hasInvalidProtocol(location) {
    try {
      return invalidProtocols.includes(new URL(location).protocol);
    } catch {
      return false;
    }
  }

  // src/client/node_modules/react-router/dist/production/lib/context.js
  init_define_import_meta_env();
  var React$12 = __toESM(require_react_shim(), 1);
  var DataRouterContext = React$12.createContext(null);
  DataRouterContext.displayName = "DataRouter";
  var DataRouterStateContext = React$12.createContext(null);
  DataRouterStateContext.displayName = "DataRouterState";
  var RSCRouterContext = React$12.createContext(false);
  function useIsRSCRouterContext() {
    return React$12.useContext(RSCRouterContext);
  }
  var ViewTransitionContext = React$12.createContext({ isTransitioning: false });
  ViewTransitionContext.displayName = "ViewTransition";
  var FetchersContext = React$12.createContext(/* @__PURE__ */ new Map());
  FetchersContext.displayName = "Fetchers";
  var AwaitContext = React$12.createContext(null);
  AwaitContext.displayName = "Await";
  var NavigationContext = React$12.createContext(null);
  NavigationContext.displayName = "Navigation";
  var LocationContext = React$12.createContext(null);
  LocationContext.displayName = "Location";
  var RouteContext = React$12.createContext({
    outlet: null,
    matches: [],
    isDataRoute: false
  });
  RouteContext.displayName = "Route";
  var RouteErrorContext = React$12.createContext(null);
  RouteErrorContext.displayName = "RouteError";

  // src/client/node_modules/react-router/dist/production/lib/hooks.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/errors.js
  init_define_import_meta_env();
  var ERROR_DIGEST_BASE = "REACT_ROUTER_ERROR";
  var ERROR_DIGEST_REDIRECT = "REDIRECT";
  var ERROR_DIGEST_ROUTE_ERROR_RESPONSE = "ROUTE_ERROR_RESPONSE";
  function decodeRedirectErrorDigest(digest) {
    if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_REDIRECT}:{`)) try {
      let parsed = JSON.parse(digest.slice(28));
      if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string" && typeof parsed.location === "string" && typeof parsed.reloadDocument === "boolean" && typeof parsed.replace === "boolean") return parsed;
    } catch {
    }
  }
  function decodeRouteErrorResponseDigest(digest) {
    if (digest.startsWith(`${ERROR_DIGEST_BASE}:${ERROR_DIGEST_ROUTE_ERROR_RESPONSE}:{`)) try {
      let parsed = JSON.parse(digest.slice(40));
      if (typeof parsed === "object" && parsed && typeof parsed.status === "number" && typeof parsed.statusText === "string") return new ErrorResponseImpl(parsed.status, parsed.statusText, parsed.data);
    } catch {
    }
  }

  // src/client/node_modules/react-router/dist/production/lib/hooks.js
  var React$13 = __toESM(require_react_shim(), 1);
  function useHref(to, { relative } = {}) {
    invariant(useInRouterContext(), `useHref() may be used only in the context of a <Router> component.`);
    let { basename, navigator: navigator2 } = React$13.useContext(NavigationContext);
    let { hash, pathname, search } = useResolvedPath(to, { relative });
    let joinedPathname = pathname;
    if (basename !== "/") joinedPathname = pathname === "/" ? basename : joinPaths([basename, pathname]);
    return navigator2.createHref({
      pathname: joinedPathname,
      search,
      hash
    });
  }
  function useInRouterContext() {
    return React$13.useContext(LocationContext) != null;
  }
  function useLocation() {
    invariant(useInRouterContext(), `useLocation() may be used only in the context of a <Router> component.`);
    return React$13.useContext(LocationContext).location;
  }
  var navigateEffectWarning = "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
  function useNavigate() {
    let { isDataRoute } = React$13.useContext(RouteContext);
    return isDataRoute ? useNavigateStable() : useNavigateUnstable();
  }
  function useNavigateUnstable() {
    invariant(useInRouterContext(), `useNavigate() may be used only in the context of a <Router> component.`);
    let dataRouterContext = React$13.useContext(DataRouterContext);
    let { basename, navigator: navigator2 } = React$13.useContext(NavigationContext);
    let { matches } = React$13.useContext(RouteContext);
    let { pathname: locationPathname } = useLocation();
    let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
    let activeRef = React$13.useRef(false);
    React$13.useLayoutEffect(() => {
      activeRef.current = true;
    });
    return React$13.useCallback((to, options2 = {}) => {
      warning(activeRef.current, navigateEffectWarning);
      if (!activeRef.current) return;
      if (typeof to === "number") {
        navigator2.go(to);
        return;
      }
      let path = resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, options2.relative === "path");
      if (dataRouterContext == null && basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
      (!!options2.replace ? navigator2.replace : navigator2.push)(path, options2.state, options2);
    }, [
      basename,
      navigator2,
      routePathnamesJson,
      locationPathname,
      dataRouterContext
    ]);
  }
  var OutletContext = React$13.createContext(null);
  function useResolvedPath(to, { relative } = {}) {
    let { matches } = React$13.useContext(RouteContext);
    let { pathname: locationPathname } = useLocation();
    let routePathnamesJson = JSON.stringify(getResolveToMatches(matches));
    return React$13.useMemo(() => resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, relative === "path"), [
      to,
      routePathnamesJson,
      locationPathname,
      relative
    ]);
  }
  function useRoutesImpl(routes, locationArg, dataRouterOpts) {
    invariant(useInRouterContext(), `useRoutes() may be used only in the context of a <Router> component.`);
    let { navigator: navigator2 } = React$13.useContext(NavigationContext);
    let { matches: parentMatches } = React$13.useContext(RouteContext);
    let routeMatch = parentMatches[parentMatches.length - 1];
    let parentParams = routeMatch ? routeMatch.params : {};
    routeMatch && routeMatch.pathname;
    let parentPathnameBase = routeMatch ? routeMatch.pathnameBase : "/";
    routeMatch && routeMatch.route;
    let locationFromContext = useLocation();
    let location;
    if (locationArg) {
      let parsedLocationArg = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
      invariant(parentPathnameBase === "/" || parsedLocationArg.pathname?.startsWith(parentPathnameBase), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${parentPathnameBase}" but pathname "${parsedLocationArg.pathname}" was given in the \`location\` prop.`);
      location = parsedLocationArg;
    } else location = locationFromContext;
    let pathname = location.pathname || "/";
    let remainingPathname = pathname;
    if (parentPathnameBase !== "/") {
      let parentSegments = parentPathnameBase.replace(/^\//, "").split("/");
      remainingPathname = "/" + pathname.replace(/^\//, "").split("/").slice(parentSegments.length).join("/");
    }
    let matches = dataRouterOpts && dataRouterOpts.state.matches.length ? dataRouterOpts.state.matches.map((m) => Object.assign(m, { route: dataRouterOpts.manifest[m.route.id] || m.route })) : matchRoutes(routes, { pathname: remainingPathname });
    let renderedMatches = _renderMatches(matches && matches.map((match) => Object.assign({}, match, {
      params: Object.assign({}, parentParams, match.params),
      pathname: joinPaths([parentPathnameBase, navigator2.encodeLocation ? navigator2.encodeLocation(match.pathname.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathname]),
      pathnameBase: match.pathnameBase === "/" ? parentPathnameBase : joinPaths([parentPathnameBase, navigator2.encodeLocation ? navigator2.encodeLocation(match.pathnameBase.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : match.pathnameBase])
    })), parentMatches, dataRouterOpts);
    if (locationArg && renderedMatches) return /* @__PURE__ */ React$13.createElement(LocationContext.Provider, { value: {
      location: {
        pathname: "/",
        search: "",
        hash: "",
        state: null,
        key: "default",
        mask: void 0,
        ...location
      },
      navigationType: "POP"
    } }, renderedMatches);
    return renderedMatches;
  }
  function DefaultErrorComponent() {
    let error = useRouteError();
    let message = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` : error instanceof Error ? error.message : JSON.stringify(error);
    let stack = error instanceof Error ? error.stack : null;
    return /* @__PURE__ */ React$13.createElement(React$13.Fragment, null, /* @__PURE__ */ React$13.createElement("h2", null, "Unexpected Application Error!"), /* @__PURE__ */ React$13.createElement("h3", { style: { fontStyle: "italic" } }, message), stack ? /* @__PURE__ */ React$13.createElement("pre", { style: {
      padding: "0.5rem",
      backgroundColor: "rgba(200,200,200, 0.5)"
    } }, stack) : null, null);
  }
  var defaultErrorElement = /* @__PURE__ */ React$13.createElement(DefaultErrorComponent, null);
  var _a5;
  var RenderErrorBoundary = (_a5 = class extends React$13.Component {
    constructor(props) {
      super(props);
      this.state = {
        location: props.location,
        revalidation: props.revalidation,
        error: props.error
      };
    }
    static getDerivedStateFromError(error) {
      return { error };
    }
    static getDerivedStateFromProps(props, state) {
      if (state.location !== props.location || state.revalidation !== "idle" && props.revalidation === "idle") return {
        error: props.error,
        location: props.location,
        revalidation: props.revalidation
      };
      return {
        error: props.error !== void 0 ? props.error : state.error,
        location: state.location,
        revalidation: props.revalidation || state.revalidation
      };
    }
    componentDidCatch(error, errorInfo) {
      if (this.props.onError) this.props.onError(error, errorInfo);
      else console.error("React Router caught the following error during render", error);
    }
    render() {
      let error = this.state.error;
      if (this.context && typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
        const decoded = decodeRouteErrorResponseDigest(error.digest);
        if (decoded) error = decoded;
      }
      let result = error !== void 0 ? /* @__PURE__ */ React$13.createElement(RouteContext.Provider, { value: this.props.routeContext }, /* @__PURE__ */ React$13.createElement(RouteErrorContext.Provider, {
        value: error,
        children: this.props.component
      })) : this.props.children;
      if (this.context) return /* @__PURE__ */ React$13.createElement(RSCErrorHandler, { error }, result);
      return result;
    }
  }, __publicField(_a5, "contextType", RSCRouterContext), _a5);
  var errorRedirectHandledMap = /* @__PURE__ */ new WeakMap();
  function RSCErrorHandler({ children, error }) {
    let { basename } = React$13.useContext(NavigationContext);
    if (typeof error === "object" && error && "digest" in error && typeof error.digest === "string") {
      let redirect = decodeRedirectErrorDigest(error.digest);
      if (redirect) {
        let existingRedirect = errorRedirectHandledMap.get(error);
        if (existingRedirect) throw existingRedirect;
        let parsed = parseToInfo(redirect.location, basename);
        let target = parsed.absoluteURL || parsed.to;
        if (hasInvalidProtocol(target)) throw new Error("Invalid redirect location");
        if (isBrowser && !errorRedirectHandledMap.get(error)) if (parsed.isExternal || redirect.reloadDocument) window.location.href = target;
        else {
          const redirectPromise = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(parsed.to, { replace: redirect.replace }));
          errorRedirectHandledMap.set(error, redirectPromise);
          throw redirectPromise;
        }
        return /* @__PURE__ */ React$13.createElement("meta", {
          httpEquiv: "refresh",
          content: `0;url=${target}`
        });
      }
    }
    return children;
  }
  function RenderedRoute({ routeContext, match, children }) {
    let dataRouterContext = React$13.useContext(DataRouterContext);
    if (dataRouterContext && dataRouterContext.static && dataRouterContext.staticContext && (match.route.errorElement || match.route.ErrorBoundary)) dataRouterContext.staticContext._deepestRenderedBoundaryId = match.route.id;
    return /* @__PURE__ */ React$13.createElement(RouteContext.Provider, { value: routeContext }, children);
  }
  function _renderMatches(matches, parentMatches = [], dataRouterOpts) {
    let dataRouterState = dataRouterOpts?.state;
    if (matches == null) {
      if (!dataRouterState) return null;
      if (dataRouterState.errors) matches = dataRouterState.matches;
      else if (parentMatches.length === 0 && !dataRouterState.initialized && dataRouterState.matches.length > 0) matches = dataRouterState.matches;
      else return null;
    }
    let renderedMatches = matches;
    let errors = dataRouterState?.errors;
    if (errors != null) {
      let errorIndex = renderedMatches.findIndex((m) => m.route.id && errors?.[m.route.id] !== void 0);
      invariant(errorIndex >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(errors).join(",")}`);
      renderedMatches = renderedMatches.slice(0, Math.min(renderedMatches.length, errorIndex + 1));
    }
    let renderFallback = false;
    let fallbackIndex = -1;
    if (dataRouterOpts && dataRouterState) {
      renderFallback = dataRouterState.renderFallback;
      for (let i = 0; i < renderedMatches.length; i++) {
        let match = renderedMatches[i];
        if (match.route.HydrateFallback || match.route.hydrateFallbackElement) fallbackIndex = i;
        if (match.route.id) {
          let { loaderData, errors: errors2 } = dataRouterState;
          let needsToRunLoader = match.route.loader && !loaderData.hasOwnProperty(match.route.id) && (!errors2 || errors2[match.route.id] === void 0);
          if (match.route.lazy || needsToRunLoader) {
            if (dataRouterOpts.isStatic) renderFallback = true;
            if (fallbackIndex >= 0) renderedMatches = renderedMatches.slice(0, fallbackIndex + 1);
            else renderedMatches = [renderedMatches[0]];
            break;
          }
        }
      }
    }
    let onErrorHandler = dataRouterOpts?.onError;
    let onError = dataRouterState && onErrorHandler ? (error, errorInfo) => {
      onErrorHandler(error, {
        location: dataRouterState.location,
        params: dataRouterState.matches?.[0]?.params ?? {},
        pattern: getRoutePattern(dataRouterState.matches),
        errorInfo
      });
    } : void 0;
    return renderedMatches.reduceRight((outlet, match, index2) => {
      let error;
      let shouldRenderHydrateFallback = false;
      let errorElement = null;
      let hydrateFallbackElement = null;
      if (dataRouterState) {
        error = errors && match.route.id ? errors[match.route.id] : void 0;
        errorElement = match.route.errorElement || defaultErrorElement;
        if (renderFallback) {
          if (fallbackIndex < 0 && index2 === 0) {
            warningOnce("route-fallback", false, "No `HydrateFallback` element provided to render during initial hydration");
            shouldRenderHydrateFallback = true;
            hydrateFallbackElement = null;
          } else if (fallbackIndex === index2) {
            shouldRenderHydrateFallback = true;
            hydrateFallbackElement = match.route.hydrateFallbackElement || null;
          }
        }
      }
      let matches2 = parentMatches.concat(renderedMatches.slice(0, index2 + 1));
      let getChildren = () => {
        let children;
        if (error) children = errorElement;
        else if (shouldRenderHydrateFallback) children = hydrateFallbackElement;
        else if (match.route.Component) children = /* @__PURE__ */ React$13.createElement(match.route.Component, null);
        else if (match.route.element) children = match.route.element;
        else children = outlet;
        return /* @__PURE__ */ React$13.createElement(RenderedRoute, {
          match,
          routeContext: {
            outlet,
            matches: matches2,
            isDataRoute: dataRouterState != null
          },
          children
        });
      };
      return dataRouterState && (match.route.ErrorBoundary || match.route.errorElement || index2 === 0) ? /* @__PURE__ */ React$13.createElement(RenderErrorBoundary, {
        location: dataRouterState.location,
        revalidation: dataRouterState.revalidation,
        component: errorElement,
        error,
        children: getChildren(),
        routeContext: {
          outlet: null,
          matches: matches2,
          isDataRoute: true
        },
        onError
      }) : getChildren();
    }, null);
  }
  function getDataRouterConsoleError(hookName) {
    return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function useDataRouterContext(hookName) {
    let ctx = React$13.useContext(DataRouterContext);
    invariant(ctx, getDataRouterConsoleError(hookName));
    return ctx;
  }
  function useDataRouterState(hookName) {
    let state = React$13.useContext(DataRouterStateContext);
    invariant(state, getDataRouterConsoleError(hookName));
    return state;
  }
  function useRouteContext(hookName) {
    let route = React$13.useContext(RouteContext);
    invariant(route, getDataRouterConsoleError(hookName));
    return route;
  }
  function useCurrentRouteId(hookName) {
    let route = useRouteContext(hookName);
    let thisRoute = route.matches[route.matches.length - 1];
    invariant(thisRoute.route.id, `${hookName} can only be used on routes that contain a unique "id"`);
    return thisRoute.route.id;
  }
  function useRouteId() {
    return useCurrentRouteId("useRouteId");
  }
  function useNavigation() {
    let state = useDataRouterState("useNavigation");
    return React$13.useMemo(() => {
      let { matches, historyAction, ...rest } = state.navigation;
      return rest;
    }, [state.navigation]);
  }
  function useMatches() {
    let { matches, loaderData } = useDataRouterState("useMatches");
    return React$13.useMemo(() => matches.map((m) => convertRouteMatchToUiMatch(m, loaderData)), [matches, loaderData]);
  }
  function useRouteError() {
    let error = React$13.useContext(RouteErrorContext);
    let state = useDataRouterState("useRouteError");
    let routeId = useCurrentRouteId("useRouteError");
    if (error !== void 0) return error;
    return state.errors?.[routeId];
  }
  function useNavigateStable() {
    let { router } = useDataRouterContext("useNavigate");
    let id = useCurrentRouteId("useNavigate");
    let activeRef = React$13.useRef(false);
    React$13.useLayoutEffect(() => {
      activeRef.current = true;
    });
    return React$13.useCallback(async (to, options2 = {}) => {
      warning(activeRef.current, navigateEffectWarning);
      if (!activeRef.current) return;
      if (typeof to === "number") await router.navigate(to);
      else await router.navigate(to, {
        fromRouteId: id,
        ...options2
      });
    }, [router, id]);
  }
  var alreadyWarned = {};
  function warningOnce(key, cond, message) {
    if (!cond && !alreadyWarned[key]) {
      alreadyWarned[key] = true;
      warning(false, message);
    }
  }

  // src/client/node_modules/react-router/dist/production/lib/components.js
  init_define_import_meta_env();
  var React$14 = __toESM(require_react_shim(), 1);
  var import_react29 = __toESM(require_react_shim(), 1);
  var MemoizedDataRoutes = React$14.memo(DataRoutes);
  function DataRoutes({ routes, manifest, future, state, isStatic, onError }) {
    return useRoutesImpl(routes, void 0, {
      manifest,
      state,
      isStatic,
      onError,
      future
    });
  }
  function Router({ basename: basenameProp = "/", children = null, location: locationProp, navigationType = "POP", navigator: navigator2, static: staticProp = false, useTransitions }) {
    invariant(!useInRouterContext(), "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");
    let basename = basenameProp.replace(/^\/*/, "/");
    let navigationContext = React$14.useMemo(() => ({
      basename,
      navigator: navigator2,
      static: staticProp,
      useTransitions,
      future: {}
    }), [
      basename,
      navigator2,
      staticProp,
      useTransitions
    ]);
    if (typeof locationProp === "string") locationProp = parsePath(locationProp);
    let { pathname = "/", search = "", hash = "", state = null, key = "default", mask } = locationProp;
    let locationContext = React$14.useMemo(() => {
      let trailingPathname = stripBasename(pathname, basename);
      if (trailingPathname == null) return null;
      return {
        location: {
          pathname: trailingPathname,
          search,
          hash,
          state,
          key,
          mask
        },
        navigationType
      };
    }, [
      basename,
      pathname,
      search,
      hash,
      state,
      key,
      navigationType,
      mask
    ]);
    warning(locationContext != null, `<Router basename="${basename}"> is not able to match the URL "${pathname}${search}${hash}" because it does not start with the basename, so the <Router> won't render anything.`);
    if (locationContext == null) return null;
    return /* @__PURE__ */ React$14.createElement(NavigationContext.Provider, { value: navigationContext }, /* @__PURE__ */ React$14.createElement(LocationContext.Provider, {
      children,
      value: locationContext
    }));
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/dom.js
  init_define_import_meta_env();
  var defaultEncType = "application/x-www-form-urlencoded";
  function isHtmlElement(object) {
    return typeof HTMLElement !== "undefined" && object instanceof HTMLElement;
  }
  function isButtonElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "button";
  }
  function isFormElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "form";
  }
  function isInputElement(object) {
    return isHtmlElement(object) && object.tagName.toLowerCase() === "input";
  }
  function isModifiedEvent(event) {
    return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
  }
  function shouldProcessLinkClick(event, target) {
    return event.button === 0 && (!target || target === "_self") && !isModifiedEvent(event);
  }
  var _formDataSupportsSubmitter = null;
  function isFormDataSubmitterSupported() {
    if (_formDataSupportsSubmitter === null) try {
      new FormData(document.createElement("form"), 0);
      _formDataSupportsSubmitter = false;
    } catch (e) {
      _formDataSupportsSubmitter = true;
    }
    return _formDataSupportsSubmitter;
  }
  var supportedFormEncTypes = /* @__PURE__ */ new Set([
    "application/x-www-form-urlencoded",
    "multipart/form-data",
    "text/plain"
  ]);
  function getFormEncType(encType) {
    if (encType != null && !supportedFormEncTypes.has(encType)) {
      warning(false, `"${encType}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${defaultEncType}"`);
      return null;
    }
    return encType;
  }
  function getFormSubmissionInfo(target, basename) {
    let method;
    let action;
    let encType;
    let formData;
    let body;
    if (isFormElement(target)) {
      let attr = target.getAttribute("action");
      action = attr ? stripBasename(attr, basename) : null;
      method = target.getAttribute("method") || "get";
      encType = getFormEncType(target.getAttribute("enctype")) || defaultEncType;
      formData = new FormData(target);
    } else if (isButtonElement(target) || isInputElement(target) && (target.type === "submit" || target.type === "image")) {
      let form = target.form;
      if (form == null) throw new Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);
      let attr = target.getAttribute("formaction") || form.getAttribute("action");
      action = attr ? stripBasename(attr, basename) : null;
      method = target.getAttribute("formmethod") || form.getAttribute("method") || "get";
      encType = getFormEncType(target.getAttribute("formenctype")) || getFormEncType(form.getAttribute("enctype")) || defaultEncType;
      formData = new FormData(form, target);
      if (!isFormDataSubmitterSupported()) {
        let { name, type, value } = target;
        if (type === "image") {
          let prefix = name ? `${name}.` : "";
          formData.append(`${prefix}x`, "0");
          formData.append(`${prefix}y`, "0");
        } else if (name) formData.append(name, value);
      }
    } else if (isHtmlElement(target)) throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');
    else {
      method = "get";
      action = null;
      encType = defaultEncType;
      body = target;
    }
    if (formData && encType === "text/plain") {
      body = formData;
      formData = void 0;
    }
    return {
      action,
      method: method.toLowerCase(),
      encType,
      formData,
      body
    };
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/single-fetch.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/invariant.js
  init_define_import_meta_env();
  function invariant2(value, message) {
    if (value === false || value === null || typeof value === "undefined") throw new Error(message);
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/markup.js
  init_define_import_meta_env();
  var ESCAPE_LOOKUP = {
    "&": "\\u0026",
    ">": "\\u003e",
    "<": "\\u003c",
    "\u2028": "\\u2028",
    "\u2029": "\\u2029"
  };
  var ESCAPE_REGEX = /[&><\u2028\u2029]/g;
  function escapeHtml(html) {
    return html.replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/single-fetch.js
  var React$15 = __toESM(require_react_shim(), 1);
  function singleFetchUrl(reqUrl, extension) {
    let url = typeof reqUrl === "string" ? new URL(reqUrl, typeof window === "undefined" ? "server://singlefetch/" : window.location.origin) : reqUrl;
    if (url.pathname.endsWith("/")) url.pathname = `${url.pathname}_.${extension}`;
    else url.pathname = `${url.pathname}.${extension}`;
    return url;
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/components.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/links.js
  init_define_import_meta_env();

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/routeModules.js
  init_define_import_meta_env();
  var import_meta = {};
  async function loadRouteModule(route, routeModulesCache) {
    if (route.id in routeModulesCache) return routeModulesCache[route.id];
    try {
      let routeModule = await import(
        /* @vite-ignore */
        /* webpackIgnore: true */
        route.module
      );
      routeModulesCache[route.id] = routeModule;
      return routeModule;
    } catch (error) {
      console.error(`Error loading route module \`${route.module}\`, reloading page...`);
      console.error(error);
      if (window.__reactRouterContext && window.__reactRouterContext.isSpaMode && import_meta.hot) throw error;
      window.location.reload();
      return new Promise(() => {
      });
    }
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/links.js
  function isPageLinkDescriptor(object) {
    return object != null && typeof object.page === "string";
  }
  function isHtmlLinkDescriptor(object) {
    if (object == null) return false;
    if (object.href == null) return object.rel === "preload" && typeof object.imageSrcSet === "string" && typeof object.imageSizes === "string";
    return typeof object.rel === "string" && typeof object.href === "string";
  }
  async function getKeyedPrefetchLinks(matches, manifest, routeModules) {
    return dedupeLinkDescriptors((await Promise.all(matches.map(async (match) => {
      let route = manifest.routes[match.route.id];
      if (route) {
        let mod = await loadRouteModule(route, routeModules);
        return mod.links ? mod.links() : [];
      }
      return [];
    }))).flat(1).filter(isHtmlLinkDescriptor).filter((link) => link.rel === "stylesheet" || link.rel === "preload").map((link) => link.rel === "stylesheet" ? {
      ...link,
      rel: "prefetch",
      as: "style"
    } : {
      ...link,
      rel: "prefetch"
    }));
  }
  function getNewMatchesForLinks(page, nextMatches, currentMatches, manifest, location, mode) {
    let isNew = (match, index2) => {
      if (!currentMatches[index2]) return true;
      return match.route.id !== currentMatches[index2].route.id;
    };
    let matchPathChanged = (match, index2) => {
      return currentMatches[index2].pathname !== match.pathname || currentMatches[index2].route.path?.endsWith("*") && currentMatches[index2].params["*"] !== match.params["*"];
    };
    if (mode === "assets") return nextMatches.filter((match, index2) => isNew(match, index2) || matchPathChanged(match, index2));
    if (mode === "data") return nextMatches.filter((match, index2) => {
      let manifestRoute = manifest.routes[match.route.id];
      if (!manifestRoute || !manifestRoute.hasLoader) return false;
      if (isNew(match, index2) || matchPathChanged(match, index2)) return true;
      if (match.route.shouldRevalidate) {
        let routeChoice = match.route.shouldRevalidate({
          currentUrl: new URL(location.pathname + location.search + location.hash, window.origin),
          currentParams: currentMatches[0]?.params || {},
          nextUrl: new URL(page, window.origin),
          nextParams: match.params,
          defaultShouldRevalidate: true
        });
        if (typeof routeChoice === "boolean") return routeChoice;
      }
      return true;
    });
    return [];
  }
  function getModuleLinkHrefs(matches, manifest, { includeHydrateFallback } = {}) {
    return dedupeHrefs(matches.map((match) => {
      let route = manifest.routes[match.route.id];
      if (!route) return [];
      let hrefs = [route.module];
      if (route.clientActionModule) hrefs = hrefs.concat(route.clientActionModule);
      if (route.clientLoaderModule) hrefs = hrefs.concat(route.clientLoaderModule);
      if (includeHydrateFallback && route.hydrateFallbackModule) hrefs = hrefs.concat(route.hydrateFallbackModule);
      if (route.imports) hrefs = hrefs.concat(route.imports);
      return hrefs;
    }).flat(1));
  }
  function dedupeHrefs(hrefs) {
    return [...new Set(hrefs)];
  }
  function sortKeys(obj) {
    let sorted = {};
    let keys = Object.keys(obj).sort();
    for (let key of keys) sorted[key] = obj[key];
    return sorted;
  }
  function dedupeLinkDescriptors(descriptors, preloads) {
    let set = /* @__PURE__ */ new Set();
    let preloadsSet = new Set(preloads);
    return descriptors.reduce((deduped, descriptor) => {
      if (preloads && !isPageLinkDescriptor(descriptor) && descriptor.as === "script" && descriptor.href && preloadsSet.has(descriptor.href)) return deduped;
      let key = JSON.stringify(sortKeys(descriptor));
      if (!set.has(key)) {
        set.add(key);
        deduped.push({
          key,
          link: descriptor
        });
      }
      return deduped;
    }, []);
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/ssr/components.js
  var React$16 = __toESM(require_react_shim(), 1);
  function useDataRouterContext2() {
    let context = React$16.useContext(DataRouterContext);
    invariant2(context, "You must render this element inside a <DataRouterContext.Provider> element");
    return context;
  }
  function useDataRouterStateContext() {
    let context = React$16.useContext(DataRouterStateContext);
    invariant2(context, "You must render this element inside a <DataRouterStateContext.Provider> element");
    return context;
  }
  var FrameworkContext = React$16.createContext(void 0);
  FrameworkContext.displayName = "FrameworkContext";
  function useFrameworkContext() {
    let context = React$16.useContext(FrameworkContext);
    invariant2(context, "You must render this element inside a <HydratedRouter> element");
    return context;
  }
  function usePrefetchBehavior(prefetch, theirElementProps) {
    let frameworkContext = React$16.useContext(FrameworkContext);
    let [maybePrefetch, setMaybePrefetch] = React$16.useState(false);
    let [shouldPrefetch, setShouldPrefetch] = React$16.useState(false);
    let { onFocus, onBlur, onMouseEnter, onMouseLeave, onTouchStart } = theirElementProps;
    let ref = React$16.useRef(null);
    React$16.useEffect(() => {
      if (prefetch === "render") setShouldPrefetch(true);
      if (prefetch === "viewport") {
        let callback = (entries) => {
          entries.forEach((entry) => {
            setShouldPrefetch(entry.isIntersecting);
          });
        };
        let observer = new IntersectionObserver(callback, { threshold: 0.5 });
        if (ref.current) observer.observe(ref.current);
        return () => {
          observer.disconnect();
        };
      }
    }, [prefetch]);
    React$16.useEffect(() => {
      if (maybePrefetch) {
        let id = setTimeout(() => {
          setShouldPrefetch(true);
        }, 100);
        return () => {
          clearTimeout(id);
        };
      }
    }, [maybePrefetch]);
    let setIntent = () => {
      setMaybePrefetch(true);
    };
    let cancelIntent = () => {
      setMaybePrefetch(false);
      setShouldPrefetch(false);
    };
    if (!frameworkContext) return [
      false,
      ref,
      {}
    ];
    if (prefetch !== "intent") return [
      shouldPrefetch,
      ref,
      {}
    ];
    return [
      shouldPrefetch,
      ref,
      {
        onFocus: composeEventHandlers2(onFocus, setIntent),
        onBlur: composeEventHandlers2(onBlur, cancelIntent),
        onMouseEnter: composeEventHandlers2(onMouseEnter, setIntent),
        onMouseLeave: composeEventHandlers2(onMouseLeave, cancelIntent),
        onTouchStart: composeEventHandlers2(onTouchStart, setIntent)
      }
    ];
  }
  function composeEventHandlers2(theirHandler, ourHandler) {
    return (event) => {
      theirHandler && theirHandler(event);
      if (!event.defaultPrevented) ourHandler(event);
    };
  }
  function PrefetchPageLinks({ page, ...linkProps }) {
    let rsc = useIsRSCRouterContext();
    let { nonce: contextNonce } = useFrameworkContext();
    let { router } = useDataRouterContext2();
    let matches = React$16.useMemo(() => matchRoutes(router.routes, page, router.basename), [
      router.routes,
      page,
      router.basename
    ]);
    if (!matches) return null;
    if (linkProps.nonce == null && contextNonce) linkProps = {
      ...linkProps,
      nonce: contextNonce
    };
    if (rsc) return /* @__PURE__ */ React$16.createElement(RSCPrefetchPageLinksImpl, {
      page,
      matches,
      ...linkProps
    });
    return /* @__PURE__ */ React$16.createElement(PrefetchPageLinksImpl, {
      page,
      matches,
      ...linkProps
    });
  }
  function useKeyedPrefetchLinks(matches) {
    let { manifest, routeModules } = useFrameworkContext();
    let [keyedPrefetchLinks, setKeyedPrefetchLinks] = React$16.useState([]);
    React$16.useEffect(() => {
      let interrupted = false;
      getKeyedPrefetchLinks(matches, manifest, routeModules).then((links) => {
        if (!interrupted) setKeyedPrefetchLinks(links);
      });
      return () => {
        interrupted = true;
      };
    }, [
      matches,
      manifest,
      routeModules
    ]);
    return keyedPrefetchLinks;
  }
  function RSCPrefetchPageLinksImpl({ page, matches: nextMatches, ...linkProps }) {
    let location = useLocation();
    let dataHrefs = React$16.useMemo(() => {
      if (page === location.pathname + location.search + location.hash) return [];
      let url = singleFetchUrl(page, "rsc");
      let hasSomeRoutesWithShouldRevalidate = false;
      let targetRoutes = [];
      for (let match of nextMatches) if (typeof match.route.shouldRevalidate === "function") hasSomeRoutesWithShouldRevalidate = true;
      else targetRoutes.push(match.route.id);
      if (hasSomeRoutesWithShouldRevalidate && targetRoutes.length > 0) url.searchParams.set("_routes", targetRoutes.join(","));
      return [url.pathname + url.search];
    }, [
      page,
      location,
      nextMatches
    ]);
    return /* @__PURE__ */ React$16.createElement(React$16.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ React$16.createElement("link", {
      key: href,
      rel: "prefetch",
      as: "fetch",
      href,
      ...linkProps
    })));
  }
  function PrefetchPageLinksImpl({ page, matches: nextMatches, ...linkProps }) {
    let location = useLocation();
    let { manifest, routeModules } = useFrameworkContext();
    let { loaderData, matches } = useDataRouterStateContext();
    let newMatchesForData = React$16.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "data"), [
      page,
      nextMatches,
      matches,
      manifest,
      location
    ]);
    let newMatchesForAssets = React$16.useMemo(() => getNewMatchesForLinks(page, nextMatches, matches, manifest, location, "assets"), [
      page,
      nextMatches,
      matches,
      manifest,
      location
    ]);
    let dataHrefs = React$16.useMemo(() => {
      if (page === location.pathname + location.search + location.hash) return [];
      let routesParams = /* @__PURE__ */ new Set();
      let foundOptOutRoute = false;
      nextMatches.forEach((m) => {
        let manifestRoute = manifest.routes[m.route.id];
        if (!manifestRoute || !manifestRoute.hasLoader) return;
        if (!newMatchesForData.some((m2) => m2.route.id === m.route.id) && m.route.id in loaderData && routeModules[m.route.id]?.shouldRevalidate) foundOptOutRoute = true;
        else if (manifestRoute.hasClientLoader) foundOptOutRoute = true;
        else routesParams.add(m.route.id);
      });
      if (routesParams.size === 0) return [];
      let url = singleFetchUrl(page, "data");
      if (foundOptOutRoute && routesParams.size > 0) url.searchParams.set("_routes", nextMatches.filter((m) => routesParams.has(m.route.id)).map((m) => m.route.id).join(","));
      return [url.pathname + url.search];
    }, [
      loaderData,
      location,
      manifest,
      newMatchesForData,
      nextMatches,
      page,
      routeModules
    ]);
    let moduleHrefs = React$16.useMemo(() => getModuleLinkHrefs(newMatchesForAssets, manifest), [newMatchesForAssets, manifest]);
    let keyedPrefetchLinks = useKeyedPrefetchLinks(newMatchesForAssets);
    return /* @__PURE__ */ React$16.createElement(React$16.Fragment, null, dataHrefs.map((href) => /* @__PURE__ */ React$16.createElement("link", {
      key: href,
      rel: "prefetch",
      as: "fetch",
      href,
      ...linkProps
    })), moduleHrefs.map((href) => /* @__PURE__ */ React$16.createElement("link", {
      key: href,
      rel: "modulepreload",
      href,
      ...linkProps
    })), keyedPrefetchLinks.map(({ key, link }) => /* @__PURE__ */ React$16.createElement("link", {
      key,
      nonce: linkProps.nonce,
      ...link,
      crossOrigin: link.crossOrigin ?? linkProps.crossOrigin
    })));
  }
  function mergeRefs(...refs) {
    return (value) => {
      refs.forEach((ref) => {
        if (typeof ref === "function") ref(value);
        else if (ref != null) ref.current = value;
      });
    };
  }

  // src/client/node_modules/react-router/dist/production/lib/dom/lib.js
  init_define_import_meta_env();
  var React$17 = __toESM(require_react_shim(), 1);
  var isBrowser2 = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
  try {
    if (isBrowser2) window.__reactRouterVersion = "8.3.0";
  } catch (e) {
  }
  function HistoryRouter({ basename, children, history, useTransitions }) {
    let [state, setStateImpl] = React$17.useState({
      action: history.action,
      location: history.location
    });
    let setState = React$17.useCallback((newState) => {
      if (useTransitions === false) setStateImpl(newState);
      else React$17.startTransition(() => setStateImpl(newState));
    }, [useTransitions]);
    React$17.useLayoutEffect(() => history.listen(setState), [history, setState]);
    return /* @__PURE__ */ React$17.createElement(Router, {
      basename,
      children,
      location: state.location,
      navigationType: state.action,
      navigator: history,
      useTransitions
    });
  }
  HistoryRouter.displayName = "unstable_HistoryRouter";
  var Link = React$17.forwardRef(function LinkWithRef({ onClick, discover = "render", prefetch = "none", relative, reloadDocument, replace, mask, state, target, to, preventScrollReset, viewTransition, defaultShouldRevalidate, ...rest }, forwardedRef) {
    let { basename, navigator: navigator2, useTransitions } = React$17.useContext(NavigationContext);
    let isAbsolute = typeof to === "string" && ABSOLUTE_URL_REGEX.test(to);
    let parsed = parseToInfo(to, basename);
    to = parsed.to;
    let href = useHref(to, { relative });
    let location = useLocation();
    let maskedHref = null;
    if (mask) {
      let resolved = resolveTo(mask, [], location.mask ? location.mask.pathname : "/", true);
      if (basename !== "/") resolved.pathname = resolved.pathname === "/" ? basename : joinPaths([basename, resolved.pathname]);
      maskedHref = navigator2.createHref(resolved);
    }
    let [shouldPrefetch, prefetchRef, prefetchHandlers] = usePrefetchBehavior(prefetch, rest);
    let internalOnClick = useLinkClickHandler(to, {
      replace,
      mask,
      state,
      target,
      preventScrollReset,
      relative,
      viewTransition,
      defaultShouldRevalidate,
      useTransitions
    });
    function handleClick(event) {
      if (onClick) onClick(event);
      if (!event.defaultPrevented) internalOnClick(event);
    }
    let isSpaLink = !(parsed.isExternal || reloadDocument);
    let link = /* @__PURE__ */ React$17.createElement("a", {
      ...rest,
      ...prefetchHandlers,
      href: (isSpaLink ? maskedHref : void 0) || parsed.absoluteURL || href,
      onClick: isSpaLink ? handleClick : onClick,
      ref: mergeRefs(forwardedRef, prefetchRef),
      target,
      "data-discover": !isAbsolute && discover === "render" ? "true" : void 0
    });
    return shouldPrefetch && !isAbsolute ? /* @__PURE__ */ React$17.createElement(React$17.Fragment, null, link, /* @__PURE__ */ React$17.createElement(PrefetchPageLinks, { page: href })) : link;
  });
  Link.displayName = "Link";
  var NavLink = React$17.forwardRef(function NavLinkWithRef({ "aria-current": ariaCurrentProp = "page", caseSensitive = false, className: classNameProp = "", end = false, style: styleProp, to, viewTransition, children, ...rest }, ref) {
    let path = useResolvedPath(to, { relative: rest.relative });
    let location = useLocation();
    let routerState = React$17.useContext(DataRouterStateContext);
    let { navigator: navigator2, basename } = React$17.useContext(NavigationContext);
    let isTransitioning = routerState != null && useViewTransitionState(path) && viewTransition === true;
    let toPathname = navigator2.encodeLocation ? navigator2.encodeLocation(path).pathname : path.pathname;
    let locationPathname = location.pathname;
    let nextLocationPathname = routerState && routerState.navigation && routerState.navigation.location ? routerState.navigation.location.pathname : null;
    if (!caseSensitive) {
      locationPathname = locationPathname.toLowerCase();
      nextLocationPathname = nextLocationPathname ? nextLocationPathname.toLowerCase() : null;
      toPathname = toPathname.toLowerCase();
    }
    if (nextLocationPathname && basename) nextLocationPathname = stripBasename(nextLocationPathname, basename) || nextLocationPathname;
    const endSlashPosition = toPathname !== "/" && toPathname.endsWith("/") ? toPathname.length - 1 : toPathname.length;
    let isActive = locationPathname === toPathname || !end && locationPathname.startsWith(toPathname) && locationPathname.charAt(endSlashPosition) === "/";
    let isPending = nextLocationPathname != null && (nextLocationPathname === toPathname || !end && nextLocationPathname.startsWith(toPathname) && nextLocationPathname.charAt(endSlashPosition) === "/");
    let renderProps = {
      isActive,
      isPending,
      isTransitioning
    };
    let ariaCurrent = isActive ? ariaCurrentProp : void 0;
    let className;
    if (typeof classNameProp === "function") className = classNameProp(renderProps);
    else className = [
      classNameProp,
      isActive ? "active" : null,
      isPending ? "pending" : null,
      isTransitioning ? "transitioning" : null
    ].filter(Boolean).join(" ");
    let style = typeof styleProp === "function" ? styleProp(renderProps) : styleProp;
    return /* @__PURE__ */ React$17.createElement(Link, {
      ...rest,
      "aria-current": ariaCurrent,
      className,
      ref,
      style,
      to,
      viewTransition
    }, typeof children === "function" ? children(renderProps) : children);
  });
  NavLink.displayName = "NavLink";
  var Form = React$17.forwardRef(({ discover = "render", fetcherKey, navigate, reloadDocument, replace, state, method = "get", action, onSubmit, relative, preventScrollReset, viewTransition, defaultShouldRevalidate, ...props }, forwardedRef) => {
    let { useTransitions } = React$17.useContext(NavigationContext);
    let submit = useSubmit();
    let formAction = useFormAction(action, { relative });
    let formMethod = method.toLowerCase() === "get" ? "get" : "post";
    let isAbsolute = typeof action === "string" && ABSOLUTE_URL_REGEX.test(action);
    let submitHandler = (event) => {
      onSubmit && onSubmit(event);
      if (event.defaultPrevented) return;
      event.preventDefault();
      let submitter = event.nativeEvent.submitter;
      let submitMethod = submitter?.getAttribute("formmethod") || method;
      let doSubmit = () => submit(submitter || event.currentTarget, {
        fetcherKey,
        method: submitMethod,
        navigate,
        replace,
        state,
        relative,
        preventScrollReset,
        viewTransition,
        defaultShouldRevalidate
      });
      if (useTransitions && navigate !== false) React$17.startTransition(() => doSubmit());
      else doSubmit();
    };
    return /* @__PURE__ */ React$17.createElement("form", {
      ref: forwardedRef,
      method: formMethod,
      action: formAction,
      onSubmit: reloadDocument ? onSubmit : submitHandler,
      ...props,
      "data-discover": !isAbsolute && discover === "render" ? "true" : void 0
    });
  });
  Form.displayName = "Form";
  function ScrollRestoration({ getKey, storageKey, ...props }) {
    let remixContext = React$17.useContext(FrameworkContext);
    let { basename } = React$17.useContext(NavigationContext);
    let location = useLocation();
    let matches = useMatches();
    useScrollRestoration({
      getKey,
      storageKey
    });
    let ssrKey = React$17.useMemo(() => {
      if (!remixContext || !getKey) return null;
      let userKey = getScrollRestorationKey(location, matches, basename, getKey);
      return userKey !== location.key ? userKey : null;
    }, []);
    if (!remixContext || remixContext.isSpaMode) return null;
    let restoreScroll = ((storageKey2, restoreKey) => {
      if (!window.history.state || !window.history.state.key) {
        let key = Math.random().toString(32).slice(2);
        window.history.replaceState({ key }, "");
      }
      try {
        let storedY = JSON.parse(sessionStorage.getItem(storageKey2) || "{}")[restoreKey || window.history.state.key];
        if (typeof storedY === "number") window.scrollTo(0, storedY);
      } catch (error) {
        console.error(error);
        sessionStorage.removeItem(storageKey2);
      }
    }).toString();
    if (props.nonce == null && remixContext?.nonce) props.nonce = remixContext.nonce;
    return /* @__PURE__ */ React$17.createElement("script", {
      ...props,
      suppressHydrationWarning: true,
      dangerouslySetInnerHTML: { __html: `(${restoreScroll})(${escapeHtml(JSON.stringify(storageKey || SCROLL_RESTORATION_STORAGE_KEY))}, ${escapeHtml(JSON.stringify(ssrKey))})` }
    });
  }
  ScrollRestoration.displayName = "ScrollRestoration";
  function getDataRouterConsoleError2(hookName) {
    return `${hookName} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
  }
  function useDataRouterContext3(hookName) {
    let ctx = React$17.useContext(DataRouterContext);
    invariant(ctx, getDataRouterConsoleError2(hookName));
    return ctx;
  }
  function useDataRouterState2(hookName) {
    let state = React$17.useContext(DataRouterStateContext);
    invariant(state, getDataRouterConsoleError2(hookName));
    return state;
  }
  function useLinkClickHandler(to, { target, replace: replaceProp, mask, state, preventScrollReset, relative, viewTransition, defaultShouldRevalidate, useTransitions } = {}) {
    let navigate = useNavigate();
    let location = useLocation();
    let path = useResolvedPath(to, { relative });
    return React$17.useCallback((event) => {
      if (shouldProcessLinkClick(event, target)) {
        event.preventDefault();
        let replace = replaceProp !== void 0 ? replaceProp : createPath(location) === createPath(path);
        let doNavigate = () => navigate(to, {
          replace,
          mask,
          state,
          preventScrollReset,
          relative,
          viewTransition,
          defaultShouldRevalidate
        });
        if (useTransitions) React$17.startTransition(() => doNavigate());
        else doNavigate();
      }
    }, [
      location,
      navigate,
      path,
      replaceProp,
      mask,
      state,
      target,
      to,
      preventScrollReset,
      relative,
      viewTransition,
      defaultShouldRevalidate,
      useTransitions
    ]);
  }
  var fetcherId = 0;
  var getUniqueFetcherId = () => `__${String(++fetcherId)}__`;
  function useSubmit() {
    let { router } = useDataRouterContext3("useSubmit");
    let { basename } = React$17.useContext(NavigationContext);
    let currentRouteId = useRouteId();
    let routerFetch = router.fetch;
    let routerNavigate = router.navigate;
    return React$17.useCallback(async (target, options2 = {}) => {
      let { action, method, encType, formData, body } = getFormSubmissionInfo(target, basename);
      if (options2.navigate === false) await routerFetch(options2.fetcherKey || getUniqueFetcherId(), currentRouteId, options2.action || action, {
        defaultShouldRevalidate: options2.defaultShouldRevalidate,
        preventScrollReset: options2.preventScrollReset,
        formData,
        body,
        formMethod: options2.method || method,
        formEncType: options2.encType || encType,
        flushSync: options2.flushSync
      });
      else await routerNavigate(options2.action || action, {
        defaultShouldRevalidate: options2.defaultShouldRevalidate,
        preventScrollReset: options2.preventScrollReset,
        formData,
        body,
        formMethod: options2.method || method,
        formEncType: options2.encType || encType,
        replace: options2.replace,
        state: options2.state,
        fromRouteId: currentRouteId,
        flushSync: options2.flushSync,
        viewTransition: options2.viewTransition
      });
    }, [
      routerFetch,
      routerNavigate,
      basename,
      currentRouteId
    ]);
  }
  function useFormAction(action, { relative } = {}) {
    let { basename } = React$17.useContext(NavigationContext);
    let routeContext = React$17.useContext(RouteContext);
    invariant(routeContext, "useFormAction must be used inside a RouteContext");
    let [match] = routeContext.matches.slice(-1);
    let path = { ...useResolvedPath(action ? action : ".", { relative }) };
    let location = useLocation();
    if (action == null) {
      path.search = location.search;
      let params = new URLSearchParams(path.search);
      let indexValues = params.getAll("index");
      if (indexValues.some((v) => v === "")) {
        params.delete("index");
        indexValues.filter((v) => v).forEach((v) => params.append("index", v));
        let qs = params.toString();
        path.search = qs ? `?${qs}` : "";
      }
    }
    if ((!action || action === ".") && match.route.index) path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
    if (basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
    return createPath(path);
  }
  var SCROLL_RESTORATION_STORAGE_KEY = "react-router-scroll-positions";
  var savedScrollPositions = {};
  function getScrollRestorationKey(location, matches, basename, getKey) {
    let key = null;
    if (getKey) if (basename !== "/") key = getKey({
      ...location,
      pathname: stripBasename(location.pathname, basename) || location.pathname
    }, matches);
    else key = getKey(location, matches);
    if (key == null) key = location.key;
    return key;
  }
  function useScrollRestoration({ getKey, storageKey } = {}) {
    let { router } = useDataRouterContext3("useScrollRestoration");
    let { restoreScrollPosition, preventScrollReset } = useDataRouterState2("useScrollRestoration");
    let { basename } = React$17.useContext(NavigationContext);
    let location = useLocation();
    let matches = useMatches();
    let navigation = useNavigation();
    React$17.useEffect(() => {
      window.history.scrollRestoration = "manual";
      return () => {
        window.history.scrollRestoration = "auto";
      };
    }, []);
    usePageHide(React$17.useCallback(() => {
      if (navigation.state === "idle") {
        let key = getScrollRestorationKey(location, matches, basename, getKey);
        savedScrollPositions[key] = window.scrollY;
      }
      try {
        sessionStorage.setItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY, JSON.stringify(savedScrollPositions));
      } catch (error) {
        warning(false, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${error}).`);
      }
      window.history.scrollRestoration = "auto";
    }, [
      navigation.state,
      getKey,
      basename,
      location,
      matches,
      storageKey
    ]));
    if (typeof document !== "undefined") {
      React$17.useLayoutEffect(() => {
        try {
          let sessionPositions = sessionStorage.getItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY);
          if (sessionPositions) savedScrollPositions = JSON.parse(sessionPositions);
        } catch (e) {
        }
      }, [storageKey]);
      React$17.useLayoutEffect(() => {
        let disableScrollRestoration = router?.enableScrollRestoration(savedScrollPositions, () => window.scrollY, getKey ? (location2, matches2) => getScrollRestorationKey(location2, matches2, basename, getKey) : void 0);
        return () => disableScrollRestoration && disableScrollRestoration();
      }, [
        router,
        basename,
        getKey
      ]);
      React$17.useLayoutEffect(() => {
        if (restoreScrollPosition === false) return;
        if (typeof restoreScrollPosition === "number") {
          window.scrollTo(0, restoreScrollPosition);
          return;
        }
        try {
          if (location.hash) {
            let el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
            if (el) {
              el.scrollIntoView();
              return;
            }
          }
        } catch {
          warning(false, `"${location.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`);
        }
        if (preventScrollReset === true) return;
        window.scrollTo(0, 0);
      }, [
        location,
        restoreScrollPosition,
        preventScrollReset
      ]);
    }
  }
  function usePageHide(callback, options2) {
    let { capture } = options2 || {};
    React$17.useEffect(() => {
      let opts = capture != null ? { capture } : void 0;
      window.addEventListener("pagehide", callback, opts);
      return () => {
        window.removeEventListener("pagehide", callback, opts);
      };
    }, [callback, capture]);
  }
  function useViewTransitionState(to, { relative } = {}) {
    let vtContext = React$17.useContext(ViewTransitionContext);
    invariant(vtContext != null, "`useViewTransitionState` must be used within `react-router/dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
    let { basename } = useDataRouterContext3("useViewTransitionState");
    let path = useResolvedPath(to, { relative });
    if (!vtContext.isTransitioning) return false;
    let currentPath = stripBasename(vtContext.currentLocation.pathname, basename) || vtContext.currentLocation.pathname;
    let nextPath = stripBasename(vtContext.nextLocation.pathname, basename) || vtContext.nextLocation.pathname;
    return matchPath(path.pathname, nextPath) != null || matchPath(path.pathname, currentPath) != null;
  }

  // src/client/src/shared/ui/dataTable.ts
  init_define_import_meta_env();
  var dtCard = "overflow-auto rounded-xl border border-stroke bg-surface";
  var dtTable = "w-full border-separate border-spacing-0 text-sm [--dt-head:42px]";
  var dtThBase = "sticky top-0 z-10 bg-muted text-left text-xs font-medium text-fg3 align-middle border-b border-stroke whitespace-nowrap";
  var dtTh = `${dtThBase} px-3 h-(--dt-head)`;
  var dtTd = "px-3 py-2 border-b border-stroke align-middle";
  var dtTableCompact = "w-full border-separate border-spacing-0 text-xs [--dt-head:2rem]";
  var dtThCompact = `${dtThBase} px-2 h-(--dt-head)`;
  var dtTdCompact = "px-2 py-1 border-b border-stroke align-middle";
  var dtTdEdit = "px-2 py-1 border-b border-stroke align-top";
  var dtTdSheet = "p-0 h-7 border-b border-r border-stroke align-middle focus-within:bg-brand-subtle";
  var dtTableSized = "table-fixed w-max! min-w-full";
  var dtRow = "transition-colors hover:bg-black/[.03] dark:hover:bg-white/[.05]";
  var dtNum = "text-right tabular-nums";

  // src/client/src/shared/ui/dataGridStates.ts
  init_define_import_meta_env();
  var DATA_GRID_STATES = {
    "no-data": {
      title: "\u0421\u0442\u0440\u043E\u043A \u043D\u0435\u0442",
      // Не «источник пуст»: строки могли и прийти, а отсеяться раньше сетки (у union — выбором
      // варианта), и тогда такая подсказка спорила бы с предупреждением над ней.
      hint: "\u0421\u044E\u0434\u0430 \u043D\u0435 \u043F\u043E\u043F\u0430\u043B\u043E \u043D\u0438 \u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438."
    },
    "filtered-out": {
      title: "\u041E\u0442\u0431\u043E\u0440 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043D\u0430\u0448\u0451\u043B",
      hint: "\u0421\u0442\u0440\u043E\u043A\u0438 \u0435\u0441\u0442\u044C, \u043D\u043E \u043D\u0438 \u043E\u0434\u043D\u0430 \u043D\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442 \u043F\u043E\u0434 \u0443\u0441\u043B\u043E\u0432\u0438\u044F \u043E\u0442\u0431\u043E\u0440\u0430."
    },
    "module-off": {
      title: "\u041C\u043E\u0434\u0443\u043B\u044C \u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D",
      hint: "\u042D\u0442\u0438 \u0434\u0430\u043D\u043D\u044B\u0435 \u0432\u0435\u0434\u0451\u0442 \u043C\u043E\u0434\u0443\u043B\u044C, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0441\u0435\u0439\u0447\u0430\u0441 \u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D."
    },
    "no-right": {
      title: "\u0441\u043A\u0440\u044B\u0442\u043E \u043F\u0440\u0430\u0432\u0430\u043C\u0438",
      hint: "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u044D\u0442\u043E\u0439 \u043A\u043E\u043B\u043E\u043D\u043A\u0438 \u0432\u0430\u043C \u043D\u0435 \u0432\u0438\u0434\u043D\u044B: \u043D\u0430 \u043D\u0438\u0445 \u043D\u0443\u0436\u043D\u043E \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0440\u0430\u0432\u043E."
    },
    removed: {
      title: "\u043F\u043E\u043B\u044F \u043D\u0435\u0442 \u0432 \u0442\u0438\u043F\u0435",
      // Без версии о том, КАК поля не стало (удалили, переименовали, не было вовсе), и без обещания о
      // документе: что будет со значением, решает генерация, а сетка показывает то, что ей дали.
      hint: "\u0422\u0430\u043A\u043E\u0433\u043E \u043F\u043E\u043B\u044F \u0432 \u0442\u0438\u043F\u0435 \u043D\u0435\u0442, \u0430 \u0440\u0430\u0437\u043C\u0435\u0442\u043A\u0430 \u043D\u0430 \u043D\u0435\u0433\u043E \u043E\u0441\u0442\u0430\u043B\u0430\u0441\u044C."
    }
  };
  function cellKind(row, key) {
    if (!Object.prototype.hasOwnProperty.call(row, key)) return "absent";
    const v = row[key];
    if (v == null || typeof v === "string" && v.trim() === "") return "empty";
    return "value";
  }
  var ABSENT_CELL_HINT = "\u0412 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0435 \u0442\u0430\u043A\u043E\u0433\u043E \u043F\u043E\u043B\u044F \u043D\u0435\u0442";

  // src/client/src/shared/ui/DataGrid.tsx
  var COLUMN_ICON = {
    "no-right": /* @__PURE__ */ React.createElement(EyeOff, { size: 12, "aria-hidden": true }),
    removed: /* @__PURE__ */ React.createElement(Unlink, { size: 12, "aria-hidden": true })
  };
  function DataGridValue({ row, column, renderValue }) {
    const kind = cellKind(row, column.key);
    if (column.unavailable) {
      const state = DATA_GRID_STATES[column.unavailable];
      if (kind === "value")
        return /* @__PURE__ */ React.createElement(Tooltip, { content: state.hint }, /* @__PURE__ */ React.createElement("span", { className: "text-fg4" }, renderValue ? renderValue(row[column.key]) : String(row[column.key])));
      return /* @__PURE__ */ React.createElement(Tooltip, { content: state.hint }, /* @__PURE__ */ React.createElement("span", { className: "text-fg4 italic" }, state.title));
    }
    switch (kind) {
      case "absent":
        return /* @__PURE__ */ React.createElement(Tooltip, { content: ABSENT_CELL_HINT }, /* @__PURE__ */ React.createElement("span", { className: "text-fg4", "aria-label": ABSENT_CELL_HINT }, "\u2014"));
      // Пустое значение — пустая клетка: так его читает любой, кто видел таблицу. Слово «null» на
      // экране было отладочным выводом, а не ответом.
      case "empty":
        return null;
      default:
        return /* @__PURE__ */ React.createElement(React.Fragment, null, renderValue ? renderValue(row[column.key]) : String(row[column.key]));
    }
  }
  function DataGrid({
    columns,
    rows,
    state,
    renderValue,
    rowKey,
    framed = true,
    className = "",
    density = "regular",
    sort,
    onSort,
    sortable,
    footer,
    pinned = 0,
    onRowOpen,
    rowOpen,
    rowLink,
    onRemoveColumn,
    emphasized,
    tone,
    fixed = false,
    section,
    drag
  }) {
    const shown = state === "module-off" ? [] : rows;
    const empty = shown.length === 0 ? DATA_GRID_STATES[state ?? "no-data"] : null;
    const pinCount = Math.min(Math.max(pinned, 0), columns.length);
    const table = usePinOffsets(pinCount, columns.map((c) => c.key).join("|"));
    const compact = density === "compact";
    const th = compact ? dtThCompact : dtTh;
    const td = compact ? dtTdCompact : dtTd;
    const top = columns.some((c) => c.wrap) ? "align-top" : "";
    const pin = (index2) => index2 < pinCount ? `sticky ${index2 === pinCount - 1 ? "border-r" : ""}` : "";
    const pinStyle = (index2, layer) => index2 < pinCount ? { left: `var(--pin-${index2}, 0px)`, zIndex: layer } : void 0;
    const grouped = columns.some((c) => c.group);
    const lower = { top: "var(--dt-head)" };
    const head = (c, i, extra) => {
      const reason = c.unavailable ? DATA_GRID_STATES[c.unavailable] : null;
      const order = sort?.findIndex((s) => s.column === c.key) ?? -1;
      const sorted = order >= 0 ? sort[order] : null;
      const canSort = onSort && (sortable ? sortable(c) : !c.unavailable);
      const label = /* @__PURE__ */ React.createElement("span", { className: `inline-flex items-center gap-1 ${reason ? "text-fg4" : ""}` }, c.unavailable && COLUMN_ICON[c.unavailable], /* @__PURE__ */ React.createElement("span", { className: c.unavailable === "removed" ? "line-through" : "" }, c.header ?? c.label), sorted && (sorted.descending ? /* @__PURE__ */ React.createElement(ArrowDown, { size: 12, "aria-hidden": true }) : /* @__PURE__ */ React.createElement(ArrowUp, { size: 12, "aria-hidden": true })), sorted && sort.length > 1 && /* @__PURE__ */ React.createElement("span", { className: "text-caption text-fg4" }, order + 1));
      return /* @__PURE__ */ React.createElement(Tooltip, { key: c.key, content: reason?.hint ?? c.hint }, /* @__PURE__ */ React.createElement(
        "th",
        {
          "data-pin": i < pinCount ? i : void 0,
          rowSpan: extra?.rowSpan,
          className: `${th} ${c.align === "right" ? "text-right" : ""} ${c.width ?? ""} ${pin(i)}`,
          style: { ...extra?.style, ...pinStyle(i, 30) },
          "aria-sort": !canSort ? void 0 : !sorted ? "none" : sorted.descending ? "descending" : "ascending"
        },
        canSort ? /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C. \u0421 Shift \u2014 \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043A\u043E\u043B\u043E\u043D\u043A\u0443 \u043A \u0441\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0435" }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            onClick: (e) => onSort(c, e.shiftKey),
            className: "hover:text-fg1 focus-visible:outline-2 rounded-sm"
          },
          label
        )) : label,
        c.unavailable === "removed" && onRemoveColumn && /* @__PURE__ */ React.createElement(Tooltip, { content: "\u0423\u0431\u0440\u0430\u0442\u044C \u043A\u043E\u043B\u043E\u043D\u043A\u0443" }, /* @__PURE__ */ React.createElement(
          "button",
          {
            type: "button",
            onClick: () => onRemoveColumn(c),
            "aria-label": `\u0423\u0431\u0440\u0430\u0442\u044C \u043A\u043E\u043B\u043E\u043D\u043A\u0443 \xAB${c.label}\xBB`,
            className: "ml-1 align-middle text-fg4 hover:text-danger"
          },
          /* @__PURE__ */ React.createElement(X, { size: 12, "aria-hidden": true })
        ))
      ));
    };
    return /* @__PURE__ */ React.createElement("div", { className: `${framed ? dtCard : "overflow-auto"} ${className}` }, /* @__PURE__ */ React.createElement("table", { ref: table, className: `${compact ? dtTableCompact : dtTable} ${fixed ? "table-fixed" : ""}` }, /* @__PURE__ */ React.createElement("thead", null, /* @__PURE__ */ React.createElement("tr", null, columns.map((c, i) => {
      if (!c.group) return head(c, i, grouped ? { rowSpan: 2 } : void 0);
      if (columns[i - 1]?.group?.key === c.group.key) return null;
      let span = 1;
      while (columns[i + span]?.group?.key === c.group.key) span++;
      return (
        // Закреплена первая колонка группы — закреплена и её шапка: иначе имя группы уезжало бы
        // вбок, а подписи полей под ним стояли на месте.
        /* @__PURE__ */ React.createElement(Tooltip, { key: `group:${c.group.key}:${i}`, content: c.group.hint }, /* @__PURE__ */ React.createElement(
          "th",
          {
            colSpan: span,
            scope: "colgroup",
            className: `${th} text-center ${pin(i)}`,
            style: pinStyle(i, 30)
          },
          c.group.label
        ))
      );
    })), grouped && /* @__PURE__ */ React.createElement("tr", null, columns.map((c, i) => c.group ? head(c, i, { style: lower }) : null))), /* @__PURE__ */ React.createElement("tbody", null, empty ? /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("td", { colSpan: Math.max(columns.length, 1), className: `${td} text-center py-4` }, /* @__PURE__ */ React.createElement("div", { className: "text-sm text-fg2" }, empty.title), /* @__PURE__ */ React.createElement("div", { className: "text-xs text-fg4" }, empty.hint))) : shown.map((row, i) => {
      const key = rowKey ? rowKey(row, i) : i;
      const heading = section?.(row, i) ?? null;
      if (heading !== null) {
        return /* @__PURE__ */ React.createElement("tr", { key }, /* @__PURE__ */ React.createElement(
          "th",
          {
            scope: "rowgroup",
            colSpan: Math.max(columns.length, 1),
            className: `${td} pt-3 text-left text-xs font-medium text-fg3`
          },
          heading
        ));
      }
      const open = rowOpen?.(row, i) ?? false;
      const link = rowLink?.(row, i) ?? null;
      const strong = emphasized?.(row, i) ?? false;
      const marked = !open && tone?.(row, i) === "warning";
      const dropMark = !drag || drag.dragging === null ? null : drag.target === i ? "inset 0 2px 0 0 var(--color-brand)" : drag.target === shown.length && i === shown.length - 1 ? "inset 0 -2px 0 0 var(--color-brand)" : null;
      return /* @__PURE__ */ React.createElement(
        "tr",
        {
          key,
          className: `group/row ${dtRow} ${onRowOpen ? "cursor-pointer" : ""} ${open ? "bg-brand-subtle" : marked ? "bg-warning-subtle" : ""} ${strong ? "font-medium" : ""} ${drag?.dragging === i ? "opacity-40" : ""}`,
          style: dropMark ? { boxShadow: dropMark } : void 0,
          ...drag ? {
            onDragOver: (e) => drag.onOver(e, i),
            onDrop: drag.onDrop
          } : {},
          ...onRowOpen ? {
            tabIndex: 0,
            // aria-current, а не aria-selected: у строки таблицы выбора нет, а «открыта сейчас» — есть.
            "aria-current": open || void 0,
            onClick: () => {
              if (!selectingText()) onRowOpen(row, i);
            },
            onKeyDown: (e) => {
              if (e.target !== e.currentTarget || e.key !== "Enter" && e.key !== " ") return;
              e.preventDefault();
              onRowOpen(row, i);
            }
          } : {}
        },
        columns.map((c, ci) => {
          const Cell = c.rowHeader ? "th" : "td";
          return /* @__PURE__ */ React.createElement(
            Cell,
            {
              key: c.key,
              style: pinStyle(ci, 5),
              scope: c.rowHeader ? "row" : void 0,
              onClick: c.interactive ? (e) => e.stopPropagation() : void 0,
              className: `${td} ${top} ${c.wrap ? "break-words" : "whitespace-nowrap"} text-fg1 ${c.rowHeader ? "text-left [font-weight:inherit]" : ""} ${c.align === "right" ? dtNum : ""} ${pin(ci)} ${ci < pinCount ? open ? "bg-brand-subtle" : marked ? "bg-warning-subtle" : "bg-surface" : ""}`
            },
            ci === 0 && link && /* @__PURE__ */ React.createElement(Tooltip, { content: link.label }, /* @__PURE__ */ React.createElement(
              Link,
              {
                to: link.to,
                "aria-label": link.label,
                onClick: (e) => e.stopPropagation(),
                className: "mr-1.5 inline-flex align-middle rounded-sm text-fg3 hover:text-brand focus-visible:outline-2"
              },
              /* @__PURE__ */ React.createElement(ArrowUpRight, { size: 14, "aria-hidden": true })
            )),
            c.cell && !c.unavailable ? c.cell(row, i) : /* @__PURE__ */ React.createElement(
              DataGridValue,
              {
                row,
                column: c,
                renderValue: renderValue ? (v) => renderValue(v, c) : void 0
              }
            )
          );
        })
      );
    })), footer && /* @__PURE__ */ React.createElement("tfoot", null, /* @__PURE__ */ React.createElement("tr", null, columns.map((c, i) => {
      const Cell = c.rowHeader ? "th" : "td";
      return /* @__PURE__ */ React.createElement(
        Cell,
        {
          key: c.key,
          style: pinStyle(i, 30),
          scope: c.rowHeader ? "row" : void 0,
          className: `sticky bottom-0 z-10 bg-muted border-t border-stroke ${compact ? "px-2 py-1" : "px-3 py-1.5"} text-xs text-fg2 whitespace-nowrap align-top ${c.rowHeader ? "text-left font-medium" : ""} ${c.align === "right" ? dtNum : ""} ${pin(i)}`
        },
        footer(c)
      );
    })))));
  }
  function selectingText() {
    return (window.getSelection()?.toString() ?? "") !== "";
  }
  function usePinOffsets(pinned, columnKeys) {
    const table = (0, import_react30.useRef)(null);
    (0, import_react30.useLayoutEffect)(() => {
      const element = table.current;
      if (!element || pinned <= 0) return;
      const heads = [...element.querySelectorAll("th[data-pin]")].sort((a, b) => Number(a.dataset.pin) - Number(b.dataset.pin));
      const measure = () => {
        let left = 0;
        heads.forEach((th, i) => {
          element.style.setProperty(`--pin-${i}`, `${left}px`);
          left += th.offsetWidth;
        });
      };
      measure();
      const observer = new ResizeObserver(measure);
      heads.forEach((th) => observer.observe(th));
      return () => observer.disconnect();
    }, [pinned, columnKeys]);
    return table;
  }

  // src/client/src/shared/ui/NumberInput.tsx
  init_define_import_meta_env();
  function NumberInput({ value, onChange, label, unit, placeholder, disabled, className = "w-full" }) {
    const field = /* @__PURE__ */ React.createElement(
      "input",
      {
        value,
        "aria-label": label,
        placeholder,
        disabled,
        inputMode: "decimal",
        onChange: (e) => onChange(e.target.value),
        className: unit ? INNER : `${BARE} ${className}`
      }
    );
    if (!unit) return field;
    return /* @__PURE__ */ React.createElement("label", { className: `${WRAP} ${className}` }, field, /* @__PURE__ */ React.createElement("span", { className: "shrink-0 text-xs text-fg4", "aria-hidden": "true" }, unit));
  }
  var BOX2 = "rounded border border-stroke bg-surface px-1.5 py-1";
  var TEXT = "text-right text-xs tabular-nums text-fg1 outline-none placeholder:text-fg4 disabled:text-fg3";
  var BARE = `${BOX2} ${TEXT} focus:border-brand disabled:bg-muted`;
  var WRAP = `${BOX2} flex items-baseline gap-1 focus-within:border-brand has-[:disabled]:bg-muted`;
  var INNER = `min-w-0 flex-1 bg-transparent ${TEXT}`;

  // src/client/src/shared/ui/ArchivedMark.tsx
  init_define_import_meta_env();

  // src/client/src/shared/ui/archive.ts
  init_define_import_meta_env();
  var ARCHIVED_WORD = "\u0432 \u0430\u0440\u0445\u0438\u0432\u0435";
  var ARCHIVED_HINT = "\u0417\u0430\u043F\u0438\u0441\u044C \u0432 \u0430\u0440\u0445\u0438\u0432\u0435: \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u0435\u0451 \u0437\u0430\u043D\u043E\u0432\u043E \u043D\u0435\u043B\u044C\u0437\u044F, \u0437\u0434\u0435\u0441\u044C \u043E\u043D\u0430 \u043E\u0441\u0442\u0430\u0451\u0442\u0441\u044F";

  // src/client/src/shared/ui/ArchivedMark.tsx
  function ArchivedMark({ words = true, className = "" }) {
    return /* @__PURE__ */ React.createElement(Tooltip, { content: ARCHIVED_HINT }, /* @__PURE__ */ React.createElement(
      "span",
      {
        "aria-label": words ? void 0 : ARCHIVED_WORD,
        className: `inline-flex items-center gap-1 text-caption text-fg3 shrink-0 ${className}`
      },
      /* @__PURE__ */ React.createElement(Archive, { size: 11, className: "shrink-0" }),
      words && ARCHIVED_WORD
    ));
  }

  // src/client/src/shared/ui/ArchivedRows.tsx
  init_define_import_meta_env();
  var import_react31 = __toESM(require_react_shim(), 1);
  function ArchivedRows({ count: count3, forceOpen = false, children }) {
    const [open, setOpen] = (0, import_react31.useState)(false);
    if (count3 === 0) return null;
    const shown = open || forceOpen;
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: () => setOpen((o) => !o),
        "aria-expanded": shown,
        disabled: forceOpen,
        className: "w-full flex items-center gap-2 px-4 py-2 border-t border-muted text-left text-xs text-fg3 enabled:hover:bg-base transition-colors"
      },
      /* @__PURE__ */ React.createElement(Archive, { size: 13, className: "shrink-0" }),
      /* @__PURE__ */ React.createElement("span", { className: "flex-1" }, "\u0412 \u0430\u0440\u0445\u0438\u0432\u0435: ", count3),
      !forceOpen && (shown ? /* @__PURE__ */ React.createElement(ChevronUp, { size: 13, className: "shrink-0" }) : /* @__PURE__ */ React.createElement(ChevronDown, { size: 13, className: "shrink-0" }))
    ), shown && children);
  }

  // src/client/src/shared/ui/LeaveGuardDialog.tsx
  init_define_import_meta_env();
  function LeaveGuardDialog({ open, saving, saveBlocked, onSave, onDiscard, onCancel }) {
    return (
      // Вопрос ведёт себя как `ConfirmDialog`: промах и Esc равны «Отмене» — безопасному ответу.
      // Идущее сохранение сильнее: `busy` гасит и их, и кнопку (issue #1236).
      /* @__PURE__ */ React.createElement(
        Modal,
        {
          open,
          onOpenChange: (o) => {
            if (!o) onCancel();
          },
          title: "\u041D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F",
          nothingToLose: true,
          busy: saving,
          footer: /* @__PURE__ */ React.createElement("div", { className: "flex items-center justify-end gap-2" }, /* @__PURE__ */ React.createElement(ModalExit, null), /* @__PURE__ */ React.createElement(Button, { variant: "tonal", onClick: onDiscard, disabled: saving }, "\u041D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u044C"), /* @__PURE__ */ React.createElement(Button, { variant: "filled", onClick: onSave, loading: saving, disabled: !!saveBlocked, title: saveBlocked }, "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438 \u043F\u0435\u0440\u0435\u0439\u0442\u0438"))
        },
        /* @__PURE__ */ React.createElement("p", { className: "text-sm text-fg2" }, "\u0415\u0441\u0442\u044C \u043D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F. \u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0438\u0445 \u043F\u0435\u0440\u0435\u0434 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u043C \u043A \u0434\u0440\u0443\u0433\u043E\u043C\u0443 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0443?")
      )
    );
  }

  // src/client/src/shared/ui/NoAccessPage.tsx
  init_define_import_meta_env();
  function NoAccessPage({ what, missing }) {
    return /* @__PURE__ */ React.createElement("div", { className: "flex h-full items-center justify-center p-8" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-md space-y-4 text-center" }, /* @__PURE__ */ React.createElement(Lock, { size: 40, className: "mx-auto text-fg4", "aria-hidden": true }), /* @__PURE__ */ React.createElement("h1", { className: "text-xl font-medium text-fg1" }, "\u0420\u0430\u0437\u0434\u0435\u043B \xAB", what, "\xBB \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D"), missing?.kind === "module" && /* @__PURE__ */ React.createElement("p", { className: "text-sm text-fg3" }, "\u041E\u043D \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F \u043A \u043C\u043E\u0434\u0443\u043B\u044E \xAB", missing.title, "\xBB, \u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u044D\u0442\u043E\u043C\u0443 \u043C\u043E\u0434\u0443\u043B\u044E \u0443 \u0432\u0430\u0441 \u043D\u0435\u0442. \u0414\u043E\u0441\u0442\u0443\u043F \u043A \u043C\u043E\u0434\u0443\u043B\u044E \u0434\u0430\u0451\u0442 \u043B\u044E\u0431\u043E\u0435 \u0435\u0433\u043E \u043F\u0440\u0430\u0432\u043E."), missing?.kind === "permission" && /* @__PURE__ */ React.createElement("p", { className: "text-sm text-fg3" }, "\u0414\u043B\u044F \u043D\u0435\u0433\u043E \u043D\u0443\u0436\u043D\u043E \u043F\u0440\u0430\u0432\u043E", " ", /* @__PURE__ */ React.createElement("code", { className: "rounded bg-muted px-1.5 py-0.5 font-mono text-xs text-fg2" }, missing.code), ", \u0438 \u0435\u0433\u043E \u0443 \u0432\u0430\u0441 \u043D\u0435\u0442."), !missing && /* @__PURE__ */ React.createElement("p", { className: "text-sm text-fg3" }, "\u041F\u0440\u0430\u0432\u0430 \u043D\u0430 \u043D\u0435\u0433\u043E \u0443 \u0432\u0430\u0441 \u043D\u0435\u0442. \u0415\u0441\u043B\u0438 \u0434\u043E\u0441\u0442\u0443\u043F \u043D\u0443\u0436\u0435\u043D \u2014 \u043D\u0430\u0437\u043E\u0432\u0438\u0442\u0435 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440\u0443 \u0430\u0434\u0440\u0435\u0441 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B."), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-fg4" }, "\u041F\u0440\u0430\u0432\u0430 \u0432\u044B\u0434\u0430\u0451\u0442 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u2014 \u043E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u043D\u0435\u043C\u0443.")));
  }

  // src/client/src/shared/ui/SourceOriginIcon.tsx
  init_define_import_meta_env();

  // src/client/src/shared/api/datasetHelpers.ts
  init_define_import_meta_env();
  function staleReasonText(reason) {
    switch (reason) {
      case "FileReplaced":
        return "\u0424\u0430\u0439\u043B \u043D\u0430\u0431\u043E\u0440\u0430 \u0437\u0430\u043C\u0435\u043D\u0451\u043D \u043F\u043E\u0441\u043B\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F \u2014 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0442\u043D\u043E\u0441\u044F\u0442\u0441\u044F \u043A \u043F\u0440\u0435\u0436\u043D\u0435\u043C\u0443 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u043C\u0443";
      case "NotParsedAgainstNewFile":
        return "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u043D\u0435 \u0440\u0430\u0437\u043E\u0431\u0440\u0430\u043B\u0441\u044F \u043F\u0440\u043E\u0442\u0438\u0432 \u043D\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u2014 \u043B\u0438\u0441\u0442 \u0438\u043B\u0438 \u043F\u0443\u0442\u044C \u0438\u0441\u0447\u0435\u0437, \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u043B\u0438\u0441\u044C \u043E\u0442 \u043F\u0440\u0435\u0436\u043D\u0435\u0433\u043E";
      case "TableBoundariesChanged":
        return "\u0421\u043E\u0441\u0442\u0430\u0432 \u0441\u0442\u0440\u0430\u043D\u0438\u0446 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u2014 \u0441\u0442\u0440\u043E\u043A\u0438 \u043E\u0442\u043D\u043E\u0441\u044F\u0442\u0441\u044F \u043A \u043F\u0440\u0435\u0436\u043D\u0438\u043C \u0433\u0440\u0430\u043D\u0438\u0446\u0430\u043C";
      case "ProfileChanged":
        return "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F \u0438\u0437\u043C\u0435\u043D\u0451\u043D \u043F\u043E\u0441\u043B\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u044F \u2014 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u044B \u043F\u0440\u0435\u0436\u043D\u0438\u043C\u0438 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438";
      default:
        return "\u0414\u0430\u043D\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430 \u0443\u0441\u0442\u0430\u0440\u0435\u043B\u0438";
    }
  }

  // src/client/src/shared/ui/SourceOriginIcon.tsx
  function SourceOriginIcon({ origin: origin2, plural, stale, staleReason }) {
    const recognized = origin2 === "Recognized";
    const originText = recognized ? plural ? "\u0421\u0442\u0440\u043E\u043A\u0438 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u044B \u0441\u043E \u0441\u043A\u0430\u043D\u0430 \u2014 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u044B \u043E\u0448\u0438\u0431\u043A\u0438 \u0447\u0442\u0435\u043D\u0438\u044F" : "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043E \u0441\u043E \u0441\u043A\u0430\u043D\u0430 \u2014 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u044B \u043E\u0448\u0438\u0431\u043A\u0438 \u0447\u0442\u0435\u043D\u0438\u044F" : plural ? "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0438\u0437 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430 \u0434\u0430\u043D\u043D\u044B\u0445" : "\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043F\u043E\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0438\u0437 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430 \u0434\u0430\u043D\u043D\u044B\u0445";
    const title = stale ? `${originText}. ${staleReasonText(staleReason)}` : originText;
    const cls = stale ? "text-warning" : "text-brand";
    return /* @__PURE__ */ React.createElement(Tooltip, { content: title }, /* @__PURE__ */ React.createElement("span", null, recognized ? /* @__PURE__ */ React.createElement(ScanText, { size: 12, className: cls, "aria-hidden": true }) : /* @__PURE__ */ React.createElement(DatabaseZap, { size: 12, className: cls, "aria-hidden": true }), /* @__PURE__ */ React.createElement("span", { className: "sr-only" }, title)));
  }

  // src/client/src/shared/ui/RereadFailedNotice.tsx
  init_define_import_meta_env();
  function RereadFailedNotice({ what, error, retrying, onRetry }) {
    return /* @__PURE__ */ React.createElement("div", { role: "alert", "data-testid": "reread-failed", className: "shrink-0 flex items-start gap-2 border-b\n      border-warning-border bg-warning-subtle px-5 py-2 text-xs text-warning" }, /* @__PURE__ */ React.createElement(TriangleAlert, { size: 13, className: "shrink-0 mt-0.5" }), /* @__PURE__ */ React.createElement("p", { className: "flex-1" }, what, ": ", apiError(error, "\u0441\u0435\u0440\u0432\u0435\u0440 \u043D\u0435 \u043E\u0442\u0432\u0435\u0442\u0438\u043B"), ". \u041D\u0430 \u044D\u043A\u0440\u0430\u043D\u0435 \u2014 \u043F\u0440\u0435\u0436\u043D\u0435\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435: \u0435\u0433\u043E \u043C\u043E\u0433\u043B\u0438 \u0442\u0435\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u044C. \u041D\u0430\u0431\u0440\u0430\u043D\u043D\u043E\u0435 \u043D\u0435 \u043F\u0440\u043E\u043F\u0430\u043B\u043E."), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "outlined", icon: /* @__PURE__ */ React.createElement(RefreshCw, { size: 13 }), loading: retrying, onClick: onRetry }, "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C"));
  }

  // src/client/src/shared/ui/Chip.tsx
  init_define_import_meta_env();
  var BASE2 = "inline-flex items-center gap-1 rounded-full border text-xs bg-surface transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand disabled:opacity-50 disabled:pointer-events-none";
  var TONE = {
    neutral: "border-stroke text-fg3 hover:text-fg1 hover:border-stroke-strong",
    warning: "border-warning-border text-warning hover:bg-warning-subtle",
    danger: "border-danger text-danger hover:bg-danger-subtle"
  };
  var SELECTED = "border-brand text-brand bg-brand-subtle";
  function chipClass({ selected = false, tone = "neutral", dashed = false } = {}) {
    return `${BASE2} ${selected ? SELECTED : `${TONE[tone]}${dashed ? " border-dashed" : ""}`}`;
  }
  function Chip({ children, selected, icon: Icon2, count: count3, tone, dashed, onRemove, removeLabel, menu = false, className = "", type = "button", ...rest }) {
    const toggles = selected !== void 0 && !menu;
    const Shown = toggles && selected ? Check : Icon2;
    const body = /* @__PURE__ */ React.createElement(React.Fragment, null, Shown && /* @__PURE__ */ React.createElement(Shown, { size: 12, "aria-hidden": true, className: "shrink-0" }), /* @__PURE__ */ React.createElement("span", { className: "min-w-0 truncate" }, children), count3 !== void 0 && /* @__PURE__ */ React.createElement("span", { className: "font-medium tabular-nums" }, "\xB7 ", count3), menu && /* @__PURE__ */ React.createElement(ChevronDown, { size: 12, "aria-hidden": true, className: "shrink-0" }));
    if (!onRemove)
      return /* @__PURE__ */ React.createElement(
        "button",
        {
          ...rest,
          type,
          "aria-pressed": toggles ? selected : void 0,
          className: `${chipClass({ selected, tone, dashed })} px-2.5 py-1 ${className}`
        },
        body
      );
    return /* @__PURE__ */ React.createElement("span", { className: `${chipClass({ selected, tone, dashed })} ${className}` }, /* @__PURE__ */ React.createElement(
      "button",
      {
        ...rest,
        type,
        "aria-pressed": toggles ? selected : void 0,
        className: "inline-flex items-center gap-1 pl-2.5 pr-1 py-1 rounded-l-full min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand"
      },
      body
    ), /* @__PURE__ */ React.createElement(Tooltip, { content: removeLabel ?? "\u0421\u043D\u044F\u0442\u044C" }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        onClick: onRemove,
        "aria-label": removeLabel ?? "\u0421\u043D\u044F\u0442\u044C",
        disabled: rest.disabled,
        className: "pl-0.5 pr-2 py-1 rounded-r-full hover:text-danger focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand"
      },
      /* @__PURE__ */ React.createElement(X, { size: 12, "aria-hidden": true })
    )));
  }

  // src/client/src/shared/ui/Tabs.tsx
  init_define_import_meta_env();
  var import_react32 = __toESM(require_react_shim(), 1);
  var tabId = (id, value) => `${id}-tab-${value}`;
  var panelId = (id, value) => `${id}-panel-${value}`;
  var STYLE = {
    // Не влезающий ряд прокручивается вбок, а подписи не переносятся (issue #1384): у редактора документа
    // четыре вкладки, и на телефоне они иначе ломались в две строки и раздвигали страницу. Отсюда и черта
    // под вкладкой без `-mb-px`: прокручиваемый ряд обрезал бы её, наезжающую на линию ряда.
    underline: {
      list: "flex overflow-x-auto [scrollbar-width:none] border-b border-stroke",
      tab: "inline-flex shrink-0 items-center gap-1.5 h-12 px-4 text-sm font-medium whitespace-nowrap border-b-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand",
      on: "border-brand text-brand",
      off: "border-transparent text-fg3 hover:text-fg1"
    },
    segmented: {
      list: "inline-flex bg-muted rounded-lg p-0.5",
      tab: "inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand",
      on: "bg-surface text-fg1 font-medium shadow-sm",
      off: "text-fg3 hover:text-fg1"
    }
  };
  function Tabs({ id, items, value, onChange, variant = "underline", className = "", ...aria }) {
    const refs = (0, import_react32.useRef)([]);
    const s = STYLE[variant];
    function onKey(e, i) {
      const enabled = items.map((it, k) => it.disabled ? -1 : k).filter((k) => k >= 0);
      const at = enabled.indexOf(i);
      let next;
      if (e.key === "ArrowRight") next = enabled[(at + 1) % enabled.length];
      else if (e.key === "ArrowLeft") next = enabled[(at - 1 + enabled.length) % enabled.length];
      else if (e.key === "Home") next = enabled[0];
      else if (e.key === "End") next = enabled[enabled.length - 1];
      else return;
      e.preventDefault();
      refs.current[next]?.focus();
    }
    return /* @__PURE__ */ React.createElement("div", { role: "tablist", className: `${s.list} ${className}`, ...aria }, items.map((it, i) => {
      const on = it.value === value;
      const Icon2 = it.icon;
      return /* @__PURE__ */ React.createElement(Tooltip, { key: it.value, content: it.title }, /* @__PURE__ */ React.createElement(
        "button",
        {
          type: "button",
          role: "tab",
          id: tabId(id, it.value),
          "aria-selected": on,
          "aria-controls": panelId(id, it.value),
          tabIndex: on ? 0 : -1,
          disabled: it.disabled,
          ref: (el) => {
            refs.current[i] = el;
          },
          onClick: () => {
            if (!on) onChange(it.value);
          },
          onKeyDown: (e) => onKey(e, i),
          className: `${s.tab} ${on ? s.on : s.off} disabled:opacity-40 disabled:pointer-events-none`
        },
        Icon2 && /* @__PURE__ */ React.createElement(Icon2, { size: 14, "aria-hidden": true, className: "shrink-0" }),
        it.label,
        it.badge
      ));
    }));
  }
  function TabPanel({ id, value, className, children }) {
    return /* @__PURE__ */ React.createElement("div", { role: "tabpanel", id: panelId(id, value), "aria-labelledby": tabId(id, value), className }, children);
  }

  // src/client/src/shared/ui/StatusBadge.tsx
  init_define_import_meta_env();
  var TONE2 = {
    neutral: { fill: "bg-muted text-fg2", border: "border-stroke" },
    brand: { fill: "bg-brand-subtle text-on-brand-subtle", border: "border-brand/30" },
    success: { fill: "bg-success-subtle text-success", border: "border-success/30" },
    warning: { fill: "bg-warning-subtle text-warning", border: "border-warning-border" },
    danger: { fill: "bg-danger-subtle text-danger", border: "border-danger/30" },
    quiet: { fill: "text-fg3", border: "border-stroke" }
  };
  function StatusBadge({ tone = "neutral", icon: Icon2, bordered = false, title, className = "", children }) {
    const t = TONE2[tone];
    const outlined = bordered || tone === "quiet";
    return /* @__PURE__ */ React.createElement(Tooltip, { content: title }, /* @__PURE__ */ React.createElement(
      "span",
      {
        className: `shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-caption font-medium whitespace-nowrap ${t.fill} ${outlined ? `border ${t.border}` : ""} ${className}`
      },
      Icon2 && /* @__PURE__ */ React.createElement(Icon2, { size: 12, "aria-hidden": true, className: "shrink-0" }),
      children
    ));
  }

  // src/client/src/shared/ui/EditGrid.tsx
  init_define_import_meta_env();
  var import_react33 = __toESM(require_react_shim(), 1);
  var FOCUSABLE = 'input:not([disabled]), textarea:not([disabled]), button:not([disabled]), [role="combobox"]:not([aria-disabled="true"]), [tabindex]:not([tabindex="-1"])';
  function EditGrid({
    columns,
    rows,
    rowKey,
    label,
    numbered = false,
    add,
    onRemove,
    removeLabel,
    empty = "\u0421\u0442\u0440\u043E\u043A \u043D\u0435\u0442",
    framed = true,
    className = "",
    minWidth = "",
    rowData,
    sheet = false,
    selected,
    drag
  }) {
    const table = (0, import_react33.useRef)(null);
    const addButton = (0, import_react33.useRef)(null);
    const pendingFocus = (0, import_react33.useRef)(null);
    const removable = onRemove !== void 0;
    const hasTotal = columns.some((c) => c.total);
    const span = columns.length + (numbered ? 1 : 0) + (removable ? 1 : 0);
    (0, import_react33.useLayoutEffect)(() => {
      const wanted = pendingFocus.current;
      if (!wanted || !table.current) return;
      pendingFocus.current = null;
      if (wanted.kind === "added") {
        const row = table.current.querySelector(`tbody tr[data-row="${rows.length - 1}"]`);
        row?.querySelector(`[data-cell] :is(${FOCUSABLE})`)?.focus();
        return;
      }
      const next = Math.min(wanted.index, rows.length - 1);
      const button = next >= 0 ? table.current.querySelector(`button[data-remove="${next}"]`) : null;
      (button ?? addButton.current)?.focus();
    }, [rows.length]);
    function focusCell(r, c) {
      const cell = table.current?.querySelector(`[data-cell][data-r="${r}"][data-c="${c}"]`);
      const control = cell?.querySelector(FOCUSABLE);
      if (!control) return false;
      control.focus();
      if (control instanceof HTMLInputElement && control.type !== "checkbox") control.select();
      return true;
    }
    function onKeyDown(e) {
      if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      const target = e.target;
      const cell = target.closest("[data-cell]");
      if (!cell || !table.current?.contains(cell)) return;
      const r = Number(cell.dataset.r);
      const c = Number(cell.dataset.c);
      if (e.key === "ArrowUp" || e.key === "ArrowDown") {
        if (target.getAttribute("role") === "combobox" || target instanceof HTMLTextAreaElement) return;
        const next = e.key === "ArrowUp" ? r - 1 : r + 1;
        if (next >= 0 && next < rows.length && focusCell(next, c)) e.preventDefault();
        return;
      }
      if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
      const back = e.key === "ArrowLeft";
      if (!atEdge(target, back)) return;
      for (let next = back ? c - 1 : c + 1; next >= 0 && next < columns.length; next += back ? -1 : 1) {
        if (focusCell(r, next)) {
          e.preventDefault();
          return;
        }
      }
    }
    const sized = columns.some((c) => c.size !== void 0);
    const td = sheet ? dtTdSheet : dtTdEdit;
    const th = (extra = "") => `${dtThCompact} ${sheet ? "border-r" : ""} ${extra}`;
    const pinClass = (c) => c.pin === "start" ? "sticky border-r" : c.pin === "end" ? "sticky border-l" : "";
    const pinStyle = (c, layer) => c.pin === "start" ? { left: 0, zIndex: layer } : c.pin === "end" ? { right: 0, zIndex: layer } : void 0;
    const sizeStyle = (c) => c.size === void 0 ? void 0 : { width: c.size };
    return /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, /* @__PURE__ */ React.createElement("div", { className: `${framed ? dtCard : "overflow-auto"} ${className}` }, /* @__PURE__ */ React.createElement(
      "table",
      {
        ref: table,
        "aria-label": label,
        onKeyDown,
        className: `${dtTableCompact} ${sized ? dtTableSized : ""} ${minWidth}`
      },
      /* @__PURE__ */ React.createElement("thead", null, /* @__PURE__ */ React.createElement("tr", null, numbered && /* @__PURE__ */ React.createElement("th", { className: th("w-8") }, "\u2116"), columns.map((c) => /* @__PURE__ */ React.createElement(Tooltip, { key: c.key, content: c.hint }, /* @__PURE__ */ React.createElement(
        "th",
        {
          style: { ...sizeStyle(c), ...pinStyle(c, 30) },
          className: th(`${c.width ?? ""} ${c.align === "right" ? "text-right" : ""} ${pinClass(c)}`)
        },
        c.header ?? c.label
      ))), removable && /* @__PURE__ */ React.createElement("th", { className: th("w-8") }, /* @__PURE__ */ React.createElement("span", { className: "sr-only" }, "\u0423\u0434\u0430\u043B\u0438\u0442\u044C")))),
      /* @__PURE__ */ React.createElement("tbody", null, rows.length === 0 ? /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("td", { colSpan: span, className: `${dtTdEdit} py-3 text-center text-fg4` }, empty)) : rows.map((row, i) => {
        const chosen = selected?.(row, i) ?? false;
        const dropMark = !drag || drag.dragging === null ? null : drag.target === i ? "inset 0 2px 0 0 var(--color-brand)" : drag.target === rows.length && i === rows.length - 1 ? "inset 0 -2px 0 0 var(--color-brand)" : null;
        return /* @__PURE__ */ React.createElement(
          "tr",
          {
            key: rowKey(row, i),
            "data-row": i,
            ...rowData?.(row, i),
            className: `${dtRow} ${chosen ? "bg-brand-subtle" : ""} ${drag?.dragging === i ? "opacity-40" : ""}`,
            style: dropMark ? { boxShadow: dropMark } : void 0,
            ...drag ? {
              onDragOver: (e) => drag.onOver(e, i),
              onDrop: drag.onDrop
            } : {}
          },
          numbered && /* @__PURE__ */ React.createElement("th", { scope: "row", className: `${td} text-left font-normal text-fg4 tabular-nums` }, i + 1),
          columns.map((c, ci) => {
            const Cell = c.rowHeader ? "th" : "td";
            return /* @__PURE__ */ React.createElement(
              Cell,
              {
                key: c.key,
                "data-cell": true,
                "data-r": i,
                "data-c": ci,
                scope: c.rowHeader ? "row" : void 0,
                style: pinStyle(c, 5),
                className: `${td} text-fg1 ${c.rowHeader ? "text-left font-normal" : ""} ${c.align === "right" ? dtNum : ""} ${pinClass(c)} ${c.pin ? chosen ? "bg-brand-subtle" : "bg-surface" : ""}`
              },
              c.cell(row, i)
            );
          }),
          removable && /* @__PURE__ */ React.createElement("td", { className: `${td} text-center` }, /* @__PURE__ */ React.createElement(
            RemoveButton,
            {
              index: i,
              label: removeLabel?.(row, i) ?? `\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u0442\u0440\u043E\u043A\u0443 ${i + 1}`,
              onClick: () => {
                pendingFocus.current = { kind: "removed", index: i };
                onRemove(row, i);
              }
            }
          ))
        );
      })),
      hasTotal && /* @__PURE__ */ React.createElement("tfoot", null, /* @__PURE__ */ React.createElement("tr", null, numbered && /* @__PURE__ */ React.createElement("td", { className: FOOT }), columns.map((c) => /* @__PURE__ */ React.createElement(
        "td",
        {
          key: c.key,
          style: pinStyle(c, 30),
          className: `${FOOT} ${c.align === "right" ? dtNum : ""} ${pinClass(c)}`
        },
        c.total?.()
      )), removable && /* @__PURE__ */ React.createElement("td", { className: FOOT })))
    )), add && /* @__PURE__ */ React.createElement(
      Button,
      {
        ref: addButton,
        size: "sm",
        variant: "outlined",
        icon: /* @__PURE__ */ React.createElement(Plus, { size: 13 }),
        onClick: () => {
          pendingFocus.current = { kind: "added" };
          add.onAdd();
        }
      },
      add.label
    ));
  }
  var FOOT = "sticky bottom-0 z-10 bg-muted border-t border-stroke px-2 py-1.5 text-xs text-fg2 align-top";
  function RemoveButton({ index: index2, label, onClick }) {
    return /* @__PURE__ */ React.createElement(Tooltip, { content: label }, /* @__PURE__ */ React.createElement(
      "button",
      {
        type: "button",
        "data-remove": index2,
        onClick,
        "aria-label": label,
        className: "rounded-sm p-0.5 text-fg4 hover:text-danger focus-visible:outline-2"
      },
      /* @__PURE__ */ React.createElement(Trash2, { size: 13, "aria-hidden": true })
    ));
  }
  function atEdge(target, back) {
    if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) return true;
    const { selectionStart: start, selectionEnd: end, value } = target;
    if (start === null || end === null) return true;
    return back ? start === 0 && end === 0 : start === value.length && end === value.length;
  }

  // src/client/src/shared/ui/WindowStep.tsx
  init_define_import_meta_env();
  var import_react34 = __toESM(require_react_shim(), 1);
  var import_react_dom2 = __toESM(require_react_dom_shim(), 1);
  function WindowStep(props) {
    const host = (0, import_react34.useContext)(WindowStepContext);
    if (!host) {
      const { title, footer, children, onBack, busy, isDirty, wide } = props;
      return /* @__PURE__ */ React.createElement(
        Modal,
        {
          open: true,
          onOpenChange: (o) => {
            if (!o) onBack();
          },
          title,
          wide,
          footer,
          busy,
          isDirty
        },
        children
      );
    }
    return /* @__PURE__ */ React.createElement(HostedStep, { host, ...props });
  }
  function HostedStep({ host, title, footer, children, onBack, busy = false, isDirty }) {
    const id = (0, import_react34.useId)();
    const back = (0, import_react34.useRef)(onBack);
    (0, import_react34.useLayoutEffect)(() => {
      back.current = onBack;
    });
    const { push, update, pop } = host;
    (0, import_react34.useLayoutEffect)(() => {
      push(id, () => back.current());
      return () => pop(id);
    }, [push, pop, id]);
    (0, import_react34.useLayoutEffect)(() => {
      update(id, { title, busy, isDirty });
    }, [update, id, title, busy, isDirty]);
    const slot = host.slots[id];
    return /* @__PURE__ */ React.createElement(React.Fragment, null, slot?.body && (0, import_react_dom2.createPortal)(children, slot.body), slot?.footer && footer && (0, import_react_dom2.createPortal)(footer, slot.footer));
  }
  return __toCommonJS(ds_entry_exports);
})();
/*! Bundled license information:

lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs:
lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs:
lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs:
lucide-react/dist/esm/shared/src/utils/toPascalCase.mjs:
lucide-react/dist/esm/defaultAttributes.mjs:
lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs:
lucide-react/dist/esm/context.mjs:
lucide-react/dist/esm/Icon.mjs:
lucide-react/dist/esm/createLucideIcon.mjs:
lucide-react/dist/esm/icons/archive.mjs:
lucide-react/dist/esm/icons/arrow-down.mjs:
lucide-react/dist/esm/icons/arrow-left.mjs:
lucide-react/dist/esm/icons/arrow-up-right.mjs:
lucide-react/dist/esm/icons/arrow-up.mjs:
lucide-react/dist/esm/icons/ban.mjs:
lucide-react/dist/esm/icons/boxes.mjs:
lucide-react/dist/esm/icons/building-2.mjs:
lucide-react/dist/esm/icons/calendar-days.mjs:
lucide-react/dist/esm/icons/check.mjs:
lucide-react/dist/esm/icons/chevron-down.mjs:
lucide-react/dist/esm/icons/chevron-left.mjs:
lucide-react/dist/esm/icons/chevron-right.mjs:
lucide-react/dist/esm/icons/chevron-up.mjs:
lucide-react/dist/esm/icons/circle-check.mjs:
lucide-react/dist/esm/icons/cpu.mjs:
lucide-react/dist/esm/icons/database-zap.mjs:
lucide-react/dist/esm/icons/ellipsis-vertical.mjs:
lucide-react/dist/esm/icons/eye-off.mjs:
lucide-react/dist/esm/icons/file-text.mjs:
lucide-react/dist/esm/icons/folder-open.mjs:
lucide-react/dist/esm/icons/grip-vertical.mjs:
lucide-react/dist/esm/icons/info.mjs:
lucide-react/dist/esm/icons/layers.mjs:
lucide-react/dist/esm/icons/link-2.mjs:
lucide-react/dist/esm/icons/loader-circle.mjs:
lucide-react/dist/esm/icons/lock.mjs:
lucide-react/dist/esm/icons/map-pin.mjs:
lucide-react/dist/esm/icons/minus.mjs:
lucide-react/dist/esm/icons/package.mjs:
lucide-react/dist/esm/icons/plus.mjs:
lucide-react/dist/esm/icons/refresh-cw.mjs:
lucide-react/dist/esm/icons/ruler.mjs:
lucide-react/dist/esm/icons/scan-text.mjs:
lucide-react/dist/esm/icons/search.mjs:
lucide-react/dist/esm/icons/square-function.mjs:
lucide-react/dist/esm/icons/trash-2.mjs:
lucide-react/dist/esm/icons/triangle-alert.mjs:
lucide-react/dist/esm/icons/unlink.mjs:
lucide-react/dist/esm/icons/user.mjs:
lucide-react/dist/esm/icons/wrench.mjs:
lucide-react/dist/esm/icons/x.mjs:
lucide-react/dist/esm/lucide-react.mjs:
  (**
   * @license lucide-react v1.21.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)

react-router/dist/production/lib/router/url.js:
react-router/dist/production/lib/router/history.js:
react-router/dist/production/lib/router/utils.js:
react-router/dist/production/lib/router/router.js:
react-router/dist/production/lib/context.js:
react-router/dist/production/lib/errors.js:
react-router/dist/production/lib/hooks.js:
react-router/dist/production/lib/components.js:
react-router/dist/production/lib/dom/dom.js:
react-router/dist/production/lib/dom/ssr/invariant.js:
react-router/dist/production/lib/dom/ssr/markup.js:
react-router/dist/production/lib/dom/ssr/single-fetch.js:
react-router/dist/production/lib/dom/ssr/routeModules.js:
react-router/dist/production/lib/dom/ssr/links.js:
react-router/dist/production/lib/dom/ssr/components.js:
react-router/dist/production/lib/dom/lib.js:
react-router/dist/production/index.js:
  (**
   * react-router v8.3.0
   *
   * Copyright (c) Remix Software Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE.md file in the root directory of this source tree.
   *
   * @license MIT
   *)
*/
window.BhsCrgUi=BhsCrgUi.__dsMainNs?Object.assign({},BhsCrgUi,BhsCrgUi.__dsMainNs,{__dsMainNs:undefined}):BhsCrgUi;
