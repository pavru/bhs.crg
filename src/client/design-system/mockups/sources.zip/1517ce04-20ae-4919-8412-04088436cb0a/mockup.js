/* «Прочитано, в счёт не положено» в форме счёта (#1484). Блок «Замечания распознавания» стоит первым в
   прокручиваемой части формы (InvoiceForm, RecognitionNotes). Сервер отдаёт список записей
   { place, row, key, value, reason, detail }; слова причин — на клиенте по коду. Данные выдуманные. */
(function () {
  var h = React.createElement, F = React.Fragment;

  /* ── данные: 20 записей одного распознавания ── */
  var COUNTRIES = ['Россия', 'Китай', 'Россия', 'Россия', 'Турция', 'Китай', 'Россия', 'Россия', 'Беларусь', 'Россия', 'Китай', 'Россия'];
  var REC = [
    { place: 'header', key: 'КодКлиента', value: 'К-0042', reason: 'no-field' },
    { place: 'header', key: 'ОплатитьДо', value: '15.11.2026', reason: 'not-recognizable', detail: 'срок считает правило' },
    { place: 'header', key: 'СрокПоставки', value: 'до 15.11', reason: 'unparsed' },
    { place: 'header', key: 'КодДоговора', value: 'X-1', reason: 'guard', detail: 'код договора — «Д-» и цифры' },
    { place: 'header', key: 'НомерСчёта', value: 'СЧ-1484', reason: 'occupied' },
  ];
  [2, 5, 9].forEach(function (r) { REC.push({ place: 'line', row: r, key: 'Артикл', value: ['ВВГ-3х2,5', 'ГОФ-20', 'КМ-16'][[2, 5, 9].indexOf(r)], reason: 'no-field' }); });
  COUNTRIES.forEach(function (c, i) { REC.push({ place: 'line', row: i + 1, key: 'Страна', value: c, reason: 'no-field' }); });
  /* Как отдаёт показ: сначала шапка, потом строки файла по номеру. */
  REC.sort(function (a, b) { return a.place === b.place ? (a.row || 0) - (b.row || 0) : a.place === 'header' ? -1 : 1; });

  var NOTES = [
    'Срок поставки: «до 15.11» не прочитано как значение поля — впишите вручную.',
    'Код договора: «X-1» не записано — охрана записи: код договора — «Д-» и цифры.',
  ];

  /* Слова причины — по коду. Зовущие к действию (не разобрано, охрана, занято) ведут к предложению под полем. */
  function reason(r) {
    switch (r.reason) {
      case 'no-field': return r.place === 'line' ? 'у строки счёта нет поля с таким ключом' : 'у счёта нет поля с таким ключом';
      case 'not-recognizable': return 'поле не заполняется распознаванием: ' + r.detail;
      case 'unparsed': return 'значение не разобрано — предложено под полем';
      case 'guard': return 'охрана записи: ' + r.detail + ' — предложено под полем';
      case 'occupied': return 'поле уже заполнено — прочитанное предложено под полем';
      case 'duplicate-key': return 'повторяет ключ «' + r.detail + '» — поле уже заполнено им';
    }
  }
  var SHORT = { 'no-field': 'нет поля', 'not-recognizable': 'не заполняется', unparsed: 'не разобрано', guard: 'охрана записи', occupied: 'поле занято', 'duplicate-key': 'повтор ключа' };
  function where(r) { return r.place === 'header' ? 'шапка' : 'строка ' + r.row; }
  function plural(n, one, few, many) { var m = n % 10, c = n % 100; return m === 1 && c !== 11 ? one : m >= 2 && m <= 4 && (c < 12 || c > 14) ? few : many; }
  /* Ключ как прочитан — моноширинным и без обрезки пробелов (white-space: pre). */
  function Key(k) { return h('td', { className: 'k' }, k); }

  function Chev(p) {
    return h('svg', { className: 'chev', viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', style: { transform: p && p.up ? 'rotate(180deg)' : 'none' } }, h('polyline', { points: '6 9 12 15 18 9' }));
  }
  function X() { return h('svg', { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' }, h('line', { x1: 6, y1: 6, x2: 18, y2: 18 }), h('line', { x1: 18, y1: 6, x2: 6, y2: 18 })); }

  /* ── каркас формы: замечания + следующий блок формы приглушённо ── */
  function Form(p) {
    return h('div', { className: 'form' },
      h('section', { className: 'notes' },
        h('h2', null, 'Замечания распознавания'),
        p.notes === false ? null : h('ul', null, NOTES.map(function (n) { return h('li', { key: n }, n); })),
        p.children),
      p.ghost === false ? null : h('div', { className: 'ghost' }, h('h3', null, 'Оплата'), h('div', { className: 'g2' },
        h('div', { className: 'of' }, h('span', { className: 'lab' }, 'Отсрочка, дней'), '10'),
        h('div', { className: 'of' }, h('span', { className: 'lab' }, 'Оплатить до'), '01.11.2026'))));
  }
  function Frame(p) { return h('div', { className: 'frame', style: { width: p.w } }, p.children); }
  function Cap(k, t) { return h('p', { className: 'cap' }, h('i', null, k), t); }
  function Opt(p) {
    return h('div', { className: 'dv-opt', id: p.id, style: { '--w': p.w + 'px' } },
      h('div', { className: 'dv-olabel' }, h('a', { className: 'dv-oid', href: '#' + p.id }, p.id), p.label),
      p.children, p.note ? h('p', { className: 'dv-note' }, p.note) : null);
  }
  function Col(p) { return h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8 } }, p.children); }

  /* ── 1a: плоская таблица под строкой ── */
  function Quiet1(p) {
    p = p || {};
    return h('p', { className: 'quiet' },
      h('span', null, 'Ещё прочитано, в счёт не положено: ', h('b', null, REC.length)),
      h('span', { className: 'tbtn' + (p.focus ? ' focus' : ''), role: 'button', 'aria-expanded': !!p.open }, p.open ? 'Скрыть' : 'Показать', h(Chev, { up: p.open })));
  }
  function Flat(p) {
    return h('div', { className: 'dg', style: { '--mh': p.mh ? p.mh + 'px' : 'none' } },
      h('table', null,
        h('thead', null, h('tr', null, ['Где', 'Ключ', 'Значение', 'Причина'].map(function (t) { return h('th', { key: t }, t); }))),
        h('tbody', null, p.rows.map(function (r, i) {
          return h('tr', { key: i }, h('td', { className: 'w' }, where(r)), Key(r.key), h('td', { className: 'v' }, r.value), h('td', { className: 'r' }, reason(r)));
        }))));
  }

  /* ── 1b: сводка по ключам, раскрытие ключа ── */
  function groups() {
    var out = [], by = {};
    REC.forEach(function (r) {
      var id = r.place + '|' + r.key + '|' + r.reason;
      if (!by[id]) { by[id] = { place: r.place, key: r.key, reason: r.reason, detail: r.detail, items: [] }; out.push(by[id]); }
      by[id].items.push(r);
    });
    return out;
  }
  function rows(items) {
    var n = items.map(function (r) { return r.row; });
    var seq = n.every(function (x, i) { return i === 0 || x === n[i - 1] + 1; });
    return n.length === 1 ? 'строка ' + n[0] : seq ? 'строки ' + n[0] + '–' + n[n.length - 1] : 'строки ' + n.join(', ');
  }
  function Quiet2(p) {
    p = p || {};
    var g = groups().filter(function (x) { return x.place === 'line'; });
    var head = REC.filter(function (r) { return r.place === 'header'; });
    return h('p', { className: 'quiet' },
      h('span', null, 'Ещё прочитано, в счёт не положено: ',
        g.map(function (x, i) { return h(F, { key: x.key }, i ? ', ' : null, h('b', null, x.key), ' (в ' + x.items.length + ' ' + plural(x.items.length, 'строке', 'строках', 'строках') + ')'); }),
        ', и в шапке: ', h('b', null, head.length)),
      h('span', { className: 'tbtn', role: 'button', 'aria-expanded': !!p.open }, p.open ? 'Скрыть' : 'Показать', h(Chev, { up: p.open })));
  }
  function Grouped(p) {
    var gs = groups();
    return h('div', { className: 'dg' },
      h('table', null,
        h('thead', null, h('tr', null, ['Ключ', 'Где', 'Прочитано', 'Причина'].map(function (t) { return h('th', { key: t }, t); }))),
        h('tbody', null, gs.map(function (g) {
          var many = g.items.length > 1, open = p.open === g.key;
          var vals = g.items.map(function (r) { return r.value; });
          var uniq = vals.filter(function (v, i) { return vals.indexOf(v) === i; });
          /* Ключ без шеврона сдвинут на его ширину — ключи стоят одной колонкой. */
          var main = h('tr', { key: g.key, className: many ? 'grp' : '' },
            h('td', { className: 'k' }, h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: 2, paddingLeft: many ? 0 : 16 } }, many ? h(Chev, { up: open }) : null, g.key)),
            h('td', { className: 'w' }, g.place === 'header' ? 'шапка' : rows(g.items)),
            h('td', { className: 'v' }, many ? uniq.slice(0, 3).join(', ') + (uniq.length > 3 ? '…' : '') : vals[0]),
            h('td', { className: 'r' }, reason(g)));
          if (!open) return main;
          return h(F, { key: g.key }, main, g.items.map(function (r) {
            return h('tr', { key: g.key + r.row, className: 'sub' }, h('td', null), h('td', { className: 'w' }, 'строка ' + r.row), h('td', { className: 'v', colSpan: 2 }, r.value));
          }));
        }))));
  }

  /* ── 1c: окно с отбором по причине ── */
  function Modal(p) {
    var counts = {}; REC.forEach(function (r) { counts[r.reason] = (counts[r.reason] || 0) + 1; });
    var shown = p.only ? REC.filter(function (r) { return r.reason !== 'no-field' && r.reason !== 'not-recognizable'; }) : REC;
    return h('div', { className: 'scrim' },
      h('div', { className: 'modal', role: 'dialog' },
        h('div', { className: 'mh' },
          h('div', { style: { flex: 1 } }, h('h2', null, 'Прочитано, в счёт не положено'),
            h('p', null, 'Счёт № СЧ-1484 · по файлу «Счёт 1484.pdf». Колонки и поля без поля в счёте получают только наборы данных — это не ошибка.')),
          h('span', { className: 'x', 'aria-label': 'Закрыть' }, h(X))),
        h('div', { className: 'mb' },
          h('div', { className: 'chips' },
            h('span', { className: 'chip' + (p.only ? '' : ' on') }, 'Все', h('span', { className: 'n' }, REC.length)),
            ['unparsed', 'guard', 'occupied', 'not-recognizable', 'no-field'].map(function (c) {
              return h('span', { key: c, className: 'chip' + (p.only && c !== 'no-field' && c !== 'not-recognizable' ? ' on' : '') }, SHORT[c], h('span', { className: 'n' }, counts[c]));
            })),
          h(Flat, { rows: shown, mh: 300 })),
        h('div', { className: 'mf' }, h('span', { className: 'btn' }, 'Закрыть'))));
  }

  /* ── листы ── */
  function Common() {
    return h('section', { className: 'dv-turn', id: 't0' },
      h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t0' }, '0'), h('span', { className: 'dv-tname' }, 'Общее для всех вариантов — следует из правил и разбора Дизайнера (18.10.2026)')),
      h('p', { className: 'dv-tsub' }, h('b', null, 'Строка тихая:'), ' text-fg3, не warning и не в списке замечаний — колонка «только для наборов данных» законна, и жёлтая строка в каждом счёте стала бы шумом. ',
        h('b', null, 'Замечания, зовущие к действию'), ' («впишите вручную», «охрана записи») остаются в списке как есть; их записи есть и в таблице. ',
        h('b', null, 'Строки нет'), ' у распознавания до списка (unplaced = null — «не знаем», не «0») и при пустом списке. ',
        h('b', null, 'Ключ — моноширинным и как прочитан'), ', без обрезки: опечатка «Артикл» или «Цена » с пробелом видна. Значение — до 40 знаков, полный текст подсказкой у обрезанной клетки.'),
      h('div', { className: 'dv-opts' },
        h(Opt, { id: '0a', w: 560, label: 'Только колонки для наборов данных — блок показан ради одной строки', note: h(F, null, 'Распознавание без замечаний, но в профиле есть колонка «Страна»: раньше блок молчал, теперь показан — заголовок и одна тихая строка.') },
          h(Frame, { w: 560 }, h(Form, { notes: false, ghost: true }, h('p', { className: 'quiet' }, h('span', null, 'Ещё прочитано, в счёт не положено: ', h('b', null, '12')), h('span', { className: 'tbtn' }, 'Показать', h(Chev)))))),
        h(Opt, { id: '0b', w: 300, label: 'Прежнее распознавание (null) и пустой список', note: 'Строки нет вовсе; прежние текстовые замечания старого распознавания показаны как были.' },
          h(Frame, { w: 300 }, h(Form, { ghost: false }, null)))));
  }

  function Turn1() {
    var W = 760;
    return h('section', { className: 'dv-turn', id: 't1' },
      h('div', { className: 'dv-thd' }, h('a', { className: 'dv-tid', href: '#t1' }, '1'), h('span', { className: 'dv-tname' }, 'Три решения: что видно в свёрнутой строке и как устроено раскрытое')),
      h('p', { className: 'dv-tsub' }, 'Один и тот же счёт: 5 записей шапки (нет поля, не заполняется, не разобрано, охрана, занято) и 15 записей строк — колонка «Страна» в 12 строках и опечатка «Артикл» в 3. Варианты различаются ', h('b', null, 'единицей показа'), ': запись (', h('a', { className: 'dv-oid', href: '#1a' }, '1a'), '), ключ (', h('a', { className: 'dv-oid', href: '#1b' }, '1b'), ') или отдельное окно с отбором по причине (', h('a', { className: 'dv-oid', href: '#1c' }, '1c'), ').'),
      h('div', { className: 'pc' },
        h('div', null, h('span', { className: 'tag ok' }, '1a'), ' ', h('b', null, '+'), ' буквально по спецификации, проще всего в коде и тесте; номер строки виден у каждой записи. ', h('b', null, '−'), ' колонка «для наборов» в счёте на 400 строк — 400 одинаковых строк таблицы, опечатка тонет.'),
        h('div', null, h('span', { className: 'tag alt' }, '1b'), ' ', h('b', null, '+'), ' свёрнутая строка уже называет ключи — опечатку «Артикл» видно без раскрытия; таблица короткая при любом размере счёта. ', h('b', null, '−'), ' значения по строкам — вторым раскрытием; строка длиннее.'),
        h('div', null, h('span', { className: 'tag warn' }, '1c'), ' ', h('b', null, '+'), ' форма не растёт; отбор «зовущие к действию» отделяет важное от законного. ', h('b', null, '−'), ' окно поверх формы — дальше от предложений под полями; спецификация говорит «раскрывает», а не «открывает окно».')),
      h('div', { className: 'dv-opts' },
        h(Opt, { id: '1a', w: W, label: 'Плоская таблица записей под строкой', note: h(F, null, '«Показать» — текстовая кнопка с шевроном, aria-expanded; раскрывает DataGrid density="compact" прямо под строкой, ', h('b', null, 'по записи на строку'), ': сначала шапка, потом строки файла по номеру. Высота ограничена (≈ 12 строк), дальше прокрутка внутри таблицы; шапка таблицы липкая.') },
          h(Col, null, Cap('свёрнуто', ''), h(Frame, { w: W }, h(Form, null, h(Quiet1))),
            Cap('раскрыто', '«Показать» → «Скрыть»'), h(Frame, { w: W }, h(Form, { ghost: false }, h(Quiet1, { open: true }), h(Flat, { rows: REC, mh: 330 }))))),
        h(Opt, { id: '1b', w: W, label: 'Сводка по ключам — опечатка видна без раскрытия', note: h(F, null, 'Тексты Дизайнера: свёрнутая строка называет ключи строк с числом строк, шапку — числом. Таблица — ', h('b', null, 'по строке на ключ и причину'), ': «Где» — «шапка» или «строки 1–12», «Прочитано» — первые разные значения. Ключ, прочитанный в нескольких строках, раскрывается шевроном — значения по номерам строк (на втором кадре раскрыт «Артикл»).') },
          h(Col, null, Cap('свёрнуто', ''), h(Frame, { w: W }, h(Form, null, h(Quiet2))),
            Cap('раскрыто', 'раскрыт ключ «Артикл»'), h(Frame, { w: W }, h(Form, { ghost: false }, h(Quiet2, { open: true }), h(Grouped, { open: 'Артикл' }))))),
        h(Opt, { id: '1c', w: W, label: 'Окно «Прочитано, в счёт не положено» с отбором по причине', note: h(F, null, 'Строка в форме — как в ', h('a', { className: 'dv-oid', href: '#1a' }, '1a'), ', но «Показать…» открывает Modal. Над таблицей — чипы отбора по причине с числом (Chip, selected); зовущие к действию — первыми, «нет поля» — последним. Второй кадр — отобраны три причины из зовущих к действию: остались записи, по которым есть что делать в счёте.') },
          h(Col, null, Cap('в форме', ''), h(Frame, { w: W }, h(Form, { ghost: true }, h('p', { className: 'quiet' }, h('span', null, 'Ещё прочитано, в счёт не положено: ', h('b', null, REC.length)), h('span', { className: 'tbtn' }, 'Показать…')))),
            Cap('окно', 'все записи'), h(Frame, { w: W }, h(Modal, {})),
            Cap('окно', 'отбор: не разобрано, охрана, занято'), h(Frame, { w: W }, h(Modal, { only: true }))))),
      h('p', { className: 'dv-next' }, 'Можно сказать: «', h('a', { className: 'dv-oid', href: '#1b' }, '1b'), ', но раскрытие ключа — как плоская таблица ', h('a', { className: 'dv-oid', href: '#1a' }, '1a'), '» · «', h('a', { className: 'dv-oid', href: '#1a' }, '1a'), ' с чипами отбора из ', h('a', { className: 'dv-oid', href: '#1c' }, '1c'), ' над таблицей» · «покажи на телефоне»'));
  }

  ReactDOM.createRoot(document.getElementById('root')).render(h(F, null, h(Turn1), h(Common)));
})();
