/* Вариант А — «Скан слева, этапы справа» и вариант Б — «Мастер по этапам». */
(function () {
  'use strict';
  const { INV, btn, ibtn, srv, saveState, popover, frame, scanPanel, linesTable, recon } = window.M;
  const P = window.VC.parts;
  const POP = window.VC.POP_S2;

  // ═══ А ═══
  function stage(o) {
    const cls = o.cur ? 'cur' : o.ok ? 'ok' : '';
    const right = o.right || '';
    const foot = o.next ? `<div style="display:flex;align-items:center;gap:8px;padding:0 16px 14px"><span class="grow"></span>${btn(o.next, 'text', { trail: 'chevR' })}</div>` : '';
    return `<section class="card ${o.open ? 'open' : 'closed'} ${o.todo ? 'todo' : ''}" style="${o.cur ? 'border-color:var(--f-brand);box-shadow:0 0 0 1px var(--f-brand)' : ''}">
      <div class="card-h"><span class="stepn ${cls}">${o.ok && !o.open ? '✓' : o.n}</span><h3>${o.title}</h3>${o.line ? `<span class="sumline">${o.line}</span>` : '<span class="grow"></span>'}${right}${ibtn(o.open ? 'chevU' : 'chevD')}</div>
      ${o.open ? `<div class="card-b">${o.body}</div>${foot}` : ''}</section>`;
  }
  function aSummary(o, s) {
    return P.summary(o, Object.assign({ badges: P.badges(s.kind), meta: s.meta || `${INV.supplier} · от ${INV.date} · ${INV.amount} ₽` }, s));
  }
  function aLayout(o, s) {
    const workW = o.w - 88;
    const scanW = Math.round(Math.min(560, Math.max(440, workW * 0.42)));
    const left = s.strip
      ? `<div class="scan-strip">${ibtn('scanOn', 'Показать файл рядом')}<span class="vt">Файл счёта · рядом</span>${ibtn('open', 'Показать поверх')}</div>`
      : scanPanel({ w: scanW, side: 'left', bad: s.bad, hl: s.hl });
    return frame(o, `<div style="flex:1;min-width:0;display:flex;flex-direction:column">${aSummary(o, s.sum)}
      <div style="flex:1;min-height:0;display:flex">${left}<div class="scroll">${s.banner || ''}<div class="cards">${s.stages}</div></div></div></div>`);
  }
  const moreBtn = ibtn('more', 'Ещё: заменить файл, распознать, отклонить, удалить');
  function a1(o) {
    return aLayout(o, {
      hl: ['sup', 'no', 'date', 'amt', 'vat', 'payer'],
      sum: { ind: { tone: 'warn', text: '4 замечания' }, save: saveState('saved'), right: P.primary('Разобран', true, 'ok') + moreBtn },
      stages: stage({ n: 1, cur: 1, open: 1, title: 'Кто и сколько', right: btn('Всё верно (5)', 'text', { icon: 'check', w: 'expl' }), body: P.ktoFields('rec'), next: 'Дальше: строки' })
        + stage({ n: 2, title: 'Строки', line: '6 прочитано · 3 ждут позиции', right: `<span class="badge warning">3</span>` })
        + stage({ n: 3, title: 'Разноска', todo: 1, line: 'после строк' })
        + stage({ n: 4, title: 'Сроки и оплата', line: 'до 05.10.2026 по правилу · не оплачен' })
        + stage({ n: '…', title: 'Ещё', line: 'основание, назначение' })
    });
  }
  function a2(o, open) {
    return aLayout(o, {
      strip: 1,
      sum: { ind: { tone: 'warn', text: '6 замечаний', open }, pop: open ? popover(Object.assign({ maxH: o.h - 48 - 56 - 24 }, POP)) : '', save: saveState('saved'),
        right: P.primary('Разобран', true, 'ok') + moreBtn },
      stages: stage({ n: 1, ok: 1, title: 'Кто и сколько', line: P.ktoLine, right: `<span class="xs warn-t">✦ 2</span>` })
        + stage({ n: 2, cur: 1, open: 1, title: 'Строки', right: `<span class="xs muted">6 строк</span>`, body: P.linesBody({}), next: 'Дальше: разноска' })
        + stage({ n: 3, title: 'Разноска', line: '<span class="warn-t">не разнесён</span> · весь счёт на объект или по строкам' })
        + stage({ n: 4, title: 'Сроки и оплата', line: `до 05.10.2026 · <span class="warn-t">просрочен 21 дн.</span> ${srv()} · не оплачен` })
    });
  }
  function a3(o) {
    return aLayout(o, {
      bad: 1,
      sum: { meta: 'поставщик не выбран · загружен 26.10.2026 в 12:01', ind: { tone: 'danger', text: 'Не распознан' }, save: saveState('saved'), right: P.primary('Разобран', true, 'ok') + moreBtn },
      banner: P.bannerFail('left'),
      stages: stage({ n: 1, cur: 1, open: 1, title: 'Кто и сколько', right: `<span class="xs muted">по бумаге слева</span>`, body: P.ktoFields('empty'), next: 'Дальше: строки' })
        + stage({ n: 2, title: 'Строки', line: 'строк нет', right: btn('Вставить из буфера', 'outlined', { icon: 'paste' }) })
        + stage({ n: 3, title: 'Разноска', todo: 1, line: 'после строк или суммы' })
        + stage({ n: 4, title: 'Сроки и оплата', todo: 1, line: 'срок не определён' })
    });
  }
  function a4(o) {
    return aLayout(o, {
      hl: [],
      sum: { kind: 'parsed', meta: `${INV.supplier} · от ${INV.date} · 136 960,00 ₽`, ind: { tone: 'warn', text: 'Просрочен' }, srv: srv(),
        right: btn('Изменить', 'outlined', { icon: 'edit', w: 'expl' }) + P.primary('Отметить оплату…', false, 'pay') + ibtn('more') },
      stages: stage({ n: 1, ok: 1, open: 1, title: 'Кто и сколько', body: P.ktoRead().replace('repeat(3', 'repeat(2') })
        + stage({ n: 2, ok: 1, open: 1, title: 'Строки', right: `<span class="xs muted">6 строк</span>`, body: linesTable('read', { alloc: 'done', compact: 1 }) + recon('ok') })
        + stage({ n: 3, ok: 1, title: 'Разноска', line: `${INV.site} · ${INV.section} — 100 %` })
        + stage({ n: 4, title: 'Сроки и оплата', line: `до 05.10.2026 · <span class="warn-t">просрочен 21 дн.</span> ${srv()} · не оплачен` })
    });
  }
  const NOTES_A = {
    s1: ['Бумага слева, этап справа: глаз идёт по строке слева направо. Значения, взятые со скана, подсвечены на бумаге. Этапы — аккордеон: открыт один.',
      'Каждое поле — по уходу с поля. «Дальше: строки» ничего не сохраняет — только открывает следующий этап.',
      '«Всё верно (5)» — сразу. «Разобран» выключен с причиной.'],
    s2: ['На этапе «Строки» таблице нужно ~1100 px: файл сворачивается в полосу слева (вернуть рядом или поверх). Строку сверяют, переключаясь.',
      'Строки — после паузы/ухода из строки, шапка раньше строк. Удаление без разноски — с «Вернуть».',
      'Режим НДС — шаг с пересчётом. Минус варианта: строки и бумага не видны вместе на 1366.'],
    s2o: ['Поповер тот же, что во всех вариантах: пункт ведёт к этапу и раскрывает его.',
      'Перечень — по сохранённому.',
      'Нужен сервер: «мешает: оплата», «просрочен» в ответе счёта.'],
    s3: ['Набирает по бумаге слева.', 'Набранное пишется само.', 'Один баннер над этапами; подробности — в индикаторе.'],
    s4: ['Читает: этапы раскрыты как документ, бумага слева остаётся.', 'Ничего не пишется.', '«Изменить» — явный режим; «Отметить оплату…» — окно с раскладом.']
  };

  // ═══ Б ═══
  const STEPS = ['Основное', 'Строки', 'Разноска', 'Сроки и оплата', 'Проверка'];
  function stepper(cur, counts, done) {
    return `<nav class="stepper" aria-label="Шаги счёта">${STEPS.map((t, i) => {
      const n = i + 1; const isOk = done.indexOf(n) >= 0;
      const c = counts[n] ? `<span class="cnt">${counts[n]}</span>` : '';
      return (i ? '<span class="step-line"></span>' : '') + `<span class="step ${n === cur ? 'cur' : ''} ${isOk ? 'ok' : ''}"><span class="sn">${isOk && n !== cur ? '✓' : n}</span>${t}${c}</span>`;
    }).join('')}</nav>`;
  }
  function bLayout(o, s) {
    const workW = o.w - 88;
    const sheetW = s.scan ? Math.round(Math.min(500, Math.max(420, workW * 0.38))) : 0;
    const foot = s.foot ? `<div class="wfoot">${s.foot}</div>` : '';
    const sum = P.summary(o, Object.assign({ badges: P.badges(s.kind), meta: s.meta || `${INV.supplier} · от ${INV.date} · ${INV.amount} ₽` }, s.sum));
    return frame(o, `<div style="flex:1;min-width:0;display:flex;flex-direction:column">${sum}${s.stepper || ''}
      <div style="flex:1;min-height:0;display:flex"><div style="flex:1;min-width:0;display:flex;flex-direction:column"><div class="scroll">${s.banner || ''}<div class="cards" style="padding-top:16px">${s.body}</div></div>${foot}</div>
      ${s.scan ? scanPanel({ w: sheetW, side: 'right', bad: s.bad, hl: s.hl, close: 1 }) : ''}</div></div>`);
  }
  function bFoot(back, next, nextDis) {
    return `${back ? btn(back, 'text', { icon: 'chevL' }) : '<span></span>'}<span class="grow"></span>${saveState('saved')}<span class="grow"></span>${btn(next, 'filled', { md: 1, trail: 'chevR', dis: nextDis })}`;
  }
  const bMore = ibtn('more', 'Ещё');
  function stepCard(title, body, right) {
    return `<section class="card open"><div class="card-h"><h3>${title}</h3><span class="grow"></span>${right || ''}</div><div class="card-b">${body}</div></section>`;
  }
  function b1(o) {
    return bLayout(o, {
      scan: 1, hl: ['sup', 'no', 'date', 'amt', 'vat', 'payer'],
      sum: { ind: { tone: 'warn', text: '4 замечания' }, right: P.fileToggle(true) + bMore },
      stepper: stepper(1, { 1: 2, 2: 3 }, []),
      body: stepCard('Шаг 1 из 5 · Основное: кто и сколько', P.ktoFields('rec'), btn('Всё верно (5)', 'text', { icon: 'check', w: 'expl' }))
        + `<div class="xs muted" style="padding:0 4px">Опытный ввод: щелчок по шагу в полосе ведёт сразу к нему; «Далее» открывает первый неготовый шаг.</div>`,
      foot: bFoot('', 'Далее: строки')
    });
  }
  function b2(o, open) {
    return bLayout(o, {
      sum: { ind: { tone: 'warn', text: '6 замечаний', open }, pop: open ? popover(Object.assign({ maxH: o.h - 48 - 56 - 24 }, POP)) : '', right: P.fileToggle(false) + bMore },
      stepper: stepper(2, { 2: 2, 3: 1, 5: 6 }, [1]),
      body: stepCard('Шаг 2 из 5 · Строки', P.linesBody({}), `<span class="xs muted">к оплате по счёту — <b class="num">128 400,50</b> (из шага 1)</span>`),
      foot: bFoot('Основное', 'Далее: разноска')
    });
  }
  function b3(o) {
    return bLayout(o, {
      scan: 1, bad: 1, meta: 'поставщик не выбран · загружен 26.10.2026 в 12:01',
      sum: { ind: { tone: 'danger', text: 'Не распознан' }, right: P.fileToggle(true) + bMore },
      stepper: stepper(1, {}, []),
      banner: P.bannerFail('right'),
      body: stepCard('Шаг 1 из 5 · Основное: кто и сколько', P.ktoFields('empty')),
      foot: bFoot('', 'Далее: строки')
    });
  }
  function b4(o) {
    const body = `<section class="card open"><div class="card-b" style="padding-top:16px">
        <div style="display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:28px">
          <div><h3 style="font-size:14px;font-weight:600;margin-bottom:6px">Кто и сколько</h3>${P.ktoRead().replace('repeat(3', 'repeat(2')}</div>
          <div><h3 style="font-size:14px;font-weight:600;margin-bottom:6px">Сроки, разноска, оплата</h3><dl class="read" style="grid-template-columns:1fr">
            <div><dt>Оплатить до</dt><dd>05.10.2026 · <span class="warn-t">просрочен 21 дн.</span> ${srv()}</dd></div>
            <div><dt>Разноска</dt><dd>${INV.site} · ${INV.section} — 100 %</dd></div><div><dt>Оплата</dt><dd>не оплачен</dd></div></dl></div></div></div></section>
      <section class="card open"><div class="card-h"><h3>Строки</h3><span class="grow"></span><span class="xs muted">6 строк · цены с НДС</span></div><div class="card-b">${linesTable('read', { alloc: 'done' })}${recon('ok')}</div></section>`;
    return bLayout(o, {
      kind: 'parsed', meta: `${INV.supplier} · от ${INV.date} · 136 960,00 ₽`,
      sum: { ind: { tone: 'warn', text: 'Просрочен' }, srv: srv(), right: btn('Изменить по шагам', 'outlined', { icon: 'edit', w: 'expl' }) + P.primary('Отметить оплату…', false, 'pay') + bMore },
      body
    });
  }
  const NOTES_B = {
    s1: ['Один шаг на экране; полоса шагов — и навигация, и сводка (число замечаний у шага). Файл — лист справа, открывается кнопкой «Файл».',
      'Поля — по уходу с поля. «Далее» ничего не сохраняет: запись уже прошла, кнопка только ведёт.',
      'Единственная filled — «Далее»; на шаге «Проверка» она становится «Разобран».'],
    s2: ['Шаг «Строки» во всю ширину. Сумма к оплате видна в заголовке шага — иначе сверка требовала бы вернуться на шаг 1.',
      'Строки — после паузы/ухода из строки. Удаление без разноски — с «Вернуть».',
      'Риск: возврат к правке «Основного» — прыжок по шагам; у разобранного мастер не нужен.'],
    s2o: ['Поповер индикатора дублирует шаг «Проверка» — в мастере он нужен меньше всех: число у шага уже говорит.', 'Перечень — по сохранённому.', 'Нужен сервер: «мешает: оплата», «просрочен».'],
    s3: ['Набирает по бумаге справа.', 'Набранное пишется само.', 'Один баннер над шагом.'],
    s4: ['Разобранный в мастере не читается — второй вид, «карточка чтения» без шагов.', 'Ничего не пишется.', '«Изменить по шагам» — явный режим; «Отметить оплату…» — окно.']
  };

  window.VA = { s1: a1, s2: o => a2(o, false), s2o: o => a2(o, true), s3: a3, s4: a4, NOTES: NOTES_A };
  window.VB = { s1: b1, s2: o => b2(o, false), s2o: o => b2(o, true), s3: b3, s4: b4, NOTES: NOTES_B };
})();
