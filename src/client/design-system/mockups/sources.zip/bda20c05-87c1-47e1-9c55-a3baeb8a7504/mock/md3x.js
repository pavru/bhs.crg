/* Вариант Г: то, что в MD3 устроено иначе, чем в BHS.CRG UI, — side sheet состояния вместо поповера. */
(function () {
  'use strict';
  const { ic, btn, srv } = window.M;
  function sideSheet(o, p) {
    const lead = { danger: ['err', 'err'], warn: ['warn', 'warn'], quiet: ['info', ''] };
    const groups = p.groups.map(g => {
      const items = g.items.map(it => {
        const l = lead[g.tone] || lead.quiet;
        const tags = (it.tags || []).map(t => t === 'SRV' ? srv() : `<span class="m-status">${t}</span>`).join('');
        const acts = (it.acts || []).map(a => btn(a, 'text')).join('');
        return `<div class="m-li"><span class="lead ${l[1]}">${ic(l[0])}</span><div class="body">${it.text}${tags ? `<div class="tags">${tags}</div>` : ''}</div>${acts ? `<div class="acts">${acts}</div>` : ''}</div>`;
      }).join('');
      return `<div class="m-sub">${g.title}</div>${items}`;
    }).join('');
    return `<aside class="m-sheet" role="dialog" aria-label="Состояние счёта"><div class="m-sheet-h"><h4>Состояние счёта</h4><span class="grow"></span><span class="iconbtn">${ic('x')}</span></div>
      <div class="m-sheet-sub">${p.head} · ${p.sub}</div><div class="m-sheet-b">${groups}</div><div class="m-sheet-f">${p.foot}</div></aside>`;
  }
  window.MD3X = { sideSheet };
})();
