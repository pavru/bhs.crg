/* Вариант В — «Одна страница, прогрессивное раскрытие, липкая сводка».
   Вариант Г (чистый MD3) строится этими же функциями с M.setMd3(true): раскладка та же, язык формы другой. */
(function () {
  'use strict';
  const { INV, ic, btn, ibtn, badge, srv, ind, saveState, popover, frame, listCol, scanPanel, linesTable, recon } = window.M;
  const md = () => window.M.isMd3();

  const LIST_MIN_FORM = 940; // список стоит слева, пока форме остаётся не меньше 940 px (по месту, а не по окну)

  function summary(o, s) {
    const nav = `<div class="sum-nav">${ibtn('chevL', 'Предыдущий счёт')}<span class="sum-pos"><b>3 из 57</b>Разобрать</span>${ibtn('chevR', 'Следующий счёт')}</div>`;
    const title = `<div class="sum-title"><div class="t1"><h2>${s.no || INV.no}</h2>${s.badges}</div><div class="t2">${s.meta}</div></div>`;
    const indicator = `<span class="ind-wrap">${ind(s.ind)}${s.pop || ''}</span>`;
    return `<div class="sum">${nav}<span class="vdiv"></span>${title}${indicator}${s.srv || ''}${s.save || ''}<span class="grow"></span>${s.right}</div>`;
  }
  /** «Файл» в сводке: значок называет, что сделает нажатие ([COST-6.3], issue #1874; код — InvoiceFileButton.tsx).
      place: 'closed' (true/false — по-старому: true = 'beside', false = 'closed') | 'beside' | 'over'. */
  const FILE_LOOK = {
    closed: { icon: 'fileClosed', title: 'Показать файл рядом с формой' },
    beside: { icon: 'fileBeside', title: 'Скрыть файл' },
    over: { icon: 'fileOver', title: 'Файл откроется поверх формы: рядом форме нужно не меньше 720 px' }
  };
  function fileToggle(place) {
    const p = place === true ? 'beside' : place === false || place == null ? 'closed' : place;
    const look = FILE_LOOK[p] || FILE_LOOK.closed;
    return btn('Файл', p === 'beside' ? 'tonal' : 'outlined', { icon: look.icon }).replace('<span class="btn', `<span title="${look.title}" class="btn`);
  }
  function badges(kind) {
    if (md()) {
      if (kind === 'parsed') return `<span class="m-status ok">${window.M.ic('ok', 'ic-sm')}Разобран</span><span class="m-status">Не оплачен</span>`;
      return `<span class="m-status">${window.M.ic('edit', 'ic-sm')}Черновик</span>`;
    }
    return kind === 'parsed' ? badge('Разобран', 'success') + badge('Не оплачен') : badge('Черновик') + badge('Не оплачен');
  }
  function card(o) {
    const n = o.n != null ? `<span class="stepn ${o.stepCls || ''}">${o.n}</span>` : '';
    const chev = ibtn(o.open ? 'chevU' : 'chevD', o.open ? 'Свернуть' : 'Развернуть');
    return `<section class="card ${o.open ? 'open' : 'closed'} ${o.todo ? 'todo' : ''}" ${o.id ? `id="${o.id}"` : ''}>
      <div class="card-h">${n}<h3>${o.title}</h3>${o.line ? `<span class="sumline">${o.line}</span>` : '<span class="grow"></span>'}${o.right || ''}${o.noChev ? '' : chev}</div>
      ${o.open ? `<div class="card-b">${o.body}</div>` : ''}</section>`;
  }

  // ── содержимое карточек ──
  function ktoFields(mode) {
    const rec = mode === 'rec';
    const emp = mode === 'empty';
    const f = window.M.field;
    const amountHint = 'нужна для оплаты и сверки · обязательность — вопрос владельцу';
    return `<div class="grid12">
      <div class="s6">${f('Поставщик', { req: 1, sel: 1, val: emp ? '' : INV.supplier, ph: 'Выберите по ИНН или названию', unconf: rec, w: 'auto',
        offer: emp ? 'Нет в справочнике? — <span class="lnk">Завести организацию…</span>' : 'ИНН 7701234567 — совпал со справочником' })}</div>
      <div class="s6">${f('Плательщик', { req: 1, sel: 1, val: rec || emp ? '' : INV.payer, ph: 'Выберите организацию', focus: rec, w: 'auto',
        offer: rec ? `<span style="white-space:nowrap">В файле:</span> <span class="ell">ООО «СтройЭлектроМонтаж», ИНН 7727654321</span> <span class="lnk">Взять</span>` : '' })}</div>
      <div class="s3">${f('Номер', { req: 1, val: emp ? '' : INV.no, ph: 'по бумаге', unconf: rec, w: 'auto' })}</div>
      <div class="s3">${f('Дата', { req: 1, date: 1, val: emp ? '' : INV.date, ph: 'ДД.ММ.ГГГГ', unconf: rec, w: 'auto' })}</div>
      <div class="s3">${f('Сумма к оплате', { val: emp ? '' : INV.amount, num: 1, ph: '0,00', unconf: rec, w: 'auto', offer: rec ? `<span class="ell">${amountHint}</span>` : '' })}</div>
      <div class="s3">${f('В том числе НДС', { val: emp ? '' : INV.vat, num: 1, ph: '0,00', unconf: rec, w: 'auto' })}</div>
    </div>`;
  }
  function ktoRead() {
    return `<dl class="read"><div><dt>Поставщик</dt><dd>${INV.supplier}</dd></div><div><dt>Плательщик</dt><dd>${INV.payer}</dd></div><div><dt>Номер и дата</dt><dd>${INV.no} от ${INV.date}</dd></div>
      <div><dt>Сумма к оплате</dt><dd class="num">136 960,00 ₽</dd></div><div><dt>В том числе НДС</dt><dd class="num">22 826,67 ₽ · цены с НДС</dd></div><div><dt>Основание</dt><dd>${INV.basis}</dd></div></dl>`;
  }
  const ktoLine = `${INV.supplier} → ${INV.payer} · № ${INV.no} от ${INV.date} · к оплате <b class="num">${INV.amount}</b> (НДС ${INV.vat})`;

  function linesBody(o) {
    const tools = `<div class="lines-tools" style="margin-bottom:8px"><span class="seg" data-w="expl"><span class="on">Цены с НДС</span><span>Без НДС, НДС сверху</span></span>
      <span class="xs muted">смена — пересчёт с предпросмотром</span><span class="grow"></span>${btn('Вставить из буфера', 'outlined', { icon: 'paste' })}</div>`;
    return `${tools}<div data-w="auto">${linesTable('edit', { compact: o.narrow })}</div>
      <div style="display:flex;align-items:center;gap:8px;margin-top:6px">${btn('Добавить строку', 'text', { icon: 'plus' })}<span class="grow"></span><span class="xs muted">строка без разноски удаляется сразу, с отменой; с разноской — спросим</span></div>${recon('bad')}`;
  }
  function allocBody(read) {
    if (read) return `<div class="note">Весь счёт → <b>${INV.site}</b> · ${INV.section} — <span class="num">136 960,00</span> (100 %)</div>`;
    return `<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><span class="note">Весь счёт на объект</span>
      <div style="width:300px" data-w="auto"><div class="fld" style="height:40px"><span class="ph">— выберите объект стройки —</span><span class="tr">${ic('chevD')}</span></div></div>
      <span class="xs warn-t">не разнесён</span><span class="grow"></span>${btn('На несколько объектов…', 'text', { icon: 'grid', w: 'expl' })}</div>
      <div class="xs muted" style="margin-top:8px">Объект той же стройки пишется сразу; несколько объектов или другая стройка — матрица с предпросмотром. Строку по отдельности — колонка «Разноска».</div>`;
  }

  // ── состояния ──
  /** Общая сборка: [список?] [сводка / (форма | файл?)] */
  function layout(o, s) {
    const workW = o.w - (md() ? 80 : 88);
    const scanW = s.scan ? Math.round(Math.min(520, Math.max(420, workW * 0.38))) : 0;
    const formW = workW - scanW;
    const showList = !s.scan && s.listOk !== false && formW - 320 >= LIST_MIN_FORM;
    const detail = `<div style="flex:1;min-width:0;display:flex;flex-direction:column;position:relative">${summary(o, s.sum)}
      <div style="flex:1;min-height:0;display:flex"><div class="scroll">${s.banner || ''}<div class="cards">${s.cards}</div></div>
      ${s.scan ? scanPanel({ w: scanW, side: 'right', bad: s.scanBad, hl: s.hl, close: 1 }) : ''}</div>${s.snack || ''}${s.sheet || ''}</div>`;
    return frame(o, (showList ? listCol({ parsed: s.parsed }) : '') + detail);
  }
  function primary(label, dis, icon) { return btn(label, 'filled', { md: 1, dis, icon, w: 'expl' }); }
  function bannerFail(side) {
    const where = side === 'left' ? 'слева' : side === 'none' ? '— откройте файл кнопкой «Файл»' : 'справа';
    if (md()) {
      return `<div class="m-banner"><span class="m-banner-ic">${ic('err')}</span><div class="txt"><b>Файл не распознан.</b> В документе не прочитано ничего — возможно, это не счёт или скан нечитаем. Заполните по бумаге ${where}.</div>
        <div class="m-banner-a">${btn('Не тот файл — удалить…', 'text')}${btn('Распознать ещё раз', 'text')}</div></div>`;
    }
    return `<div style="padding:12px 20px 0"><div class="banner" role="alert">${ic('err')}<div class="txt"><b>Файл не распознан.</b> В документе не прочитано ничего — возможно, это не счёт или скан нечитаем. Заполните по бумаге ${where}.</div>
      ${btn('Распознать ещё раз', 'text', { icon: 'sync' })}${btn('Не тот файл — удалить…', 'text')}</div></div>`;
  }

  const POP_S2 = {
    head: '6 замечаний', sub: 'по сохранённому · 12:04',
    groups: [
      { title: 'Мешает «Разобран» и оплате', tone: 'danger', items: [
        { text: 'Сумма строк <b class="num">136 960,00</b> не сходится с суммой к оплате <b class="num">128 400,50</b>: расхождение 8 559,50 при допуске 1,00. На бумаге «к оплате» — 136 960,00.', tags: ['мешает: Разобран', 'мешает: оплата', 'SRV'], acts: ['К сверке'] }] },
      { title: 'До «Разобран» осталось', tone: 'warn', items: [
        { text: '2 строки без позиции номенклатуры — строки 4 и 5', acts: ['К строкам'] },
        { text: 'Строки не разнесены: 6 из 6', acts: ['К разноске'] }] },
      { title: 'Проверьте', tone: 'warn', items: [
        { text: 'Похоже на дубликат: у «Кабель-Торг» уже есть СЧ-104 от 03.09.2026 на 128 400,50 ₽', acts: ['Открыть', 'Это дубль…'] },
        { text: '2 значения со скана не проверены: «Номер», «Сумма к оплате»', acts: ['Всё верно'] },
        { text: 'Срок оплаты 05.10.2026 прошёл — просрочен на 21 дн.', tags: ['SRV'] }] },
      { title: 'К сведению · не считается', tone: 'quiet', items: [
        { text: 'Распознано 26.10 в 12:02. 3 строки — из запомненного у «Кабель-Торг». Режим НДС «в том числе» — со скана.' }] }
    ],
    foot: `${ic('info', 'ic-sm')}<span>Каждое расхождение — одним пунктом. Пункт ведёт к месту. Пометка «мешает: оплата» у пункта готовности — <b>нужен сервер</b>.</span>`
  };

  function s1(o) {
    return layout(o, {
      scan: true, hl: ['sup', 'no', 'date', 'amt', 'vat'],
      sum: { badges: badges(), meta: `${INV.supplier} · от ${INV.date} · ${INV.amount} ₽`, ind: { tone: 'warn', text: '4 замечания' }, save: saveState('saved'),
        right: `${fileToggle(true)}${primary('Разобран', true, 'ok')}${ibtn('more', 'Ещё: заменить файл, распознать, отклонить, удалить')}` },
      cards: card({ n: 1, stepCls: 'cur', title: 'Кто и сколько', open: 1, right: `<span class="xs warn-t" style="white-space:nowrap">5 со скана не проверены</span>${btn('Всё верно (5)', 'text', { icon: 'check', w: 'expl' })}`, body: ktoFields('rec') })
        + card({ n: 2, title: 'Строки', line: '6 прочитано из файла · 3 подставлены из запомненного · 3 ждут позиции', right: '' })
        + card({ n: 3, title: 'Разноска', todo: 1, line: 'после строк' })
        + card({ n: 4, title: 'Сроки и оплата', line: 'оплатить до 05.10.2026 — по правилу: отгрузка 05.09 + 30 дн. · не оплачен' })
        + card({ title: 'Ещё', line: 'основание, назначение, дополнительные поля' })
    });
  }
  function s2(o, open) {
    const workW = o.w - (md() ? 80 : 88);
    const showList = workW - 320 >= LIST_MIN_FORM;
    const maxH = o.h - 48 - 56 - 24;
    return layout(o, {
      sum: { badges: badges(), meta: `${INV.supplier} · от ${INV.date} · ${INV.amount} ₽`, ind: { tone: 'warn', text: '6 замечаний', open },
        pop: open ? (md() ? '' : popover(Object.assign({ maxH, left: 0 }, POP_S2))) : '', save: saveState('saved'),
        right: `${fileToggle(false)}${primary('Разобран', true, 'ok')}${ibtn('more', 'Ещё')}` },
      sheet: open && md() ? window.MD3X.sideSheet(o, POP_S2) : '',
      cards: card({ n: 1, stepCls: 'ok', title: 'Кто и сколько', line: ktoLine, right: `<span class="xs warn-t">✦ 2</span>` })
        + card({ n: 2, stepCls: 'cur', title: 'Строки', open: 1, right: `<span class="xs muted">6 строк</span>`, body: linesBody({ narrow: showList }) })
        + card({ n: 3, title: 'Разноска', open: 1, body: allocBody() })
        + card({ n: 4, title: 'Сроки и оплата', line: `оплатить до 05.10.2026 · <span class="warn-t">просрочен 21 дн.</span> ${srv()} · не оплачен`, right: btn('Отметить оплату…', 'tonal', { icon: 'pay', dis: 1 }) })
        + card({ title: 'Ещё', line: `${INV.basis} · ${INV.purpose}` })
        + card({ title: 'История', line: 'Распознано 26.10 в 12:02 · Строки изменены 12:04 · ещё 3 записи' }),
      snack: open ? '' : `<div class="snack">Строка 7 удалена<span class="act">Вернуть</span>${window.M.ic('x', 'ic-sm')}</div>`
    });
  }
  function s3(o) {
    return layout(o, {
      scan: true, scanBad: true,
      sum: { badges: badges(), meta: `поставщик не выбран · загружен 26.10.2026 в 12:01`, ind: { tone: 'danger', text: 'Не распознан' }, save: saveState('saved'),
        right: `${fileToggle(true)}${primary('Разобран', true, 'ok')}${ibtn('more', 'Ещё')}` },
      banner: bannerFail(),
      cards: card({ n: 1, stepCls: 'cur', title: 'Кто и сколько', open: 1, right: `<span class="xs muted">впишите по бумаге — сохраняется само</span>`, body: ktoFields('empty') })
        + card({ n: 2, title: 'Строки', line: 'строк нет — вставьте из буфера или добавьте; черновик живёт и без них', right: btn('Вставить из буфера', 'outlined', { icon: 'paste' }) })
        + card({ n: 3, title: 'Разноска', todo: 1, line: 'после строк или суммы' })
        + card({ n: 4, title: 'Сроки и оплата', todo: 1, line: 'срок не определён: нужны дата отгрузки и отсрочка' })
        + card({ title: 'Ещё', line: 'основание, назначение, дополнительные поля' })
    });
  }
  function s4(o) {
    return layout(o, {
      parsed: 1,
      sum: { badges: badges('parsed'), meta: `${INV.supplier} · от ${INV.date} · 136 960,00 ₽`, ind: { tone: 'warn', text: 'Просрочен' }, srv: srv(),
        right: `${btn('Изменить', 'outlined', { icon: 'edit', w: 'expl' })}${primary('Отметить оплату…', false, 'pay')}${ibtn('more', 'Ещё: вернуть в черновик, отклонить')}` },
      cards: card({ n: 1, stepCls: 'ok', title: 'Кто и сколько', open: 1, noChev: 1, body: ktoRead() })
        + card({ n: 2, stepCls: 'ok', title: 'Строки', open: 1, noChev: 1, right: `<span class="xs muted">6 строк · цены с НДС</span>`, body: linesTable('read', { alloc: 'done' }) + recon('ok') })
        + card({ n: 3, stepCls: 'ok', title: 'Разноска', open: 1, noChev: 1, body: allocBody(true) })
        + card({ n: 4, title: 'Сроки и оплата', open: 1, noChev: 1, body: `<dl class="read"><div><dt>Отгрузка · отсрочка</dt><dd>05.09.2026 · 30 дн.</dd></div><div><dt>Оплатить до</dt><dd>05.10.2026 · по правилу · <span class="warn-t">просрочен 21 дн.</span> ${srv()}</dd></div><div><dt>Оплата</dt><dd>не оплачен</dd></div></dl>` })
        + card({ title: 'История', line: 'Разобран 26.10.2026 в 12:31 — Потоцкий А. · ещё 6 записей' })
    });
  }

  const NOTES = {
    s1: ['Сверяет поля с бумагой справа: ✦ в поле — «со скана, не проверено»; правка снимает метку. Плательщик — «Взять» из файла или выбор.',
      'Каждое поле — по уходу с поля (шапка раньше строк, одна очередь записи). Состояние записи — в сводке: «Сохранено · 12:04».',
      '«Всё верно (5)» — снимает метки сразу. «Разобран» выключен и объясняет почему (готовность — по сохранённому).'],
    s2: ['Правит строки в таблице во всю ширину; позиция — выбор в клетке. Список счетов слева остаётся, пока форме хватает ≥ 940 px; на 1280 он сворачивается в «‹ 3 из 57 ›».',
      'Строки — после паузы/ухода из строки; объект той же стройки — сразу. Удаление строки без разноски — сразу, снэкбар «Вернуть» вместо вопроса.',
      'Режим НДС — отдельный шаг с пересчётом. «Отметить оплату…» выключена с причиной из индикатора. Матрица — с предпросмотром.'],
    s2o: ['Щелчок по индикатору: все замечания одним списком, по уровням. Каждый пункт — одна строка и одно действие, ведущее к месту.',
      'Перечень — о сохранённом («по сохранённому · 12:04»). При автосохранении разрыв почти исчезает; пока запись не дошла — пометка «Сохраняю…».',
      '«Это дубль…» — окно удаления (необратимо). «Всё верно» — сразу. Нужен сервер: «мешает: оплата» у пункта готовности и «просрочен» в ответе счёта.'],
    s3: ['Заполняет по бумаге справа; поля пустые и обязательные помечены *. Можно вставить строки из буфера.',
      'Набранное пишется само — распознавание потом не затирает его (пишет только в пустые поля).',
      'Один баннер вместо красной плашки на 270 px: «Распознать ещё раз», «Не тот файл — удалить…» (окно, необратимо). Подробности — в индикаторе.'],
    s4: ['Только читает. Править — «Изменить»: явный режим, без автосохранения (правка разобранного роняет его в черновик).',
      'Ничего не пишется само.',
      '«Отметить оплату…» — окно с датой и раскладом (stamp предпросмотра). Готовность у разобранного не приходит (null) — нужен сервер, если её показывать.']
  };

  window.VC = { s1, s2: o => s2(o, false), s2o: o => s2(o, true), s3, s4, NOTES, POP_S2,
    parts: { summary, card, badges, fileToggle, ktoFields, ktoRead, ktoLine, linesBody, allocBody, bannerFail, primary } };
})();
