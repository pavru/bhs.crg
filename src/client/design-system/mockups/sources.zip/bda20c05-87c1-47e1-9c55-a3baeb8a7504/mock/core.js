/* Экран счёта · общие данные, оболочка и контролы макетов.
   Ничего не сохраняет: это картинка с прокруткой, а не прототип. */
(function () {
  'use strict';

  // ── данные ──
  const INV = {
    no: 'СЧ-104', date: '03.09.2026', supplier: 'ООО «Кабель-Торг»', inn: '7701234567',
    payer: 'ООО «СтройЭлектроМонтаж»', amount: '128 400,50', vat: '21 400,08',
    basis: 'Договор поставки № 17/26 от 12.01.2026', purpose: 'Кабель и щиты для АПС, ЖК «Северный», корп. 3',
    shipped: '05.09.2026', delay: '30', due: '05.10.2026', site: 'ЖК «Северный», корпус 3', section: 'Секция 2 · АПС'
  };
  const LINES = [
    { n: 1, pos: 'Кабель ВВГнг(А)-LS 3×2,5', mem: 1, name: 'Кабель ВВГнг(А)-LS 3х2,5', art: 'ВВГ325', qty: '500', u: 'м', price: '98,40', sum: '49 200,00' },
    { n: 2, pos: 'Кабель ВВГнг(А)-LS 5×6', mem: 1, name: 'Кабель ВВГнг(А)-LS 5х6', art: 'ВВГ56', qty: '120', u: 'м', price: '312,00', sum: '37 440,00' },
    { n: 3, pos: 'Выключатель автоматический ВА47-29 1P C16', name: 'Автомат. выключатель ВА47-29 1P С16', art: 'MVA20-1', qty: '24', u: 'шт', price: '386,00', sum: '9 264,00' },
    { n: 4, pos: '', pos2: 'Короб кабельный 40×25', name: 'Короб кабельный 40х25 белый', art: 'КК4025', qty: '200', u: 'м', price: '96,80', sum: '19 360,00' },
    { n: 5, pos: '', pos2: 'Труба гофрированная ПВХ d20 с зондом', name: 'Гофротруба ПВХ d20 с зондом', art: 'GT20', qty: '300', u: 'м', price: '18,32', sum: '5 496,00' },
    { n: 6, pos: 'Щит распределительный ЩРН-24 IP31', mem: 1, name: 'Щит ЩРН-24 IP31 навесной', art: 'SHRN24', qty: '4', u: 'шт', price: '4 050,00', sum: '16 200,00' }
  ];
  const LIST = [
    { no: 'СЧ-104', d: '03.09.2026', amt: '128 400,50', who: 'ООО «Кабель-Торг»', tags: [['warning', '✦ 2'], ['warning', '≡ 2'], ['danger', 'просрочен']], rest: 'осталось: позиции · разноска', sel: 1 },
    { no: 'СЧ-104', d: '03.09.2026', amt: '128 400,50', who: 'ООО «Кабель-Торг»', tags: [['danger', 'просрочен']], rest: 'осталось: строки · разноска' },
    { no: '2611', d: '22.10.2026', amt: '54 300,00', who: 'ООО «ЭлектроКомплект»', tags: [['brand', 'распознаётся…']], rest: '' },
    { no: 'А-0918', d: '21.10.2026', amt: '12 760,80', who: 'ИП Савельев А. В.', tags: [], rest: 'осталось: плательщик' },
    { no: '4417', d: '20.10.2026', amt: '318 905,00', who: 'ООО «ИЭК Холдинг»', tags: [['neutral', '7 дн.']], rest: 'осталось: разноска' },
    { no: 'УТ-552', d: '19.10.2026', amt: '7 420,00', who: 'ООО «Метизы-Центр»', tags: [], rest: 'осталось: позиции' },
    { no: '1093', d: '17.10.2026', amt: '96 000,00', who: 'ООО «ЭТМ»', tags: [['danger', 'не распознан']], rest: '' },
    { no: '88-К', d: '16.10.2026', amt: '41 118,40', who: 'ООО «Светотехника»', tags: [['neutral', '12 дн.']], rest: 'осталось: разноска' },
    { no: '3305', d: '15.10.2026', amt: '2 980,00', who: 'ООО «Крепёж-Опт»', tags: [], rest: 'осталось: строки' },
    { no: 'ЭК-71', d: '14.10.2026', amt: '204 600,00', who: 'АО «Электрощит»', tags: [], rest: 'осталось: разноска' }
  ];

  // ── значки: lucide (А–В) и Material Symbols (Г) ──
  const ICONS = {
    chevL: ['chevron-left', 'chevron_left'], chevR: ['chevron-right', 'chevron_right'], chevD: ['chevron-down', 'expand_more'],
    chevU: ['chevron-up', 'expand_less'], more: ['ellipsis-vertical', 'more_vert'], file: ['file-text', 'description'],
    sparkle: ['sparkles', 'auto_awesome'], cal: ['calendar', 'calendar_month'], search: ['search', 'search'],
    bell: ['bell', 'notifications'], help: ['circle-help', 'help'], check: ['check', 'check'], ok: ['circle-check', 'check_circle'],
    warn: ['triangle-alert', 'warning'], err: ['circle-alert', 'error'], info: ['info', 'info'], cloud: ['circle-check', 'cloud_done'],
    sync: ['refresh-cw', 'refresh'], trash: ['trash-2', 'delete'], plus: ['plus', 'add'], paste: ['clipboard-paste', 'content_paste'],
    dup: ['copy', 'file_copy'], grid: ['grid-3x3', 'grid_on'], pay: ['banknote', 'payments'], undo: ['undo-2', 'undo'],
    edit: ['pencil', 'edit'], open: ['external-link', 'open_in_new'], apps: ['layout-grid', 'apps'], sites: ['building-2', 'apartment'],
    data: ['database', 'database'], costs: ['calculator', 'calculate'], sys: ['wrench', 'build'], logo: ['file-check', 'task'],
    hist: ['history', 'history'], x: ['x', 'close'], lock: ['lock', 'lock'], panel: ['panel-left', 'menu_open'],
    scanOn: ['panel-right-open', 'vertical_split'],
    fileClosed: ['panel-right-open', 'right_panel_open'], fileBeside: ['panel-right-close', 'right_panel_close'], fileOver: ['maximize-2', 'open_in_full'],
    rotate: ['rotate-cw', 'rotate_right'], zoom: ['zoom-in', 'zoom_in'],
    queue: ['list-checks', 'checklist'], filter: ['building', 'filter_alt'], upload: ['upload', 'upload_file'], down: ['arrow-down', 'arrow_downward'],
    right: ['arrow-right', 'arrow_forward'], left: ['arrow-left', 'arrow_back'], flag: ['flag', 'flag'], eye: ['eye', 'visibility']
  };
  let MD3 = false;
  function ic(k, cls) {
    const pair = ICONS[k] || [k, k];
    if (MD3) return `<span class="msym${cls ? ' ' + cls : ''}">${pair[1]}</span>`;
    return `<span class="ic${cls ? ' ' + cls : ''}"><i data-lucide="${pair[0]}"></i></span>`;
  }

  // ── контролы ──
  function btn(label, v, o) {
    o = o || {};
    const cls = ['btn', v || 'outlined'];
    if (o.md) cls.push('md');
    if (o.dis) cls.push('dis');
    const w = o.w ? ` data-w="${o.w}"` : '';
    return `<span class="${cls.join(' ')}"${w}>${o.icon ? ic(o.icon, 'ic-sm') : ''}${label}${o.trail ? ic(o.trail, 'ic-sm') : ''}</span>`;
  }
  function ibtn(k, title) { return `<span class="iconbtn" aria-label="${title || ''}">${ic(k)}</span>`; }
  function badge(t, tone) { return `<span class="badge ${tone || 'neutral'}">${t}</span>`; }
  function srv(t) { return `<span class="srv">${t || 'нужен сервер'}</span>`; }
  function chip(t, o) {
    o = o || {};
    return `<span class="chip${o.sel ? ' sel' : ''}">${o.icon ? ic(o.icon, 'ic-sm') : ''}${t}${o.n != null ? ` <span class="n">${o.n}</span>` : ''}${o.menu ? ic('chevD', 'ic-sm') : ''}</span>`;
  }
  /** Поле OutlinedField. o: {req, val, ph, unconf, sel, date, focus, offer, ro, w, cls} */
  function field(label, o) {
    o = o || {};
    const cls = ['fld'];
    if (o.unconf) cls.push('unconf');
    if (o.focus) cls.push('focus');
    if (o.ro) cls.push('ro');
    const inner = o.val != null && o.val !== ''
      ? `<span class="val${o.num ? ' num' : ''}">${o.val}</span>`
      : `<span class="ph">${o.ph || ''}</span>`;
    const tr = [];
    if (o.unconf) tr.push(`<span class="mark">${ic('sparkle', 'ic-sm')}</span>`);
    if (o.date) tr.push(`<span class="tr">${ic('cal')}</span>`);
    if (o.sel) tr.push(`<span class="tr">${ic('chevD')}</span>`);
    const offer = o.offer ? `<div class="offer">${o.offer}</div>` : '';
    const w = o.w ? ` data-w="${o.w}"` : '';
    return `<div class="fwrap ${o.cls || ''}"><div class="${cls.join(' ')}"${w}><span class="lbl">${label}${o.req ? '<span class="req">*</span>' : ''}</span>${inner}${tr.join('')}</div>${offer}</div>`;
  }
  /** Индикатор состояния счёта. i: {tone, text, spin, open} */
  function ind(i) {
    return `<span class="ind ${i.tone || ''}${i.open ? ' open' : ''}" role="button" aria-haspopup="dialog">${i.spin ? '<span class="spin"></span>' : '<span class="dot"></span>'}${i.text}${ic(i.open ? 'chevU' : 'chevD', 'ic-sm')}</span>`;
  }
  function saveState(kind, extra) {
    if (kind === 'saving') return `<span class="save"><span class="spin" style="width:10px;height:10px;color:var(--f-fg4)"></span>Сохраняю…</span>`;
    if (kind === 'ro') return `<span class="save">${ic('eye', 'ic-sm')}Только чтение</span>`;
    if (kind === 'none') return '';
    return `<span class="save" data-w="auto">${ic('cloud', 'ic-sm')}Сохранено · 12:04${extra || ''}</span>`;
  }

  /** Поповер индикатора. p: {head, sub, groups:[{title, tone, items:[{text, tags, acts}]}], foot, maxH} */
  function popover(p) {
    const tones = { danger: 'var(--f-danger-fg)', warn: 'var(--f-warning-stroke)', quiet: 'var(--f-fg4)', brand: 'var(--f-brand)', ok: 'var(--f-success-fg)' };
    const groups = p.groups.map(g => {
      const items = g.items.map(it => {
        const tags = (it.tags || []).map(t => t === 'SRV' ? srv() : `<span class="badge quiet">${t}</span>`).join('');
        const acts = (it.acts || []).map(a => btn(a, 'text')).join('');
        return `<div class="pop-i"><div class="txt">${it.text}${tags ? `<div class="tags">${tags}</div>` : ''}</div>${acts ? `<div class="acts">${acts}</div>` : ''}</div>`;
      }).join('');
      return `<div class="pop-g"><span class="gdot" style="background:${tones[g.tone] || tones.quiet}"></span>${g.title}</div>${items}`;
    }).join('');
    return `<div class="pop" style="${p.left != null ? 'left:' + p.left + 'px;' : ''}${p.maxH ? 'max-height:' + p.maxH + 'px' : ''}" role="dialog" aria-label="Состояние счёта">
      <div class="pop-h"><h4>${p.head}</h4><span class="xs muted">${p.sub || ''}</span><span class="grow"></span>${ibtn('x', 'Закрыть')}</div>
      <div class="pop-b">${groups}</div>${p.foot ? `<div class="pop-f">${p.foot}</div>` : ''}</div>`;
  }

  // ── оболочка ──
  function rail() {
    const it = (k, t, on) => `<div class="it${on ? ' on' : ''}"><span class="pill">${ic(k)}</span>${t}</div>`;
    return `<nav class="rail"><div class="logo">${ic('logo')}BHS.CRG</div>${it('sites', 'Стройки')}${it('data', 'Данные')}${it('costs', 'Затраты', 1)}<div class="sep"></div>${it('sys', 'Система')}</nav>`;
  }
  function topbar() {
    return `<header class="topbar"><span class="iconbtn">${ic('panel')}</span><span class="mod">${ic('apps')}Все доступные модули${ic('chevD', 'ic-sm')}</span>
      <span class="srch">${ic('search')}Найти счёт, стройку или действие<kbd>Ctrl K</kbd></span><span class="grow"></span>
      <span class="ib">${ic('bell')}<span class="cnt">2</span></span><span class="ib">${ic('help')}</span><span class="ava">АП</span></header>`;
  }
  /** o: {w, h, md3} */
  function frame(o, inner) {
    return `<div class="frame${o.md3 ? ' md3' : ''}" style="width:${o.w}px;height:${o.h}px" data-screen-label="${o.label || ''}">${rail()}<div class="appcol">${topbar()}<div class="work">${inner}</div></div></div>`;
  }

  // ── список счетов ──
  function listCol(o) {
    const src = o && o.parsed ? [Object.assign({}, LIST[0], { amt: '136 960,00', tags: [['success', 'разобран'], ['danger', 'просрочен']], rest: '' })].concat(LIST.slice(1)) : LIST;
    const rows = src.map(r => `<div class="li${r.sel ? ' sel' : ''}"><div class="r1"><b>${r.no}</b><span class="xs muted">${r.d}</span><span class="amt">${r.amt} ₽</span></div>
      <div class="r2"><span class="ell">${r.who}</span><span class="grow"></span>${r.tags.map(t => badge(t[1], t[0])).join('')}</div>${r.rest ? `<div class="ell">${r.rest}</div>` : ''}</div>`).join('');
    return `<aside class="list"><div class="list-h"><div class="row lh-title"><h1 class="lh-h1">Счета на оплату</h1><span class="grow"></span>${btn('Из файла', 'tonal', { icon: 'upload' })}</div><div class="row"><span class="search">${ic('search')}Номер, поставщик, назначение…</span></div>
      <div class="row">${chip('Разобрать', { sel: 1, icon: 'queue', n: 57 })}${chip('Стройки', { menu: 1 })}<span class="grow"></span>${ibtn('more', 'Справочники и отборы')}</div></div>
      <div class="scroll">${rows}</div></aside>`;
  }

  // ── файл счёта ──
  function paper(hl) {
    const h = k => (hl && hl.indexOf(k) >= 0 ? ' class="hl"' : '');
    const rows = LINES.map(l => `<tr><td>${l.n}</td><td>${l.name}</td><td>${l.art}</td><td>${l.u}</td><td class="r">${l.qty}</td><td class="r">${l.price}</td><td class="r">${l.sum}</td></tr>`).join('');
    return `<div class="paper"><div class="bank">ПАО «Сбербанк» г. Москва · БИК 044525225 · Сч. № 30101810400000000225<br>ИНН ${INV.inn} КПП 770101001 · Получатель: ООО «Кабель-Торг» · Сч. № 40702810938000012345</div>
      <h5><span${h('no')}>Счёт на оплату № СЧ-104</span> от <span${h('date')}>03 сентября 2026 г.</span></h5>
      <div>Поставщик: <span${h('sup')}>ООО «Кабель-Торг», ИНН 7701234567</span>, 115114, г. Москва, Дербеневская наб., д. 7</div>
      <div>Покупатель: <span${h('payer')}>ООО «СтройЭлектроМонтаж», ИНН 7727654321</span></div>
      <div>Основание: Договор поставки № 17/26 от 12.01.2026</div>
      <table><tr><th>№</th><th>Товар</th><th>Арт.</th><th>Ед.</th><th>Кол-во</th><th>Цена</th><th>Сумма</th></tr>${rows}</table>
      <div class="r" style="text-align:right;margin-top:4px">Итого: 136 960,00<br><span${h('vat')}>В том числе НДС 20 %: 22 826,67</span><br><b><span${h('amt')}>Всего к оплате: 136 960,00</span></b></div>
      <div style="margin-top:6px">Всего наименований 6, на сумму 136 960,00 руб. Счёт действителен 5 банковских дней.</div>
      <div style="margin-top:14px">Руководитель ____________ Бухгалтер ____________</div></div>`;
  }
  /** o: {w, side:'left'|'right', bad, hl, close} */
  function scanPanel(o) {
    const body = o.bad
      ? `<div class="ph-stripes">фото счёта под углом, текст не читается<br>(скан-счёта.jpg, 1 лист)</div>`
      : paper(o.hl);
    return `<section class="scan ${o.side === 'left' ? 'left' : ''}" style="width:${o.w}px" aria-label="Файл счёта">
      <div class="scan-h">${ic('file', 'ic-sm')}<span class="ell">${o.bad ? 'скан-счёта.jpg' : 'Счёт СЧ-104 Кабель-Торг.pdf'}</span><span class="grow"></span>${btn('Во вкладке', 'text', { icon: 'open' })}${o.close ? ibtn('x', 'Скрыть файл') : ''}</div>
      <div class="scan-b">${body}</div>
      <div class="scan-f">${ibtn('chevL')}<span>1 из 1</span>${ibtn('chevR')}<span class="grow"></span>${chip('По ширине', { menu: 1 })}${ibtn('rotate', 'Повернуть')}</div></section>`;
  }

  // ── строки ──
  function posCell(l, mode) {
    if (mode === 'read') return `<span class="tx">${l.pos || l.pos2 || '—'}</span>`;
    if (!l.pos) return `<div class="cell pick"><span class="v">выбрать позицию</span>${ic('chevD', 'ic-sm')}</div>`;
    return `<div class="cell"><span class="v">${l.pos}</span>${l.mem ? '<span class="mem">запомнено</span>' : ''}</div>`;
  }
  /** mode: 'edit' | 'read'; o: {alloc, compact} */
  function linesTable(mode, o) {
    o = o || {};
    const ed = mode === 'edit';
    const c = (v, r) => ed ? `<div class="cell${r ? ' r' : ''}"><span class="v${r ? ' num' : ''}">${v}</span></div>` : `<span class="tx${r ? ' num' : ''}" style="${r ? 'text-align:right' : ''}">${v}</span>`;
    const alloc = l => {
      if (o.alloc === 'done') return `<span class="tx xs">${INV.section}</span>`;
      return ed ? `<span class="xs warn-t">не разнесена</span>` : '—';
    };
    const rows = LINES.map(l => `<tr><td class="c xs muted">${l.n}</td><td>${posCell(l, mode)}</td><td>${ed ? `<div class="cell"><span class="v">${l.name}</span></div>` : `<span class="tx">${l.name} <span class="muted xs">· ${l.art}</span></span>`}</td>
      <td>${c(l.qty, 1)}</td><td>${ed ? `<div class="cell"><span class="v">${l.u}</span></div>` : l.u}</td><td>${c(l.price, 1)}</td><td class="r num">${l.sum}</td><td>${alloc(l)}</td>${ed ? `<td class="c">${ibtn('trash', 'Удалить строку')}</td>` : ''}</tr>`).join('');
    return `<table class="grid"><colgroup><col style="width:34px"><col><col><col style="width:66px"><col style="width:52px"><col style="width:86px"><col style="width:100px"><col style="width:${o.compact ? 96 : 116}px">${ed ? '<col style="width:38px">' : ''}</colgroup>
      <thead><tr><th>№</th><th>Позиция номенклатуры</th><th>Наименование в счёте</th><th class="r">Кол-во</th><th>Ед.</th><th class="r">Цена</th><th class="r">Сумма</th><th>Разноска</th>${ed ? '<th></th>' : ''}</tr></thead>
      <tbody>${rows}</tbody><tfoot><tr><td></td><td colspan="5" class="xs muted" style="font-weight:400">Итого по строкам</td><td class="r num">136 960,00</td><td colspan="${ed ? 2 : 1}"></td></tr></tfoot></table>`;
  }
  function recon(state) {
    if (state === 'ok') return `<div class="recon">${ic('ok', 'ic-sm succ-t')}<span>Строк <b>6</b> · сумма строк <b>136 960,00</b> · к оплате <b>136 960,00</b> — <span class="succ-t">сходится</span></span></div>`;
    return `<div class="recon">${ic('warn', 'ic-sm warn-t')}<span>Строк <b>6</b> · без позиции <b class="warn-t">2</b> · из запомненного 3</span><span class="vdiv"></span>
      <span>Сумма строк <b class="num">136 960,00</b> · к оплате <b class="num">128 400,50</b> · <span class="bad">расхождение −8 559,50</span> <span class="muted">(допуск 1,00)</span></span></div>`;
  }

  window.M = { INV, LINES, LIST, ic, btn, ibtn, badge, srv, chip, field, ind, saveState, popover, frame, listCol, scanPanel, paper, linesTable, recon,
    setMd3(v) { MD3 = !!v; }, isMd3() { return MD3; } };
})();
