/* Экраны трёх макетов В7. Один набор экранов на все три варианта: разница — только в размерах,
   которые задаёт V ниже. Подписи и числа — с настоящих экранов (разбор Дизайнера, раздел 1). */
(function () {
  const VARS = {
    a: { key: 'a', name: 'А', title: 'MD3 40 везде',
      cell: '', cellBtn: '', bar: '',
      rule: 'Все кнопки и кнопки-иконки — 40, в строках таблиц и окон тоже. Строка с кнопкой-иконкой — 48.' },
    b: { key: 'b', name: 'Б', title: 'Размер XS 32 в клетках таблиц',
      cell: 'dense', cellBtn: '', bar: '',
      rule: 'Кнопки с подписью — 40 везде. Кнопка-иконка — 32 (размер XS из шкалы M3 Expressive, знак 20) только в клетках DataGrid и EditGrid и только при мыши; при касании — 40. Размер ставит сама сетка.' },
    v: { key: 'v', name: 'В', title: 'dense 32 в строках и панелях',
      cell: 'dense', cellBtn: 'dense', bar: 'dense',
      rule: 'Кнопки и кнопки-иконки 32 — в строках таблиц и в панелях инструментов (включая кнопки с подписью). Шапки страниц и окна — 40. При касании — 40.' },
  };
  const V = VARS[window.VARIANT || 'a'];

  /* ---- кирпичи ---- */
  const s = (n, c) => `<span class="sym${c ? ' ' + c : ''}">${n}</span>`;
  const ib = (n, label, c) => `<span class="ib${c ? ' ' + c : ''}" aria-label="${label}">${s(n)}</span>`;
  const btn = (t, v, n, c) => `<span class="btn ${v}${c ? ' ' + c : ''}">${n ? s(n) : ''}${t}</span>`;
  const chip = (t, o = {}) => `<span class="chip${o.sel ? ' sel' : ''}${o.assist ? ' assist' : ''}${o.c ? ' ' + o.c : ''}">` +
    (o.sel ? s('check') : o.icon ? s(o.icon, o.tone ? 'ic-' + o.tone : '') : '') + t +
    (o.cnt != null ? ` <span class="cnt">${o.cnt}</span>` : '') + (o.x ? s('close', 'x') : '') + (o.dd ? s('arrow_drop_down', 'dd') : '') + '</span>';
  const seg = (items, on, c, role) => `<span class="seg${c ? ' ' + c : ''}" role="${role || 'radiogroup'}">` +
    items.map((t, i) => `<span class="${i === on ? 'on' : ''}">${t}</span>`).join('') + '</span>';
  const st = (t, k, n) => `<span class="st ${k}">${s(n, '')}${t}</span>`;
  const fld = (label, val, h, w) => `<span style="display:inline-flex;align-items:center;gap:6px;height:${h}px;width:${w}px;padding:0 8px 0 12px;border:1px solid var(--outline);border-radius:4px;color:var(--on-surface);white-space:nowrap;overflow:hidden"><span class="muted t-bs">${label}</span> ${val}<span style="flex:1"></span>${s('arrow_drop_down')}</span>`;

  const rail = (on) => `<nav class="rail">` + [
    ['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['apartment', 'Стройки'],
    ['folder_open', 'Комплекты'], ['table_chart', 'Таблицы'], ['settings', 'Настройки'],
  ].map(([n, t]) => `<div class="it${t === on ? ' on' : ''}"><span class="pill">${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</nav>';
  const laptop = (label, on, inner) => `<div class="md3" data-screen-label="${label}"><div class="app laptop">${rail(on)}<div class="work">${inner}</div></div></div>`;
  const pnav = (on) => `<div class="pnav">` + [['receipt_long', 'Счета'], ['local_shipping', 'Накладные'], ['folder_open', 'Комплекты'], ['menu', 'Ещё']]
    .map(([n, t]) => `<div class="it${t === on ? ' on' : ''}"><span class="pill">${s(n, 's24' + (t === on ? ' fill' : ''))}</span>${t}</div>`).join('') + '</div>';
  const phone = (label, inner, on) => `<div class="md3" data-screen-label="${label}"><div class="app phone">${inner}${pnav(on)}</div></div>`;

  /* ---- L1. Реестр счетов: шапка из пяти кнопок, очереди, строки счёта (EditGrid) ---- */
  function invoices() {
    const lines = [
      ['Кабель ВВГнг(А)-LS 3×2,5', '1 200', 'м', '92,40', '110 880,00', 'Кабель и провод', 1],
      ['Кабель ВВГнг(А)-LS 5×10', '320', 'м', '612,00', '195 840,00', 'Кабель и провод', 0],
      ['Автомат ВА 47-29 1Р 16А С', '64', 'шт', '214,00', '13 696,00', 'Аппараты защиты', 1],
      ['Щит ЩРН-М-24 встраиваемый', '8', 'шт', '3 180,00', '25 440,00', 'Щитовое оборудование', 0],
      ['Гофра ПВХ 20 мм с зондом', '900', 'м', '11,80', '10 620,00', 'Крепёж и трубы', 1],
      ['Коробка распаечная 100×100×50', '120', 'шт', '96,00', '11 520,00', 'Крепёж и трубы', 0],
      ['Розетка с заземлением скрытой установки', '240', 'шт', '188,00', '45 120,00', 'Электроустановочные', 1],
      ['Выключатель одноклавишный', '180', 'шт', '142,00', '25 560,00', 'Электроустановочные', 0],
      ['Светильник светодиодный 36 Вт', '96', 'шт', '1 420,00', '136 320,00', 'Светильники', 1],
      ['Хомут нейлоновый 200 мм (100 шт)', '30', 'уп', '164,00', '4 920,00', 'Крепёж и трубы', 0],
      ['Доставка', '1', 'усл', '4 500,00', '4 500,00', 'Транспорт', 0],
    ];
    const actW = V.cell ? 44 : 52, artW = V.cell ? 230 : 238;
    const rows = lines.map((l, i) => `<tr><td class="num muted">${i + 1}</td><td><span class="cellin">${l[0]}</span></td>` +
      `<td class="num"><span class="cellin">${l[1]}</span></td><td><span class="cellin">${l[2]}</span></td><td class="num"><span class="cellin">${l[3]}</span></td><td class="num">${l[4]}</td>` +
      `<td style="overflow:visible"><div style="display:flex;align-items:center;gap:4px"><span class="cellin" style="flex:1;min-width:0">${l[6] ? s('bookmark_added', '') + ' ' : ''}${l[5]}</span>${l[6] ? ib('undo', 'Отменить подстановку', V.cell) : ''}</div></td>` +
      `<td class="acts"><div>${ib('close', 'Удалить строку', V.cell)}</div></td></tr>`).join('');
    const list = [['1020', 'ЭТМ', 'Разобрать', '624 316,00', 1], ['1019', 'Минимакс', 'Разобран', '58 200,00'], ['1018', 'Электрокомплект', 'Оплачен', '212 960,00'],
      ['1017', 'Леруа Мерлен', 'Разобрать', '9 418,50'], ['1016', 'ЭТМ', 'Оплачен', '88 044,00'], ['1015', 'Руссвет', 'Разобран', '141 300,00'], ['1014', 'Минимакс', 'Оплачен', '17 640,00'], ['1013', 'ЭТМ', 'Оплачен', '305 112,00']]
      .map(r => `<div class="li" style="min-height:64px;${r[4] ? 'background:var(--secondary-container);color:var(--on-secondary-container)' : ''}"><div class="b"><div>№ ${r[0]} · ${r[1]}</div><div class="t-bs muted" style="${r[4] ? 'color:inherit' : ''}">${r[2]} · 31.10.2026</div></div><div class="num" style="padding-right:12px">${r[3]}</div></div>`).join('');
    return laptop('L1 Реестр счетов', 'Счета', `
      <div class="ph" style="flex-wrap:wrap"><h1>Счета</h1><span class="sub">248</span><span class="sp"></span>
        ${btn('Статьи вне строек', 'outlined')}${btn('Соответствия', 'outlined')}${btn('Условия поставщиков', 'outlined')}${btn('Новый счёт', 'outlined', 'add')}${btn('Счёт из файла', 'filled', 'upload_file')}</div>
      <div class="fbar">${chip('Разобрать', { sel: 1, cnt: 12 })}${chip('Не распознано', { icon: 'document_scanner', tone: 'warn', cnt: 3 })}${chip('Удалённые записи', { icon: 'help', tone: 'warn', cnt: 2 })}${chip('В архиве', { icon: 'archive', cnt: 5 })}${chip('Избранные стройки · скрыто 4', { icon: 'star', x: 1 })}</div>
      <div class="split" style="border-top:1px solid var(--outline-variant)">
        <div style="width:300px;flex:none;overflow:hidden;background:var(--scl)"><div style="padding:8px 12px"><span class="search" style="width:100%">${s('search', 's24')}Поиск по счетам</span></div>${list}</div>
        <div class="pane">
          <div class="tbar"><span class="t-tm">Счёт № 1020 · ЭТМ — строки</span><span class="sp"></span>
            <span style="display:inline-flex;align-items:center;gap:8px">${s('check_box_outline_blank', 's24 muted')}Цены без НДС</span>
            ${btn('Вставить из таблицы', 'text', 'content_paste', V.bar)}${btn('Сохранить строки', 'tonal', 'save', V.bar)}</div>
          <div class="tblw"><table class="g"><colgroup><col style="width:36px"><col><col style="width:76px"><col style="width:52px"><col style="width:96px"><col style="width:110px"><col style="width:${artW}px"><col style="width:${actW}px"></colgroup>
            <thead><tr><th class="num">№</th><th>Наименование</th><th class="num">Кол-во</th><th>Ед.</th><th class="num">Цена</th><th class="num">Сумма</th><th>Статья</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
          <div class="tbar" style="border-bottom:0;border-top:1px solid var(--outline-variant)"><span class="muted">11 строк · итого</span><b class="num">624 316,00 ₽</b><span class="sp"></span>${btn('Разобран', 'outlined', 'check', V.bar)}</div>
        </div></div>`);
  }

  /* ---- L2. Комплект документов (SetDetail): главный экран для В7 — строка из трёх кнопок-иконок, «PDF» и меню ---- */
  function setDetail() {
    const docs = [['АОСР № 12 — прокладка кабеля в гофре, 2 этаж', 'АОСР', ['Собран', 'ok', 'check_circle']],
      ['АОСР № 13 — установка распаечных коробок', 'АОСР', ['Собран', 'ok', 'check_circle']],
      ['Кабельный журнал, секция 2', 'КабельныйЖурнал', ['Изменён', 'warn', 'edit']],
      ['Ведомость материалов', 'ВедомостьМатериалов', ['Собран', 'ok', 'check_circle']],
      ['Протокол измерения сопротивления изоляции', 'ПротоколИзоляции', ['Ошибка сборки', 'err', 'error']],
      ['Протокол измерения фаза — ноль', 'ПротоколФазаНоль', ['Черновик', 'q', 'draft']],
      ['Протокол металлосвязи', 'ПротоколМеталлосвязи', ['Собран', 'ok', 'check_circle']],
      ['Реестр документов комплекта', 'РеестрДокументов', ['Собран', 'ok', 'check_circle']],
      ['Титульный лист', 'ТитульныйЛист', ['Собран', 'ok', 'check_circle']],
      ['АОСР № 14 — монтаж щитов ЩРН', 'АОСР', ['Черновик', 'q', 'draft']]];
    const k = V.cell, ordW = k ? 120 : 144, pdfW = V.cellBtn ? 132 : 148, actW = k ? 44 : 52;
    const rows = docs.map((d, i) => `<tr${i === 2 ? ' class="sel"' : ''}><td class="acts" style="text-align:left"><div>${ib('drag_indicator', 'Перетащить', k)}${ib('arrow_upward', 'Выше', k)}${ib('arrow_downward', 'Ниже', k)}</div></td>` +
      `<td class="num muted">${i + 1}</td><td>${d[0]}</td><td class="muted">${d[1]}</td><td>${st(d[2][0], d[2][1], d[2][2])}</td>` +
      `<td class="acts" style="text-align:left"><div>${btn('PDF', 'outlined', 'picture_as_pdf', V.cellBtn)}${ib('download', 'Скачать PDF', k)}</div></td><td class="acts"><div>${ib('more_vert', 'Действия', k)}</div></td></tr>`).join('');
    return laptop('L2 Комплект документов', 'Комплекты', `
      <div style="padding:12px 24px 0" class="t-bs muted">Стройки › ЖК «Северный» › Раздел ЭОМ</div>
      <div class="ph" style="padding-top:4px"><h1>Комплект ИД № 4 — ЭОМ, секция 2</h1><span class="sub">10 документов</span><span class="sp"></span>
        ${btn('Скачать', 'outlined', 'download')}${btn('Почта', 'outlined', 'mail')}${btn('Собрать', 'outlined', 'inventory_2')}${btn('Добавить документ', 'filled', 'add')}${ib('more_vert', 'Ещё')}</div>
      <div class="tblw" style="padding-top:4px"><table class="g"><colgroup><col style="width:${ordW}px"><col style="width:40px"><col><col style="width:200px"><col style="width:150px"><col style="width:${pdfW}px"><col style="width:${actW}px"></colgroup>
        <thead><tr><th>Порядок</th><th class="num">№</th><th>Документ</th><th>Тип</th><th>Состояние</th><th>Файл</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`);
  }

  /* ---- L3. Таблица с отбором (TablePage): три ряда чипов filter / input / assist ---- */
  function tablePage() {
    const data = [['1020', '31.10.2026', 'ЭТМ', 'ЖК «Северный»', '624 316,00', ['Разобрать', 'q', 'pending']],
      ['1017', '29.10.2026', 'Леруа Мерлен', 'ЖК «Северный»', '9 418,50', ['Разобрать', 'q', 'pending']],
      ['1012', '24.10.2026', 'ЭТМ', 'Школа № 7', '133 870,00', ['Разобран', 'ok', 'check_circle']],
      ['1009', '22.10.2026', 'ЭТМ', 'ЖК «Северный»', '402 118,00', ['Оплачен', 'ok', 'paid']],
      ['1004', '17.10.2026', 'ЭТМ', 'Склад «Восток»', '57 300,00', ['Оплачен', 'ok', 'paid']],
      ['0998', '12.10.2026', 'ЭТМ', 'Школа № 7', '18 240,00', ['Нет статьи', 'err', 'error']],
      ['0991', '08.10.2026', 'ЭТМ', 'ЖК «Северный»', '211 004,00', ['Оплачен', 'ok', 'paid']],
      ['0987', '03.10.2026', 'ЭТМ', 'ЖК «Северный»', '76 560,00', ['Оплачен', 'ok', 'paid']]]
      .map(r => `<tr><td class="num">${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td class="num">${r[4]}</td><td>${st(r[5][0], r[5][1], r[5][2])}</td></tr>`).join('');
    const lab = (t) => `<span class="muted t-bs" style="width:128px;flex:none">${t}</span>`;
    return laptop('L3 Таблица с отбором', 'Таблицы', `
      <div class="ph"><h1 style="display:inline-flex;align-items:center;gap:4px">Счета — мой вид ${s('arrow_drop_down', 's24')}</h1><span class="sub">· изменено</span>
        ${btn('Сохранить', 'tonal', '', V.bar)}${btn('Сохранить как своё', 'outlined', '', V.bar)}${btn('Сбросить', 'text', '', V.bar)}<span class="sp"></span>${ib('view_column', 'Колонки')}${ib('download', 'Выгрузить')}</div>
      <div class="fbar">${lab('Навести порядок')}${chip('Без статьи', { icon: 'warning', tone: 'err', cnt: 7 })}${chip('В архиве', { icon: 'archive', cnt: 5 })}</div>
      <div class="fbar">${lab('Объект')}${chip('Избранные стройки', { icon: 'star' })}<span class="t-bs muted">был пунктиром «предложение»; теперь filter chip — переключатель, не assist</span></div>
      <div class="fbar">${lab('Условия')}${chip('Поставщик: <b>ЭТМ</b>', { x: 1 })}${chip('Сумма: <b>&gt; 10 000</b>', { x: 1 })}${chip('Дата: <b>31.02.2026</b>', { icon: 'warning', tone: 'err', x: 1 })}${chip('Статья: <b>Кабель ВВГ</b>', { icon: 'search_off', tone: 'warn', x: 1 })}
        ${chip('условие', { assist: 1, icon: 'add' })}${chip('Поставщик', { assist: 1, icon: 'add' })}<span class="sp"></span>${btn('Расширенный', 'text', 'filter_list', V.bar)}${btn('Снять отбор', 'text', '', V.bar)}</div>
      <div style="padding:0 24px 8px 160px" class="t-bs"><span style="color:var(--error)">Дата 31.02.2026 не существует — условие не выполнится.</span> <span style="color:var(--warning)">«Кабель ВВГ» нет в справочнике — условие ничего не найдёт.</span></div>
      <div class="tblw" style="border-top:1px solid var(--outline-variant)"><table class="g"><colgroup><col style="width:90px"><col style="width:120px"><col><col><col style="width:150px"><col style="width:170px"></colgroup>
        <thead><tr><th class="num">№</th><th>Дата</th><th>Поставщик</th><th>Стройка</th><th class="num">Сумма</th><th>Состояние</th></tr></thead><tbody>${data}</tbody></table></div>
      <div class="tbar" style="border-bottom:0;border-top:1px solid var(--outline-variant);justify-content:flex-end"><span class="muted">1–50 из 248</span>${ib('chevron_left', 'Назад', V.bar)}${ib('chevron_right', 'Вперёд', V.bar)}</div>`);
  }

  /* ---- L4. Сегменты: затраты по стройке (radiogroup), закрытые периоды (вкладки), шапка шаблонов ---- */
  function segments() {
    const rowsC = [['ЭТМ', '1 862 400,00', '1 552 000,00', '310 400,00'], ['Минимакс', '418 260,00', '348 550,00', '69 710,00'], ['Электрокомплект', '212 960,00', '177 466,67', '35 493,33'], ['Руссвет', '141 300,00', '117 750,00', '23 550,00']]
      .map(r => `<tr><td>${r[0]}</td><td class="num">${r[1]}</td><td class="num">${r[2]}</td><td class="num">${r[3]}</td></tr>`).join('');
    const filt = (h) => `<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">${fld('Стройка', 'ЖК «Северный»', h, 240)}${chip('Стройки', { icon: 'apartment', cnt: 3, dd: 1 })}${fld('Период', '01.10–31.10.2026', h, 220)}${seg(['с НДС', 'без НДС'], 0, V.bar)}${seg(['по контрагентам', 'по разделам'], 0, V.bar)}</div>`;
    const tabsU = `<div style="display:flex;border-bottom:1px solid var(--outline-variant)">` + ['Шаблоны документов', 'Общие функции Typst', 'Системные функции', 'Блоки типов']
      .map((t, i) => `<span style="height:48px;display:inline-flex;align-items:center;padding:0 16px;font-weight:500;${i === 0 ? 'color:var(--primary);box-shadow:inset 0 -3px 0 var(--primary)' : 'color:var(--on-surface-variant)'}">${t}</span>`).join('') + '</div>';
    return laptop('L4 Сегменты', 'Стройки', `
      <div class="ph"><h1>Затраты по стройке</h1><span class="sp"></span>${btn('Выгрузить', 'outlined', 'download')}</div>
      <div style="padding:0 24px">
        <div class="t-bs muted" style="margin:0 0 6px">Ряд отбора между change 10 и 11: поля ещё 32, сегменты и чипы уже новые</div>${filt(32)}
        <div class="t-bs muted" style="margin:14px 0 6px">После 11 (плотное поле 40 — решается в 11, здесь для сравнения)</div>${filt(40)}
        <div style="display:flex;align-items:center;gap:16px;margin:20px 0 8px"><span class="t-tm">Закрытые периоды</span>${seg(['С исправлениями', 'На момент закрытия'], 0, '', 'tablist')}<span class="t-bs muted">с панелью: вкладки, Enter переключает</span></div>
        <table class="g" style="max-width:820px"><colgroup><col><col style="width:170px"><col style="width:170px"><col style="width:150px"></colgroup><thead><tr><th>Контрагент</th><th class="num">С НДС</th><th class="num">Без НДС</th><th class="num">НДС</th></tr></thead><tbody>${rowsC}</tbody></table>
        <div class="t-tm" style="margin:24px 0 8px">Шапка «Шаблоны»: четыре раздела страницы</div>
        <div style="display:flex;gap:32px;align-items:flex-start;flex-wrap:wrap">
          <div><div class="t-bs muted" style="margin-bottom:6px">как сегменты (по задаче 2.5)</div>${seg(['Шаблоны документов', s('functions') + 'Общие функции Typst', s('lock') + 'Системные функции', s('widgets') + 'Блоки типов'], 0, '', 'tablist')}</div>
          <div><div class="t-bs muted" style="margin-bottom:6px">как вкладки разделов (рекомендация Дизайнера)</div>${tabsU}</div>
        </div></div>`);
  }

  /* ---- L5. Окна: compact-таблица с действием в строке и удаление с filled danger ---- */
  function dialogs() {
    const m = [['ВВГнг(А)-LS 3×2,5', 'Кабель ВВГнг-LS 3×2,5 мм²', ''], ['ВА 47-29 1Р 16А', 'Автомат однополюсный 16 А', ''], ['ЩРН-М-24', 'Щит распределительный на 24 модуля', 'del'], ['Гофра ПВХ 20', 'Труба гофрированная 20 мм', ''], ['Розетка СП 2П+З', 'Розетка с заземлением', 'arch'], ['Хомут 200 мм', 'Хомут нейлоновый', ''], ['Светильник 36 Вт', 'Светильник светодиодный потолочный', '']]
      .map(r => `<tr><td>${r[0]}</td><td>${r[1]} ${r[2] === 'del' ? chip('Позиция удалена', { icon: 'delete', tone: 'err' }) : r[2] === 'arch' ? chip('В архиве', { icon: 'archive' }) : ''}</td><td class="acts"><div>${ib('link_off', 'Забыть соответствие', V.cell)}</div></td></tr>`).join('');
    return laptop('L5 Окна', 'Счета', `
      <div class="ph"><h1>Счета</h1></div>
      <div class="scrim" style="gap:24px;align-items:center">
        <div class="dlg" style="width:680px"><h2>Соответствия поставщика · ЭТМ</h2>
          <div class="muted">Позиции счетов, запомненные за номенклатурой. Строка таблицы окна — compact (D7: 40).</div>
          <table class="g"><colgroup><col style="width:190px"><col><col style="width:${V.cell ? 40 : 48}px"></colgroup><thead><tr><th style="height:40px">В счёте</th><th style="height:40px">Позиция номенклатуры</th><th style="height:40px"></th></tr></thead><tbody>${m}</tbody></table>
          <div class="acts">${btn('Закрыть', 'text')}</div></div>
        <div class="dlg" style="width:440px"><h2>Удалить 3 записи насовсем?</h2>
          <div class="muted">На записи ссылаются 2 счёта и 1 накладная. Ссылки станут пустыми, вернуть их нельзя.</div>
          <div class="acts" style="align-items:center">${btn('Отмена', 'text')}<span class="btn filled danger" style="height:auto;min-height:40px;padding:10px 24px;white-space:normal;max-width:240px;text-align:center">Удалить записи, потеряв ссылки</span></div>
          <div style="height:1px;background:var(--outline-variant);margin:4px 0"></div>
          <div class="t-bs muted">Обычное подтверждение (ConfirmDialog): сегодня кнопки 32, станут 40</div>
          <div class="acts">${btn('Отмена', 'text')}${btn('Удалить счёт', 'filled danger', 'delete')}</div></div>
      </div>`);
  }

  /* ---- Телефон ---- */
  function pInvoices() {
    const items = [['1020', 'ЭТМ', 'Разобрать', '624 316,00'], ['1019', 'Минимакс', 'Разобран', '58 200,00'], ['1018', 'Электрокомплект', 'Оплачен', '212 960,00'], ['1017', 'Леруа Мерлен', 'Разобрать', '9 418,50'], ['1016', 'ЭТМ', 'Оплачен', '88 044,00'], ['1015', 'Руссвет', 'Разобран', '141 300,00'], ['1014', 'Минимакс', 'Оплачен', '17 640,00']]
      .map(r => `<div class="li"><div class="b"><div>№ ${r[0]} · ${r[1]}</div><div class="t-bs muted">${r[2]} · 31.10.2026</div></div><div class="num" style="padding-right:12px">${r[3]}</div></div>`).join('');
    return phone('P1 Счета, телефон', `<div class="ptop"><h1>Счета</h1>${ib('search', 'Поиск')}${ib('more_vert', 'Ещё')}</div>
      <div class="pbody"><div class="chiprow" style="flex-wrap:wrap">${chip('Разобрать', { sel: 1, cnt: 12 })}${chip('Не распознано', { icon: 'document_scanner', tone: 'warn', cnt: 3 })}${chip('Удалённые записи', { icon: 'warning', tone: 'err', cnt: 1 })}${chip('В архиве', { icon: 'archive', cnt: 5 })}</div>${items}
      <span class="fab">${s('upload_file')}Счёт из файла</span></div>`, 'Счета');
  }
  function pRows(cls, label) {
    const docs = [['АОСР № 12 — прокладка кабеля', 'Собран'], ['АОСР № 13 — распаечные коробки', 'Собран'], ['Кабельный журнал, секция 2', 'Изменён'], ['Ведомость материалов', 'Собран'], ['Протокол изоляции', 'Ошибка сборки'], ['Протокол фаза — ноль', 'Черновик'], ['Протокол металлосвязи', 'Собран']]
      .map((d, i) => `<div class="li" style="min-height:${cls ? 56 : 64}px;gap:4px"><div class="b"><div>${i + 1}. ${d[0]}</div><div class="t-bs muted">${d[1]}</div></div>${ib('arrow_upward', 'Выше', cls)}${ib('download', 'Скачать PDF', cls)}${ib('more_vert', 'Действия', cls)}</div>`).join('');
    return phone(label, `<div class="ptop">${ib('arrow_back', 'Назад')}<h1 style="margin-left:0">Комплект ИД № 4</h1>${ib('more_vert', 'Ещё')}</div>
      <div class="pbody"><div style="display:flex;gap:8px;padding:8px 16px">${btn('Собрать', 'outlined', 'inventory_2')}${btn('Добавить', 'filled', 'add')}</div>${docs}</div>`, 'Комплекты');
  }
  function pDialogs() {
    const lib = ['Сертификат соответствия ВВГнг(А)-LS', 'Паспорт качества № 4471', 'Декларация ЕАЭС RU Д-RU.РА', 'Сертификат пожарной безопасности']
      .map(t => `<div class="li" style="min-height:56px">${s('description', 's24 muted')}<div class="b"><div>${t}</div></div></div>`).join('');
    return phone('P3 Окно связи и удаление, телефон', `<div class="ptop">${ib('close', 'Закрыть')}<h1 style="margin-left:0">Документ качества</h1>${btn('Связать', 'text')}</div>
      <div class="pbody"><div style="padding:4px 16px 8px;overflow:hidden">${seg(['Из библиотеки', 'Поиск в интернете', 'Создать вручную'], 0, '', 'tablist')}</div>
        <div class="t-bs" style="padding:0 16px 8px;color:var(--error)">Ряд сегментов шире экрана уже сегодня (≈ 500 px против 343)</div>${lib}
        <div class="scrim" style="align-items:flex-end;padding-bottom:120px"><div class="dlg" style="width:320px"><h2>Удалить счёт № 1020?</h2><div class="muted">Счёт и его строки удалятся. Файл останется в журнале.</div><div class="acts">${btn('Отмена', 'text')}${btn('Удалить', 'filled danger')}</div></div></div></div>`, 'Счета');
  }

  /* ---- лист варианта ---- */
  const BORDER = {
    a: 'Границы нет: 40 везде. Строка с кнопкой-иконкой — 48, в окне с compact-таблицей тоже 48 (против 40 по D7).',
    b: '32 — кнопки-иконки в клетках строк счёта, комплекта и окна соответствий. 40 — всё остальное: шапки, панели над и под таблицей, постраничность, сегменты, кнопка «PDF» в строке комплекта (она с подписью — и держит строку 48). На телефоне всё 40.',
    v: '32 — кнопки и кнопки-иконки в строках и в панелях: «Вставить из таблицы», «Сохранить строки», «Разобран», «Сохранить / Сбросить» у вида, постраничность, сегменты в ряду отбора, «PDF». 40 — шапки страниц и окна. На телефоне всё 40. «Панель» здесь нарисована рукой — в коде такого компонента нет.',
  };
  const order = ['a', 'b', 'v'], files = { a: 'А - 40 везде.html', b: 'Б - XS 32 в клетках.html', v: 'В - dense 32 в панелях.html' };
  const nav = `<span class="nav"><a href="${encodeURI('00 Разбор и вопрос.html')}">0 Разбор</a>` + order.map(k => `<a href="${encodeURI(files[k])}"${k === V.key ? ' class="cur"' : ''}>${VARS[k].name} — ${VARS[k].title}</a>`).join('') + '</span>';
  const sec = (h, cap, body) => `<h2>${h}</h2>${cap ? `<div class="cap">${cap}</div>` : ''}<div class="row">${body}</div>`;
  const html = `<div class="ctl"><button data-t="light" class="on">Светлая</button><button data-t="dark">Тёмная</button><button data-tg="1">Показать цели нажатия</button>${nav}</div>
    <h1>${V.name} — ${V.title}</h1>
    <div class="lead"><p>${V.rule}</p><p><b>Граница:</b> ${BORDER[V.key]}</p></div>
    ${sec('Реестр счетов — 1366×768', 'Шапка из пяти кнопок (четыре outlined и filled «Счёт из файла»), очереди — filter chips, строки счёта — EditGrid: «Отменить подстановку» и крестик удаления строки (сегодня самодельный 22 px, станет IconButton).', invoices())}
    ${sec('Комплект документов — 1366×768', 'Главный экран для В7: в строке ручка и «выше / ниже», «PDF» с подписью, «Скачать» и «три точки» (сегодня самодельные 22–26 px). Колонки сегодня w-16 и w-10 — здесь расширены под вариант.', setDetail())}
    ${sec('Таблица с отбором — 1366×768', 'Три ряда: filter chips «Навести порядок» и «Избранные стройки», input chips условий (обычное, «не выполнится» — знак error, «нет в справочнике» — знак warning и строка-пояснение вместо жёлтой заливки), assist chips «+ условие».', tablePage())}
    ${sec('Сегменты — 1366×768', 'Без панели («с НДС / без НДС») — группа радиокнопок, стрелка выбирает. С панелью — вкладки с ручной активацией. Ряд отбора показан дважды: как будет между 10 и 11 и после 11.', segments())}
    ${sec('Окна — 1366×768', 'Слева — окно с compact-таблицей и действием в строке (проверяет D7: строка 40 против кнопки 40). Справа — filled danger: многострочная (отступление) и обычная. В одном кадре для сравнения; в приложении окно одно.', dialogs())}
    ${sec('Телефон — 375 px', V.key === 'a' ? 'Кнопки-иконки 40, цель нажатия 48 («Показать цели нажатия»). FAB — primary-container над нижней навигацией.'
      : 'При касании всё 40, как в А (первый, второй и четвёртый кадр). Третий кадр — что было бы, оставь мы 32 и на телефоне: цель только 40 (меньше 48 MD3 и 44 оболочки), а при расширении до 48 соседние цели наезжают друг на друга. Включите «Показать цели нажатия».',
      pInvoices() + pRows('', 'P2 Строки комплекта, телефон') + (V.key === 'a' ? '' : pRows('dense', 'P2′ Если бы 32 и при касании')) + pDialogs())}`;

  const root = document.getElementById('root');
  root.innerHTML = html;
  root.querySelectorAll('.ctl [data-t]').forEach(b => b.addEventListener('click', () => {
    root.querySelectorAll('.ctl [data-t]').forEach(x => x.classList.toggle('on', x === b));
    root.querySelectorAll('.md3').forEach(m => m.setAttribute('data-theme', b.dataset.t));
  }));
  const tg = root.querySelector('[data-tg]');
  tg.addEventListener('click', () => { document.body.classList.toggle('show-targets'); tg.classList.toggle('on'); });
  const q = new URLSearchParams(location.search);
  if (q.get('theme') === 'dark') root.querySelector('[data-t="dark"]').click();
  if (q.get('targets')) tg.click();
})();
