/* Три решения «раскрываемой группы строк» на двух экранах: типы документов (колонка 320) и шаблоны
   редактора (боковая колонка 256). Общее у всех: ListItem 48 / 64, body-large, знак 24, выбранная —
   secondary-container, действие «⋮» видно всегда (на касании наведения нет). Различие — только группа. */
(function () {
  const V = window.VARIANT;
  const S = (n, c = '') => `<span class="sym s24 ${c}">${n}</span>`;
  const ib = n => `<span class="ib"><span class="sym">${n}</span></span>`;

  // ListItem: цель во всю площадь, действие — соседом; depth — 16 на уровень.
  function li({ lead, leadCls = '', hl, sup, tr, act, sel, depth = 0 }) {
    const pad = depth ? ` style="padding-left:${16 + depth * 16}px"` : '';
    return `<div class="li ${sup ? 'two' : ''} ${sel ? 'sel' : ''} ${act ? 'act' : ''}">` +
      `<span class="tgt"${pad}>${lead ? `<span class="sym s24 lead ${leadCls}">${lead}</span>` : ''}` +
      `<span class="tx"><span class="hl">${hl}</span>${sup ? `<span class="sup">${sup}</span>` : ''}</span>` +
      `${tr ? `<span class="tr">${tr}</span>` : ''}</span>${act ? ib(act) : ''}</div>`;
  }

  const TYPES = [
    { g: 'Акты', items: [['Акт освидетельствования скрытых работ (АОСР)', 24, 'c'], ['Акт освидетельствования ответственных конструкций', 18], ['Акт гидравлических испытаний', 12], ['Акт приёмки электромонтажных работ', 9]] },
    { g: 'Журналы', items: [['Журнал прокладки кабеля', 14], ['Кабельный журнал', 11]] },
    { g: 'Протоколы', items: [['Протокол измерения сопротивления изоляции', 16], ['Протокол измерения сопротивления заземления', 15], ['Протокол проверки металлосвязи', 10], ['Протокол проверки цепи фаза-ноль', 13]] },
    { g: 'Реестры', closed: true, items: [['Запись реестра документов (протоколы измерений)', 7], ['Запись реестра документов (основные)', 7], ['Запись реестра документов (документы качества)', 7]] },
    { g: 'Прочее', items: [['Титульный лист', 4, 'c'], ['Ведомость схем', 6]] },
  ];
  const SEL_TYPE = 'Акт освидетельствования скрытых работ (АОСР)';

  function typeRow([name, n, kind], depth) {
    return li({ lead: kind === 'c' ? 'widgets' : 'description', hl: name, tr: n, sel: name === SEL_TYPE, depth });
  }

  function typesList() {
    return TYPES.map(({ g, items, closed }) => {
      const open = V === 'a' || !closed;
      if (V === 'a') return `<div class="sub sticky"><span class="tx">${g}</span><span class="cnt">${items.length}</span></div>` + items.map(t => typeRow(t)).join('');
      if (V === 'b') return `<div class="subx"><span class="tgt"><span class="tx">${g}</span><span class="cnt">${items.length}</span>` +
        `<span class="sym s24">${open ? 'expand_less' : 'expand_more'}</span></span></div>` + (open ? items.map(t => typeRow(t)).join('') : '');
      return li({ lead: open ? 'folder_open' : 'folder', hl: g, tr: `${items.length}<span class="sym s24">${open ? 'expand_less' : 'expand_more'}</span>` }) +
        (open ? items.map(t => typeRow(t, 1)).join('') : '');
    }).join('');
  }

  const TPL = [
    { name: 'АОСР — основной', def: true, vs: [{ v: 3, st: 'активная', used: 41, c: 'по замечаниям технадзора' }, { v: 2, st: 'по умолчанию', used: 12 }, { v: 1 }] },
    { name: 'АОСР — короткая форма', vs: [{ v: 1, st: 'активная', used: 3 }] },
    { name: 'АОСР — с приложениями к акту и подписями', closed: true, vs: [{ v: 2, st: 'активная' }, { v: 1 }] },
  ];
  const SEL_T = 'АОСР — основной', SEL_V = 3;
  const plural = n => `${n} ${n === 1 ? 'версия' : 'версии'}`;
  const stTag = x => x.st ? `<span class="st ${x.st === 'активная' ? 'ok' : 'warn'}">${x.st}</span>` : '';

  function verRow(t, x, depth) {
    const used = x.used ? `<span class="st q"><span class="sym">description</span>${x.used}</span>` : '';
    return li({ hl: `v${x.v}`, sup: x.c, tr: stTag(x) + used, act: 'more_vert', sel: t.name === SEL_T && x.v === SEL_V, depth });
  }

  function tplList() {
    return TPL.map(t => {
      const open = !t.closed;
      const act = t.vs.find(x => x.st === 'активная');
      if (V === 'a') return li({ lead: t.def ? 'star' : 'description', leadCls: t.def ? 'def' : '', hl: t.name,
        sup: `v${act.v} активная · ${plural(t.vs.length)}`, act: 'more_vert', sel: t.name === SEL_T });
      if (V === 'b') return `<div class="subx act"><span class="tgt">${t.def ? '<span class="sym s20" style="color:var(--warning);font-variation-settings:\'FILL\' 1">star</span>' : ''}` +
        `<span class="tx">${t.name}</span><span class="sym s24">${open ? 'expand_less' : 'expand_more'}</span></span>${ib('more_vert')}</div>` +
        (open ? t.vs.map(x => verRow(t, x)).join('') : '');
      const hasSel = t.name === SEL_T && !open;
      return li({ lead: t.def ? 'star' : 'description', leadCls: t.def ? 'def' : '', hl: t.name,
        sup: plural(t.vs.length), tr: `${hasSel ? '<span class="dot"></span>' : ''}<span class="sym s24">${open ? 'expand_less' : 'expand_more'}</span>`, act: 'more_vert' }) +
        (open ? t.vs.map(x => verRow(t, x, 1)).join('') : '');
    }).join('');
  }

  const NAV = [['description', 'Документы'], ['dataset', 'Наборы'], ['receipt_long', 'Счета'], ['settings', 'Настройки', 1]];
  const navItems = () => NAV.map(([i, l, on]) => `<div class="it ${on ? 'on' : ''}"><div class="pill">${S(i)}</div>${l}</div>`).join('');
  const rail = `<div class="rail">${navItems()}</div>`;

  const typeDetail = `<div class="det"><div class="dh"><h2>${SEL_TYPE}</h2><span class="btn tonal">Шаблоны</span><span class="btn filled">Сохранить</span></div>
    <div class="bd"><div class="sk" style="width:240px"></div><div class="fld"></div><div class="fld"></div><div class="sk" style="width:180px"></div><div class="fld"></div><div class="fld" style="height:120px"></div></div></div>`;

  // А: версии — в карточке, меню у чипа версии в шапке редактора (показано открытым).
  const menuA = `<div class="mnu" style="left:250px;top:60px">` +
    TPL[0].vs.map(x => `<div class="mi ${x.v === 3 ? 'sel' : ''}"><span class="tx">v${x.v}${x.c ? ' — ' + x.c : ''}</span>${stTag(x)}</div>`).join('') +
    `<div class="mi" style="border-top:1px solid var(--outline-variant)">${S('cleaning_services')}<span class="tx">Очистить старые версии…</span></div></div>`;
  const verLabel = V === 'a' ? `<span class="vchip">v3 · активная${S('arrow_drop_down')}</span>` : '<span class="muted">v3 · активная</span>';
  const code = `<b>#import</b> "typeblocks.typ": *
<b>#let</b> d = json("data.json")

<b>#set</b> page(paper: "a4", margin: (left: 20mm, rest: 10mm))
<b>#set</b> text(font: "Times New Roman", size: 11pt, lang: "ru")

= АКТ освидетельствования скрытых работ № #d.Номер

#ОбъектКапстроительства(d.Объект)
#Организация(d.Застройщик, роль: "Застройщик")
#Организация(d.Подрядчик, роль: "Лицо, осуществляющее строительство")

<b>#for</b> (i, r) <b>in</b> d.Работы.enumerate() [
  + #r.Наименование — #r.Объём #r.ЕдИзм
]`;
  const tplDetail = `<div class="det" style="position:relative"><div class="dh"><h2 style="flex:none">АОСР — основной</h2>${verLabel}<span class="sp"></span><span class="btn outlined">Предпросмотр</span><span class="btn filled">Сохранить</span></div>
    <div class="code">${code}</div>${V === 'a' ? menuA : ''}</div>`;

  function laptop(screen) {
    const title = screen === 'types' ? 'Типы документов' : 'Шаблоны: АОСР';
    const col = screen === 'types'
      ? `<div class="col"><div class="srch"><span class="search">${S('search')}Поиск типа…</span></div><div class="scroll">${typesList()}</div></div>${typeDetail}`
      : `<div class="col w64"><div class="hd"><span class="t">Шаблоны</span>${ib('add')}</div>${li({ lead: 'perm_media', hl: 'Ассеты типа', tr: '3' })}<div class="scroll" style="border-top:1px solid var(--outline-variant)">${tplList()}</div></div>${tplDetail}`;
    return `<div class="app laptop">${rail}<div class="work"><div class="ph"><h1>${title}</h1><span class="sp"></span>${ib('more_vert')}</div><div class="ld">${col}</div></div></div>`;
  }

  function phone(screen) {
    const head = screen === 'types'
      ? `<div class="tab"><h1>Типы документов</h1>${ib('add')}</div><div class="col"><div class="srch"><span class="search">${S('search')}Поиск типа…</span></div><div class="scroll">${typesList()}</div></div>`
      : `<div class="tab">${ib('arrow_back')}<h1>Шаблоны: АОСР</h1>${ib('add')}</div><div class="col"><div class="scroll">${tplList()}</div></div>`;
    return `<div class="app phone"><div class="work" style="display:flex;flex-direction:column">${head}</div><div class="nb">${navItems()}</div></div>`;
  }

  // Имена файлов хранилище пишет с дефисом, а не с тире.
  const NAMES = { a: 'А — Группа без сворачивания, версии в карточке', b: 'Б — Подзаголовок сворачивает группу', c: 'В — Строка-родитель с отступом' };
  const LEAD = {
    a: `<p><b>MD3 буквально.</b> У списка MD3 нет сворачивания: группа — подзаголовок (<code>title-small</code>, 16 / 16 / 8), прилипает к верху колонки при прокрутке; найти — поиском. Шаблон — <b>одна строка</b> в две строчки: имя и «v3 активная · 3 версии»; версии выбираются в шапке редактора (меню у чипа версии, показано открытым), «Очистить старые» — там же. Выбрана всегда одна строка — шаблон.</p>
      <p>Цена: колонка типов длиннее — свернуть нельзя; правка шапки редактора шаблонов (версия уходит из колонки в карточку) — работа сверх перечня change. Дерево файлов библиотеки (<code>UserLibFileList</code>) остаётся деревом с <code>depth</code> во всех трёх вариантах.</p>`,
    b: `<p><b>Подзаголовок, который сворачивает.</b> Заголовок группы — тот же подзаголовок MD3, но целью 48 с шевроном раскрытия справа (<code>aria-expanded</code>); не выбирается никогда и без заливки. Строки группы — без отступа, как в А. У шаблона «⋮» группы (дублировать, удалить все версии) — у заголовка и видно всегда. Версия — строка 48 (с комментарием — 64), выбрана только она — двойная подсветка сегодняшнего <code>TemplateSidebar</code> снимается.</p>
      <p>Цена: заголовок группы — второй вид цели в списке (часть <code>shared/ui</code> рядом с <code>ListItem</code>); свёрнута группа — выбранная внутри не видна (сегодня открытый тип свою группу раскрывает сам).</p>`,
    c: `<p><b>Строка-родитель.</b> Группа — полноценный ListItem: знак папки 24, подпись <code>body-large</code>, число и шеврон в хвосте; ребёнок — с отступом 16 на уровень (<code>depth</code>, отступление D8 — то же, что у дерева <code>UserLibFileList</code>). Группа не выбирается; свёрнутая группа с выбранной внутри показывает точку <code>primary</code>.</p>
      <p>Цена: родитель и ребёнок одного вида и высоты — различает их только отступ 16 и знак; узкая колонка шаблонов (256) теряет ещё 16 на подпись.</p>`,
  };

  function frames(screen, cap) {
    const th = t => t === 'light' ? 'светлая' : 'тёмная';
    return `<h2>${cap}</h2><div class="frames">` +
      ['light', 'dark'].map(t => `<div class="fr"><span class="lbl">1366×768 · ${th(t)}</span><div class="md3" data-theme="${t}">${laptop(screen)}</div></div>`).join('') +
      `</div><div class="frames" style="margin-top:20px">` +
      ['light', 'dark'].map(t => `<div class="fr"><span class="lbl">375 · ${th(t)}</span><div class="md3" data-theme="${t}">${phone(screen)}</div></div>`).join('') + `</div>`;
  }

  const href = k => encodeURI(NAMES[k].replace(' — ', ' - ') + '.html');
  const nav = ['a', 'b', 'c'].map(k => `<a href="${href(k)}" class="${k === V ? 'cur' : ''}">${NAMES[k].split(' — ')[0]}</a>`).join('');
  document.getElementById('root').innerHTML =
    `<div class="ctl"><b>md3-18 · раскрываемая группа строк</b><span class="nav"><a href="${encodeURI('00 Вопрос.html')}">Вопрос</a>${nav}</span></div>` +
    `<h1>${NAMES[V]}</h1><div class="lead">${LEAD[V]}</div>` +
    frames('types', 'Типы документов — колонка 320') + frames('tpl', 'Редактор шаблонов — колонка 256');
})();
