const VARIANTS = [{"id":"was","kind":"l","sizes":{"inline":11,"button":13,"chip":12,"row":14,"iconBtn":18,"rail":20}},{"id":"a","kind":"o","sizes":{"inline":18,"button":18,"chip":18,"row":18,"iconBtn":18,"rail":20}},{"id":"b","kind":"o","sizes":{"inline":16,"button":16,"chip":16,"row":16,"iconBtn":20,"rail":20}},{"id":"c","kind":"r","sizes":{"inline":16,"button":16,"chip":16,"row":16,"iconBtn":20,"rail":20}}];
function use(id) { return '<use href="#' + id + '"/>'; }
function icon(v, k, place, { filled = false, cls = '' } = {}) {
  const s = v.sizes[place];
  const id = v.kind === 'l' ? 'l-' + k : v.kind + (filled ? 'f' : '') + '-' + k;
  return `<svg class="ic ${cls}" width="${s}" height="${s}" viewBox="0 0 24 24" aria-hidden="true">${use(id)}</svg>`;
}
function spinner(v, place) {
  const s = v.sizes[place];
  if (v.kind === 'l')
    return `<svg class="ic spin" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>`;
  const w = s <= 16 ? 2 : s <= 20 ? 2.5 : 3, r = (s - w) / 2, c = 2 * Math.PI * r;
  return `<svg class="cp" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" role="progressbar" aria-label="Идёт распознавание"><circle cx="${s / 2}" cy="${s / 2}" r="${r}" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-dasharray="${(c * 0.3).toFixed(2)} ${c.toFixed(2)}"/></svg>`;
}
function scenes(v) {
  const I = (k, p, o) => icon(v, k, p, o);
  const pill = (tone, k, text) => `<span class="pill ${tone}">${I(k, 'inline')}${text}</span>`;
  return {
    registry: `
      <div class="reg">
        <div class="reg-row">
          <div class="reg-top"><span class="num">№ 1020</span>${I('scan', 'inline', { cls: 'muted' })}<span class="party">ООО «ЭлектроСнаб»</span><span class="sum">184 320,00 ₽</span></div>
          <div class="reg-pills">${pill('warn', 'warn', 'нет организации')}${pill('danger', 'alarm', 'через 2 дня')}${pill('tonal', 'spark', '3')}${pill('tonal', 'checklist', '2')}</div>
        </div>
        <div class="reg-row active">
          <div class="reg-top"><span class="num">№ 987</span><span class="party">ИП Сидоров А. В.</span><span class="sum">12 900,00 ₽</span></div>
          <div class="reg-pills">${pill('muted', 'clock', '14 нояб.')}${pill('muted', 'history', 'исправлен')}<span class="pill tonal">${spinner(v, 'inline')}распознаётся</span></div>
        </div>
        <div class="reg-row">
          <div class="reg-top"><span class="num">№ 412</span><span class="party">АО «Кабельный завод»</span><span class="sum">2 040,00 ₽</span></div>
          <div class="reg-pills">${pill('muted', 'ban', 'отклонён')}${pill('muted', 'archive', 'в архиве')}</div>
        </div>
      </div>`,
    lines: `
      <div class="lines">
        <div class="ln head"><span>Наименование</span><span class="r">Кол.</span><span class="r">Сумма</span><span></span></div>
        <div class="ln"><span class="nm">Кабель ВВГнг(А)-LS 3×2,5</span><span class="r">250</span><span class="r">31 250,00</span><span class="acts"><button class="ib sm">${I('del', 'row')}</button><button class="ib sm">${I('more', 'row')}</button></span></div>
        <div class="ln"><span class="nm">Автомат ВА47-29 C16</span><span class="r">12</span><span class="r">2 760,00</span><span class="acts"><button class="ib sm">${I('del', 'row')}</button><button class="ib sm">${I('more', 'row')}</button></span></div>
        <div class="bar"><button class="btn filled">${I('save', 'button')}Сохранить</button><button class="btn outlined">${I('undo', 'button')}Отменить</button><button class="btn outlined">${I('done', 'button')}Разобран</button></div>
      </div>`,
    chips: `
      <div class="chips">
        <span class="chip sel">${I('check', 'chip')}Ждут разбора</span>
        <span class="chip">Стройка${I('drop', 'chip')}</span>
        <span class="chip">Поставщик: ЭлектроСнаб<span class="x">${I('close', 'chip')}</span></span>
      </div>`,
    rail: `
      <div class="rail">
        ${[['folder', 'Комплекты', 0], ['receipt', 'Счета', 1], ['truck', 'Накладные', 0], ['cal', 'План', 0], ['settings', 'Настройка', 0]]
          .map(([k, t, on]) => `<div class="ri"><span class="pillnav ${on ? 'on' : ''}">${I(k, 'rail', { filled: !!on && v.kind !== 'l' })}</span><span class="rl ${on ? 'on' : ''}">${t}</span></div>`).join('')}
      </div>`,
    dialog: `
      <div class="dlg">
        <div class="dlg-h"><span>Удалить черновик?</span><button class="ib">${I('close', 'iconBtn')}</button></div>
        <div class="dlg-b">Черновик счёта № 1020 и его 14 строк будут удалены. Файл скана останется в библиотеке.</div>
        <div class="dlg-f"><button class="btn text">${I('copy', 'button')}Сделать копию</button><button class="btn danger">${I('del', 'button')}Удалить</button></div>
      </div>`,
    progress: `
      <div class="prog">
        <button class="btn filled" disabled>${spinner(v, 'button')}Распознаётся…</button>
        <span class="progbig">${v.kind === 'l' ? spinner({ ...v, sizes: { x: 24 } }, 'x') : spinner({ ...v, sizes: { x: 40 } }, 'x')}<span>Загружаем скан</span></span>
      </div>`,
  };
}
const S = Object.fromEntries(VARIANTS.map(v => [v.id, scenes(v)]));
document.querySelectorAll('.frame[data-v]').forEach(f => { f.innerHTML = S[f.dataset.v][f.dataset.k]; });
document.querySelectorAll('.frame.light').forEach(f => { const d = f.cloneNode(true); d.className = 'frame dark'; d.dataset.theme = 'dark'; f.after(d); });
const one = (id) => '<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">' + use(id) + '</svg>';
document.getElementById('cmps').innerHTML = ['warn', 'del', 'save', 'receipt', 'settings', 'cal'].map(k =>
  '<div class="cmp"><div>' + one('l-' + k) + '</div><div>' + one('o-' + k) + one('of-' + k) + '</div><div>' + one('r-' + k) + one('rf-' + k) + '</div></div>').join('');
document.querySelectorAll('.themes button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.themes button').forEach(x => x.classList.toggle('on', x === b));
  document.body.dataset.show = b.dataset.t;
});
