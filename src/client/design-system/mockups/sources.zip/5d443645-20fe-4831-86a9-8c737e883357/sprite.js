(async () => {
  const MAP = {"warn":["triangle-alert","warning"],"alarm":["alarm-clock","alarm"],"spark":["sparkles","star_shine"],"checklist":["list-checks","checklist"],"scan":["scan-line","document_scanner"],"archive":["archive","archive"],"ban":["ban","block"],"history":["history","history"],"check":["check","check"],"clock":["clock","schedule"],"save":["save","save"],"undo":["undo-2","undo"],"done":["circle-check","check_circle"],"del":["trash-2","delete"],"copy":["copy","content_copy"],"close":["x","close"],"drop":["chevron-down","arrow_drop_down"],"more":["ellipsis-vertical","more_vert"],"folder":["folder-open","folder_open"],"receipt":["receipt-text","receipt_long"],"truck":["truck","local_shipping"],"table":["table-2","table"],"settings":["settings","settings"],"cal":["calendar-check","event_available"]};
  const KINDS = ['l', 'o', 'of', 'r', 'rf'];
  const IDS = Object.keys(MAP).flatMap(k => KINDS.map(x => x + '-' + k));
  const L = 'https://cdn.jsdelivr.net/npm/lucide-static@1.21.0/icons/', M = 'https://cdn.jsdelivr.net/npm/@material-symbols/svg-400@0.48.1/';
  const STYLE = { o: 'outlined', r: 'rounded' };
  const parts = await Promise.all(IDS.map(async id => {
    const [kind, k] = id.split('-');
    if (kind === 'l') {
      const t = await (await fetch(L + MAP[k][0] + '.svg')).text();
      const inner = t.slice(t.indexOf('>', t.indexOf('<svg')) + 1, t.lastIndexOf('</svg>'));
      return '<symbol id="' + id + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + inner + '</symbol>';
    }
    const t = await (await fetch(M + STYLE[kind[0]] + '/' + MAP[k][1] + (kind.length > 1 ? '-fill' : '') + '.svg')).text();
    return '<symbol id="' + id + '" viewBox="0 -960 960 960" fill="currentColor"><path d="' + t.match(/ d="([^"]+)"/)[1] + '"/></symbol>';
  }));
  document.getElementById('sprite').innerHTML = parts.join('');
})();
