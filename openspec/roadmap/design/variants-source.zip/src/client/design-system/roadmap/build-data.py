"""Снимок настоящих задач для обсуждения трёх компоновок карты, без изменения OpenSpec."""
import json
import runpy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
roadmap = runpy.run_path(str(ROOT / 'openspec/roadmap/build.py'))
changes = {}
for name, (path, archived) in roadmap['change_dirs']().items():
    title, sections = roadmap['read_tasks'](path / 'tasks.md', name)
    changes[name] = {'title': title, 'sections': sections, 'archived': archived}
marks = json.loads((ROOT / 'openspec/roadmap/claude-marks.json').read_text(encoding='utf-8'))['marks']


def tasks(change, prefixes):
    return [dict(item, key=change + ':' + item['n'])
            for section in changes[change]['sections'] for item in section['items']
            if any(item['n'] == prefix or (not prefix or prefix.endswith('.'))
                   and item['n'].startswith(prefix) for prefix in prefixes)]


def gate(change, prefixes, label, target=None):
    selected = tasks(change, prefixes)
    assert selected, (change, prefixes)
    return {'label': label, 'done': all(item['done'] for item in selected),
            'source': change + '/tasks.md', 'target': target,
            'tasks': [item['n'] for item in selected]}


def row(change, part, title, prefixes, conditions=(), note=''):
    selected = tasks(change, prefixes)
    assert selected, (change, prefixes)
    return {'id': change + '/pr-' + str(part), 'change': change, 'part': part,
            'title': title, 'tasks': selected, 'conditions': list(conditions), 'note': note,
            'archived': changes[change]['archived']}


rows = [
    row('work-17-photos', 1, 'Фото строки под изоляцией', [''], note='Change архивирован.'),
    row('work-18-crew', 1, 'Сервер бригад и единый итог', ['1.'],
        note='Серверный PR #2027 слит. Change остаётся открытым до панели.'),
    row('work-18-crew', 2, 'Панель «Сверка бригад»', ['2.'], [
        gate('work-18-crew', ['1.'], 'Сервер бригад готов', 'work-18-crew/pr-1'),
        gate('work-18-crew', ['2.1'], 'Владелец выбрал макет Р4 или Р4б'),
        gate('work-21-review-ui', ['2.', '3.'], 'Очередь и карточка Work-21 готовы', 'work-21-review-ui/pr-1'),
    ], 'Условия панели — из proposal и design Work-18. Галочки условий читаются из задач.'),
    row('work-19-period-closure', 1, 'Запрет закрытия периода', ['1.'], [],
        'Сервер можно начать. Клиентская задача 1.4 ждёт выбора Р4 в задаче 1.3.'),
    row('work-19-period-closure', 2, 'Закрытие и версии отчёта Work', ['2.'], [
        gate('work-19-period-closure', ['1.1', '1.2'], 'Механизм запрета закрытия готов', 'work-19-period-closure/pr-1'),
    ]),
    row('work-21-review-ui', 1, 'Очередь приёмки', ['2.'], [
        gate('work-21-review-ui', ['1.1', '1.2', '1.3'], 'Макеты Р4 и проверка полей сервера завершены'),
    ]),
    row('work-21-review-ui', 2, 'Карточка отчёта', ['3.'], [
        gate('work-21-review-ui', ['1.1', '1.2', '1.3'], 'Макеты Р4 и проверка полей сервера завершены'),
        gate('work-21-review-ui', ['2.'], 'Очередь приёмки готова', 'work-21-review-ui/pr-1'),
        gate('work-19-period-closure', ['2.'], 'Версии отчётов готовы', 'work-19-period-closure/pr-2'),
    ]),
    row('plan-14-pricelist', 1, 'Прайс-лист и КП без сметы', [''], note='Change архивирован.'),
    row('plan-15-record-print', 1, 'Ядро печати записей модулей', ['1.'], [
        gate('plan-15-record-print', ['0.1'], 'Ответ владельца В-13 зафиксирован'),
    ]),
    row('plan-15-record-print', 2, 'Печатная форма КП', ['2.'], [
        gate('plan-15-record-print', ['1.'], 'Механизм печати готов', 'plan-15-record-print/pr-1'),
    ]),
    row('plan-18-calendars', 1, 'Сервер календарей', ['1.'], [
        gate('plan-18-calendars', ['0.'], 'Входные условия календарей проверены'),
    ]),
    row('plan-18-calendars', 2, 'Экраны календарей', ['2.'], [
        gate('plan-18-calendars', ['1.'], 'Сервер календарей готов', 'plan-18-calendars/pr-1'),
        gate('plan-18-calendars', ['2.1'], 'Владелец выбрал макеты П4'),
    ]),
]

payload = {'rows': rows, 'marks': marks, 'markCount': len(marks), 'date': '22.11.2026'}
(HERE / 'data.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f'{len(rows)} вех; {len(marks)} исторических дат Claude')
