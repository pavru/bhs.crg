import { createRoot } from 'react-dom/client';
import { useState } from 'react';
import { Button, IconButton } from '@/shared/ui/Button';
import { Checkbox } from '@/shared/ui/Checkbox';
import { SearchInput } from '@/shared/ui/SearchInput';
import { StatusText } from '@/shared/ui/StatusText';
import { Chip } from '@/shared/ui/Chip';
import { DataGrid, type DataGridColumn } from '@/shared/ui/DataGrid';
import { DarkMode, LightMode } from '@/shared/ui/icons';
import { useTheme } from '@/shared/ui/themeContext';
import { StoryProviders } from '../story-providers';
import data from './data.json';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '../catalog.css';
import './roadmap.css';

type Row = typeof data.rows[number];
type State = 'done' | 'ready' | 'waiting';
const stateOf = (row: Row): State => row.tasks.every(t => t.done) ? 'done'
  : row.conditions.some(c => !c.done) ? 'waiting' : 'ready';
const labels = { done: 'Задачи выполнены', ready: 'Можно начать', waiting: 'Ожидает условий' };
const tones = { done: 'success', ready: 'primary', waiting: 'warning' } as const;
const variants = [
  { id: 'a', label: 'А · Вехи в ведомости', title: 'Вехи внутри change',
    description: 'Сохраняем привычный порядок карты. Под каждым change видны его PR и причины ожидания.',
    tradeoff: 'Удобно сверять весь этап. Для выбора доступной работы нужен фильтр «Можно начать».' },
  { id: 'b', label: 'Б · Очередь работ', title: 'Сначала доступная работа',
    description: 'Два потока Work и Plan. В начале каждого — доступные вехи, затем ожидающие и завершённые.',
    tradeoff: 'Быстро выбираем следующую работу. Исходный порядок зонтика уступает порядку готовности.' },
  { id: 'c', label: 'В · Зависимости', title: 'Вехи и цепочка условий',
    description: 'Выбираем PR в списке. Справа — его задачи, условия старта и связанные вехи.',
    tradeoff: 'Удобно разбирать блокировки. Для обзора всех условий нужно последовательно выбирать PR.' },
];
const params = new URLSearchParams(location.search);
const variant = variants.find(v => v.id === params.get('variant')) ?? variants[0];
const marks: Record<string, string> = data.marks;
const format = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short' });

function History({ row }: { row: Row }) {
  const history = row.tasks.filter(t => marks[t.key]);
  return history.length ? <span className="rm-history">Claude: {history.length} отметок · последняя{' '}
    <time dateTime={history.map(t => marks[t.key]).sort().at(-1)}>{format.format(new Date(history.map(t => marks[t.key]).sort().at(-1)!))}</time></span> : null;
}

function StateLabel({ row }: { row: Row }) {
  const state = stateOf(row);
  return <StatusText tone={tones[state]}>{labels[state]}</StatusText>;
}

function Conditions({ row, go }: { row: Row; go: (id: string) => void }) {
  return <div className="rm-conditions"><h4>Условия старта</h4>{row.conditions.length === 0
    ? <p className="rm-secondary">{stateOf(row) === 'done' ? 'Задачи этой вехи выполнены.' : 'В показанном объёме можно начать.'}</p>
    : <ul>{row.conditions.map((c, i) => <li key={i}><div className="rm-condition-title"><StatusText tone={c.done ? 'success' : 'warning'}>{c.done ? 'Выполнено' : 'Ожидает'}</StatusText><span>{c.label}</span></div>
      <div className="rm-source">{c.source} · {c.tasks.join(', ')}</div>
      {c.target && <Button variant="text" onClick={() => go(c.target!)}>Открыть связанную веху</Button>}</li>)}</ul>}
    {row.note && <p className="rm-note">{row.note}</p>}
  </div>;
}

function Tasks({ row }: { row: Row }) {
  return <details className="rm-tasks"><summary>Задачи OpenSpec ({row.tasks.filter(t => t.done).length}/{row.tasks.length})</summary>
    <div>{row.tasks.map(t => <div key={t.key} className="rm-task"><Checkbox checked={t.done} onChange={() => {}} disabled aria-label={'Статус задачи ' + t.n} />
      <div><span className="rm-task-number">{t.n}</span> {t.text}
        {marks[t.key] && <time className="rm-history" dateTime={marks[t.key]}>Claude · {format.format(new Date(marks[t.key]))}</time>}
      </div></div>)}</div></details>;
}

function Milestone({ row, go, compact = false }: { row: Row; go: (id: string) => void; compact?: boolean }) {
  return <article className={'rm-milestone' + (compact ? ' rm-compact' : '')} id={row.id.replace('/', '-')}>
    <div className="rm-milestone-head"><div><span className="rm-pr">PR {row.part}</span><h3>{row.title}</h3></div><StateLabel row={row} /></div>
    <div className="rm-progress"><span>{row.tasks.filter(t => t.done).length}/{row.tasks.length} задач</span><History row={row} />
      {stateOf(row) === 'done' && <span className="rm-secondary">{row.archived ? 'Change архивирован' : 'Change ещё открыт'}</span>}</div>
    <Conditions row={row} go={go} /><Tasks row={row} />
  </article>;
}

function App() {
  const { resolvedTheme, setTheme } = useTheme();
  const [query, setQuery] = useState(params.get('q') ?? '');
  const [filter, setFilter] = useState('all');
  const [module, setModule] = useState('all');
  const [selectedId, setSelectedId] = useState('work-18-crew/pr-2');
  const [revision, setRevision] = useState(0);
  const selected = data.rows.find(r => r.id === selectedId)!;
  const shown = data.rows.filter(r => (module === 'all' || r.change.startsWith(module))
    && (filter === 'all' || stateOf(r) === filter)
    && (!query || JSON.stringify(r).toLowerCase().includes(query.toLowerCase())));
  const go = (id: string) => {
    setSelectedId(id); setQuery(''); setFilter('all'); setModule('all'); setRevision(n => n + 1);
    setTimeout(() => document.getElementById(variant.id === 'c' ? 'rm-detail' : id.replace('/', '-'))?.scrollIntoView({ block: 'center', behavior: 'instant' }), 0);
  };
  const columns: DataGridColumn<Row>[] = [
    { key: 'title', label: 'Веха PR', rowHeader: true, wrap: true, interactive: true,
      cell: r => <div className="rm-grid-title"><Button variant="text" multiline onClick={() => go(r.id)} aria-pressed={r.id === selectedId}>{r.title}</Button><span className="rm-source">{r.change} / PR {r.part}</span></div> },
    { key: 'state', label: 'Готовность', cell: r => <StateLabel row={r} /> },
    { key: 'count', label: 'Задачи', cell: r => `${r.tasks.filter(t => t.done).length}/${r.tasks.length}` },
  ];
  return <div className="rm-root">
    <header className="rm-review"><div><strong>Карта работ BHS.CRG</strong><p>Три макета для выбора · {data.date}</p></div>
      <nav aria-label="Варианты карты">{variants.map(v => <Button key={v.id} variant={variant.id === v.id ? 'tonal' : 'text'}
        aria-current={variant.id === v.id ? 'page' : undefined} onClick={() => { const u = new URL(location.href); u.searchParams.set('variant', v.id); u.searchParams.delete('q'); location.assign(u); }}>{v.label}</Button>)}</nav>
      <IconButton icon={resolvedTheme === 'dark' ? LightMode : DarkMode} label="Переключить тему" onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')} />
    </header>
    <section className="rm-concept"><h1>{variant.title}</h1><p>{variant.description}</p><p className="rm-secondary">{variant.tradeoff}</p></section>
    <main className="rm-main">
      <div className="rm-heading"><div><h2>Дорожная карта этапов 3–4</h2><p className="rm-secondary">По одной работе Work и Plan параллельно. Work — приоритет.</p></div><span className="rm-secondary">Галочки — из OpenSpec · {data.markCount} дат Claude сохранены</span></div>
      <div className="rm-toolbar"><SearchInput value={query} onChange={setQuery} placeholder="Change, веха или условие" />
        <div className="rm-filters" role="group" aria-label="Готовность вех">{[['all', 'Все вехи'], ['ready', 'Можно начать'], ['waiting', 'Ожидают'], ['done', 'Выполнены']].map(([id, label]) => <Chip key={id} selected={filter === id} onClick={() => setFilter(id)}>{label}</Chip>)}</div>
        <div className="rm-filters" role="group" aria-label="Модуль">{[['all', 'Work и Plan'], ['work', 'Work'], ['plan', 'Plan']].map(([id, label]) => <Chip key={id} selected={module === id} onClick={() => setModule(id)}>{label}</Chip>)}</div>
      </div>
      {shown.length === 0 && <p className="rm-empty">По выбранным условиям вех нет. Измените поиск или отбор.</p>}
      {variant.id === 'a' && <div className="rm-ledger">{[...new Set(shown.map(r => r.change))].map(change => {
        const rows = shown.filter(r => r.change === change);
        return <section key={change} className="rm-change"><div className="rm-change-heading"><h2>{change}</h2><span className="rm-secondary">{rows.filter(r => stateOf(r) === 'done').length}/{rows.length} показанных вех выполнено</span></div>
          {rows.map(row => <Milestone key={row.id + revision} row={row} go={go} />)}</section>;
      })}</div>}
      {variant.id === 'b' && <div className="rm-board">{['work', 'plan'].filter(m => module === 'all' || module === m).map(m => <section className="rm-lane" key={m}>
        <div className="rm-lane-title"><h2>{m === 'work' ? 'Work' : 'Plan'}</h2><span className="rm-secondary">{m === 'work' ? 'Приоритетный поток' : 'Параллельный поток'}</span></div>
        {(['ready', 'waiting', 'done'] as const).map(state => {
          const rows = shown.filter(r => r.change.startsWith(m) && stateOf(r) === state);
          return rows.length > 0 && <section className="rm-state-group" key={state}><h3>{labels[state]} <span className="rm-secondary">{rows.length}</span></h3>{rows.map(row => <div key={row.id + revision}><p className="rm-change-code">{row.change}</p><Milestone row={row} go={go} compact /></div>)}</section>;
        })}</section>)}</div>}
      {variant.id === 'c' && <div className="rm-master-detail"><div className="rm-master"><DataGrid columns={columns} rows={shown} rowKey={r => r.id} onRowOpen={r => go(r.id)}
        emphasized={r => r.id === selectedId} state={shown.length ? undefined : 'filtered-out'} /></div>
        <aside className="rm-detail" id="rm-detail" key={selectedId + revision}><p className="rm-change-code">{selected.change}</p><Milestone row={selected} go={go} />
          <section className="rm-dependents"><h4>Кому нужна эта веха</h4>{data.rows.filter(r => r.conditions.some(c => c.target === selected.id)).map(r => <Button key={r.id} variant="text" multiline onClick={() => go(r.id)}>{r.change} / PR {r.part} · {r.title}</Button>)}
            {!data.rows.some(r => r.conditions.some(c => c.target === selected.id)) && <p className="rm-secondary">В показанном фрагменте зависимых вех нет.</p>}</section>
        </aside></div>}
    </main>
    <footer className="rm-footer">Макет на настоящем снимке OpenSpec, а не обновлённая рабочая карта. Показаны 12 вех для обсуждения компоновки.
      Статусы вычислены из tasks.md; дата Claude — история отметки, она не меняет статус. Условия перечислены явно по proposal/design.
      Выполнение задач PR и архивация всего change показаны отдельно. Проверки change остаются общими и не дублируются как отдельный PR.</footer>
  </div>;
}

createRoot(document.getElementById('root')!).render(<StoryProviders theme={params.get('theme') === 'dark' ? 'dark' : 'light'} component="Roadmap"><App /></StoryProviders>);
